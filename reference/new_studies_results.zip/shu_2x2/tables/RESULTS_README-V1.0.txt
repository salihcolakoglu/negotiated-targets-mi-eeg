SHU FBCNET COMPARISON: COMPLETE EXPLORATORY RESULTS
15 target people; five neural random starts averaged per person; classical one deterministic fit.
50 first-day training trials and20 reserved first-day calibration trials. All later-day trials retained.
A: EEGNet/CE; B: EEGNet/Walsh; C: FBCNet/CE; D: FBCNet/Walsh.
Day2 accuracy contrasts below form exactly one five-test Holm family.
Intervals are pointwise95% paired-person t intervals, not multiplicity-adjusted intervals.

DAY2 METHOD TABLE: accuracy(%), NLL, ECE15, summed Brier (raw -> calibrated)
A: accuracy 51.5522; NLL 2.549974 -> 0.906772; ECE15 0.405652 -> 0.163328; Brier 0.825834 -> 0.568662
B: accuracy 50.9452; NLL 17.972924 -> 1.205181; ECE15 0.484525 -> 0.193962; Brier 0.959393 -> 0.587678
C: accuracy 52.5583; NLL 0.980960 -> 0.726949; ECE15 0.271658 -> 0.098904; Brier 0.652601 -> 0.519573
D: accuracy 52.2908; NLL 4.122216 -> 0.819134; ECE15 0.446451 -> 0.124671; Brier 0.892225 -> 0.547084
SINGLE_CSP_LDA: accuracy 50.7089; NLL 1.611439 -> 0.770945; ECE15 0.342882 -> 0.131585; Brier 0.763694 -> 0.552330
BANK_CSP_LDA: accuracy 49.2927; NLL 22.022413 -> 2.706604; ECE15 0.487850 -> 0.330236; Brier 0.977920 -> 0.769442

DAY2 NATIVE-ACCURACY CONTRASTS (percentage points)
C-A: delta 1.006098; pointwise95%CI [-1.698736, 3.710931]; Holm5 p=1; n=15
D-B: delta 1.345605; pointwise95%CI [-1.269607, 3.960818]; Holm5 p=1; n=15
B-A: delta -0.607009; pointwise95%CI [-2.365216, 1.151199]; Holm5 p=1; n=15
D-C: delta -0.267501; pointwise95%CI [-1.547215, 1.012213]; Holm5 p=1; n=15
(D-C)-(B-A): delta 0.339508; pointwise95%CI [-1.472654, 2.151669]; Holm5 p=1; n=15

SHU was previously examined: these are exploratory development results, not untouched external validation.
Temperature affects confidence only and does not change retained native decisions.
The fixed10-person source pool and small20-trial calibration reserve limit generalization claims.
IEEE Access submission files were hash-verified unchanged.
