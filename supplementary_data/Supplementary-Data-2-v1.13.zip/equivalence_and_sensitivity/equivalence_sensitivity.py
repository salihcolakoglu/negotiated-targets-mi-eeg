#!/usr/bin/env python3
"""Post hoc equivalence (TOST) and sensitivity analysis of the planned accuracy contrasts (manuscript v1.9).

Nothing is trained or re-evaluated here. The script reads the participant-level tables that are already part of
the supplementary data and computes, for every planned accuracy contrast of the five statistical families:

  * the paired statistics that the manuscript reports (mean difference, SD, d_z, 95% t interval, two-sided p,
    Holm-adjusted p within the family), as a cross-check that the same data are used;
  * two one-sided paired t tests (TOST) against the bounds -1 and +1 percentage point, the 90% t interval that
    corresponds to them, the TOST p value (the larger of the two one-sided p values) and its Holm adjustment
    within the same family;
  * the sensitivity of each family: the standardized paired effect d_z that a two-sided paired t test detects
    with 80% power at alpha = 0.05 and at alpha = 0.05 / m (the first Holm step for m tests), expressed in
    percentage points with the observed SD of each paired difference;
  * the number of participants at which the observed d_z of the cumulative-minus-fixed contrasts would reach
    80% power.

The bound of one percentage point is the operational benefit criterion written in the plans of Experiments 1
and 2. It was not fixed as an equivalence bound for any experiment in advance: this analysis is post hoc.

Usage:
  equivalence_sensitivity.py E1_E2_DIFFERENCES.csv LEE_PARTICIPANT_SEED_AVERAGES.csv S1W5_PARTICIPANT_MEANS.csv OUT.json
"""
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy import stats

BOUND = 1.0            # percentage points
ALPHA = 0.05
POWER = 0.80


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def holm(pvalues):
    """Holm step-down adjusted p values, in the order given."""
    m = len(pvalues)
    order = sorted(range(m), key=lambda i: pvalues[i])
    adjusted = [0.0] * m
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * pvalues[i])
        adjusted[i] = min(1.0, running)
    return adjusted


def paired(differences):
    d = np.asarray(differences, dtype=np.float64)
    n = d.size
    mean = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    df = n - 1
    t = mean / se
    p = float(2.0 * stats.t.sf(abs(t), df))
    t95 = float(stats.t.ppf(0.975, df))
    t90 = float(stats.t.ppf(0.95, df))
    p_lower = float(stats.t.sf((mean + BOUND) / se, df))      # H0: difference <= -BOUND
    p_upper = float(stats.t.cdf((mean - BOUND) / se, df))     # H0: difference >= +BOUND
    return dict(n=n, df=df, mean_difference_pp=mean, sd_difference_pp=sd, se_pp=se, d_z=mean / sd, t=t,
                p_two_sided=p, ci95_pp=[mean - t95 * se, mean + t95 * se],
                ci90_pp=[mean - t90 * se, mean + t90 * se],
                tost_p_lower_bound=p_lower, tost_p_upper_bound=p_upper, tost_p=max(p_lower, p_upper),
                ci90_within_bounds=bool(mean - t90 * se > -BOUND and mean + t90 * se < BOUND))


def power_two_sided(dz, alpha, n):
    df = n - 1
    nc = dz * math.sqrt(n)
    crit = float(stats.t.ppf(1.0 - alpha / 2.0, df))
    upper = float(stats.nct.sf(crit, df, nc))
    lower = float(stats.nct.cdf(-crit, df, nc))
    if not math.isfinite(lower):
        lower = 0.0                                           # numerically zero for a positive effect
    return upper + lower


def detectable_dz(alpha, n):
    lo, hi = 0.0, 3.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if power_two_sided(mid, alpha, n) < POWER:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def participants_needed(dz, alpha):
    n = 3
    while power_two_sided(abs(dz), alpha, n) < POWER:
        n += 1
        if n > 100000:
            return None
    return n


def main():
    e12_path, lee_path, s1w5_path, out_path = sys.argv[1:5]

    # ---- Experiments 1 and 2: the published participant differences (percentage points) ---------------------
    e12 = {}
    for row in csv.DictReader(open(e12_path, newline="", encoding="utf-8")):
        key = (row["experiment"], row["condition_a"], row["condition_b"])
        e12.setdefault(key, {})[(row["dataset"], int(row["subject"]))] = float(row["difference_pp"])

    def e12_diff(experiment, a, b):
        values = e12[(experiment, a, b)]
        assert len(values) == 32, (experiment, a, b, len(values))
        return [values[k] for k in sorted(values)]

    # ---- Experiment 3: participant means (five seeds) of accuracy, as proportions ------------------------------
    lee = {}
    for row in csv.DictReader(open(lee_path, newline="", encoding="utf-8")):
        assert int(row["seeds"]) == 5
        lee.setdefault(row["condition"], {})[int(row["subject"])] = 100.0 * float(row["accuracy"])
    subjects = sorted(lee["W0"])
    assert len(subjects) == 54 and all(sorted(lee[c]) == subjects for c in lee)

    # ---- W4 and S1/W5 controls: participant means of the S1/W5 result file (S0, S1, W0, W1, W4, W5) -------------
    ctl = {}
    for row in csv.DictReader(open(s1w5_path, newline="", encoding="utf-8")):
        ctl.setdefault(row["condition"], {})[int(row["subject"])] = 100.0 * float(row["accuracy"])
    assert all(sorted(ctl[c]) == subjects for c in ctl), "participants differ between the files"
    # the stored reference conditions of the control are the Experiment 3 fits: the two files must agree
    reuse = {c: max(abs(ctl[c][s] - lee[c][s]) for s in subjects) for c in ("S0", "W0", "W1")}
    assert max(reuse.values()) < 1e-9, reuse

    def col(table, c):
        return np.array([table[c][s] for s in subjects], dtype=np.float64)

    families = [
        dict(family="Experiment 1", n_expected=32, planned_primary="C3-C0", contrasts=[
            ("C1-C0", "cumulative minus fixed", e12_diff("E1", "C1", "C0")),
            ("C3-C0", "anchored, gated minus fixed (primary)", e12_diff("E1", "C3", "C0")),
            ("C3-C1", "anchored, gated minus cumulative", e12_diff("E1", "C3", "C1")),
            ("C2-C4", "anchored, ungated minus bit smoothing", e12_diff("E1", "C2", "C4"))]),
        dict(family="Experiment 2", n_expected=32, planned_primary="W2-W0", contrasts=[
            ("W1-W0", "cumulative minus fixed", e12_diff("E2", "W1", "W0")),
            ("W2-W0", "anchored, gated minus fixed (primary)", e12_diff("E2", "W2", "W0")),
            ("W2-W1", "anchored, gated minus cumulative", e12_diff("E2", "W2", "W1")),
            ("W2-W3", "anchored, gated minus class smoothing", e12_diff("E2", "W2", "W3"))]),
        dict(family="Experiment 3", n_expected=54, planned_primary="W2-W0", contrasts=[
            ("W2-W0", "anchored, gated minus fixed (primary)", col(lee, "W2") - col(lee, "W0")),
            ("W1-W0", "cumulative minus fixed", col(lee, "W1") - col(lee, "W0")),
            ("W2-W1", "anchored, gated minus cumulative", col(lee, "W2") - col(lee, "W1")),
            ("W2-W3", "anchored, gated minus class smoothing", col(lee, "W2") - col(lee, "W3")),
            ("W0-S0", "fixed Walsh minus ordinary outputs", col(lee, "W0") - col(lee, "S0"))]),
        dict(family="W4 control", n_expected=54, planned_primary="W2-W4", contrasts=[
            ("W2-W4", "gated minus ungated anchoring (primary)", col(lee, "W2") - col(ctl, "W4")),
            ("W4-W1", "ungated anchoring minus cumulative", col(ctl, "W4") - col(lee, "W1"))]),
        dict(family="S1/W5 control", n_expected=54, planned_primary=None, contrasts=[
            ("S1-S0", "cumulative minus hard labels, ordinary outputs", col(ctl, "S1") - col(ctl, "S0")),
            ("(W1-W0)-(S1-S0)", "interaction of negotiation with the output formulation",
             (col(ctl, "W1") - col(ctl, "W0")) - (col(ctl, "S1") - col(ctl, "S0"))),
            ("W1-W5", "cumulative minus share-matched anchored", col(ctl, "W1") - col(ctl, "W5")),
            ("W5-W4", "share-matched minus original anchored", col(ctl, "W5") - col(ctl, "W4"))]),
    ]
    descriptive = [("Experiment 2 (descriptive, outside the family)", "W0-S0", "fixed Walsh minus ordinary outputs",
                    e12_diff("E2", "W0", "S0"))]

    result = dict(
        analysis="post hoc equivalence (two one-sided paired t tests) and sensitivity of the planned accuracy contrasts",
        equivalence_bounds_pp=[-BOUND, BOUND], alpha=ALPHA, power_for_sensitivity=POWER,
        note="The bound is the one-percentage-point operational benefit criterion of the plans of Experiments 1 and 2. "
             "It was not fixed as an equivalence bound in advance for any experiment; the analysis is post hoc.",
        inputs={Path(p).name: sha(p) for p in (e12_path, lee_path, s1w5_path)},
        reference_conditions_reused_max_abs_difference_pp=reuse, families=[], descriptive=[])
    for family in families:
        rows = []
        for label, description, d in family["contrasts"]:
            row = dict(contrast=label, description=description, **paired(d))
            assert row["n"] == family["n_expected"]
            rows.append(row)
        m = len(rows)
        for row, p_adj, tost_adj in zip(rows, holm([r["p_two_sided"] for r in rows]), holm([r["tost_p"] for r in rows])):
            row["p_holm_in_family"] = p_adj
            row["tost_p_holm_in_family"] = tost_adj
            row["equivalent_within_bounds_after_holm"] = bool(tost_adj < ALPHA)
        n = family["n_expected"]
        sens = dict(n=n, tests_in_family=m)
        for name, alpha in (("alpha_0.05", ALPHA), ("alpha_first_holm_step", ALPHA / m)):
            dz = detectable_dz(alpha, n)
            sens[name] = dict(alpha=alpha, detectable_d_z=dz,
                              detectable_difference_pp={r["contrast"]: dz * r["sd_difference_pp"] for r in rows})
        result["families"].append(dict(family=family["family"], planned_primary=family["planned_primary"],
                                       contrasts=rows, sensitivity=sens))
    for label_family, label, description, d in descriptive:
        result["descriptive"].append(dict(family=label_family, contrast=label, description=description, **paired(d)))

    needed = {}
    for family in result["families"]:
        for row in family["contrasts"]:
            if row["contrast"] in ("C1-C0", "W1-W0"):
                m = len(family["contrasts"])
                needed["%s %s" % (family["family"], row["contrast"])] = dict(
                    observed_d_z=row["d_z"],
                    participants_for_80pct_power_alpha_0_05=participants_needed(row["d_z"], ALPHA),
                    participants_for_80pct_power_first_holm_step=participants_needed(row["d_z"], ALPHA / m),
                    first_holm_step_alpha=ALPHA / m)
    result["participants_needed_for_observed_cumulative_effect"] = needed
    Path(out_path).write_text(json.dumps(result, indent=1) + "\n", encoding="utf-8")

    for family in result["families"]:
        print(family["family"], "(n=%d)" % family["sensitivity"]["n"])
        for r in family["contrasts"]:
            print("  %-18s diff %+.3f  95%% CI [%+.3f, %+.3f]  p %.4f  Holm %.3f | 90%% CI [%+.2f, %+.2f]  TOST p %.3g  Holm %.3g  %s"
                  % (r["contrast"], r["mean_difference_pp"], r["ci95_pp"][0], r["ci95_pp"][1], r["p_two_sided"],
                     r["p_holm_in_family"], r["ci90_pp"][0], r["ci90_pp"][1], r["tost_p"], r["tost_p_holm_in_family"],
                     "within" if r["ci90_within_bounds"] else "NOT within"))
        s = family["sensitivity"]
        for name in ("alpha_0.05", "alpha_first_holm_step"):
            print("  sensitivity %-22s alpha %.4f  d_z %.3f  ->  %s" % (name, s[name]["alpha"], s[name]["detectable_d_z"],
                  ", ".join("%s %.2f pp" % (k, v) for k, v in s[name]["detectable_difference_pp"].items())))
    for r in result["descriptive"]:
        print(r["family"], r["contrast"], "diff %+.3f  90%% CI [%+.2f, %+.2f]  TOST p %.3g" % (
            r["mean_difference_pp"], r["ci90_pp"][0], r["ci90_pp"][1], r["tost_p"]))
    print(json.dumps(needed, indent=1))


if __name__ == "__main__":
    main()
