#!/usr/bin/env python3
"""Sensitivity of the Lee2019 80/20 calibration control to temperatures that reached a boundary (manuscript v1.9).

Nothing is fitted here. The script reads two tables of public software release v2.2.0
(reference/new_studies_results.zip, folder lee_calibration80_20/tables): temperatures.csv (one fitted
class-score temperature per participant, condition and seed, with a flag for a boundary solution) and
run_metrics.csv (stable NLL, clipped NLL, ECE and summed Brier score of every fit, raw and scaled).

For each condition it reports the calibrated-minus-raw change of every measure
  (a) over all 270 fits (cross-check against the published participant-level means),
  (b) over the fits whose temperature lies strictly inside the interval [0.05, 100],
  (c) over the fits at the lower bound and (d) over the fits at the upper bound,
each as the mean over participants of the participant's mean over the fits concerned.

Usage: calibration_boundary_sensitivity.py TEMPERATURES.csv RUN_METRICS.csv OUT.json
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

MEASURES = (("nll_unclipped", "stable NLL"), ("nll_legacy_clipped", "clipped NLL"),
            ("ece_15_equal_width", "ECE"), ("brier_sum_over_classes", "Brier"))
LOW, HIGH = 0.05, 100.0


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    t_path, m_path, out_path = sys.argv[1:4]
    kind = {}
    for row in csv.DictReader(open(t_path, newline="", encoding="utf-8")):
        key = (int(row["subject"]), row["condition"], int(row["seed"]))
        T = float(row["temperature"])
        where = "lower" if abs(T - LOW) < 1e-12 else "upper" if abs(T - HIGH) < 1e-12 else "inside"
        assert (row["boundary"] == "True") == (where != "inside"), row
        kind[key] = (where, T)
    values = {}
    for row in csv.DictReader(open(m_path, newline="", encoding="utf-8")):
        key = (int(row["subject"]), row["condition"], int(row["seed"]))
        values.setdefault(key, {})[row["mode"]] = {m: float(row[m]) for m, _ in MEASURES}
    assert set(values) == set(kind) and len(kind) == 1350
    out = dict(analysis="calibration control: change (scaled minus raw) by where the fitted temperature lies",
               temperature_interval=[LOW, HIGH], inputs={Path(p).name: sha(p) for p in (t_path, m_path)},
               note="Each entry is the mean over participants of the participant's mean over the fits concerned; "
                    "participants without such a fit do not enter that entry. Descriptive; no test.",
               conditions={})
    for condition in ("S0", "W0", "W1", "W2", "W3"):
        keys = sorted(k for k in kind if k[1] == condition)
        entry = dict(fits=len(keys), counts={w: sum(1 for k in keys if kind[k][0] == w) for w in ("inside", "lower", "upper")},
                     median_temperature_all=float(np.median([kind[k][1] for k in keys])),
                     median_temperature_inside=float(np.median([kind[k][1] for k in keys if kind[k][0] == "inside"])))
        for subset in ("all", "inside", "lower", "upper"):
            chosen = [k for k in keys if subset == "all" or kind[k][0] == subset]
            by_participant = {}
            for k in chosen:
                by_participant.setdefault(k[0], []).append(k)
            block = dict(fits=len(chosen), participants=len(by_participant))
            for m, label in MEASURES:
                raw = [np.mean([values[k]["raw"][m] for k in ks]) for ks in by_participant.values()]
                cal = [np.mean([values[k]["calibrated"][m] for k in ks]) for ks in by_participant.values()]
                diff = np.array(cal) - np.array(raw)
                block[label] = dict(raw=float(np.mean(raw)), scaled=float(np.mean(cal)), change=float(diff.mean()),
                                    participants_with_decrease=int((diff < 0).sum()),
                                    participants_with_increase=int((diff > 0).sum()))
            entry[subset] = block
        out["conditions"][condition] = entry
    Path(out_path).write_text(json.dumps(out, indent=1) + "\n", encoding="utf-8")
    for condition, e in out["conditions"].items():
        print(condition, e["counts"], "median T all %.2f inside %.2f" % (e["median_temperature_all"], e["median_temperature_inside"]))
        for subset in ("all", "inside", "lower", "upper"):
            b = e[subset]
            print("   %-6s fits %3d participants %2d | " % (subset, b["fits"], b["participants"]) + " | ".join(
                "%s %.3f -> %.3f (%+.3f; -%d/+%d)" % (label, b[label]["raw"], b[label]["scaled"], b[label]["change"],
                                                     b[label]["participants_with_decrease"], b[label]["participants_with_increase"])
                for _, label in MEASURES))


if __name__ == "__main__":
    main()
