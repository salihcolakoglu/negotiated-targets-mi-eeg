POST HOC EQUIVALENCE AND SENSITIVITY ANALYSIS, AND THE CALIBRATION CONTROL BY TEMPERATURE BOUNDARY
(added in manuscript version 1.9; Supplementary Section S17 and Supplementary Table S11c)

These analyses were added on 15 November 2026, after all results were known. Nothing was
fitted or evaluated again: the scripts read tables that the original analyses had written.
The analyses are exploratory. The equivalence bound of one percentage point was not fixed
in advance for any experiment.


FILES

equivalence_sensitivity.py
    For every planned accuracy contrast of the five statistical families: the paired
    statistics that the manuscript reports, two one-sided paired t tests against bounds of
    -1 and +1 percentage point with the 90% t interval, Holm adjustment within the family,
    and the smallest effect that a two-sided paired t test detects with 80% power.
EQUIVALENCE_SENSITIVITY-v1.9.json
    Its result (manuscript Table 8; Supplementary Tables S17a and S17b).
cross_check_published.py
    Compares the paired statistics that the first script recomputes (mean difference, SD,
    d_z, t, p, 95% interval, Holm-adjusted p) with the result files of the original
    analyses.
CROSS_CHECK_PUBLISHED-v1.9.json
    Its result: 154 values of 20 contrasts agree; the largest absolute difference is
    9.5e-15.
calibration_boundary_sensitivity.py
    Splits the fits of the Lee2019 80/20 calibration control by where the fitted temperature
    lies (inside the interval, at the lower bound, at the upper bound).
CALIBRATION_BOUNDARY_SENSITIVITY-v1.9.json
    Its result (Supplementary Table S11c).
inputs/
    Copies of the nine input files, so that this folder can be checked on its own.


INPUT FILES (copies)

  e1_e2_paired_participant_differences_verified_v4.csv
      participant-level paired differences of Experiments 1 and 2
      from: Supplementary-Data-1-v1.13.zip, legacy/Analysis_Data_v4.0/
      SHA-256 836ce09c0b45e467ba9a2d994a420b9b000298fb3492f24c6ec89dfa2f4fccef
  verified_e1_e2_tables_v4.json
      result tables of Experiments 1 and 2 (original analysis)
      from: Supplementary-Data-1-v1.13.zip, legacy/Analysis_Data_v4.0/
      SHA-256 1aaef096a2a2870d59233d6484328f474a6e9edc82559ebde5fcf725e6a60f54
  participant_seed_averages.csv
      participant seed averages of Experiment 3
      from: Supplementary-Data-1-v1.13.zip, lee2019/final_analysis/
      SHA-256 39a69f7d5c51985c3de5c492d94a7944718905cb964cd0f57b42027643498600
  five_paired_contrasts_holm.csv
      the five contrasts of Experiment 3 (original analysis)
      from: Supplementary-Data-1-v1.13.zip, lee2019/final_analysis/
      SHA-256 72bec700fd7e6023a20de188b0e8b4c16619204f4b09157da15f169d077430af
  participant_means.csv
      participant means of S0, S1, W0, W1, W4 and W5
      from: this archive, s1_w5_control/data/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/final_analysis/
      SHA-256 ab32e50cfb45aaccea3392dbbfdf00c810f4d210bad57eca75d70323052c1cbc
  four_contrasts_holm.json
      the four contrasts of the S1/W5 control (original analysis)
      from: this archive, s1_w5_control/data/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/final_analysis/
      SHA-256 d5956b43583081e5b51a8db0d923b79918a22694b999b95e3aa7d81c77c7435e
  two_contrasts_holm.json
      the two contrasts of the W4 control (original analysis)
      from: public release v2.2.0, reference/lee_w4_results.zip, tables/
      SHA-256 53cb4cd62dcc8cc48e09af83fd346e164d511f0b6ebb067267420ebf8a5895fb
  temperatures.csv
      fitted temperature of each of the 1,350 calibration-control models
      from: public release v2.2.0, reference/new_studies_results.zip, lee_calibration80_20/tables/
      SHA-256 6214cae70dee174d27e42600d00a57fb4c349e7243fee6f3022711de50e3acf2
  run_metrics.csv
      raw and scaled probability measures of the same models
      from: public release v2.2.0, reference/new_studies_results.zip, lee_calibration80_20/tables/
      SHA-256 2d4a680d6f7da7215416e161b0e5e5fc43884565c1a3f239efabfd38ba7ca6af


HOW TO REPEAT THE ANALYSES

Python 3 with NumPy and SciPy; no EEG data and no GPU. From this folder:

    mkdir check
    python equivalence_sensitivity.py inputs/e1_e2_paired_participant_differences_verified_v4.csv \
           inputs/participant_seed_averages.csv inputs/participant_means.csv \
           check/EQUIVALENCE_SENSITIVITY-v1.9.json
    python cross_check_published.py check/EQUIVALENCE_SENSITIVITY-v1.9.json \
           inputs/verified_e1_e2_tables_v4.json inputs/five_paired_contrasts_holm.csv \
           inputs/two_contrasts_holm.json inputs/four_contrasts_holm.json \
           check/CROSS_CHECK_PUBLISHED-v1.9.json
    python calibration_boundary_sensitivity.py inputs/temperatures.csv inputs/run_metrics.csv \
           check/CALIBRATION_BOUNDARY_SENSITIVITY-v1.9.json

The three files in check/ should equal the three result files of this folder. The stored
results were computed with Python 3.13.18, NumPy 2.5.3 and SciPy 1.18.1; with other versions
the last digits can differ. The sensitivity values were also compared with the power
functions of statsmodels 0.15.0: the detectable effects agree to five decimals and the
participant numbers are the same.


WHO PREPARED THIS

The analysis plan and the three scripts were prepared by Claude (Anthropic) at the authors'
request. The check in cross_check_published.py was made in the same work; it is not a
verification by an independent party.
