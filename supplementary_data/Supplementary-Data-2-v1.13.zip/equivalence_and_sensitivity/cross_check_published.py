#!/usr/bin/env python3
"""Cross-check of equivalence_sensitivity.py against the original result files (manuscript v1.9).

equivalence_sensitivity.py recomputes, for every planned accuracy contrast, the paired statistics that the
manuscript reports (mean difference, SD of the differences, d_z, t, two-sided p, 95% t interval, Holm-adjusted p)
before it adds the equivalence tests. This script compares those recomputed statistics with the result files that
the original analyses wrote, so that a reader can see that the equivalence analysis starts from the published
numbers. Nothing is fitted.

Original result files:
  E1_E2_TABLES.json    verified_e1_e2_tables_v4.json    Experiments 1 and 2 (four contrasts each, and W0-S0 of
                                                        Experiment 2, which was outside the planned family)
  LEE_CONTRASTS.csv    five_paired_contrasts_holm.csv   Experiment 3 (five contrasts)
  W4_CONTRASTS.json    two_contrasts_holm.json          W4 control (two contrasts; public release v2.2.0)
  S1W5_CONTRASTS.json  four_contrasts_holm.json         S1/W5 control (four contrasts)

Usage:
  cross_check_published.py EQUIVALENCE.json E1_E2_TABLES.json LEE_CONTRASTS.csv W4_CONTRASTS.json S1W5_CONTRASTS.json OUT.json
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

TOLERANCE = 1e-9


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    eq_path, e12_path, lee_path, w4_path, s1w5_path, out_path = sys.argv[1:7]
    eq = json.loads(Path(eq_path).read_text("utf-8"))
    recomputed = {(f["family"], c["contrast"]): c for f in eq["families"] for c in f["contrasts"]}
    for c in eq["descriptive"]:
        recomputed[("Experiment 2, outside the family", c["contrast"])] = c

    original = {}
    e12 = json.loads(Path(e12_path).read_text("utf-8"))
    for family, key in (("Experiment 1", "E1_main_family"), ("Experiment 2", "E2_main_family")):
        for row in e12[key]:
            original[(family, row["contrast"].replace(" ", ""))] = dict(      # written "C1 - C0" in that file
                mean=row["mean_diff_pp"], sd=row["sd_diff_pp"], d_z=row["d_z"], t=row["t"], p=row["p_t"],
                ci_low=row["ci95_pp"][0], ci_high=row["ci95_pp"][1], holm=row["p_holm"])
    row = e12["E2_W0_minus_S0_descriptive"]
    original[("Experiment 2, outside the family", row["contrast"].replace(" ", ""))] = dict(
        mean=row["mean_diff_pp"], sd=row["sd_diff_pp"], d_z=row["d_z"], t=row["t"], p=row["p_t"],
        ci_low=row["ci95_pp"][0], ci_high=row["ci95_pp"][1])
    for row in csv.DictReader(open(lee_path, newline="", encoding="utf-8")):
        original[("Experiment 3", row["contrast"])] = dict(
            mean=float(row["mean_difference_percentage_points"]), d_z=float(row["paired_dz"]), t=float(row["t_statistic"]),
            p=float(row["p_two_sided"]), ci_low=float(row["ci95_low_percentage_points"]),
            ci_high=float(row["ci95_high_percentage_points"]), holm=float(row["p_holm_five"]))
    for row in json.loads(Path(w4_path).read_text("utf-8")):
        original[("W4 control", row["contrast"])] = dict(
            mean=row["mean_difference_pp"], sd=row["sd_difference_pp"], d_z=row["d_z"], t=row["t"], p=row["p_unadjusted"],
            ci_low=row["pointwise_95ci_pp"][0], ci_high=row["pointwise_95ci_pp"][1], holm=row["p_holm_two"])
    for row in json.loads(Path(s1w5_path).read_text("utf-8")):
        original[("S1/W5 control", row["contrast"])] = dict(
            mean=row["mean_difference"], sd=row["sd_difference"], d_z=row["d_z"], t=row["t"], p=row["p_unadjusted"],
            ci_low=row["pointwise_95ci"][0], ci_high=row["pointwise_95ci"][1], holm=row["p_holm_four"])

    if set(original) != set(recomputed):
        raise SystemExit("The contrasts differ: %s" % sorted(set(original) ^ set(recomputed)))
    rows, largest = [], 0.0
    for key in sorted(original):
        new = recomputed[key]
        mine = dict(mean=new["mean_difference_pp"], sd=new["sd_difference_pp"], d_z=new["d_z"], t=new["t"], p=new["p_two_sided"],
                    ci_low=new["ci95_pp"][0], ci_high=new["ci95_pp"][1], holm=new.get("p_holm_in_family"))
        differences = {name: abs(mine[name] - value) for name, value in original[key].items()}
        worst = max(differences.values())
        largest = max(largest, worst)
        rows.append(dict(family=key[0], contrast=key[1], statistics_compared=sorted(differences),
                         largest_absolute_difference=worst, original=original[key],
                         recomputed={name: mine[name] for name in original[key]}))
    result = dict(
        check="paired statistics recomputed by equivalence_sensitivity.py versus the original result files",
        tolerance=TOLERANCE, contrasts=len(rows), values_compared=sum(len(r["statistics_compared"]) for r in rows),
        largest_absolute_difference=largest, status="AGREE" if largest < TOLERANCE else "DIFFER",
        inputs={Path(p).name: sha(p) for p in (eq_path, e12_path, lee_path, w4_path, s1w5_path)}, rows=rows)
    Path(out_path).write_text(json.dumps(result, indent=1) + "\n", encoding="utf-8")
    print("%d contrasts, %d values, largest absolute difference %.3g: %s"
          % (result["contrasts"], result["values_compared"], largest, result["status"]))
    if largest >= TOLERANCE:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
