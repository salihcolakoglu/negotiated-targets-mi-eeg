SUPPLEMENTARY DATA 2, VERSION 1.13 (file Supplementary-Data-2-v1.13.zip)
Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding:
A Controlled Evaluation of Accuracy and Confidence
S. Colakoglu, M. Onat, N. Korhan

This file accompanies manuscript version 1.13 and its Supplementary Information. It holds
the records, stored outputs and code of the S1/W5 control, the record-based summaries, the
classical-pipeline and resource files and the post hoc equivalence and sensitivity analysis.
It contains no raw EEG, no prepared signal arrays and no model or optimizer checkpoints.
The EEG data must be obtained from the original providers under their own terms.

The records of the S1/W5 control include working documents of its AI-assisted preparation;
Section 4 lists them. The work journals of the project are not included.

MANIFEST-SHA256.txt lists the SHA-256 value, size and name of every file.

The supplementary data of this submission consist of three files:

  Supplementary-Data-1-v1.13.zip
      The numerical supplement of Experiments 1, 2 and 3 (35,882,232 bytes, SHA-256
      bb1b0d75b74c013a39616cf3e11bd76809917a053e8cfeac7da55895de45e3c5).
      It carries its own README and verification script.

  Supplementary-Data-2-v1.13.zip (this file)
      The two added Lee2019 controls S1 and W5, the record-based summaries, the
      classical-pipeline and resource files and the equivalence and sensitivity analysis,
      described below.

  Supplementary-Data-3-v1.13.zip
      The three additional sensitivity analyses of Supplementary Section S19 (38,294,518
      bytes, SHA-256
      6ab22d72b68d81c44e897cca051ce35c645f05797f7e8cf3c7c3edd778e09c99).
      It carries its own README and manifest.


WHAT CHANGED IN VERSION 1.13 (18 November 2026)

  - Only three files: this README, equivalence_and_sensitivity/README.txt and
    MANIFEST-SHA256.txt. They carry the version, the names of the three data files and the
    size and SHA-256 value of the other two; section 5 now names software release v2.3.0,
    in which the three data files are published.
  - Every other file is byte-identical to Supplementary-Data-2-v1.12.zip (SHA-256
    b766fa9eb512881e72d23d44ad7a61923406918a3135b0b71ef90e8d13a274ce).


WHAT CHANGED IN VERSION 1.12 (17 November 2026)

  - Only three files: this README, equivalence_and_sensitivity/README.txt and
    MANIFEST-SHA256.txt. They carry the version, the names of the three data files and the
    size and SHA-256 value of the other two.
  - Every other file is byte-identical to Supplementary-Data-2-v1.11.zip (SHA-256
    3ec957fc8dfabb7d9aec881734a190bfa7ce1eb41d8905f7cae13f0231e41334).


WHAT CHANGED IN VERSION 1.11 (17 November 2026)

  - Only three files: this README, equivalence_and_sensitivity/README.txt and
    MANIFEST-SHA256.txt. They carry the version, the names of the three data files and the
    size and SHA-256 value of the other two.
  - Every other file is byte-identical to Supplementary-Data-2-v1.10.zip (SHA-256
    820200a58ec79f3640dc25b37f64da22f6fe17a70bc5200768f46ec2216382c8).


WHAT CHANGED IN VERSION 1.10 (16 November 2026)

  - Only three files: this README, equivalence_and_sensitivity/README.txt and
    MANIFEST-SHA256.txt. They carry the version, the names of the three data files and the
    size and SHA-256 value of the other two; one sentence of the second README on how the
    analysis came about was shortened.
  - Every other file is byte-identical to Supplementary-Data-2-v1.9.zip (SHA-256
    9131e7a4861fa545bbd07f5da294f2bae7c8bdef03a4e8b62ad16b37a4cceb81).
  - The result files and scripts of equivalence_and_sensitivity/ keep "v1.9" in their
    names: those analyses were added in manuscript version 1.9.


WHAT CHANGED IN VERSION 1.9 (15 November 2026; against Supplementary-Data-v1.8.zip)

  - The folder equivalence_and_sensitivity/ is new.
  - The folder s1_w5_control/independent_recomputation/ is now called
    s1_w5_control/second_recomputation/. Its files are unchanged, except that the note
    run_on_public_copy/NOTE.txt no longer calls the session that wrote the script
    "the reviewer".
  - This README was rewritten. It lists the working documents of the AI-assisted
    preparation, which the README of version 1.8 did not mention, and it describes the
    second recomputation as a check by a separate AI session within the authors' work.
  - The manifest names the new file names. Every other file is byte-identical to
    version 1.8.


PUBLIC COPIES

Six files of this archive are public copies in which text without scientific content was
replaced by a placeholder; PUBLIC_COPY_CHANGES.json lists them with the SHA-256 value and
size of the original and of the public copy:
  - Three files of the S1/W5 control: the frozen protocol (PROTOKOL-V1.0.json), the record
    of its pre-written content (records/ONCEDEN_YAZILAN_ICERIK-V1.0.json) and the script
    that wrote it (records/freeze_protocol-V1.0.py). Their authorization entry quoted three
    short instructions of the first author to run the control; in the public copies each
    reads "[removed from the public copy]". Nothing else in these files was changed.
  - Three files of the second recomputation of the record-based summaries
    (bagimsiz_kontrol/karsilastirma_sonuc.json, karsilastirma_mutasyon_testi.json and
    lee_fit_tablosu.json): an internal session identifier inside file paths reads
    "session-id-removed".
The originals are kept by the authors. The SHA-256 values that the records of the S1/W5
control name for the protocol (protocol_sha256 in the fit, test, gate and result files;
fixed_content_sha256; the list of the frozen package; the transfer lists) are the values of
the originals, so they differ from the three public copies. Section 2 says what this means
for the check of the numbers: nothing numerical changes.


1. CONTENTS OF THIS ARCHIVE

s1_w5_control/
    The two post hoc Lee2019 controls of manuscript Table 11 and Supplementary Section S14:
    S1 (ordinary outputs with cumulative negotiation) and W5 (Walsh outputs with an anchored
    target whose label share is matched to the cumulative rule).

    data/
        The 5,240 files that were given to the second recomputation (see below); two of
        them, the protocol and the record of its pre-written content, are public copies.
        LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/
            PROTOKOL-V1.0.json    the frozen protocol, as a public copy (see PUBLIC COPIES);
                                  SHA-256 of the original, the value named in the records:
                                  8aad66b370d1dedfdc1ac66ad02dcaf3bbcce552414d1aa4b08a4ebed9a62277
            campaign/             612 fit records and 612 test records, the stored training
                                  outputs (fit_outputs) and second-day predictions (predictions)
                                  of the 540 new fits and of the 72 repeated reference fits,
                                  and the decision and gate files
            data/                 the list of bound source files with their SHA-256 values
                                  and the normalization values of the 54 participants
            final_analysis/       the result files behind Table 11 and Section S14
            logs/, ops/, records/ the run logs, the receipts of the generated-data checks and
                                  the pre-written content of the protocol
        LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/ and LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/
            The 1,080 stored reference fits that the control uses for S0, W0, W1 (Experiment 3)
            and W4 (the W4 control): records and stored outputs, at the relative paths named
            in the list of bound source files. Every file equals its bound SHA-256 value.
    code_and_checks/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/
        The other files of the same study folder, which were not given to the second
        recomputation: the training code (code/), the analysis script of the campaign
        (analysis/), the generated-data checks (qa/), the launcher and runner (ops/,
        BASLAT-V1.0.cmd), and the notes and scripts with which the protocol was prepared and
        frozen (records/; see Section 4). Copying this folder over
        data/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/ restores the study folder of the training
        computer, without checkpoints and prepared EEG arrays.
    second_recomputation/
        recompute.py              a script written by a separate AI session (Anthropic Claude)
                                  that had not been given the analysis script of the control.
                                  It recomputes the results from the stored outputs and
                                  compares them with final_analysis/.
        RECOMPUTED.json, COMPARISON.json, COMPARISON.md, REPORT.md
                                  its numbers, the comparison and the report of that session,
                                  from its run on the original data. The files are unchanged;
                                  the script and the report call the work an "independent
                                  recomputation" (see Section 6 for this word).
        run_on_public_copy/       the outputs of the same script on data/ as it is in this
                                  archive, with a note that lists the differences (NOTE.txt)
        transfer_lists/           SHA-256, size and path of the data files as they were
                                  transferred from the training computer (original files)

record_based_summaries/MEVCUT_KAYITLARDAN_SAYILAR-V1.0/
    The descriptive numbers of Supplementary Section S15 (training fit, gate activity,
    agreement of the two decision rules, Walsh class scores divided by eight). They were
    derived from the stored records of Experiments 1 to 3 without any new training.
    SAYILAR-V1.0.json holds the numbers; kod/ holds the script that derived them;
    bagimsiz_kontrol/ holds a second recomputation of the same numbers by a separate AI
    session and its comparison; ek/ holds the Experiment 1 comparison of the gated and the
    ungated anchored rule. The scripts read the fit records at the folder layout of the
    authors' workstation; they are included as a record of the derivation.

classical_pipelines_and_resources/archival_addendum-V1.0/
    The files behind Supplementary Section S16 (four classical pipelines on Lee2019;
    training time and memory), with their own README and verification script
    (verify_archival_addendum.py, run from that folder). That README was written when this
    material was a separate addendum document; where it speaks of a local working revision
    or of an addendum, it describes that earlier stage. The content is now Section S16 of the
    Supplementary Information.

equivalence_and_sensitivity/
    The post hoc equivalence and sensitivity analysis of the planned accuracy contrasts
    (manuscript Table 8; Supplementary Section S17) and the calibration control split by
    where the fitted temperature lies (Supplementary Table S11c): three scripts, their
    results and copies of the nine input files. The README.txt of that folder describes the
    files and gives the commands that repeat the analyses.


2. HOW TO CHECK THE NUMBERS OF THE S1/W5 CONTROL

Requirements: Python 3.12 with NumPy 2.2.6 and SciPy 1.15.3 (the versions used for the
reported analysis; other recent versions are expected to agree within rounding).

    cd s1_w5_control
    python second_recomputation/recompute.py data check_output \
           second_recomputation/transfer_lists

The script reads only the stored outputs and records in s1_w5_control/data/. It needs no EEG
data and no GPU. It takes a few seconds and writes
RECOMPUTED.json, COMPARISON.json and COMPARISON.md into check_output/; these should equal
the three files in second_recomputation/run_on_public_copy/. (RECOMPUTED.json records
the Python, NumPy and SciPy versions; with other versions those entries differ.)

Public copy and original data. The session that wrote the script ran it on the original
files; those outputs are the files directly in second_recomputation/. On the data of this
archive the script reports twelve further lines, all identity checks and all caused by the
three replaced instructions: the protocol hash named in seven gate and completion files
(A09), SHA-256 and size of the two changed data files against the transfer lists (A10), and
the count of the 612 campaign records that name the protocol hash of the original (A18).
Every recomputed number is identical in the two runs; run_on_public_copy/NOTE.txt lists
the changed lines.

What the comparison shows: 255,759 values in 109 groups were compared. All accuracies,
participant means, contrasts and tests agree with final_analysis/ (largest difference of
the contrast statistics 8.3e-16). One descriptive measure is flagged, target_displacement:
the result files carry the value that was recorded during training in single precision
(field last_target_dist of the fit records), and the script recomputes it from the stored
targets in double precision. 989 values of the result files differ by more than 1e-9; the
largest difference is 6.1e-8, and no number printed in the manuscript or the Supplementary
Information changes. REPORT.md states what could and what could not be checked from the
stored data (for example, training itself cannot be checked without checkpoints and EEG).
REPORT.md is the text of the session that wrote the script; it was saved to a file by the
session that built this archive, because the other session could return text only.

This recomputation was made within the author team with AI assistance. It is not a
verification by an independent party, and it did not repeat EEG preprocessing or training.

The script that produced final_analysis/ on the authors' workstation is
code_and_checks/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/analysis/final_analysis.py. Before
computing anything it verifies every bound source file, including the prepared EEG arrays
and the model checkpoints, which are not part of this archive; it is included for
inspection and cannot be run from this archive alone.


3. WHAT THE CAMPAIGN DID, IN ORDER

12 November 2026, local time (UTC+3), from the run logs in logs/:
  07:25-07:30  generated-data checks on the training computer (342, 75 and 58 checks; all
               passed); no real data opened
  07:30        protocol frozen
  07:31-07:47  72 stored reference fits trained again (9 participants, seeds 1 and 5,
               conditions S0, W0, W1, W4)
  07:47-09:41  540 new fits (S1 and W5; 54 participants, seeds 1 to 5)
  09:41        reference-source decision from first-day information only: the 72 repeated
               fits reproduced the stored training-side arrays bit for bit and all 270 W5
               third-phase target distances equaled the stored W4 values, so the stored
               fits serve as references
  09:42        all 612 models listed with their SHA-256 values (model freeze); second-day
               arrays were opened only after this step; the 72 repeated fits were evaluated
               first and reproduced the stored second-day outputs bit for bit
  09:42-09:43  every model evaluated once; analysis written

The protocol was not registered with an external service. Its time stamp
(2026-11-12T07:30:06+03:00) and the times above were written by the authors' computer.


4. WORKING DOCUMENTS OF THE AI-ASSISTED PREPARATION

The S1/W5 control was prepared with AI assistance, as the Acknowledgment of the manuscript
states. The two questions that the control addresses were raised by the third author on
manuscript version 1.7 (see data/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/README-V1.0.md, in
Turkish). Claude (Anthropic) wrote the protocol, the training and analysis code and the
checks at the authors' request. The first author decided to run the control and started
the fits by hand on his own computer; the authorization entry of the protocol records this
("executing_agent ...; the user starts the run by hand").

The frozen file list of the control (data/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/records/
PAKET_OZETLERI-V1.0.json) binds every file of the study folder by its SHA-256 value.
Working documents of the preparation are among these files. They are therefore part of
this archive and are unchanged:

  code_and_checks/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/
    records/BAGIMSIZ_INCELEME_RAPORU-V1.0.md
        A review of the package before the protocol was frozen, written in English by a
        second AI session that had not written the code (the file name means "independent
        review report"). It found no defect that would change a number and listed points
        to fix before the run.
    records/INCELEMEYE_YANIT-V1.0.md
        The reply to that review: what was done about each finding (in Turkish).
    records/prelaunch/NOT-V1.0.md and the four JSON files next to it
        Receipts of the generated-data checks that were run while the package was
        prepared, with a note (in Turkish).
    records/LEE_CORE_DEGISIKLIKLERI-V1.0.diff
        The lines by which the training core of this control differs from that of the W4
        control.
    BASLAT-V1.0.cmd
        The start script that the first author ran (messages in Turkish).

The authorization entry of the protocol also names two records of the project's work
journal (decision_record and journal_record). These journals are not part of this archive.


5. RELATION TO THE PUBLIC RELEASE

Software release v2.2.0 (https://doi.org/10.5281/zenodo.23504655) is the public archive of
the code. It covers Experiments 1 to 3, the calibration control (1,350 models), the SHU
architecture/output comparison (400 fits) and the W4 control (270 fits). It is not
duplicated here. The S1/W5 control was run after that release; it is documented in this
archive. From version 1.13 this archive and the other two data files are published in folder
supplementary_data/ of software release v2.3.0 of the same repository
(https://github.com/salihcolakoglu/negotiated-targets-mi-eeg).


6. LANGUAGE, NAMES AND FILE PATHS

Folder names, several notes (README-V1.0.md, PROTOKOL_OZETI-V1.0.md, the notes in records/)
and the run logs are in Turkish. The protocol, the code, the result files and this README
are in English. Folder names in English:
  LEE2019_S1_W5_KONTROL_KOSULLARI       Lee2019, control conditions S1 and W5
  LEE2019_BAGIMSIZ_DOGRULAMA            "Lee2019 independent validation": the working name of
                                        the study folder of Experiment 3
  LEE2019_ANKRAJ_KAPI_AYRISTIRMA        the W4 control (anchoring without the gate)
  MEVCUT_KAYITLARDAN_SAYILAR            numbers from the existing records
  bagimsiz_kontrol / kod / ek           "independent check" / code / addition
Condition names: S0 ordinary outputs with hard labels; S1 ordinary outputs with cumulative
negotiation; W0 fixed Walsh targets; W1 cumulative negotiation; W4 anchored, ungated;
W5 anchored, ungated, share matched to W1.

The word "independent". Names and records were written during the work and are kept as
they were bound. Where they say "independent" (Turkish "bagimsiz") about a review, check
or recomputation, they mean that it was made by a separate AI session or script that had
not seen the code or analysis it checked. In the name of the Experiment 3 folder the word
refers to participants and data that were not used in Experiments 1 and 2. In no case does
it mean a verification by an independent party.

File paths. Some records contain file paths of the first author's computer and of the AI
work environment in which code and checks were prepared (for example /home/claude/work/...).
The paths carry no scientific content. They were not edited, because an edit would change
a SHA-256 value that the frozen records bind.


7. LICENSES AND DATA SOURCES

MIT applies to code and CC BY 4.0 to author-owned explanatory materials and numerical
results. Labels derived from the original datasets keep their upstream terms. Lee2019:
data DOI 10.5524/100542 (CC0 1.0), data paper 10.1093/gigascience/giz002.
The record-based summaries also contain numbers derived from the BNCI Horizon 2020
datasets 001-2014, 002-2014 and 004-2014 (Experiments 1 and 2); the manuscript gives
their sources.


8. USE OF AI TOOLS

AI-assisted preparation used Claude (Anthropic) and Codex (OpenAI); the Acknowledgment of
the manuscript states the scope.
