"""Frozen-input classical Lee benchmark core; no file-based EEG loader.

The caller owns the global Day2 gate, provenance and trusted serialization.
Only float32 arrays explicitly passed by the caller are consumed here.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import importlib.util
from pathlib import Path
import time
import warnings

import numpy as np
from scipy.special import log_expit
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from pyriemann.estimation import Covariances
from pyriemann.utils.distance import distance_riemann
from pyriemann.utils.mean import mean_riemann
from pyriemann.utils.tangentspace import tangent_space

METHOD_IDS = ('MDM', 'TS_LDA', 'TS_SVM', 'CSP6_COMMON_Z_SVD_LDA')
SCHEMA = 'LEE_MATCHED_RIEMANN_CORE_V1.0'
MEAN_TOL = 1e-8
MEAN_MAXITER = 50
MEAN_RESIDUAL_MAX = 1e-7
SOURCE_SHA256 = {
    'code/lee_data.py': '49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740',
    'prepare/classical_reference.py': '7a58a2490b1a2c8d1a7d9347276d0401395180e085d01366c980f685d157f619',
}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def core_contract():
    return {
        'schema': SCHEMA, 'methods': list(METHOD_IDS),
        'packages': {name: importlib.metadata.version(name)
                     for name in ('numpy', 'scipy', 'scikit-learn', 'pyriemann')},
        'mean': {'tol': MEAN_TOL, 'maxiter': MEAN_MAXITER,
                 'independent_residual_max': MEAN_RESIDUAL_MAX,
                 'any_warning_is_error': True},
        'OAS': {'dtype': 'float64', 'assume_centered': False,
                'denominator': 'T, not T-1', 'trace_normalization': False},
        'TS': {'metric': 'riemann', 'tsupdate': False,
               'vector': 'upper triangle; diagonal1/offdiagonal sqrt2',
               'shared_scaler': 'StandardScaler fit only on training'},
        'TS_LDA': {'solver': 'lsqr', 'shrinkage': 'auto', 'priors': [.5, .5]},
        'TS_SVM': {'kernel': 'linear', 'C': 1., 'probability': False,
                   'class_weight': None, 'tol': .001, 'max_iter': -1,
                   'shrinking': True, 'cache_size': 200,
                   'decision_function_shape': 'ovr', 'break_ties': False,
                   'random_state': 0},
        'CSP': {'frozen_source': SOURCE_SHA256['prepare/classical_reference.py'],
                'n_features': 6, 'LDA_solver': 'svd', 'LDA_priors': None},
        'model_selection': None,
        'probability': {'MDM': None, 'TS_SVM': None,
                        'TS_LDA': 'separate raw LDA diagnostic',
                        'CSP6_COMMON_Z_SVD_LDA': 'separate raw LDA diagnostic'},
    }


def _check_versions():
    for name, expected in [('pyriemann', '0.9'), ('scikit-learn', '1.7.2')]:
        if importlib.metadata.version(name) != expected:
            raise RuntimeError(f'Pinned package mismatch: {name} != {expected}')


def legacy_functions(source_root=None):
    """Load only known-normalizer source and two checksum-bound CSP functions.

    The old prepare script's imports and CLI are not executed. Exactly its
    original two pure CSP function definitions are compiled in an np namespace.
    """
    project = Path(source_root) if source_root is not None else Path(__file__).resolve().parents[2]
    base = project / 'LEE2019_BAGIMSIZ_DOGRULAMA-V1.0'
    bindings = []
    for relative, expected in SOURCE_SHA256.items():
        path = base / relative
        actual = _sha(path)
        if actual != expected:
            raise RuntimeError(f'Bound legacy source changed: {path}')
        bindings.append({'path': str(path), 'sha256': actual})
    normalizer_path = base / 'code/lee_data.py'
    spec = importlib.util.spec_from_file_location('_bound_lee_zscore_core', normalizer_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    csp_path = base / 'prepare/classical_reference.py'
    tree = ast.parse(csp_path.read_text(encoding='utf-8'))
    names = {'fit_csp', 'csp_transform'}
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    if {node.name for node in nodes} != names or len(nodes) != 2:
        raise RuntimeError('Bound source CSP function definitions missing/duplicated')
    selected = ast.Module(body=nodes, type_ignores=[])
    namespace = {'np': np}
    exec(compile(ast.fix_missing_locations(selected), str(csp_path), 'exec'), namespace)
    return module.zscore_fit, module.zscore_apply, namespace['fit_csp'], namespace['csp_transform'], bindings


def _waveform(X, *, channels=None, n_times=None):
    if not isinstance(X, np.ndarray) or X.dtype != np.float32 or X.ndim != 3:
        raise ValueError('Waveform must be float32 ndarray[trial,channel,time]')
    if X.shape[0] < 1 or X.shape[1] < 6 or X.shape[2] < 8 or not np.isfinite(X).all():
        raise ValueError('Nonfinite or insufficient waveform dimensions')
    if channels is not None and X.shape[1] != channels:
        raise ValueError('Changed channel count')
    if n_times is not None and X.shape[2] != n_times:
        raise ValueError('Changed time count')
    return X


def _labels(y, n):
    if not isinstance(y, np.ndarray) or y.dtype != np.int64 or y.shape != (n,):
        raise ValueError('Labels must be int64 vector matching trials')
    classes, counts = np.unique(y, return_counts=True)
    if classes.tolist() != [0, 1] or min(counts) < 2:
        raise ValueError('Exactly semantic classes0/1 with at least2 trials each required')
    return classes


def check_spd(bank):
    bank = np.asarray(bank)
    if bank.dtype != np.float64 or bank.ndim != 3 or bank.shape[1] != bank.shape[2] or not np.isfinite(bank).all():
        raise ValueError('Finite float64 square covariance bank required')
    if len(bank) < 1:
        raise ValueError('Empty covariance bank')
    error = float(np.max(np.abs(bank - bank.transpose(0, 2, 1))))
    if error > 1e-10 * max(1., float(np.max(np.abs(bank)))):
        raise ValueError('Covariance not symmetric within fixed tolerance')
    eig = np.linalg.eigvalsh(bank)
    if not np.isfinite(eig).all() or np.any(eig <= 0):
        raise ValueError('Covariance not strictly positive definite; no silent jitter/drop')
    return {'minimum_eigenvalue': float(eig.min()), 'maximum_eigenvalue': float(eig.max()),
            'max_symmetry_error': error}


def covariance_bank(X_normalized):
    _waveform(X_normalized)
    # Conversion BEFORE transform ensures pyRiemann preserves float64 output.
    with warnings.catch_warnings():
        warnings.simplefilter('error')
        bank = Covariances(estimator='oas', assume_centered=False).transform(
            X_normalized.astype(np.float64))
    diagnostics = check_spd(bank)
    return bank, diagnostics


def independent_mean_residual(bank, mean):
    """Affine-invariant residual using NumPy eigen-log, not pyRiemann log/mean."""
    check_spd(np.asarray(mean, dtype=np.float64)[None])
    values, vectors = np.linalg.eigh(mean)
    inverse_root = (vectors * (values ** -.5)) @ vectors.T
    whitened = inverse_root @ bank @ inverse_root
    # Explicit symmetry corrects only roundoff in the algebraic product, not
    # eigenvalues or input data. No regularization/jitter is introduced.
    whitened = .5 * (whitened + whitened.transpose(0, 2, 1))
    eig, vec = np.linalg.eigh(whitened)
    if np.any(eig <= 0) or not np.isfinite(eig).all():
        raise ValueError('Independent residual logarithm is not SPD')
    logs = (vec * np.log(eig)[:, None, :]) @ vec.transpose(0, 2, 1)
    return float(np.linalg.norm(logs.mean(axis=0), ord='fro'))


def checked_mean(bank):
    check_spd(bank)
    with warnings.catch_warnings():
        warnings.simplefilter('error')
        mean = mean_riemann(bank, tol=MEAN_TOL, maxiter=MEAN_MAXITER,
                            init=None, sample_weight=None)
    residual = independent_mean_residual(bank, mean)
    if not np.isfinite(residual) or residual > MEAN_RESIDUAL_MAX:
        raise RuntimeError(f'Riemann mean residual failed: {residual} > {MEAN_RESIDUAL_MAX}')
    return np.asarray(mean, dtype=np.float64), residual


def _lda_state(estimator):
    if estimator.classes_.tolist() != [0, 1] or estimator.coef_.shape[0] != 1:
        raise ValueError('Binary native LDA state/class order invalid')
    return {'coef': np.array(estimator.coef_, dtype=np.float64, copy=True),
            'intercept': np.array(estimator.intercept_, dtype=np.float64, copy=True),
            'classes': np.array(estimator.classes_, dtype=np.int64, copy=True)}


def _lda_readout(state, features):
    # Exact binary sklearn LDA native decision rule: scores>0, then classes_;
    # equality remains class0. Do not replace by a reconstructed proba argmax.
    margin = (features @ state['coef'].T + state['intercept']).ravel()
    pred = state['classes'][(margin > 0).astype(np.intp)]
    logp = np.column_stack((log_expit(-margin), log_expit(margin)))
    return {'prediction': pred.astype(np.int64),
            'diagnostics': {'margin': margin, 'confidence_available': True},
            'scores': margin, 'scores_kind': 'binary LDA native decision margin',
            'log_proba': logp}


def _readout(shared, models, normalized, bank, ts_scaled):
    means = models['MDM']['means']
    distances = np.empty((len(bank), 2), dtype=np.float64)
    for i in range(len(bank)):
        for k in range(2):
            distances[i, k] = float(distance_riemann(bank[i], means[k]))
    result = {'MDM': {'prediction': shared['classes'][distances.argmin(axis=1)].astype(np.int64),
                      'diagnostics': {'distance': distances, 'confidence_available': False},
                      'scores': distances, 'scores_kind': 'Riemann distances; lower is nearer',
                      'log_proba': None}}
    result['TS_LDA'] = _lda_readout(models['TS_LDA'], ts_scaled)
    svc = models['TS_SVM']['estimator']
    result['TS_SVM'] = {'prediction': svc.predict(ts_scaled).astype(np.int64),
                        'diagnostics': {'margin': svc.decision_function(ts_scaled),
                                        'confidence_available': False},
                        'scores': svc.decision_function(ts_scaled),
                        'scores_kind': 'native binary SVC decision margin; native predict authoritative',
                        'log_proba': None}
    csp_state = models['CSP6_COMMON_Z_SVD_LDA']
    # The pure function loaded from the checksum-bound old source is shared
    # by fit and test; caller source_root is not needed for rehydration.
    features = np.array([np.log(np.var(csp_state['W'] @ trial, axis=1)) for trial in normalized])
    if features.shape != (len(normalized), 6) or not np.isfinite(features).all():
        raise ValueError('CSP produced nonfinite or incorrectly shaped features')
    result['CSP6_COMMON_Z_SVD_LDA'] = _lda_readout(csp_state, features)
    result['CSP6_COMMON_Z_SVD_LDA']['diagnostics']['features'] = features
    for method in METHOD_IDS:
        row = result[method]
        if row['prediction'].shape != (len(normalized),) or row['prediction'].dtype != np.int64:
            raise ValueError('Invalid native prediction output')
        if not np.isfinite(row['scores']).all():
            raise ValueError('Nonfinite native decision diagnostic')
    return result


def fit_person(X_train, y_train, *, source_root=None, subject=None):
    """Fit exactly4 final classifiers on the passed Day1 array; no data I/O."""
    _check_versions()
    _waveform(X_train)
    classes = _labels(y_train, len(X_train))
    zfit, zapply, cspfit, csptransform, sources = legacy_functions(source_root)
    timing = {}; started = time.perf_counter()
    normalizer_mean, normalizer_sd = zfit(X_train)
    normalized = zapply(X_train, normalizer_mean, normalizer_sd)
    timing['normalization'] = time.perf_counter() - started
    started = time.perf_counter(); bank, spd_diagnostics = covariance_bank(normalized)
    timing['covariance'] = time.perf_counter() - started
    started = time.perf_counter(); means = []; class_residuals = []
    for cls in classes:
        mean, residual = checked_mean(bank[y_train == cls]); means.append(mean); class_residuals.append(residual)
    reference, reference_residual = checked_mean(bank)
    timing['riemann_mean'] = time.perf_counter() - started
    started = time.perf_counter()
    vectors = tangent_space(bank, reference, metric='riemann')
    scaler = StandardScaler(with_mean=True, with_std=True)
    scaled = scaler.fit_transform(vectors)
    timing['tangent_scaler'] = time.perf_counter() - started
    if scaled.dtype != np.float64 or not np.isfinite(scaled).all():
        raise ValueError('Invalid shared tangent feature bank')
    timing['classifier_fit'] = {}
    with warnings.catch_warnings():
        warnings.simplefilter('error')
        started = time.perf_counter()
        lda = LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto', priors=[.5, .5])
        lda.fit(scaled, y_train)
        timing['classifier_fit']['TS_LDA'] = time.perf_counter() - started
        started = time.perf_counter()
        svc = SVC(kernel='linear', C=1., probability=False, class_weight=None,
                  tol=.001, max_iter=-1, shrinking=True, cache_size=200,
                  decision_function_shape='ovr', break_ties=False, random_state=0)
        svc.fit(scaled, y_train)
        timing['classifier_fit']['TS_SVM'] = time.perf_counter() - started
        if svc.fit_status_ != 0 or svc.classes_.tolist() != [0, 1]:
            raise RuntimeError('Native SVC convergence/class-order failure')
        started = time.perf_counter()
        W, selected = cspfit(normalized, y_train)
        features = csptransform(normalized, W)
        csp_lda = LinearDiscriminantAnalysis(solver='svd', shrinkage=None, priors=None, tol=1e-4)
        csp_lda.fit(features, y_train)
        timing['classifier_fit']['CSP6_COMMON_Z_SVD_LDA'] = time.perf_counter() - started
    # MDM class-mean cost is in riemann_mean, not a zero classifier cost claim.
    timing['classifier_fit']['MDM'] = None
    shared = {'classes': classes.copy(), 'normalizer_mean': normalizer_mean,
              'normalizer_sd': normalizer_sd, 'cov_train': bank,
              'ts_reference': reference, 'scaler_mean': scaler.mean_.copy(),
              'scaler_scale': scaler.scale_.copy(), 'scaler_var': scaler.var_.copy(),
              'training_ts_scaled': scaled,
              'n_channels': np.array(X_train.shape[1], dtype=np.int64),
              'n_times': np.array(X_train.shape[2], dtype=np.int64),
              'n_train': np.array(len(X_train), dtype=np.int64)}
    models = {'MDM': {'means': np.stack(means)}, 'TS_LDA': _lda_state(lda),
              'TS_SVM': {'estimator': svc},
              'CSP6_COMMON_Z_SVD_LDA': {**_lda_state(csp_lda), 'W': W, 'selected': selected}}
    train_predictions = _readout(shared, models, normalized, bank, scaled)
    # Native library parity is checked before a model is handed to caller.
    for method, native, f in [('TS_LDA', lda, scaled), ('CSP6_COMMON_Z_SVD_LDA', csp_lda, features)]:
        if not np.array_equal(native.predict(f), train_predictions[method]['prediction']):
            raise RuntimeError('Persisted LDA native prediction parity failed')
        if not np.allclose(native.predict_proba(f), np.exp(train_predictions[method]['log_proba']), atol=1e-14, rtol=1e-13):
            raise RuntimeError('Persisted LDA posterior parity failed')
    diagnostics = {'subject': subject, 'input_dtype': str(X_train.dtype),
                   'normalized_dtype': str(normalized.dtype),
                   'n_train': len(X_train), 'n_channels': X_train.shape[1],
                   'n_times': X_train.shape[2], 'tangent_features': scaled.shape[1],
                   'class_counts': np.bincount(y_train, minlength=2).tolist(),
                   'class_mean_residuals': class_residuals,
                   'reference_mean_residual': reference_residual,
                   'covariance': spd_diagnostics, 'timing_seconds': timing,
                   'sources': sources, 'contract': core_contract(),
                   'model_selection_fits': 0, 'final_classifiers_fitted': 4}
    rehydrate_person(shared, models)
    return {'schema': SCHEMA, 'shared': shared, 'models': models,
            'diagnostics': diagnostics, 'train_predictions': train_predictions}


def rehydrate_person(shared, models):
    """Validate only a trusted caller's loaded state; never deserialize here."""
    if tuple(models) != METHOD_IDS and set(models) != set(METHOD_IDS):
        raise ValueError('Expected exactly4 method states')
    if (np.asarray(shared['classes']).dtype != np.int64 or
            np.asarray(shared['classes']).shape != (2,) or shared['classes'].tolist() != [0, 1]):
        raise ValueError('Shared semantic class order must be0/1')
    for name in ('n_channels', 'n_times', 'n_train'):
        value = np.asarray(shared[name])
        if value.dtype != np.int64 or value.shape != () or int(value) < 1:
            raise ValueError('Invalid dimension scalar ' + name)
    p = int(shared['n_channels']); q = p * (p + 1) // 2
    for name, shape in [('normalizer_mean', (1, p, 1)), ('normalizer_sd', (1, p, 1)),
                        ('ts_reference', (p, p)), ('scaler_mean', (q,)),
                        ('scaler_scale', (q,)), ('scaler_var', (q,))]:
        a = np.asarray(shared[name])
        if a.shape != shape or a.dtype != np.float64 or not np.isfinite(a).all():
            raise ValueError('Invalid shared state ' + name)
    if np.any(shared['normalizer_sd'] <= 0) or np.any(shared['scaler_scale'] <= 0):
        raise ValueError('Nonpositive frozen scale')
    if (np.asarray(shared['cov_train']).shape != (int(shared['n_train']), p, p) or
            shared['cov_train'].dtype != np.float64 or not np.isfinite(shared['cov_train']).all()):
        raise ValueError('Invalid retained training covariance shape')
    if (np.asarray(shared['training_ts_scaled']).shape != (int(shared['n_train']), q) or
            shared['training_ts_scaled'].dtype != np.float64 or not np.isfinite(shared['training_ts_scaled']).all()):
        raise ValueError('Invalid retained tangent training shape')
    if np.asarray(models['MDM']['means']).shape != (2, p, p) or models['MDM']['means'].dtype != np.float64:
        raise ValueError('Invalid MDM centroids')
    check_spd(models['MDM']['means'])
    check_spd(shared['ts_reference'][None])
    if np.any(shared['scaler_var'] < 0):
        raise ValueError('Negative stored feature variance')
    for name, width in [('TS_LDA', q), ('CSP6_COMMON_Z_SVD_LDA', 6)]:
        state = models[name]
        if np.asarray(state['classes']).tolist() != [0, 1] or np.asarray(state['coef']).shape != (1, width) or np.asarray(state['intercept']).shape != (1,):
            raise ValueError('Invalid LDA state ' + name)
        if (np.asarray(state['classes']).dtype != np.int64 or state['coef'].dtype != np.float64 or
                state['intercept'].dtype != np.float64 or not np.isfinite(state['coef']).all() or
                not np.isfinite(state['intercept']).all()):
            raise ValueError('Nonfinite LDA state')
    csp = models['CSP6_COMMON_Z_SVD_LDA']
    if (csp['W'].shape != (6, p) or csp['W'].dtype != np.float64 or
            not np.isfinite(csp['W']).all() or not np.array_equal(csp['selected'], np.r_[0:3, p-3:p])):
        raise ValueError('Invalid CSP state')
    svc = models['TS_SVM']['estimator']
    if not isinstance(svc, SVC) or svc.classes_.tolist() != [0, 1] or svc.n_features_in_ != q or svc.fit_status_ != 0:
        raise ValueError('Invalid trusted native SVC state')
    params = svc.get_params()
    if params['C'] != 1. or params['kernel'] != 'linear' or params['probability']:
        raise ValueError('Changed frozen SVC science parameters')
    return {'schema': SCHEMA, 'shared': shared, 'models': models}


def predict_person(shared, models, X_test):
    """Apply only frozen transformations; return original passed trial order."""
    rehydrate_person(shared, models)
    _waveform(X_test, channels=int(shared['n_channels']), n_times=int(shared['n_times']))
    normalized = ((X_test.astype(np.float64) - shared['normalizer_mean']) /
                  shared['normalizer_sd']).astype(np.float32)
    bank, _ = covariance_bank(normalized)
    vectors = tangent_space(bank, shared['ts_reference'], metric='riemann')
    scaled = (vectors - shared['scaler_mean']) / shared['scaler_scale']
    return _readout(shared, models, normalized, bank, scaled)


def state_fingerprint(shared, models):
    """Content fingerprint including all native SVC learned attributes."""
    h = hashlib.sha256()
    def walk(x):
        if isinstance(x, np.ndarray):
            h.update(b'array'); h.update(str(x.dtype).encode()); h.update(str(x.shape).encode()); h.update(np.ascontiguousarray(x).tobytes())
        elif isinstance(x, np.generic):
            walk(x.item())
        elif isinstance(x, dict):
            h.update(b'dict')
            for key in sorted(x): walk(key); walk(x[key])
        elif isinstance(x, (list, tuple)):
            h.update(type(x).__name__.encode())
            for item in x: walk(item)
        elif isinstance(x, SVC):
            h.update(b'trusted_native_SVC'); walk(x.get_params()); walk(x.__dict__)
        elif x is None or isinstance(x, (str, bool, int, float)):
            h.update((type(x).__name__ + ':' + repr(x)).encode())
        else:
            raise TypeError('Unsupported persisted fingerprint value ' + type(x).__name__)
    walk(shared); walk(models)
    return h.hexdigest()
