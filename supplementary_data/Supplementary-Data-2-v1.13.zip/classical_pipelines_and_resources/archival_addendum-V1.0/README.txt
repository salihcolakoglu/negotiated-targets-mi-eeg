SUPPLEMENTARY ARCHIVAL ADDENDUM V1.0 -- LOCAL WORKING REVISION

This addendum accompanies the separate IEEE_ACCESS_GELISTIRME_CALISMA-V1.1
working project. It is not a new submission package, public release or DOI.
Earlier IEEE source projects, PDFs, DOCX files and upload packages remain intact.
The public v2.2.0 release and DOI 10.5281/zenodo.23504655 retain their earlier
scope; they are not asserted to contain this later classical benchmark or this
retrospective resource summary.

FILES AND WHAT THEY VERIFY
portable_classical_context.csv: all four prespecified later classical pipelines
plus the original archived S0 EEGNet reference, on 54 participants. Classical
fits are deterministic once/person; S0 averages five starts within each person.
resource_fit_metrics.csv: 540 scalar resource rows, with logical source JSON
paths and original SHA256 identities. No signals, labels, prediction arrays or
model weights are included. Resource fields were extracted from immutable
original records, not measured by a new training run.
resource_participant_means.csv: 108 rows (54 people by 2 conditions), after
five-start averaging within person. This is the analysis unit; 540 fits are
not 540 people.
expected_summary.json: the previously fixed root summary and tolerance used
for the portable consistency check. No p-value or confidence interval is added.
PROTOCOL_AND_METHODS_EXCERPT.json: explicitly disclosed source-protocol,
method, runtime and retained-result excerpts; not new replacement protocols.
PROVENANCE.json and ADDENDUM_INPUTS_MANIFEST-V1.0.json: source identities and
byte-integrity bindings. Paths are logical project-relative archival paths.
source/: exact author-owned implementation snapshots for inspecting the
classical method, preprocessing and timing boundaries. Third-party library
code, EEG data and weights are not bundled. These snapshots are not asserted
to be a standalone complete model-training project. Existing licences and
third-party terms are not changed by this local compilation.

PORTABLE CHECK -- STANDARD LIBRARY ONLY
From this directory, run: python -X utf8 -B verify_archival_addendum.py
No installation, raw EEG, NumPy, PyTorch, GPU, model fitting or inference is
needed. The verifier reads only this directory's retained CSV/JSON/text/code
bytes. It first checks the input manifest, then recomputes the108participant
means and the condition/paired summaries from 540 scalar CSV rows. Quartiles
use the inclusive method; GPU bytes are converted using 1 MiB = 1,048,576 bytes.
The classical table is checked against the retained result excerpt, rather
than recalculated from predictions or EEG. It prints
PASS_PORTABLE_ARCHIVED_CONTEXT_VERIFICATION and does not modify any file.

Read LIMITATIONS.txt before interpreting the results. Compilation of the main
working manuscript is a separate action; no publication or author approval is
implied by this addendum or its numerical verification.
