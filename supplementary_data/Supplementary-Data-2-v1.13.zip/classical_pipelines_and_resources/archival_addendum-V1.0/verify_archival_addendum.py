"""Verify retained archival scalar tables using only Python's standard library."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
def check(value, message):
    if not value:
        raise AssertionError(message)
def read_json(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))
def read_csv(name):
    with (ROOT / name).open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))
manifest = read_json('ADDENDUM_INPUTS_MANIFEST-V1.0.json')
for entry in manifest['files']:
    relative = Path(entry['path'])
    check(not relative.is_absolute() and '..' not in relative.parts, 'unsafe path')
    raw = (ROOT / relative).read_bytes()
    check(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], 'input byte hash: '+entry['path'])
expected = read_json('expected_summary.json')
tolerance = expected['comparison_absolute_tolerance']
metrics = expected['metric_names']
rows = read_csv('resource_fit_metrics.csv')
check(len(rows) == 540, '540fit rows required')
groups = {}
identities = set()
for row in rows:
    subject, condition, seed = int(row['subject']), row['condition'], int(row['seed'])
    identity = (subject, condition, seed)
    check(identity not in identities and subject in range(1,55) and seed in range(1,6) and condition in ['W0','W1'], 'fit identity')
    identities.add(identity)
    values = {name: float(row[name]) for name in ['train_seconds','wall_seconds','final_test_seconds','phase_total_seconds']}
    values['cuda_peak_allocated_MiB'] = int(row['cuda_peak_allocated_bytes']) / 1048576
    values['cuda_peak_reserved_MiB'] = int(row['cuda_peak_reserved_bytes']) / 1048576
    check(all(math.isfinite(value) and value >= 0 for value in values.values()), 'invalid resource scalar')
    check(len(row['source_sha256']) == 64 and all(c in '0123456789abcdef' for c in row['source_sha256']), 'source hash')
    groups.setdefault((subject, condition), []).append(values)
check(len(groups) == 108 and all(len(values) == 5 for values in groups.values()), '54people by2conditions by5starts')
means = {key: {name: statistics.mean(row[name] for row in values) for name in metrics} for key, values in groups.items()}
stored_means = read_csv('resource_participant_means.csv')
check(len(stored_means) == 108, '108stored participant means')
seen = set()
for row in stored_means:
    key = (int(row['subject']), row['condition'])
    check(key in means and key not in seen, 'participant identity')
    seen.add(key)
    for name in metrics:
        check(math.isclose(float(row[name]), means[key][name], rel_tol=0, abs_tol=tolerance), 'participant mean '+str(key)+' '+name)
def summarize(values):
    values = sorted(values)
    q1, _, q3 = statistics.quantiles(values, n=4, method='inclusive')
    return {'n_people': len(values), 'mean': statistics.mean(values), 'median': statistics.median(values), 'q1': q1, 'q3': q3, 'min': values[0], 'max': values[-1]}
actual = {'condition_summaries': {}, 'paired_W1_minus_W0': {}}
for condition in ['W0','W1']:
    actual['condition_summaries'][condition] = {name: summarize([means[(subject,condition)][name] for subject in range(1,55)]) for name in metrics}
for name in metrics:
    actual['paired_W1_minus_W0'][name] = summarize([means[(subject,'W1')][name]-means[(subject,'W0')][name] for subject in range(1,55)])
def compare(a, b, path=''):
    if isinstance(b, dict):
        check(set(a) == set(b), 'summary keys '+path)
        for key in b:
            compare(a[key], b[key], path+'/'+key)
    else:
        check(math.isclose(a, b, rel_tol=0, abs_tol=tolerance), 'summary mismatch '+path)
compare(actual['condition_summaries'], expected['condition_summaries'], 'conditions')
compare(actual['paired_W1_minus_W0'], expected['paired_W1_minus_W0'], 'paired')
classical = read_csv('portable_classical_context.csv')
check(len(classical) == 5, 'all4classical plusS0')
retained = {row['method']: row for row in read_json('PROTOCOL_AND_METHODS_EXCERPT.json')['later_classical']['retained_method_results']}
by_method = {row['method']: row for row in classical}
check(set(by_method) == {'MDM','TS_LDA','TS_SVM','CSP6_COMMON_Z_SVD_LDA','S0'}, 'classical method set')
for row in expected['classical_context']:
    stored = by_method[row['method']]
    check(int(stored['n_people']) == 54 and int(stored['models_per_person']) == row['models_per_person'], 'classical analysis unit')
    check(math.isclose(float(stored['mean_accuracy_percent']), row['mean_accuracy_percent'], rel_tol=0, abs_tol=tolerance), 'classical expected mean')
    check(math.isclose(float(stored['mean_accuracy_percent']), retained[row['method']]['mean_accuracy_pct'], rel_tol=0, abs_tol=tolerance), 'classical retained result')
print(json.dumps({'status':'PASS_PORTABLE_ARCHIVED_CONTEXT_VERIFICATION','verified_input_files':len(manifest['files']),'resource_fit_rows':540,'participant_condition_means':108,'classical_context_rows':5,'aggregation':'five starts within each of54participants; inclusive quartiles','training_or_inference':False,'raw_EEG_prediction_NPZ_or_model_opened':False,'files_written':False}, sort_keys=True))
