"""Campaign runner of the S1/W5 control study. One process, one frozen protocol.

Stages: environment record -> generated-data checks on this machine -> campaign (see code/campaign.py)
-> final analysis -> completion record. Safe to start again after an interruption: finished fits are
kept, an interrupted fit resumes at its last completed phase.

To stop: close the window, or create campaign/STOP_AFTER_CURRENT_FIT (stops after the running fit).

Exit codes: 0 complete, 3 stopped on request, 4 another run of this study is alive, 1 any failure.
Every failure is written to the run log and to ops/CAMPAIGN_FAILURE-<time>-V1.0.json.
"""
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
from pathlib import Path
import argparse
import ctypes
import datetime
import json
import platform
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
import campaign as c
import conditions as cond

LOCK = ROOT / "campaign/RUNNING.lock"
STATUS = ROOT / "campaign/STATUS.json"
COMPLETION = ROOT / "ops/CAMPAIGN_COMPLETION-V1.0.json"
LOG_DIR = ROOT / "logs"
EXIT_STOPPED, EXIT_ALREADY_RUNNING = 3, 4
_log_file = None


class AlreadyRunning(RuntimeError):
    pass


def stamp():
    return datetime.datetime.now().strftime("%Y%m%dT%H%M%S")


def say(message):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%H:%M:%S"), message)
    try:
        print(line, flush=True)
    except Exception:
        pass
    if _log_file is not None:
        try:
            _log_file.write(line + "\n")
            _log_file.flush()
        except Exception:
            pass


def process_start(pid):
    """Opaque start-time token of a live process, or None when no live process has this id.

    Stored in the lock, so that a process id reused by another program is not mistaken for this study.
    """
    pid = int(pid)
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return None
        try:
            code = wintypes.DWORD()
            if kernel.GetExitCodeProcess(handle, ctypes.byref(code)) and code.value != 259:
                return None
            times = [wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetProcessTimes(handle, *[ctypes.byref(t) for t in times]):
                return "nt:unknown"
            return "nt:%d" % ((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)
        finally:
            kernel.CloseHandle(handle)
    try:
        text = Path("/proc/%d/stat" % pid).read_text()
        fields = text[text.rfind(")") + 2:].split()
        return None if fields[0] == "Z" else "proc:" + fields[19]
    except FileNotFoundError:
        pass
    except OSError:
        return "posix:unknown"
    if Path("/proc/self/stat").exists():
        return None                          # /proc is available and has no such process
    try:
        os.kill(pid, 0)
        return "posix:unknown"
    except ProcessLookupError:
        return None
    except PermissionError:
        return "posix:unknown"


def keep_awake(enable):
    """While this process runs, ask Windows not to sleep on its own (display may still turn off)."""
    if os.name != "nt":
        return False
    try:
        return bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | (0x00000001 if enable else 0)))
    except Exception:
        return False


def console_setup():
    if os.name != "nt":
        return
    try:
        kernel = ctypes.windll.kernel32
        handle = kernel.GetStdHandle(-10)
        mode = ctypes.c_uint32()
        if kernel.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel.SetConsoleMode(handle, (mode.value & ~0x0040) | 0x0080)    # no freeze on mouse selection
        kernel.SetConsoleTitleW("EEG deneyi (S1/W5) - durdurmak icin bu pencereyi kapatin")
    except Exception:
        pass


def environment_record():
    """Informational snapshot (driver, power, disk). Not a gate; the gate is the frozen runtime check."""
    record = dict(observed_utc=c.now_utc(), host=platform.node(), platform=platform.platform(),
                  python=sys.version, python_executable=sys.executable, runtime=c.runtime(), errors=[])

    def attempt(name, function):
        try:
            record[name] = function()
        except Exception as error:
            record["errors"].append("%s: %s: %s" % (name, type(error).__name__, error))

    def nvidia():
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.used,temperature.gpu",
                              "--format=csv,noheader"], capture_output=True, text=True, encoding="utf-8",
                             errors="replace", timeout=60)
        return out.stdout.strip()

    def power():
        class Status(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", ctypes.c_ulong), ("BatteryFullLifeTime", ctypes.c_ulong)]
        status = Status()
        ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status))
        return dict(ac_line={0: "battery", 1: "plugged_in"}.get(status.ACLineStatus, "unknown"),
                    battery_percent=int(status.BatteryLifePercent))

    def disk():
        import shutil
        usage = shutil.disk_usage(str(ROOT))
        return dict(total_bytes=usage.total, free_bytes=usage.free)

    def versions():
        import torch
        return dict(cudnn=torch.backends.cudnn.version())

    attempt("nvidia_smi", nvidia)
    attempt("disk", disk)
    attempt("versions", versions)
    if os.name == "nt":
        attempt("power", power)
    target = ROOT / "ops" / ("ENVIRONMENT-%s.json" % stamp())
    c.atomic_json(target, record)
    return record


def run_checks(study):
    """Generated-data checks on this very machine and device, before any real data is used."""
    device = study.device
    receipts = {}
    for script, extra in (("qa/test_core_training-V1.0.py", ["--device", device]),
                          ("qa/test_analysis-V1.0.py", [])):
        name = Path(script).stem.replace("-V1.0", "")
        receipt = ROOT / "ops/qa" / ("%s-%s-%s.json" % (name, device, stamp()))
        receipt.parent.mkdir(parents=True, exist_ok=True)
        say("Kontrol calisiyor: %s" % script)
        argv = [sys.executable, "-X", "utf8", "-B", str(ROOT / script), "--receipt", str(receipt)] + extra
        result = subprocess.run(argv, cwd=str(ROOT), env=os.environ.copy(), capture_output=True, text=True,
                                encoding="utf-8", errors="replace")
        (receipt.with_suffix(".stdout.txt")).write_text(result.stdout + "\n--- stderr ---\n" + result.stderr,
                                                         encoding="utf8")
        c.require(result.returncode == 0 and receipt.is_file(), "Check failed: %s\n%s" % (script, result.stderr[-2000:]))
        value = c.read(receipt)
        c.require(value["status"].startswith("PASS") and all(
            c.sha(c.local(rel)) == digest for rel, digest in value["code_sha256"].items()),
            "Check receipt is not a pass for the frozen code: " + script)
        say("  gecti: %s (%d kontrol)" % (value["status"], value["checks"]))
        receipts[script] = dict(receipt=str(receipt.relative_to(ROOT)).replace("\\", "/"), sha256=c.sha(receipt),
                                status=value["status"], checks=value["checks"], device=value.get("device"))
    return receipts


def counts():
    return dict(fit_records=len(list((ROOT / "campaign/fit_records").glob("*.json"))),
                test_records=len(list((ROOT / "campaign/test_records").glob("*.json"))))


def human(seconds):
    if seconds is None:
        return "?"
    minutes = int(seconds // 60)
    return "%d sa %02d dk" % (minutes // 60, minutes % 60)


STAGE_NAMES = {"TRAIN_REPRODUCTION_SAMPLE": "Ornek egitim (arsivle karsilastirilacak)",
               "TRAIN_NEW_CONDITIONS": "Yeni kosul egitimi (S1, W5)",
               "TRAIN_REFERENCE_CONDITIONS": "Eski dort kosulun yeniden egitimi"}


def acquire_lock(lease, protocol_sha256, resume):
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    if LOCK.exists():
        try:
            old = c.read(LOCK)
            readable = isinstance(old, dict) and "pid" in old
        except (ValueError, OSError):
            old, readable = None, False
        if readable:
            live = process_start(old["pid"])
            same = live is not None and old.get("process_start") in (None, live)
            if same:
                raise AlreadyRunning("Ayni calisma zaten acik (PID %s); ikincisi baslatilmadi." % old["pid"])
            c.require(resume and old.get("protocol_sha256") == protocol_sha256, "Only an explicit same-protocol resume")
            c.archive_orphan(LOCK, "Earlier process confirmed dead; explicit same-protocol resume")
            say("Onceki yarim kalan calisma kaldigi yerden surduruluyor.")
        else:
            c.archive_orphan(LOCK, "Unreadable lock file treated as stale")
            say("Okunamayan eski kilit dosyasi kenara alindi.")
    with LOCK.open("x", encoding="utf8") as stream:
        json.dump(lease, stream)


def other_owner_alive():
    try:
        old = c.read(LOCK)
        live = process_start(old["pid"])
        return live is not None and old.get("process_start") in (None, live)
    except Exception:
        return False


def honour_stop_file():
    """A stop request is used once: the file is moved aside so that the next start runs normally."""
    if c.STOP_FILE.exists():
        target = c.STOP_FILE.with_name(c.STOP_FILE.name + ".honoured-" + stamp())
        try:
            os.replace(c.STOP_FILE, target)
        except OSError:
            pass


def campaign(protocol, protocol_sha256, resume, fixed_sha256, owned):
    say("S1/W5 kontrol calismasi basliyor. Protokol SHA-256: %s" % protocol_sha256)
    say("Baslangic dogrulamasi (protokol, kod ve kaynak dosyalarin ozetleri) yapiliyor...")
    study = c.validate_protocol(protocol, protocol_sha256, check_runtime=True)
    if not study.engineering:
        c.require(fixed_sha256 is not None and study.p["fixed_content_sha256"] == fixed_sha256,
                  "The protocol's prespecified part is not the one this launcher was written for")
    say("Dogrulama tamam. Kip: %s. Cihaz: %s." % ("MUHENDISLIK DENEMESI" if study.engineering else "GERCEK", study.device))
    lease = dict(pid=os.getpid(), process_start=process_start(os.getpid()), protocol_sha256=protocol_sha256,
                 started_utc=c.now_utc(), host=platform.node())
    acquire_lock(lease, protocol_sha256, resume)
    owned.update(lock=True, lease=lease)
    awake = keep_awake(True)
    say("Bu pencere acikken bilgisayar kendiliginden uykuya gecmez: %s" % ("evet" if awake else "ayarlanamadi"))
    last = dict(time=0.0, counts=counts(), fit=None, stage=None, warned=False, test_line=0)

    def status(**fields):
        """Progress for the console, the log and STATUS.json. Never allowed to stop the campaign."""
        try:
            now = time.time()
            if now - last["time"] > 10:
                last["counts"] = counts()
                last["time"] = now
            stage = fields.get("stage", "")
            fit = fields.get("fit_id")
            if stage in STAGE_NAMES and fit and fit != last["fit"]:
                last["fit"] = fit
                say("%s %d/%d  %s  (bu asamada kalan sure: %s)" % (
                    STAGE_NAMES[stage], fields.get("stage_done", 0) + 1, fields.get("stage_total", 0), fit,
                    human(fields.get("stage_eta_seconds"))))
            elif stage == "REFERENCE_SOURCE_DECIDED" and stage != last["stage"]:
                if fields.get("reference_source") == "ARCHIVE":
                    say("KARAR: eski dort kosul ARSIVDEN alinacak (ornek egitimler ve W5-W4 baglantisi arsivle ayni).")
                else:
                    say("KARAR: eski dort kosul BU CALISMADA YENIDEN EGITILECEK (%s). Kalan egitim: %s." % (
                        fields.get("decision_status"), fields.get("remaining_reference_fits")))
            elif stage == "MODELS_FROZEN" and stage != last["stage"]:
                say("Butun modeller donduruldu (%s egitim). Ikinci gun verisi ancak simdi aciliyor." % fields.get("fits"))
            elif stage == "SAMPLE_TEST_COMPARED" and stage != last["stage"]:
                say("Ornek egitimlerin test ciktilari arsivle karsilastirildi: %s" % fields.get("comparison_status"))
            elif stage in ("TEST_REPRODUCTION_SAMPLE", "TEST_DAY2"):
                done, total = fields.get("stage_done", 0), fields.get("stage_total", 0)
                if stage != last["stage"] or done - last["test_line"] >= 100:
                    last["test_line"] = done
                    say("%s: %d/%d" % ("Ornek testleri" if stage == "TEST_REPRODUCTION_SAMPLE" else "Testler", done, total))
            last["stage"] = stage or last["stage"]
            c.atomic_json(STATUS, dict(lease, status="RUNNING", counts=last["counts"], updated_utc=c.now_utc(), **fields))
        except Exception as error:
            if not last["warned"]:
                last["warned"] = True
                say("Uyari: durum dosyasi yazilamadi (%s); calisma suruyor." % type(error).__name__)

    status(stage="ENVIRONMENT")
    environment = environment_record()
    say("Ortam: %s" % json.dumps(environment.get("runtime"), ensure_ascii=False))
    if study.engineering and study.p.get("engineering_skip_generated_data_checks") is True:
        receipts = {}
        say("Muhendislik denemesi: yapay veri kontrolleri bu baslatmada atlandi.")
    else:
        status(stage="GENERATED_DATA_CHECKS")
        receipts = run_checks(study)
    status(stage="VALIDATED_START")
    state = c.Campaign(study, status).run()
    if state == "STOPPED_AFTER_CURRENT_FIT":
        honour_stop_file()
        c.atomic_json(STATUS, dict(lease, status=state, counts=counts(), updated_utc=c.now_utc()))
        say("Istek uzerine durduruldu (calisan egitim bittikten sonra). Yeniden baslatinca kaldigi yerden surer.")
        return state
    say("Egitim ve test tamam. Sonuc hesabi calisiyor...")
    status(stage="FINAL_ANALYSIS")
    argv = [sys.executable, "-X", "utf8", "-B", str(ROOT / "analysis/final_analysis.py"),
            "--protocol", str(c.PROTOCOL), "--protocol-sha256", protocol_sha256]
    result = subprocess.run(argv, cwd=str(ROOT), env=os.environ.copy(), capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    (LOG_DIR / ("analysis-%s.txt" % stamp())).write_text(result.stdout + "\n--- stderr ---\n" + result.stderr,
                                                         encoding="utf8")
    c.require(result.returncode == 0, "Final analysis failed:\n" + result.stderr[-3000:])
    results_path = ROOT / "final_analysis/RESULTS-V1.0.json"
    results = c.read(results_path)
    c.require(results["status"] == "COMPLETE_S1_W5_CONTROL_ANALYSIS_VERIFIED", "Final analysis not verified")
    for relative, digest in study.b.get("protected", {}).items():
        c.require(c.sha(c.project_path(relative)) == digest, "A protected delivery file changed: " + relative)
    complete = dict(status="COMPLETE", protocol_sha256=protocol_sha256,
                    engineering_fixture_only=study.engineering,
                    reference_source=results["reference_source"], counts=results["counts"],
                    model_freeze_sha256=c.sha(c.MODEL_FREEZE), test_completion_sha256=c.sha(c.TEST_COMPLETION),
                    results_sha256=c.sha(results_path), no_test_driven_changes=True)
    if COMPLETION.exists():
        prior = c.read(COMPLETION)
        c.require(all(prior.get(k) == v for k, v in complete.items()),
                  "A repeated run changed the completed scientific record")
    else:
        c.atomic_json(COMPLETION, dict(complete, completed_utc=c.now_utc(), generated_data_checks=receipts))
    c.atomic_json(STATUS, dict(lease, status="COMPLETE", stage="VERIFIED_COMPLETE", counts=counts(),
                               updated_utc=c.now_utc()))
    say("TAMAMLANDI. Kaynak: %s. Sonuclar: final_analysis klasorunde." % results["reference_source"])
    return "COMPLETE"


def main(protocol, protocol_sha256, resume, fixed_sha256=None):
    global _log_file
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    _log_file = (LOG_DIR / ("run-%s.log" % stamp())).open("a", encoding="utf8")
    console_setup()
    owned = dict(lock=False, lease=None)
    try:
        return campaign(protocol, protocol_sha256, resume, fixed_sha256, owned)
    except AlreadyRunning as error:
        say(str(error))
        raise
    except BaseException as error:
        text = traceback.format_exc()
        failure = dict(status="FAILED", pid=os.getpid(), protocol_sha256=protocol_sha256,
                       error_type=type(error).__name__, error=str(error), traceback=text, failed_utc=c.now_utc(),
                       held_the_lock=owned["lock"])
        try:
            c.atomic_json(ROOT / ("ops/CAMPAIGN_FAILURE-%s-V1.0.json" % stamp()), failure)
            if owned["lock"] or not other_owner_alive():      # never overwrite the status of a live run
                c.atomic_json(STATUS, dict(owned["lease"] or {}, counts=counts(), **failure))
        except Exception:
            pass
        say("DURDU (hata): %s: %s" % (type(error).__name__, error))
        say(text)
        raise
    finally:
        keep_awake(False)
        if owned["lock"] and LOCK.exists():
            try:
                LOCK.unlink()
            except OSError:
                pass


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--protocol-sha256", required=True)
    parser.add_argument("--fixed-sha256", default=None,
                        help="SHA-256 of the prespecified part of the protocol (required for the real campaign)")
    parser.add_argument("--resume", action="store_true")
    arguments = parser.parse_args()
    try:
        outcome = main(arguments.protocol, arguments.protocol_sha256, arguments.resume, arguments.fixed_sha256)
    except SystemExit:
        raise
    except AlreadyRunning:
        sys.exit(EXIT_ALREADY_RUNNING)
    except BaseException:
        sys.exit(1)
    print(outcome)
    sys.exit(EXIT_STOPPED if outcome == "STOPPED_AFTER_CURRENT_FIT" else 0)
