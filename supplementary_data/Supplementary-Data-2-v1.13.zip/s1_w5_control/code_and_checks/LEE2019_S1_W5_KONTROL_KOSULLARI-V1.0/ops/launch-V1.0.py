"""Single entry point of the S1/W5 control study (started by BASLAT-V1.0.cmd).

First start on the campaign computer
  1. Preflight: software of this computer against the software of the archived fits; source bindings
     and earlier code in place; no campaign output yet.
  2. Generated-data checks on this computer and device (no EEG, no archived result is opened):
     training core, analysis functions, and a complete dry run of the pipeline.
  3. Protocol freeze: the prespecified content (fixed before the launch, identified by the SHA-256
     given on the command line) plus the machine facts of this computer. Written once.
  4. Campaign (ops/run_campaign-V1.0.py).

Later starts skip steps 1-3 and resume the campaign under the same protocol.

Exit codes: those of the runner (0 complete, 3 stopped on request, 4 already running, 1 failure);
2 when the preflight, a check or the freeze fails. In that case no real training has started.
"""
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
from pathlib import Path
import argparse
import datetime
import importlib.util
import json
import shutil
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
RUNNER = ROOT / "ops/run_campaign-V1.0.py"
FREEZE_RECORD = ROOT / "records/PROTOCOL_FREEZE_RECORD-V1.0.json"
PREFLIGHT = ROOT / "ops/preflight"
SHIPPED = ROOT / "records/prelaunch"
LOG_DIR = ROOT / "logs"
DEVICE = "cuda"
EXIT_PREFLIGHT = 2
# name, script, takes --device, approximate duration shown to the user
CHECKS = (("core", "qa/test_core_training-V1.0.py", True, "1-3 dakika"),
          ("analysis", "qa/test_analysis-V1.0.py", False, "birkac saniye"),
          ("dryrun", "qa/test_campaign_dryrun-V1.0.py", True, "10-20 dakika"))
_log_file = None


def stamp():
    return datetime.datetime.now().strftime("%Y%m%dT%H%M%S")


def say(message):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%H:%M:%S"), message)
    try:
        print(line, flush=True)
    except Exception:
        pass
    if _log_file is not None:
        try:
            _log_file.write(line + "\n")
            _log_file.flush()
        except Exception:
            pass


def need(value, message):
    if not value:
        raise RuntimeError(message)


def window_setup():
    """Windows only, best effort; nothing here can stop the launch.

    While this window is open the computer does not go to sleep by itself (the display may still turn
    off), and a mouse click inside the window does not freeze the program. Returns the power source.
    """
    if os.name != "nt":
        return None
    power = None
    try:
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    except Exception:
        return None
    try:
        kernel.SetThreadExecutionState.argtypes = (wintypes.DWORD,)
        kernel.SetThreadExecutionState.restype = wintypes.DWORD
        kernel.SetThreadExecutionState(0x80000000 | 0x00000001)       # continuous, system required
    except Exception:
        pass
    try:
        kernel.GetStdHandle.argtypes = (wintypes.DWORD,)
        kernel.GetStdHandle.restype = wintypes.HANDLE
        kernel.GetConsoleMode.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel.GetConsoleMode.restype = wintypes.BOOL
        kernel.SetConsoleMode.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel.SetConsoleMode.restype = wintypes.BOOL
        handle = kernel.GetStdHandle(0xFFFFFFF6)                      # console input
        mode = wintypes.DWORD()
        if handle and kernel.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel.SetConsoleMode(handle, (mode.value & ~0x0040) | 0x0080)   # quick-edit off
    except Exception:
        pass
    try:
        class Status(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]
        status = Status()
        kernel.GetSystemPowerStatus.argtypes = (ctypes.POINTER(Status),)
        kernel.GetSystemPowerStatus.restype = wintypes.BOOL
        if kernel.GetSystemPowerStatus(ctypes.byref(status)):
            power = {0: "battery", 1: "plugged_in"}.get(status.ACLineStatus, "unknown")
    except Exception:
        pass
    return power


def load_freezer():
    spec = importlib.util.spec_from_file_location("s1w5_freeze_protocol", ROOT / "records/freeze_protocol-V1.0.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def valid_receipt(c, path, device):
    """A passed check of exactly the present code (and device, where the check has one)."""
    try:
        value = c.read(path)
        return bool(value["status"].startswith("PASS") and (device is None or value.get("device") == device)
                    and all(c.sha(c.local(rel)) == digest for rel, digest in value["code_sha256"].items()))
    except Exception:
        return False


def run_check(c, name, script, takes_device, duration):
    device = DEVICE if takes_device else None
    target = PREFLIGHT / ("%s-%s.json" % (name, device) if device else "%s.json" % name)
    if target.exists():
        if valid_receipt(c, target, device):
            say("Kontrol daha once gecti, yeniden kosulmadi: %s" % script)
            return target
        c.archive_orphan(target, "Check receipt of other code or without a pass; the check is repeated")
    say("Kontrol calisiyor (%s): %s" % (duration, script))
    argv = [sys.executable, "-X", "utf8", "-B", str(ROOT / script), "--receipt", str(target)]
    if takes_device:
        argv += ["--device", DEVICE]
    result = subprocess.run(argv, cwd=str(ROOT), env=os.environ.copy(), capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    (PREFLIGHT / ("%s-%s.output.txt" % (name, stamp()))).write_text(
        result.stdout + "\n--- stderr ---\n" + result.stderr, encoding="utf8")
    need(result.returncode == 0 and valid_receipt(c, target, device),
         "Kontrol gecmedi: %s\n%s\n%s" % (script, result.stdout[-1500:], result.stderr[-3000:]))
    say("  gecti: %s (%d kontrol)" % (c.read(target)["status"], c.read(target)["checks"]))
    return target


def preflight_and_freeze(c, fixed_sha256):
    freezer = load_freezer()
    PREFLIGHT.mkdir(parents=True, exist_ok=True)
    say("ON KONTROL: bu bilgisayarin yazilimi, eski egitimlerin yazilimiyla karsilastiriliyor...")
    need(c.fixed_content_sha256(freezer.fixed_content()) == fixed_sha256,
         "Paketteki onceden yazilmis protokol icerigi, baslaticinin bekledigi icerik degil.")
    runtime = c.runtime()
    say("  bu bilgisayar: %s" % json.dumps(runtime, ensure_ascii=False))
    for key, value in freezer.EXPECTED_RUNTIME.items():
        need(runtime.get(key) == value,
             "Yazilim, eski egitimlerin yapildigi yazilimdan farkli: %s = %r, beklenen %r. Hicbir egitim baslamadi."
             % (key, runtime.get(key), value))
    need(runtime.get("GPU"), "Ekran karti (CUDA) kullanilamiyor. Hicbir egitim baslamadi.")
    need(c.BINDINGS.is_file(), "Kaynak baglari dosyasi yok: data/SOURCE_BINDINGS-V1.0.json")
    for relative, digest in freezer.EXPECTED_EARLIER_CODE.items():
        need(c.sha(c.project_path(relative)) == digest, "Onceki calismanin kod dosyasi degismis: " + relative)
    for folder in ("campaign", "final_analysis"):
        need(not (ROOT / folder).exists() or not any((ROOT / folder).rglob("*")),
             "Protokol dondurulmadan once kampanya ciktisi bulunamaz: " + folder)
    free = shutil.disk_usage(str(ROOT)).free
    need(free > 5 * 1024 ** 3, "Diskte en az 5 GB bos yer gerekli (su an %.1f GB)." % (free / 1024 ** 3))
    runtime_path = PREFLIGHT / "RUNTIME.json"
    c.atomic_json(runtime_path, runtime)
    say("ON KONTROL: yapay veriyle kontroller bu bilgisayarin ekran kartinda kosuluyor (gercek veri acilmaz).")
    receipts = [run_check(c, *check) for check in CHECKS]
    relative = [str(path.relative_to(ROOT)).replace("\\", "/") for path in receipts]
    if SHIPPED.is_dir():                     # receipts made while the package was prepared (other machine, CPU)
        for path in sorted(SHIPPED.glob("*.json")):
            if valid_receipt(c, path, None):
                relative.append(str(path.relative_to(ROOT)).replace("\\", "/"))
    say("Protokol donduruluyor (bir kez yazilir)...")
    record = freezer.freeze(str(runtime_path), relative, fixed_sha256)
    say("Protokol donduruldu. SHA-256: %s" % record["protocol_sha256"])
    return record


def main(fixed_sha256):
    global _log_file
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    _log_file = (LOG_DIR / ("launch-%s.log" % stamp())).open("a", encoding="utf8")
    say("S1/W5 kontrol calismasi - baslatici. Onceden yazilmis protokol icerigi SHA-256: %s" % fixed_sha256)
    power = window_setup()
    if power == "battery":
        say("UYARI: bilgisayar prize takili degil. Uzun surecek; lutfen prize takin.")
    try:
        import campaign as c
        if c.PROTOCOL.exists() and not FREEZE_RECORD.exists():
            need(not (ROOT / "campaign").exists() or not any((ROOT / "campaign").rglob("*")),
                 "Protokol var ama dondurma kaydi yok ve kampanya ciktisi bulunuyor; elle inceleme gerekir.")
            c.archive_orphan(c.PROTOCOL, "Protocol file without its freeze record (interrupted freeze); frozen again")
        if not c.PROTOCOL.exists():
            need(not FREEZE_RECORD.exists(), "Dondurma kaydi var ama protokol dosyasi yok; elle inceleme gerekir.")
            preflight_and_freeze(c, fixed_sha256)
        record = c.read(FREEZE_RECORD)
        protocol_sha256 = c.sha(c.PROTOCOL)
        need(record["protocol_sha256"] == protocol_sha256 and record["fixed_content_sha256"] == fixed_sha256,
             "Protokol dosyasi, dondurma kaydindaki ya da baslaticidaki kimlikle uyusmuyor.")
    except BaseException as error:
        say("ON KONTROL BASARISIZ - hicbir gercek egitim baslamadi: %s: %s" % (type(error).__name__, error))
        say(traceback.format_exc())
        return EXIT_PREFLIGHT
    say("Kampanya baslatiliyor (protokol %s)." % protocol_sha256)
    _log_file.flush()
    argv = [sys.executable, "-X", "utf8", "-B", str(RUNNER), "--protocol", str(c.PROTOCOL),
            "--protocol-sha256", protocol_sha256, "--fixed-sha256", fixed_sha256, "--resume"]
    code = subprocess.call(argv, cwd=str(ROOT), env=os.environ.copy())
    say("Kampanya sureci bitti; cikis kodu %d." % code)
    return code


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixed-sha256", required=True,
                        help="SHA-256 of the prespecified protocol content, recorded before the launch")
    sys.exit(main(parser.parse_args().fixed_sha256))
