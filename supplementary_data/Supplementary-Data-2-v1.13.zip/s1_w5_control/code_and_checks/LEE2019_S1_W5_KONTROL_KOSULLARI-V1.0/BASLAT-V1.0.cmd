@echo off
setlocal
title EEG deneyi (S1/W5) - durdurmak icin bu pencereyi kapatin
cd /d "%~dp0"
set "PYEXE="
for /d %%D in ("C:\Doktora makale iy*") do (
  if exist "%%D\Lee2019-V1.0-env\Scripts\python.exe" set "PYEXE=%%D\Lee2019-V1.0-env\Scripts\python.exe"
)
if not exist "%~dp0logs" mkdir "%~dp0logs"
echo baslatici calisti: %date% %time% >> "%~dp0logs\BASLATICI.txt"
if not defined PYEXE goto :nopython
echo.
echo  Lee2019 - iki yeni kontrol kosulu: S1 ve W5
echo.
echo  Ilk baslatmada once bu bilgisayar denetlenir ve yapay veriyle kontroller kosulur.
echo  Bu on kontrol 15-25 dakika surer; gecmezse hicbir gercek egitim baslamaz.
echo  Sonra egitimler baslar. Bu pencere acik kaldikca deney ilerler.
echo.
echo  Durdurmak icin pencereyi kapatin; yeniden cift tiklayinca kaldigi yerden surer.
echo  Bilgisayar prize takili ve kapagi acik kalmalidir.
echo.
"%PYEXE%" -X utf8 -B "%~dp0ops\launch-V1.0.py" --fixed-sha256 9ebd967d29ef2585ac00f515f99cb5659679dab9190297e878649ff3b606b888
set "KOD=%errorlevel%"
echo cikis kodu %KOD%: %date% %time% >> "%~dp0logs\BASLATICI.txt"
echo.
if "%KOD%"=="0" goto :done
if "%KOD%"=="2" goto :preflight
if "%KOD%"=="3" goto :stopped
if "%KOD%"=="4" goto :already
echo  CALISMA DURDU. Cikis kodu %KOD%. Ayrinti logs klasorundedir.
echo  Pencere kapandiysa ya da elektrik kesildiyse: yeniden cift tiklayin, kaldigi yerden surer.
echo  Baska bir hata ise Claude'a haber verin; hicbir dosyayi silmeyin.
"%PYEXE%" -c "import sys; print(sys.version)" >> "%~dp0logs\BASLATICI.txt" 2>&1
goto :end
:done
echo  TAMAMLANDI. Sonuclar final_analysis klasorunde. Bu pencereyi kapatabilirsiniz.
goto :end
:preflight
echo  ON KONTROL GECMEDI. Hicbir gercek egitim baslamadi, hicbir sonuc uretilmedi.
echo  Ayrinti logs klasorundeki launch dosyasindadir. Claude'a haber verin.
goto :end
:stopped
echo  Istek uzerine durduruldu. Yeniden cift tiklayinca kaldigi yerden surer.
goto :end
:already
echo  Bu calisma zaten baska bir pencerede acik. Bu pencereyi kapatabilirsiniz.
goto :end
:nopython
echo HATA: Lee2019 Python ortami bulunamadi >> "%~dp0logs\BASLATICI.txt"
echo.
echo  HATA: Lee2019 Python ortami bulunamadi. Hicbir sey calistirilmadi.
echo  Beklenen yer: C:\Doktora makale iyilestirme calismalari\Lee2019-V1.0-env
echo  Claude'a haber verin.
set "KOD=1"
:end
echo.
pause
exit /b %KOD%
