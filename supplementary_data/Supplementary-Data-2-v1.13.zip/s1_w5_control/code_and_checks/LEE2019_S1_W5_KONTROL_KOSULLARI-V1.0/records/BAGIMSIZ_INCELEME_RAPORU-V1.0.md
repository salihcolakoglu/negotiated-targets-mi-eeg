<!-- Not (Claude, 12.11.2026): Bu dosya, protokol dondurulmadan once paketi inceleyen ayri yardimci oturumun raporunun degistirilmemis kopyasidir (SHA-256 4120f9a900869b121fa82a7aaf3e114a7d1ebc15b133f59ffc12263ac214a34d, 41611 bayt). Icindeki /home/claude/... yollari bulut hazirlik ortamina aittir; o ortam gecicidir. Rapordaki satir numaralari paketin inceleme anindaki haline aittir. Bulgulara ne yapildigi: records/INCELEMEYE_YANIT-V1.0.md -->

# REVIEW-1 — independent review of `LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0` before the protocol freeze

Reviewed package: `/home/claude/work/pkg/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/` (read only; the SHA-256 of every file under `/home/claude/work/pkg/` was recorded at the start and was identical at the end).
Launcher template: `/home/claude/work/launcher/BASLAT-V1.0.cmd.template`.
Earlier code used for comparison: `/home/claude/work/pkg/LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/`, `/home/claude/work/pkg/LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/`.

## 0. Summary

- **BLOCKER: none found.** I found no defect that would change a number: S1 and W5 do what the protocol says (checked bit for bit against loops I wrote independently from the protocol text), and the final analysis gives the same four contrasts as my own recomputation.
- **SHOULD-FIX: 9** (F01–F09). They concern (a) the fact that nothing has run on Windows/CUDA before a write-once freeze, (b) three protocol rules that are not fully specified, (c) four robustness gaps that can stop an unattended run and need a manual repair, and (d) blind spots of the package's own checks, which become unchangeable once the protocol is frozen.
- **MINOR: 13** (F10–F22). **NOTE: 8** (F23–F30).

What was run for this review (all on Linux, CPU, Python 3.13.18, torch 2.5.1+cu124, numpy 2.5.3, scipy 1.18.1 — not the real Windows/CUDA stack):

| What | Result |
|---|---|
| `qa/test_analysis-V1.0.py` (allowed check) | PASS, 65 checks. Receipt: `/home/claude/work/review/analysis.json` |
| `qa/test_core_training-V1.0.py --device cpu` (allowed check) | PASS, 326 checks, 181.6 s. Receipt: `/home/claude/work/review/core.json` |
| `qa/test_campaign_dryrun-V1.0.py` | **Not run by me.** The other process finished at 02:14 with PASS, 25 checks (`/home/claude/work/qa_out/dryrun_cpu_2.json`; its code hashes match the package). |
| My own probes (10 scripts, 12 kill-and-resume scenarios, 16 mutated copies, 2 altered-archive variants) | See sections 2 and 3. Scripts: `/home/claude/work/review/probes/`. Outputs: `/home/claude/work/review/logs/`. |

Note on side effects: my first core check ran for about 15 minutes at normal priority next to the other process's dry run and slowed it. I stopped it and ran everything afterwards at the lowest priority.

## 1. Direct answers to the seven points

1. **Scientific validity.** S1 and W5 as implemented match their definitions exactly (V01, V02). "S1 is bit-identical to S0 until the first moved target" is guaranteed by the structure of the code for phases 0 and 1 as long as predictions are finite, and I confirmed it (V03). Using the class-index loss while the target is exactly one-hot is defensible: it is the same loss mathematically, and on CPU the soft-target path with one-hot targets is bit-identical anyway, so the device changes nothing there (V04); on CUDA this is unknown until the launch check runs. Label-share matching is correct algebraically and to 6e-8 in float32 (V05). The linkage claim is correct (V06). I found no asymmetry in seeds, random-number consumption, data, normalisation, timing of updates, evaluation-mode predictions or number of updates (8 effective updates in S1, W1, W4, W5). Caveats: F04 (S1 answers "does the same rule change accuracy", not "does the same amount of target movement"), F02 (linkage is not acted on), F24.
2. **Statistics.** Unit, pairing, sign and arithmetic of the interaction, rounding, Holm and Wilcoxon are correct (V09, V10). Archive and campaign numbers are not mixed (V11). All-zero differences are handled; a constant non-zero difference is a degenerate case that cannot occur with real data (F23). "Immutable" outputs break a legitimate rerun after a torn write (F05).
3. **Code correctness.** No defect on the main path. Resume was exact in 12 kill-and-resume scenarios, including a half-written file, a finished checkpoint without record and leftover temp files (V12). The second-day gate is not bypassed by the campaign code (V15); its guard does not cover archived second-day outputs (F11). Validators accept some wrong data (F12, F13). The runner did not report COMPLETE wrongly in any scenario I tried; it exits with code 0 after a STOP request (F16). Robustness gaps: F05–F08, F18.
4. **Reproduction logic.** The right arrays are compared, never an array with itself; formats match the earlier code (V16). The comparison is value equality, not bit equality (F10). The decision is written once and survives kills before and after it (V13). Open rules: F02, F03.
5. **Windows 11.** Checked by reading only. Paths stay below 260 characters (V17), the launcher is ASCII with CRLF and correct quoting (V21). Risks: F01, F06, F07, F08, F16, F18.
6. **Consistency.** All numbers in the three documents match the code (V23). Discrepancies: F21, F15.
7. **Anything else.** F09 (the checks cannot see some errors), F15, F24, F01.

## 2. Numbered findings

Severity: BLOCKER = would invalidate results or crash the real run; SHOULD-FIX; MINOR; NOTE. Line numbers refer to the files under `/home/claude/work/pkg/LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/` unless another path is given.

### F01 — SHOULD-FIX — Nothing has been executed on the machine that will run it, and the freeze is write-once

- **Where:** `records/freeze_protocol-V1.0.py` lines 23–24 (`RUNTIME` is a constant), 41 (protocol written once), 86–88 (prelaunch note); `qa/test_core_training-V1.0.py` lines 40–45 (`EXPECTED_SOURCES`); `ops/run_campaign-V1.0.py` line 193 (runtime gate) and 149–171 (checks on the campaign device); launcher template lines 6–8.
- **What:** Every execution so far (the author's receipts, the dry run, this review) was on Linux, CPU, Python 3.13.18, numpy 2.5.3. The first execution on Windows, CUDA, Python 3.12.14, numpy 2.2.6 will be the real launch, after the protocol has been frozen together with the SHA-256 of all code and check files. The following stop the launch if they are wrong, and none can be checked here:
  1. `campaign.runtime()` must equal the `RUNTIME` dictionary exactly, including the GPU name string.
  2. The four `EXPECTED_SOURCES` hashes must equal the bytes of the earlier code on the PC (first check of the core QA). The copies here have CRLF line endings; a transfer that changed line endings would break this. `records/build_source_bindings-V1.0.py` line 130 records `earlier_code_sha256` on the real machine but does not compare it with `EXPECTED_SOURCES`.
  3. scipy must be importable in the Lee2019 environment (analysis and its check). Its version is unknown and not part of `RUNTIME`.
  4. No receipt of the core check on CUDA exists yet (bitwise old-versus-new loop, exact resume, the new soft-target path); the existing receipts are from a CPU.
  5. I found no evidence here that the `for /d %%D in ("C:\Doktora makale iy*")` search has been executed on the PC (the queue launcher that uses the same pattern was not copied there, see `/home/claude/work/devir/G210_EKLENEN_METIN-V1.0.md` section 5).
- **Why it matters:** None of these can corrupt a result; all fail before training. But each would leave a frozen protocol that cannot start. The repair is a new protocol version, which is the kind of post-freeze change the design is meant to avoid.
- **Fix:** Before freezing, run a preflight on the real machine that reads no EEG and trains no real model: print `campaign.runtime()` and the scipy version, run both generated-data checks with `--device cuda`, run `build_source_bindings`. Then let `freeze_protocol` (i) take `RUNTIME` from the preflight output, (ii) require the cuda receipts in `--prelaunch`, (iii) assert that `bindings["earlier_code_sha256"]` equals `EXPECTED_SOURCES`, (iv) include scipy in `RUNTIME`. A small second launcher with the same Python search would also test item 5.

### F02 — SHOULD-FIX — The W5/W4 linkage is computed for all 270 pairs but nothing depends on it

- **Where:** `analysis/final_analysis.py` lines 345–355 (comparison), 401 (status is always `..._VERIFIED`), 421–422 (reported as two counts, plus one CSV file); `records/freeze_protocol-V1.0.py` lines 144–146 ("must equal ... descriptive").
- **What:** Under the ARCHIVE rule the premise is "the present environment reproduces the archived fits". The linkage tests exactly that for every W4/W5 pair over three phases, and it uses training-side information only. Yet a failure has no consequence. Probe `p08_linkage.py`: with 0 of 6 pairs identical the analysis still returned `COMPLETE_S1_W5_CONTROL_ANALYSIS_VERIFIED`, and the runner would print "TAMAMLANDI". Under REFIT the W5 value is still compared with the archived W4, not with the campaign's own W4, so the result is uninformative there.
- **Why it matters:** Suppose the linkage came out identical in, say, 263 of 270 pairs. A referee who reads that next to "the archive was used because the environment reproduces it" will ask why the archive was still used. The rule must be written before the result is known.
- **Fix:** Decide before freezing. Either make the linkage part of the reference-source decision (it needs no second-day data; train the new fits before deciding), or make it a gate under ARCHIVE like the test-side comparison, or at least give it a distinct status and console line. Under REFIT compare W5 with the campaign's W4, which must be identical by construction and is a free self-check.

### F03 — SHOULD-FIX — A test-side mismatch under ARCHIVE is a dead end, and it is detected only after every new model has been tested

- **Where:** `code/campaign.py` lines 577–606 (line 604 raises), 777–778 (`test_all()` runs before `reproduction_test_check()`); `records/freeze_protocol-V1.0.py` lines 141–143.
- **What:** Variant T1 (`/home/claude/work/review/logs/variants.log`): training outputs reproduce, one archived test output differs. The campaign stops with "Training outputs matched the archive but test outputs do not; no statistics before a review", every relaunch stops the same way, and the standalone analysis also refuses. That is as designed. But the protocol does not say what happens next, and at that moment the second-day outputs and per-fit accuracies of all 540 new fits are already on disk (`campaign/test_records/`). A later switch to REFIT would then train 1,008 reference fits after second-day results of the new conditions exist.
- **Why it matters:** An unspecified rule decided after results exist is a forking path. The current order also makes the clean fallback impossible.
- **Fix:** Write the fallback into the protocol (for example: the reference source becomes REFIT and this is reported). In `test_all`, evaluate the re-trained sample fits first, run the comparison, and only then evaluate the new fits; a mismatch then stops before any second-day output of S1 or W5 exists.

### F04 — SHOULD-FIX — S1 applies the same rule, but nothing shows that it applies a comparable amount of target movement

- **Where:** `code/lee_core.py` lines 217–253 (soft path), 248 and 285 (distance = L2 norm over all outputs); `analysis/final_analysis.py` lines 340–343 (`target_displacement`); protocol `analysis.descriptive`.
- **What:** With softmax output the training-set probabilities sit close to the labels, so the negotiated target may hardly move (the protocol's own expectation says so). The interaction contrast then mixes two things: "the same target movement has a different effect" and "the output type changes how much the target moves". The only recorded measure, the L2 distance, is taken over 2 outputs for S1 and 16 for the Walsh conditions and is not comparable. In my generated-data run the S1 distance was 0.003–0.005 where W5 had 0.03–0.18 (`p05_reference_loops.py`; not predictive for EEG, but it shows the scale problem). Likewise, W1 and W5 targets may be nearly the same, because 73% of W1's non-label weight in its last used target sits on the three most recent predictions (35%, 23%, 16%).
- **Why it matters:** Without a manipulation check a null result for S1 − S0 or W1 − W5 cannot be interpreted, and adding one after seeing results looks post hoc.
- **Fix:** Prespecify as descriptive output: mean absolute target change per output unit; for Walsh also over the 8 bits in which the two code words differ; the share of trials whose target decodes to the other class (already recorded); and the distance between the last used targets of W1 and W5 for the same participant and seed. All of it can be derived from arrays that are saved anyway.

### F05 — SHOULD-FIX — A torn analysis output file makes every relaunch fail until someone deletes it by hand

- **Where:** `analysis/final_analysis.py` lines 85–91 (`immutable`: `open("xb")` then `write`, no temp file, no fsync).
- **What:** I truncated `final_analysis/RESULTS-V1.0.json` in a finished fixture, and separately emptied `participant_means.csv` (what a closed window or a power cut during the write leaves behind). Both times every relaunch failed with "Analysis output differs from an earlier run" and status FAILED. Deleting the file by hand restored the run and the outputs came back byte-identical.
- **Why it matters:** The window is short, but the repair is "delete a results file after the tests are done", which is the last thing one wants to do by hand in this study, and the README does not describe it.
- **Fix:** Write to a temp file, fsync, `os.replace` (as `campaign.atomic_json` does). Optionally write all files into a temp folder and rename the folder.

### F06 — SHOULD-FIX — Failures before the lock is taken are written to no file

- **Where:** `ops/run_campaign-V1.0.py` lines 186–204 run before the `try:` on line 222; lines 287–293 print the traceback to the console only. Launcher template line 32 says "Ayrinti logs klasorundedir".
- **What:** A wrong protocol or code hash, a changed source file, a runtime mismatch, "already running" and an unreadable lock all raise before the failure handler exists, so no `CAMPAIGN_FAILURE` file is written on this path. In my lock tests the run log had three lines and no error, and `STATUS.json` still said RUNNING from the earlier run.
- **Why it matters:** These are the most likely first-launch failures (see F01). Monitoring is done through files, so they are invisible remotely, and the launcher points the user to a log that contains nothing.
- **Fix:** Wrap the whole of `main()` in the failure handler, or at least write the traceback to the run log and a `CAMPAIGN_FAILURE` file in the `__main__` handler.

### F07 — SHOULD-FIX — A status-file write that fails for three seconds aborts the running fit and the campaign

- **Where:** `ops/run_campaign-V1.0.py` lines 209–214 (`status()` calls `atomic_json(STATUS, ...)` about ten times per fit, from inside the training loop); `code/campaign.py` lines 84–94 (six attempts, about 3.1 s).
- **What:** Probe `p10_status_blocked.py` makes `os.replace` onto `STATUS.json` fail the way Windows fails it while another program holds the file open. Result: "Atomic JSON replacement failed after 6 bounded attempts", campaign FAILED, no fit record. The relaunch resumed and the scientific content was identical.
- **Why it matters:** No result is harmed, but a cosmetic file can stop an unattended multi-hour run. `STATUS.json` is the file an outside reader (monitoring, antivirus, indexer) is most likely to hold open.
- **Fix:** Make `status()` best effort: catch the exception, log it once, continue.

### F08 — SHOULD-FIX — The stale-lock logic can refuse a legitimate relaunch, and an unreadable lock crashes every launch

- **Where:** `ops/run_campaign-V1.0.py` lines 51–76 (`pid_alive`), 196–204.
- **What:** (a) After a closed window the lock keeps the old PID. If Windows has given that PID to any other program, the relaunch stops with "Ayni calisma zaten acik (PID …)". I reproduced this with a lock whose PID belonged to an unrelated live process. (b) An empty or half-written lock file gives `JSONDecodeError` on every launch until it is deleted by hand (reproduced with an empty and with a truncated lock).
- **Why it matters:** Neither can change a result, but both leave the user stuck with a misleading message.
- **Fix:** Store the process start time in the lock and treat the lock as stale when the live process with that PID started later than the lock was written. Treat an unreadable lock as stale and move it to `ops/orphans`.

### F09 — SHOULD-FIX — The package's own checks cannot see several kinds of error, and they are frozen with the protocol

- **Where:** `qa/test_core_training-V1.0.py`, `qa/test_analysis-V1.0.py`, `qa/test_campaign_dryrun-V1.0.py` lines 285–292.
- **What:** I made 16 copies of the package with one deliberate defect each (`make_mutants.py`, results in `/home/claude/work/review/logs/mutants.log` and `variants.log`). Eleven were caught. Five passed every check:

| Defect put into a copy | Core check (326) | Analysis check (65) |
|---|---|---|
| S1 trains against its target one phase late (recorded targets unchanged) | **passes** | — |
| S1 always uses the soft loss (no one-hot device) | passes (equivalent on CPU, see V04) | — |
| Seeds averaged with the median instead of the mean | — | **passes** |
| Reference conditions always read from the archive, even under REFIT | — | **passes** |
| Differences not scaled to percentage points | — | **passes** |

  The first row means that no check ties the target actually fed to the loss in the new softmax branch to the recorded target. (My first build of that copy contained an error of my own and crashed at the resume stage; the repaired copy passes all 326 checks. Both runs are in the logs.) The last three rows mean that `final_analysis.run()` (aggregation, origin selection, scaling) is not tested against anything independent. The dry run does not close the gap: on a REFIT fixture whose archive differs from the refit (variant T2), the wrong analysis of row four changed S1 − S0 from −0.67 to +8.67 points while every REFIT assertion of the dry run evaluated to True (`p09_mutant_refit.py`). The reason is that in the dry run's own REFIT fixture archive and refit numbers are identical, and the "origin" label in the summary is derived from the decision, not from the files that were read. One qualification: in my variant I altered archived arrays without rewriting the archived records, so the analysis's replay of recorded metrics would have stopped that particular run; I switched the replay off in memory to imitate a real archive, which is consistent with its own records. The dry run also has no scenario for a test-side mismatch or for the STOP file.
- **Why it matters:** The current code is correct on all five points (V01, V09, V11). But the checks are what the protocol cites as evidence, and after the freeze they cannot be improved without a new version.
- **Fix:** Add to the core check a short independent loop for S1 and W5 and compare weights bit for bit (as `p05_reference_loops.py` does). Add to the dry run an independent recomputation of the four contrasts from the saved prediction files (as `p06_recompute.py` does), make the REFIT fixture's archived test outputs differ from the refit, and assert the per-row `origin` column of `run_metrics.csv`.

### F10 — MINOR — "Bit for bit" is value equality

- **Where:** `code/campaign.py` lines 522–523 (`np.array_equal`); `README-V1.0.md` line 37 and `PROTOKOL_OZETI-V1.0.md` line 51 ("bayt düzeyinde").
- **What:** −0.0 equals +0.0 under this comparison and NaN does not equal NaN. Files are not compared as bytes either (the Lee-format archive files are uncompressed, the new files compressed).
- **Why it matters:** No practical effect (sigmoid and softmax outputs and these targets cannot be −0.0), but the wording claims more than the code does.
- **Fix:** Compare `a.tobytes() == b.tobytes()` after the dtype and shape check, or say "identical arrays" in the documents.

### F11 — MINOR — The second-day guard does not cover archived second-day outputs

- **Where:** `code/campaign.py` lines 266–285 (guard), 321–332, 344–347 (`archive_fit_record`, never called).
- **What:** Before the freeze the guard blocks the bound second-day inputs and this study's prediction folder (V15). It does not block the archived prediction files. Reading `P_test` or `y_test` from a Lee-format archive, an archived W4 prediction file, or the archived test metrics in the JSON records all succeed before the freeze (`p04_guard.py`). The campaign code does not do this: only the training-side members are read. That is a convention, not an enforced rule. `archive_fit_record` is dead code that would return a record with `acc_test` in it.
- **Why it matters:** The archived test results are already known and cannot influence training, so nothing is leaked. But "enforced by a guard" is true only for part of what the documents call second-day data.
- **Fix:** Delete `archive_fit_record`. Let the guard refuse archived prediction files except inside `archive_train_arrays` (a depth counter like `_HASH_DEPTH`), and read only the named training-side members there.

### F12 — MINOR — The record validators take the fit identity from the record, not from the caller

- **Where:** `code/campaign.py` line 384 (`key = r["id"]`), line 473 (`key = r["fit_id"]`).
- **What:** A complete record of another fit stored under this fit's file name is accepted, and `Campaign.train` then treats the fit as done (`p07_validators.py`). The model freeze catches it later, with the unhelpful message "Complete model and normalizer artifact union". Also, numbers in a fit record that the analysis uses (`acc_train`, `used_target_dist_by_phase`, `last_target_dist`) are bound by nothing until the freeze.
- **Fix:** Pass the expected key to both validators and require equality. Optionally recompute `acc_train` from the saved training outputs when validating.

### F13 — MINOR — The standalone analysis trusts the manifests more than "standalone" suggests

- **Where:** `analysis/final_analysis.py` lines 262–265, 278–288.
- **What:** It checks the hash of every file listed in `MODEL_FREEZE` and `TEST_COMPLETION` and the number of entries, but not that the fit and test records it then reads are the listed ones. It accepts the decision file without checking that `status`, `reference_source`, `mismatched_fits` and `compared_fits` agree with each other and with the sample size, and it does not repeat the training-side comparison.
- **Fix:** Require the key sets of both manifests to equal the expected paths; check the decision record for internal consistency; optionally recompute the 72 comparisons.

### F14 — MINOR — scipy is outside the frozen runtime and the Wilcoxon method is left to scipy

- **Where:** `records/freeze_protocol-V1.0.py` lines 23–24; `analysis/final_analysis.py` line 206 (`method="auto"`).
- **What:** What "auto" does (exact, normal approximation, handling of ties and zeros) differs between scipy versions. Neither the version nor the method actually used is written to the results.
- **Fix:** Add scipy to `RUNTIME`, write `scipy.__version__` and the method into `RESULTS-V1.0.json`, or choose the method explicitly.

### F15 — MINOR — The analysis writes measures the protocol does not list, and wall-clock time sits inside the results file

- **Where:** `analysis/final_analysis.py` lines 147–164, 344; protocol `analysis.descriptive` (`records/freeze_protocol-V1.0.py` lines 162–164).
- **What:** Not listed but computed and written for every fit, participant and condition: posterior accuracy, bit-wise BCE, the three "scores divided by 8" calibration values, `train_seconds`. Because `train_seconds` is part of `RESULTS-V1.0.json` and three CSV files, two otherwise identical campaigns do not give identical result files. The first dry run (`/home/claude/work/logs/dryrun1.log`) failed on a byte comparison of `run_metrics.csv`; the check now ignores this column.
- **Fix:** List these measures in the protocol or drop them. Move timing to a separate file.

### F16 — MINOR — Stop request and launcher messages

- **Where:** `ops/run_campaign-V1.0.py` lines 230–233 (returns normally, exit code 0); `code/campaign.py` lines 681–682; launcher template lines 28–33; `README-V1.0.md` line 55.
- **What:** After a STOP request the launcher prints "Bitti." because the exit code is 0. The STOP file is never removed, so each further launch trains exactly one fit and stops; once all fits are trained the file is ignored and the campaign completes (scenario K14 in `kill_scenarios.log`). The README does not mention the STOP file. Once Python has run, the launcher ends with `pause` and returns 0 whatever Python returned. For an error that cannot be resumed (hash mismatch) it still says that a second double click continues.
- **Fix:** Use a distinct exit code and message for a stop, remove or rename the STOP file when it is honoured, add `exit /b %KOD%`, and describe the STOP file in the README.

### F17 — MINOR — The console and the run log do not show the reference-source decision, the freeze or the tests

- **Where:** `ops/run_campaign-V1.0.py` lines 215–220 (only `TRAIN…` stages are printed); `code/campaign.py` line 772.
- **What:** Between the last training line and "Egitim ve test tamam" nothing is printed; the decision ARCHIVE or REFIT appears only in the final line. For REFIT the user notices only that the counter says 1620 instead of 612.
- **Fix:** Print one line for the decision (with what it means for the remaining time), one for the freeze, and progress for the tests.

### F18 — MINOR — Two places without the Windows precautions used elsewhere

- **Where:** `code/campaign.py` lines 364–366 (`unlink` and `os.replace` in `archive_orphan` without the retry of `_replace`); `ops/run_campaign-V1.0.py` lines 160 and 238 (`text=True` decodes child output strictly).
- **Fix:** Use `_replace` in `archive_orphan`; pass `encoding="utf-8", errors="replace"` to `subprocess.run`.

### F19 — MINOR — A bytecode cache is inside the package

- **Where:** `code/__pycache__/` with three `cpython-313.pyc` files written at 01:10:13, before this review.
- **What:** They match the current sources and Python 3.12 will ignore them. They would still be copied to the PC, and the code-hash gate covers `.py` files only.
- **Fix:** Delete the folder before copying and freezing.

### F20 — MINOR — Checks that cannot fail or whose name says something else

- `qa/test_analysis-V1.0.py` line 63, "Decision-rule agreement is a share of trials" (9 checks): a mean of true/false values is always between 0 and 1.
- `qa/test_core_training-V1.0.py` line 240, "The target of the final update is saved but never trained against" (3 checks): it compares `Y_used_last` with the target used in the last phase, i.e. a target that was trained against. The final update is not in the training outputs at all, only in the checkpoint.
- Line 153, "Negotiation rate after phase p is 0.03 x p": compares `0.03 * p` with `0.03 * p`; it only pins the constant.
- Line 272, "With rate zero the S1 path is exactly S0": with rate zero the target never moves, so the class-index loss is used throughout and the soft path is never exercised.
- Lines 55–61, `reject()`: any `RuntimeError` or `ValueError` counts, whatever the reason. I read each case; they fail for the intended reason today.
- `qa/test_analysis-V1.0.py` lines 129–132: the Wilcoxon check calls scipy with the same arguments as the code under test.

### F21 — MINOR — Documentation discrepancies

1. `README-V1.0.md` line 55: "ikinci bir pencere açılırsa ikincisi kendini kapatır". In fact the second window shows a Python traceback and "Calisma durdu, cikis kodu 1 … Yeniden cift tiklayinca kaldigi yerden surer" and waits for a key.
2. `README-V1.0.md` line 37 and `PROTOKOL_OZETI-V1.0.md` line 51: "bayt düzeyinde" (see F10).
3. `README-V1.0.md` line 37 ("yalnız 540 yeni eğitim yapılır") and protocol text `reference_source_rule.archive` ("the campaign trains the 540 new fits"): under ARCHIVE the campaign trains 612 fits (72 + 540), as the protocol's own `counts` and README line 46–47 say.
4. `README-V1.0.md` line 38 "1.080 ek eğitim" versus line 47 "1.008 eğitim daha": both are defensible, but a reader sees two numbers for the same event.
5. Protocol `reference_source_rule.step_1` lists "training-set predictions, last used targets, normaliser". The code also compares the labels; the normaliser is compared only for S0, W0, W1 and the last used target only for Walsh conditions.
6. Protocol `analysis.descriptive` (see F15).
7. The README folder table omits `analysis\`, `records\` (two scripts), `data\preprocessors\`, `ops\orphans\`, `ops\qa\` and the launcher.

### F22 — MINOR — The README does not tell the user what must not be touched during the run

- **What:** The six v1.7 delivery files and the two archive folders are hash-checked at every launch and after the analysis. Saving one of the Word files, or moving a folder, stops the campaign for good under this protocol. The README also does not say what to do after "Calisma durdu".
- **Fix:** Two sentences in the README.

### F23 — NOTE — Two degenerate branches in the statistics

`analysis/final_analysis.py` line 184: for 54 equal non-zero differences (for example 0.2) `np.std` returns about 8e-17, not 0, so the special branch is not taken and the output is t ≈ 1.7e16, p = 0. `holm()` turns `None` or NaN into a number without complaint. Neither can be reached with real data; `paired()` always returns a finite p.

### F24 — NOTE — The four contrasts are tied to numbers that are already reported

Contrasts 3 and 4 add up to W1 − W4, and contrasts 1 and 2 add up to W1 − W0. Both sums are already known from the archive. The family therefore contains two new pieces of information, not four. Holm over four is conservative, but the paper should say that the pairs are not independent evidence and that this is a third family on the same second-day data.

### F25 — NOTE — Leftovers and fail-stop states

Temp files left by a kill are never cleaned (seen after K3, K4, K6, K10). A corrupted checkpoint stops every relaunch with "Checkpoint size or payload SHA mismatch" until it is removed by hand. `STATUS.json` keeps saying RUNNING after a kill; monitoring must look at `updated_utc` and the lock.

### F26 — NOTE — Cheap extra evidence that is not used

The normaliser and training labels are compared with the archive for the 9 sample participants only, although these training-side arrays exist in the archive for all 54. `build_source_bindings` checks participant, seed, condition, data hashes and device of every archived record but not the software versions and code hashes stored in the same record; comparing them with `RUNTIME` and `EXPECTED_SOURCES` at binding time would predict ARCHIVE or REFIT before the launch.

### F27 — NOTE — `assert` as gate

`records/build_source_bindings-V1.0.py` and `records/freeze_protocol-V1.0.py` use `assert` for their conditions; under `python -O` these disappear. Both write their output non-atomically (acceptable, they run once).

### F28 — NOTE — Path length

Under `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\` the longest path the campaign creates has 237 characters (the temp file of an orphan note). The margin to 259 is 22 characters, so the study folder must not be renamed longer or moved deeper.

### F29 — NOTE — The diff record

`records/LEE_CORE_DEGISIKLIKLERI-V1.0.diff` describes the change correctly (21 lines added, 3 removed). It has LF line endings while `lee_core.py` has CRLF, so it applies only after removing carriage returns.

### F30 — NOTE — Columns that invite wrong comparisons

`target_displacement` is not comparable between softmax and Walsh conditions (F04). `train_seconds` is not comparable between archive fits (plain loop) and campaign fits (with checkpoint overhead); the record says so, the CSV does not.

## 3. Verified and found correct

- **V01 — S1 is implemented as specified.** I wrote an independent loop from the protocol text (one-hot start, class-index loss while one-hot, soft-target cross-entropy afterwards, evaluation-mode predictions, `T − (T − P)·0.03·p` in float32). For two seeds, 6 phases × 2 epochs on generated data, weights, training outputs, last used target and per-phase target distances were bit-identical to `lee_core.fit_training_only` (`p05_reference_loops.py`).
- **V02 — W5 is implemented as specified.** Same method, label share computed as the plain product, earlier targets not carried forward: bit-identical for two seeds.
- **V03 — S1 equals S0 for the first two phases.** Bit-identical model state after two phases (my probe and check C of the core QA). The update after phase 0 leaves a one-hot target bit-identical for predictions of 0, 0.5 and 1.
- **V04 — The one-hot device is harmless.** On CPU, S1 without the device (soft loss throughout, also with the loss written out by hand) gives bit-identical weights. This fits the fact that both paths go through the same log-softmax and hand it the same gradient when the target is one-hot. Whether the same holds on CUDA is recorded by the core check in its receipt field `soft_target_loss_path_bitwise_equal_to_index_path_on_onehot`.
- **V05 — Label share.** `c_p = ∏(1 − 0.03k)` is the coefficient of the label in the W1 recurrence; values 0.97, 0.9118, 0.829738, 0.730169, 0.620644, 0.508928, 0.402053, 0.305560 match the table in `PROTOKOL_OZETI-V1.0.md`. In float32 the W1 and W5 shares differ by at most 6e-8. `float32(c) + float32(1 − c)` is exactly 1 for every update, and no target leaves [0, 1] even for a prediction of exactly 1 (`p01_targets.py`).
- **V06 — Linkage arithmetic.** The W5 update after phase 1 is bit-identical to the W4 update on 1.6 million values including 0, 1, the value just below 1 and the smallest float. W4 and W5 are identical through the third phase (core QA).
- **V07 — Declared changes.** The original core and the W4 core differ by the two lines of the W4 rule. The W4 core and the new core differ by exactly the declared lines. `lee_data.py` is byte-identical in all three packages.
- **V08 — Same call order as the archived runs.** Seed, build, move to device, fit: identical in `lee_train.py`, the W4 wrapper and the new wrapper (by reading); checkpoint and progress callbacks consume no random numbers.
- **V09 — The analysis numbers.** My recomputation from the saved prediction files (own decoder, own aggregation, `scipy.stats.ttest_1samp`, own Holm) agrees with `RESULTS-V1.0.json` and `participant_differences.csv` on the ARCHIVE fixture and on a REFIT variant (`p06_recompute.py`).
- **V10 — Pieces of the statistics.** Interaction sign and arithmetic; Holm equals a reference implementation on 2,000 random vectors; rounding to 10 decimals recovers exact multiples of 0.2 points; all-zero differences give t = 0, p = 1 (`p02_stats.py`).
- **V11 — No mixing of sources.** On variant T2 (REFIT, with archived test outputs altered so that archive and refit accuracies differ) the package's analysis used only campaign fits.
- **V12 — Resume.** Ten kill points with a hard exit (`os._exit`, no clean-up, like a closed window): before a checkpoint rename, in the middle of a checkpoint write, after the training outputs but before the record, in the middle of a record write, before the decision file, after the model freeze, after a prediction file, in the middle of a test record, before the test manifest, after the reproduction test. Plus two states prepared by hand: a finished checkpoint without record, with and without training outputs. In all twelve the relaunch completed, and fit outputs, predictions, model hashes and the contrast file were identical to the uninterrupted fixture (`kill_scenarios.log`).
- **V13 — The decision is written once.** With the decision file missing it is recomputed with the same result; with it present every launch repeats the comparison and requires the same outcome.
- **V14 — Test-side mismatch.** Variant T1 stops as designed, permanently, and the standalone analysis refuses as well.
- **V15 — Second-day inputs.** Before the freeze `np.load`, `open`, `os.open`, `Path.read_bytes`, `zipfile`, a relative spelling, a symlink and `shutil.copyfile` on a bound test file are all refused; hashing is allowed. From a Lee-format archive file only `P_train`, `y_train`, `Y_used_last`, `normalization_mean`, `normalization_sd` are read (I recorded the zip members actually opened) (`p03_npz.py`, `p04_guard.py`).
- **V16 — Formats.** Member names, dtypes and shapes written by `lee_train.py` and by the W4 wrapper are the ones the new code reads. Compressed versus uncompressed makes no difference. The normaliser survives the JSON round trip bit for bit. A wrong dtype or shape gives "not equal", never "equal".
- **V17 — Path lengths** (F28).
- **V18 — Python 3.12.** All 12 source files compile under Python 3.12.3 and use no syntax newer than 3.9.
- **V19 — Rerun and concurrency.** Starting a finished campaign again leaves `final_analysis` byte-identical. Of two simultaneous launches the second is refused and the first finishes unaffected.
- **V20 — Subprocess with a difficult interpreter path.** The unmodified runner, with its real checks and analysis as child processes, completed when started through `…/Doktora makale iyileştirme çalışmaları/Lee2019-V1.0-env/Scripts/python.exe` (`nonascii_interp.log`). This was on Linux; Windows quoting is covered only by reading.
- **V21 — Launcher.** ASCII only, CRLF, all paths quoted, the non-ASCII folder name reaches Python only through the wildcard, the exit code is captured immediately after Python. By reading.
- **V22 — Identity check.** `validate_identity` rejected all 11 malformed variants I tried (bool or float participant, out of range, upper-case or short digest, wrong rule, extra field, foreign condition, wrong scope).
- **V23 — Numbers in the documents.** Schedule table, 540 / 72 / 612 / 1,620 / 1,008, the sample, 7 updates per epoch and 2,100 per fit, 256 features, the four contrasts and their meaning all match the code.

## 4. Could not be verified here

- The real data, the real archives, and every hard-coded SHA-256 in `records/build_source_bindings-V1.0.py`. Archive formats were checked against the earlier code, not against files.
- Anything specific to Windows: `os.replace` on open files, closing the console, the `for /d` search, sleep behaviour, the real `MAX_PATH` limit.
- Anything specific to CUDA: determinism, the soft-target path, the launch checks on the GPU, the time estimates in the README.
- That `RUNTIME` equals what the PC reports, that scipy is installed there, and that the earlier code on the PC has the bytes the core check expects (F01).
- numpy 2.2.6 and Python 3.12.14 at run time (only a syntax compile under 3.12.3).

## 5. Verdict

The scientific core is sound: S1 and W5 are implemented exactly as specified, the analysis reproduces under independent recomputation, and interrupted runs resume to identical results. I would not freeze the protocol yet. The package should first be run once on the real machine in a mode that touches no EEG (F01), three rules should be written down before any result exists (F02, F03, F04), and the four small robustness gaps and the blind spots of the checks should be closed (F05–F09), because code and checks cannot be changed after the freeze without a new protocol version.

## 6. Files of this review

- Report: `/home/claude/work/review/REVIEW-1.md`
- Receipts of the two allowed checks: `/home/claude/work/review/analysis.json`, `/home/claude/work/review/core.json`
- Probe scripts: `/home/claude/work/review/probes/` (`p01_targets.py` … `p10_status_blocked.py`, `harness.py`, `killpoint.py`, `compare_fx.py`, `make_mutants.py`, `make_variant.py`, four driver scripts `run_*.sh`, `make_prefreeze_template.sh`)
- Probe outputs: `/home/claude/work/review/logs/probe_outputs.log` (probes p01–p08 and p10), `/home/claude/work/review/logs/kill_scenarios.log` (V12, F16), `/home/claude/work/review/logs/mutants.log` and `/home/claude/work/review/logs/variants.log` (F09, F03, V11, V14), `/home/claude/work/review/logs/lock_and_torn_output.log` (F05, F06, F08 and the wrong-analysis demonstration of F09), `/home/claude/work/review/logs/nonascii_interp.log` (V20), `/home/claude/work/review/logs/race_first.log` (V19)
- Package hashes at the start: `/home/claude/work/review/allpkg_sha_before.txt`
- One generated fixture kept so that the probes can be repeated: `/home/claude/work/review/fixtureA/` (71 MB, a copy of the other process's finished ARCHIVE fixture; generated data, marked engineering-only). Derived copies, the mutated code copies and their receipts were deleted so that no altered code or misleading PASS receipt stays on disk.
- Not saved to a log: the corrupted-checkpoint experiment quoted in F25 (run once interactively; the relaunch stopped twice with "Checkpoint size or payload SHA mismatch").

Reviewer: Claude (Anthropic), model id `claude-fable-5-2` as given by the session configuration. Independent pre-freeze review; the reviewer did not write the package. Environment: cloud Linux session, kernel 6.18.44, 2 CPU cores, 7 GB memory, no GPU; Python 3.13.18, torch 2.5.1+cu124 (CPU), numpy 2.5.3, scipy 1.18.1. Tools: shell, Python probes, file reading. Written 12.11.2026, 02:24 (UTC+03:00).
