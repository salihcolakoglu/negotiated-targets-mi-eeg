# Bağımsız incelemeye yanıt — V1.0

**Hazırlayan:** Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · **Tarih:** 12.11.2026 · **Günce:** G211

## Bu belge nedir?

Paket hazırlandıktan sonra, protokol dondurulmadan önce, işi yazan oturumun gerekçelerini görmeyen ayrı bir yardımcı oturuma (yine Claude) paketi baştan sona incelettim. İncelemenin kendi raporu İngilizce ve olduğu gibi yanda duruyor: `records\BAGIMSIZ_INCELEME_RAPORU-V1.0.md`. Bu belge o rapordaki 30 bulgunun her birine ne yapıldığını sade Türkçe ile yazar.

İncelemenin özeti: **sonucu değiştirecek bir hata bulunmadı.** S1 ve W5 protokolde yazdığı gibi çalışıyor (incelemeci protokol metninden kendi eğitim döngüsünü yazıp ağırlıkları bit düzeyinde karşılaştırdı) ve sonuç hesabı bağımsız yeniden hesapla aynı dört karşılaştırmayı veriyor. Bulguların 9'u "düzeltilmeli", 13'ü "küçük", 8'i "not" düzeyindeydi. İncelemeci protokolün o haliyle dondurulmamasını önerdi; öneriye uydum ve paketi aşağıdaki gibi yeniden düzenledim.

## Bulgular ve yapılanlar

| No | Bulgu (kısaca) | Ne yapıldı |
|---|---|---|
| F01 | Paket, çalışacağı bilgisayarda (Windows, ekran kartı) hiç denenmeden protokol bir kez yazılıp dondurulacaktı. | Protokol iki katmana ayrıldı. Bilimsel içerik başlatmadan önce yazıldı ve kimliği (SHA-256) günceye kaydedildi. Bilgisayara ait bilgiler ilk başlatmada eklenir: başlatıcı önce yazılımı eski eğitimlerin yazılımıyla karşılaştırır, sonra yapay veriyle üç kontrolü o bilgisayarın ekran kartında koşar; hepsi geçerse protokolü yazar. Geçmezse hiçbir gerçek eğitim başlamaz. (`ops\launch-V1.0.py`) |
| F02 | W5 ile W4 arasındaki "ilk güncelleme aynı olmalı" bağı 270 çift için hesaplanıyor ama hiçbir karar ona bağlı değildi. | Bağ, arşiv/yeniden eğitim kararının ikinci koşulu oldu. Bunun için sıra değişti: önce 72 örnek eğitim, sonra 540 yeni eğitim, sonra karar. Karar yalnız birinci gün bilgisine bakar. |
| F03 | Arşiv kuralı altında test tarafında fark çıkarsa ne olacağı yazılı değildi ve fark ancak bütün yeni modeller test edildikten sonra görülecekti. | Modeller dondurulduktan sonra önce 72 örnek eğitim test edilir ve arşivle karşılaştırılır; o anda S1 ve W5'in hiçbir test çıktısı yoktur. Fark çıkarsa çalışma durur. Yedek kural protokole yazıldı: kaynak "yeniden eğitim" olur, kayıtlı bir protokol ekiyle. |
| F04 | S1 aynı kuralı uyguluyor, ama hedefini W1 kadar oynatıp oynatmadığını gösteren bir ölçü yoktu. | Betimsel ölçüler önceden yazıldı: çıktı başına ortalama mutlak hedef değişimi; Walsh'ta ayrıca iki kod sözcüğünün ayrıştığı 8 bit üzerinden; hedefi öbür sınıfa dönen denemelerin payı; W1 ile W5'in son hedefleri arasındaki fark. Sıfıra yakın bir karşılaştırma bu ölçülerle birlikte okunacak. |
| F05 | Yarım yazılmış bir sonuç dosyası, elle silinene kadar her yeniden başlatmayı durdururdu. | Sonuç dosyaları artık önce geçici dosyaya yazılıp diske işlendikten sonra yerine konuyor. Windows'ta dosya bir an meşgulse sınırlı sayıda yeniden denenir. |
| F06 | Kilit alınmadan önceki hatalar hiçbir dosyaya yazılmıyordu. | Bütün yürütme tek bir hata yakalayıcının içine alındı; her hata çalışma günlüğüne ve `ops\CAMPAIGN_FAILURE-…json` dosyasına yazılır. |
| F07 | Durum dosyası üç saniye yazılamazsa çalışan eğitim ve bütün kampanya duruyordu. | Durum yazımı "elinden geleni yap" haline getirildi: yazılamazsa bir kez uyarır, çalışma sürer. |
| F08 | Eski kilit mantığı haklı bir yeniden başlatmayı reddedebiliyor, okunamayan bir kilit her başlatmayı çökertiyordu. | Kilide sürecin başlama zamanı yazılıyor; aynı numara başka bir programa geçtiyse karıştırılmaz. Okunamayan kilit eski sayılıp kenara alınır. |
| F09 | Paketin kendi kontrolleri bazı hata türlerini göremiyordu. | Eğitim çekirdeği kontrolüne S1 ve W5 için protokol metninden yazılmış bağımsız bir eğitim döngüsü eklendi (ağırlıklar bit düzeyinde karşılaştırılır). Kuru denemeye, dört karşılaştırmanın kayıtlı tahmin dosyalarından bağımsız yeniden hesabı ve beş senaryo eklendi: arşiv, durdur/öldür/yeniden başlat, örnek uyuşmazlığıyla yeniden eğitim, test tarafı uyuşmazlığı, bağ uyuşmazlığıyla yeniden eğitim. |
| F10 | "Bit düzeyinde aynı" denen karşılaştırma değer eşitliğiydi. | Karşılaştırma veri türü, boyut ve baytların eşitliği oldu. |
| F11 | İkinci gün koruması arşivdeki ikinci gün çıktılarını kapsamıyordu. | Koruma arşiv dizi dosyalarını da kapatıyor; yalnız birinci güne ait adlandırılmış üyeler okunabiliyor. Kullanılmayan işlev silindi. |
| F12 | Kayıt denetimleri eğitimin kimliğini çağırandan değil kaydın kendisinden alıyordu. | İki denetim de beklenen kimliği çağırandan alıyor. |
| F13 | Sonuç hesabı listelere gereğinden fazla güveniyordu. | Liste anahtarları beklenen yollarla birebir eşleşmek zorunda; karar kaydının iç tutarlılığı denetleniyor. |
| F14 | scipy dondurulan yazılım listesinde yoktu; Wilcoxon yöntemi scipy'nin seçimine bırakılmıştı. | scipy sürümü yazılım kaydına eklendi; Wilcoxon yöntemi açıkça sabitlendi (normal yaklaşım, sıfır farklar atılır, süreklilik düzeltmesi yok) ve sonuç dosyasına yazılıyor. |
| F15 | Sonuç hesabı protokolde sayılmayan ölçüler yazıyordu; süre bilgisi sonuç dosyasının içindeydi. | Betimsel ölçülerin tam listesi protokole yazıldı; süreler ayrı bir dosyaya alındı (`fit_timing.csv`). |
| F16 | Durdurma isteği ve başlatıcı iletileri. | Durdurmanın kendi çıkış kodu ve iletisi var; durdurma dosyası bir kez kullanılıp yeniden adlandırılıyor; README'de anlatıldı. |
| F17 | Pencere ve günlük, kaynak kararını, dondurmayı ve testleri göstermiyordu. | Karar (ve kalan süreye etkisi), dondurma ve test ilerlemesi için satırlar eklendi. |
| F18 | İki yerde Windows önlemleri eksikti. | Kenara alma işlemi yeniden denemeli hale getirildi; alt süreç çıktıları UTF-8 ve hataya dayanıklı okunuyor. |
| F19 | Paketin içinde derlenmiş Python önbelleği vardı. | Silindi; bütün betikler önbellek yazmadan çalıştırılıyor. |
| F20 | Hiç başarısız olamayacak ya da adı başka şey söyleyen kontroller. | Altı kontrol yeniden yazıldı: kurgulanmış bir uyuşmazlık örneği, hata iletisine bakan ret denetimi, açık yazılmış Wilcoxon hesabı ve doğru adlar. |
| F21 | Belgelerde tutarsızlıklar. | `README-V1.0.md` ve `PROTOKOL_OZETI-V1.0.md` yeni tasarıma göre baştan yazıldı (612 ve 1.620 sayıları, karşılaştırılan diziler, klasör tablosu, ikinci pencerenin davranışı). |
| F22 | README çalışma sırasında neye dokunulmaması gerektiğini söylemiyordu. | README'ye "dokunulmaması gerekenler" ve "pencere durdu derse" bölümleri eklendi. |
| F23 | İstatistikte iki uç durum. | Bütün farklar eşitse özel dal doğru çalışıyor; Holm düzeltmesi sonlu olmayan değeri reddediyor. İkisi de kontrol ediliyor. |
| F24 | Dört karşılaştırma daha önce raporlanmış iki sayıya bağlı. | Protokole ve README'ye bağımlılık notu yazıldı: aile iki yeni bilgi parçası ekler; aynı ikinci gün verisinde üçüncü ailedir. Makalenin Yöntem bölümüne de yazılacak. |
| F25 | Öldürülen çalışmadan kalan geçici dosyalar; öldürmeden sonra durum dosyası "çalışıyor" demeyi sürdürüyor. | Değişiklik yok: geçici dosyalar hiçbir denetimi etkilemez. İzlerken durum dosyasının güncellenme zamanına ve kilide bakılır. |
| F26 | Kullanılmayan ucuz ek kanıt. | Kaynak bağları yazılırken arşiv kayıtlarındaki yazılım sürümleri ve kod özetleri de toplanıyor ve 1.080 eğitimin tek bir yazılım bileşimiyle yapıldığı denetleniyor. Ölçekleme değerlerinin 54 kişinin hepsi için karşılaştırılması eklenmedi; 72 örnek eğitim ve 270 bağ yeterli görüldü. |
| F27 | Koşullar `assert` ile yazılmıştı. | Açık hata veren denetimlerle değiştirildi. |
| F28 | Yol uzunluğu: en uzun yol 237 karakter, sınıra 22 karakter var. | README'ye yazıldı: klasör daha derine taşınmamalı, adı uzatılmamalı. |
| F29 | Çekirdekteki değişiklik kaydı doğru, ama satır sonları farklı. | Bilgi notu: `LEE_CORE_DEGISIKLIKLERI-V1.0.diff` Unix satır sonludur, `lee_core.py` Windows satır sonludur; kayıt okunmak içindir, 21 satır eklenip 3 satır çıkarıldığını gösterir. |
| F30 | Yanlış karşılaştırmaya davet eden sütunlar. | Hedef kayması artık çıktı başına ölçülerle birlikte veriliyor; süreler sonuç dosyalarından çıkarıldı. |

## İncelemeden sonra eklenenler

- **Başlatıcı provası** (`qa\test_launch_rehearsal-V1.0.py`): ilk başlatmada olacakların (kontrol makbuzlarının yeniden kullanılması, protokolün bir kez yazılması, ret durumlarının hiçbir şey yazılmadan önce gerçekleşmesi, yarım kalan dondurmanın onarılması) bu hazırlık ortamında denenmesi. 17 kontrol.
- **Bilgisayarla aynı sürümlerle yeniden koşu:** bütün kontroller, deney bilgisayarındaki sürümlerle (Python 3.12, numpy 2.2.6, scipy 1.15.3, torch 2.5.1) kurulmuş ayrı bir ortamda yeniden koşuldu. Makbuzlar: `records\prelaunch\`.
- **Başlatıcıya üç küçük ek:** pencere açıkken bilgisayarın kendiliğinden uyumaması, pencereye tıklanınca programın donmaması, pilde çalışıyorsa uyarı.

## Bu hazırlık ortamında denenemeyenler

Hazırlık ortamı Linux'tur ve ekran kartı yoktur. Şunlar ancak deney bilgisayarında, ilk başlatmadaki ön kontrolde sınanır: Windows'a özgü dosya davranışı, ekran kartında bit düzeyinde tekrarlanabilirlik, süre tahminleri. Ön kontrol geçmezse hiçbir gerçek eğitim başlamaz ve hiçbir sonuç üretilmez.
