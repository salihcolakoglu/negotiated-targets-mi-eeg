"""Bind the unchanged inputs and the archived reference fits by SHA-256 (standard library only).

Nothing is decoded: files are hashed as bytes and small JSON records are read. Paths are stored
relative to the project root, with forward slashes, so that the same bindings work under Windows and
under the bridge's Linux view of the same folder.

Cross-checks made while binding:
  * each archived record names exactly the prepared train/test/meta bytes bound here;
  * each archived prediction file has the SHA-256 written in its record;
  * the prepared-file and W1 archive hashes equal those frozen for the W4 study on 20.10.2026;
  * the earlier studies are complete (1,350 and 270 fits) and their protocols have the recorded SHA-256;
  * the earlier code files on this computer are the ones the generated-data checks expect, and every
    archived record of the first Lee2019 study names exactly these code files;
  * the software recorded with the archived fits is one single combination (collected below);
  * the six v1.7 delivery files have the SHA-256 values recorded on 26.10.2026 (KD-20261026-02).
"""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
LEE = PROJECT / "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0"
W4 = PROJECT / "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0"
OUT = ROOT / "data/SOURCE_BINDINGS-V1.0.json"
LEE_PROTOCOL_SHA = "493378c9982feff6182216eb7406f68799e1435284cd80d39d91b258130fcab8"
W4_PROTOCOL_SHA = "1702e81efcc5dcadb04546acdcac6be90645aaac4b56fe238e57f939d73f49d4"
W4_BINDINGS_SHA = "46046bc951d53d7649f539530f5b0c285f04457e743ffc82880ee6e1ce99ad8c"
DELIVERY_V17 = {
    "IEEE_ACCESS_GONDERIM-v1.7/Archival-Addendum-v1.7.zip": "83d7ea27f70ce921d0048d0cfe421d996067ef987d877b9720d8e2988c5a829c",
    "IEEE_ACCESS_GONDERIM-v1.7/Cover-Letter-v1.7.docx": "3fb89dc8655f57ad70d3b32316c79a5de2ba9b429867f5ee5e022da18801e85f",
    "IEEE_ACCESS_GONDERIM-v1.7/Manuscript-IEEE-Access-v1.7.docx": "2b4c33c3f637b54ce916f7a2799265877e7bef09a3946860bcf55d80ac30ebf4",
    "IEEE_ACCESS_GONDERIM-v1.7/Supplementary-Archival-Addendum-v1.7.docx": "af3b6df8fd64492e3ceb39c8815aab27eb0225110dd2bba1d1e65311ccbbf713",
    "IEEE_ACCESS_GONDERIM-v1.7/Supplementary-Data-v1.7.zip": "5c1d2c5174311d8458f1b05b12d254bfe4dddddc3201db51108af036e46d9130",
    "IEEE_ACCESS_GONDERIM-v1.7/Supplementary-Information-v1.7.docx": "70439eb0fd1b57805e3c5b2ca6f5ccc8ea36d02dfb3bb7fe81d3b1bb394a26d1",
}
# The earlier code that the generated-data checks compare the new training core with.
EARLIER_CODE = {
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py": "5614c5fc08a1ed4e5f57596241d4dfafe5df5c027b8a17dce166108b8abd2638",
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_core.py": "bf1639f7afb931a2d7fa5c0ff7de10daaecd6b85a8ab539efd4809e0ca09ed48",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
}
PEOPLE = range(1, 55)
SEEDS = range(1, 6)


def need(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text("utf-8"))


def relative(path):
    return str(Path(path).resolve().relative_to(PROJECT.resolve())).replace("\\", "/")


def leaf(path):
    return dict(path=relative(path), sha256=sha(path))


def fit_id(subject, condition, seed):
    return f"subject_{subject:02d}_train__{condition}__seed{seed}"


def main():
    need(not OUT.exists(), "Bindings already exist; they are written once")
    need(sha(LEE / "DENEY_PROTOKOLU-V1.0.json") == LEE_PROTOCOL_SHA, "Lee protocol SHA")
    need(sha(W4 / "ANKRAJ_KAPI_PROTOKOLU-V1.0.json") == W4_PROTOCOL_SHA, "W4 protocol SHA")
    need(sha(W4 / "data/SOURCE_BINDINGS-V1.0.json") == W4_BINDINGS_SHA, "W4 bindings SHA")
    accounting = load(LEE / "final_analysis/completion_accounting.json")
    need(accounting["valid_completed_fits"] == 1350 and accounting["missing_fits"] == 0, "Lee study complete")
    w4_done = load(W4 / "ops/CAMPAIGN_COMPLETION-V1.0.json")
    need(w4_done["status"] == "COMPLETE" and w4_done["protocol_sha256"] == W4_PROTOCOL_SHA
         and w4_done["counts"] == dict(fits=270, preprocessors=54, tests=270), "W4 study complete")
    w4_bindings = load(W4 / "data/SOURCE_BINDINGS-V1.0.json")
    w4_protocol = load(W4 / "ANKRAJ_KAPI_PROTOKOLU-V1.0.json")
    for path, digest in EARLIER_CODE.items():
        need(sha(PROJECT / path) == digest, "Earlier code file differs from the bytes the checks expect: " + path)

    subjects = {}
    for s in PEOPLE:
        parts = {part: leaf(LEE / f"data/prepared/subject_{s:02d}_{part}.{ext}")
                 for part, ext in (("train", "npz"), ("test", "npz"), ("meta", "json"))}
        for part in parts:
            need(parts[part]["sha256"] == w4_bindings["subjects"][str(s)][part]["sha256"],
                 "Prepared file differs from the bytes bound for the W4 study: subject %d %s" % (s, part))
        subjects[str(s)] = parts

    archive, software = {}, {}
    for s in PEOPLE:
        data_sha = {part: subjects[str(s)][part]["sha256"] for part in ("train", "test", "meta")}
        for k in SEEDS:
            for condition in ("S0", "W0", "W1"):
                key = fit_id(s, condition, k)
                found = list((LEE / "results").glob(f"worker_*/records/{key}.json"))
                need(len(found) == 1, "Exactly one archived record: %s (%d found)" % (key, len(found)))
                record_path = found[0]
                r = load(record_path)
                prediction = record_path.parent.parent / r["prediction_file"]
                need(sha(prediction) == r["prediction_sha256"], "Archived prediction bytes changed: " + key)
                need(r["job"] == key and r["epochs_completed"] == 300 and r["n_train"] == 100
                     and r["n_test"] == 100 and r["final_test_evaluations"] == 1, "Archived record budget: " + key)
                identity = r["identity"]
                need(identity["subject"] == s and identity["seed"] == k and identity["condition"] == condition
                     and identity["data_sha256"] == data_sha and identity["device"] == "cuda",
                     "Archived record identity: " + key)
                need(identity["code_sha256"]["lee_core.py"] == EARLIER_CODE["LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py"]
                     and identity["code_sha256"]["lee_data.py"] == EARLIER_CODE["LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py"],
                     "Archived record was made by other code: " + key)
                combination = json.dumps(dict(python=identity["python"], numpy=identity["numpy"], torch=identity["torch"],
                                              cuda=identity["cuda"], GPU=identity["cuda_device"],
                                              threads=identity["threads"]), sort_keys=True)
                software[combination] = software.get(combination, 0) + 1
                entry = dict(format="lee", files=dict(record=leaf(record_path), prediction=leaf(prediction)))
                if condition == "W1":
                    old = w4_bindings["historical"][key]
                    need(old["record"]["sha256"] == entry["files"]["record"]["sha256"]
                         and old["prediction"]["sha256"] == entry["files"]["prediction"]["sha256"],
                         "W1 archive differs from the bytes bound for the W4 study: " + key)
                archive[key] = entry
            key = fit_id(s, "W4", k)
            fit_record = W4 / f"campaign/fit_records/{key}.json"
            test_record = W4 / f"campaign/test_records/{key}_day2.json"
            fit_outputs = W4 / f"campaign/fit_outputs/{key}.npz"
            prediction = W4 / f"campaign/predictions/{key}_day2.npz"
            f, t = load(fit_record), load(test_record)
            need(f["id"] == key and f["condition"] == "W4" and f["subject"] == s and f["seed"] == k
                 and f["epochs_completed"] == 300 and f["campaign_eligible"] is True
                 and f["protocol_sha256"] == W4_PROTOCOL_SHA and f["train_source_sha256"] == data_sha["train"]
                 and f["files"]["fit_outputs"]["sha256"] == sha(fit_outputs)
                 and len(f["used_target_dist_by_phase"]) == 10 and not any(name.endswith("_test") for name in f),
                 "Archived W4 fit record: " + key)
            need(t["fit_id"] == key and t["n_test"] == 100 and t["final_test_evaluations"] == 1
                 and t["protocol_sha256"] == W4_PROTOCOL_SHA and t["prediction_sha256"] == sha(prediction)
                 and t["source_fit_sha256"] == sha(fit_record), "Archived W4 test record: " + key)
            archive[key] = dict(format="w4", files=dict(fit_record=leaf(fit_record), fit_outputs=leaf(fit_outputs),
                                                        test_record=leaf(test_record), prediction=leaf(prediction)))
    combination = json.dumps(dict(w4_protocol["runtime"]), sort_keys=True)
    software[combination] = software.get(combination, 0) + 270
    need(len(software) == 1 and sum(software.values()) == 1080,
         "The archived fits were made with more than one software combination: %r" % (software,))

    protected = {}
    for path, expected in DELIVERY_V17.items():
        need(sha(PROJECT / path) == expected, "v1.7 delivery file differs from its recorded SHA-256: " + path)
        protected[path] = expected
    earlier_code = {relative(p): sha(p) for p in (LEE / "code/lee_core.py", LEE / "code/lee_data.py",
                                                  LEE / "code/lee_train.py", W4 / "code/lee_core.py",
                                                  W4 / "code/lee_data.py", W4 / "code/training.py",
                                                  W4 / "code/campaign.py")}
    record = dict(
        status="BOUND_INPUTS_AND_ARCHIVED_REFERENCE_FITS_BEFORE_S1_W5",
        created_trt=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat(),
        project_relative_paths=True,
        source_studies=dict(lee=dict(folder="LEE2019_BAGIMSIZ_DOGRULAMA-V1.0", protocol_sha256=LEE_PROTOCOL_SHA,
                                     completed_fits=1350),
                            w4=dict(folder="LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0", protocol_sha256=W4_PROTOCOL_SHA,
                                    source_bindings_sha256=W4_BINDINGS_SHA, completed_fits=270)),
        earlier_code_sha256=earlier_code,
        software_of_archived_fits=json.loads(next(iter(software))),
        subjects=subjects, archive=archive, protected=protected,
        counts=dict(subjects=len(subjects), prepared_files=3 * len(subjects), archived_fits=len(archive),
                    archived_files=sum(len(e["files"]) for e in archive.values()), protected_files=len(protected)),
        new_training=0, arrays_decoded=0,
        limits="Lee2019 results were examined in earlier studies. S0, W0, W1 and W4 are previously reported "
               "conditions used as paired references; they are not additional participants.")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(dict(status=record["status"], counts=record["counts"],
                          software_of_archived_fits=record["software_of_archived_fits"], sha256=sha(OUT))))


if __name__ == "__main__":
    main()
