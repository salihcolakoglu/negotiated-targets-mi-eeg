"""Write the protocol of the S1/W5 control study, once, before any real training.

The protocol has two layers.

  Prespecified content   Design, conditions, rules and analysis, written below as literals. Its SHA-256
                         (campaign.fixed_content_sha256) is recorded in the work journal before the launch
                         and is given to the launcher, which refuses any other content.
  Machine facts          Runtime of the campaign computer, SHA-256 of the code and of the source bindings,
                         receipts of the generated-data checks, time of the freeze. They are added at the
                         first launch, after the checks have passed on that computer and before any real
                         training. They cannot change the prespecified content.

Usage
  --print-fixed-sha256                      print the SHA-256 of the prespecified content; write nothing
  --runtime-json F --prelaunch R [R ...]    freeze: write PROTOKOL-V1.0.json and the freeze record
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
import conditions as cond

CODE = ("code/lee_core.py", "code/lee_data.py", "code/conditions.py", "code/training.py", "code/campaign.py",
        "ops/run_campaign-V1.0.py", "ops/launch-V1.0.py", "analysis/final_analysis.py",
        "qa/test_core_training-V1.0.py", "qa/test_analysis-V1.0.py", "qa/test_campaign_dryrun-V1.0.py",
        "records/build_source_bindings-V1.0.py", "records/freeze_protocol-V1.0.py")
# Software of the archived reference fits (18 and 20 October 2026). The campaign computer must match it.
EXPECTED_RUNTIME = dict(python="3.12.14", numpy="2.2.6", torch="2.5.1+cu124", cuda="12.4")
EXPECTED_EARLIER_CODE = {
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py": "5614c5fc08a1ed4e5f57596241d4dfafe5df5c027b8a17dce166108b8abd2638",
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_core.py": "bf1639f7afb931a2d7fa5c0ff7de10daaecd6b85a8ab539efd4809e0ca09ed48",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
}
REQUIRED_RECEIPTS = {"PASS_S1_W5_CORE_AND_TRAINING_GENERATED_QA": "cuda", "PASS_S1_W5_ANALYSIS_NUMERIC_QA": None,
                     "PASS_S1_W5_FULL_PIPELINE_DRY_RUN": "cuda"}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text("utf-8"))


def fixed_content():
    """Everything that is decided before the launch. No machine fact, no time, no hash of a file."""
    design = cond.REAL_DESIGN
    people, seeds = len(design["people"]), len(design["seeds"])
    sample = len(design["reproduction_sample"]["subjects"]) * len(design["reproduction_sample"]["seeds"]) * 4
    new = people * seeds * 2
    reference = people * seeds * 4
    return dict(
        schema="lee2019-s1-w5-control-conditions-v1",
        study_id=cond.STUDY_ID,
        status="FROZEN_BEFORE_S1_W5_CONTROL_CONDITIONS",
        timezone="Europe/Istanbul",
        authorization=dict(
            decision_record="CALISMA_DISIPLINI-V1.1/records/KD-20261112-01-CLAUDE_DEVIR_VE_YEREL_YURUTME-V1.0.json",
            journal_record="CALISMA_GUNCESI.md G210 and G211",
            user_statements=["[removed from the public copy]", "[removed from the public copy]",
                             "[removed from the public copy]"],
            executing_agent="Claude (Anthropic), configured model id claude-fable-5-2; the user starts the run by hand"),
        research_questions=[
            "S1: Does cumulative negotiation change accuracy when the network has an ordinary two-class softmax "
            "output instead of the Walsh-coded output (the cell missing from the output-type by negotiation design)?",
            "W5: Is the accuracy difference between the cumulative rule (W1) and the label-anchored ungated rule (W4) "
            "tied to carrying earlier predictions forward, or to the size of the prediction share in the target?"],
        design=design,
        counts=dict(new_fits=new, reproduction_sample_fits=sample, campaign_fits_if_archive=new + sample,
                    campaign_fits_if_refit=new + reference, participants=people, seeds=seeds),
        data_and_information=dict(
            dataset="Lee2019 motor imagery (OpenBMI), 54 participants, left versus right hand",
            train="The same prepared 100 first-day offline trials per participant (50 left, 50 right), 62 EEG "
                  "channels, 512 samples at 128 Hz, as in the earlier Lee2019 studies; bound by SHA-256.",
            test="The same separate 100 second-day offline trials; opened only after every model of this campaign "
                 "is frozen; one final evaluation per model.",
            normalization="First-day channel mean and population SD (+1e-6) over trials and time in float64; applied "
                          "to both days; input cast to float32.",
            no_adaptation="No test statistics, no model or seed selection, no early stopping, no temperature "
                          "scaling, no alignment or transfer."),
        conditions={
            "S0": "Softmax output (2 units), cross-entropy against the labels in all ten phases. Previously reported.",
            "S1": "Softmax output (2 units). Target T_0 = one-hot label. After each phase p (zero-based) the "
                  "training-set class probabilities P_p are computed in evaluation mode and "
                  "T_{p+1} = T_p - (T_p - P_p) * 0.03 * p (float32). Loss: cross-entropy between T and the "
                  "predicted class probabilities; while T is exactly one-hot (phases 0 and 1) this is the same "
                  "class-index loss as S0, so S1 and S0 coincide until the first moved target. NEW.",
            "W0": "Walsh output (16 sigmoid units), bit-wise binary cross-entropy against the fixed 16-bit code word. "
                  "Previously reported.",
            "W1": "Walsh output; cumulative negotiation T_{p+1} = T_p - (T_p - P_p) * 0.03 * p. Previously reported.",
            "W4": "Walsh output; label-anchored, ungated: T_{p+1} = (1 - 0.03 p) * Y + 0.03 p * P_p. Previously reported.",
            "W5": "Walsh output; label-anchored, ungated, label share matched to W1: "
                  "T_{p+1} = c_p * Y + (1 - c_p) * P_p with c_p = prod_{k=1..p} (1 - 0.03 k), the share of the label "
                  "left in the W1 target after the same updates. Earlier targets are not carried forward. NEW."},
        schedule=dict(
            note="Target used in each zero-based training phase. The update after the last phase is saved but "
                 "never trained against.",
            rows=cond.schedule(design["phases"])),
        training=dict(
            model="EEGNet-8,2 as released: temporal 8, depth multiplier 2, separable 16, 256 features, dropout 0.5, "
                  "max-norm 1 (depthwise) and 0.25 (classifier); original constructor and random-draw order.",
            optimizer="Adam 0.001, fresh per model, batch 16, 7 updates per epoch, 2,100 updates per fit.",
            budget="10 phases x 30 epochs = 300 epochs for every condition; terminal model only.",
            seeds="seeds 1..5: global seed and sample-order generator as in the earlier studies.",
            target_predictions="Predictions that enter a target are computed on the training set in evaluation "
                               "mode (dropout off, BatchNorm running statistics).",
            determinism="cudnn deterministic, benchmark off, torch.use_deterministic_algorithms(warn_only), "
                        "CUBLAS_WORKSPACE_CONFIG=:4096:8, two CPU threads; float32, no mixed precision.",
            resume="Phase-boundary checkpoints with model, BatchNorm, Adam, targets, sample-order generator and all "
                   "global random states; an interrupted fit continues exactly."),
        reference_source_rule=dict(
            why="The four reference conditions were fitted on this same computer on 18 and 20 October 2026. If the "
                "present environment reproduces them bit for bit, the archived fits are valid same-environment "
                "references and need not be fitted again.",
            sample="All four reference conditions for participants %s and seeds %s: %d fits, fixed before any run."
                   % (design["reproduction_sample"]["subjects"], design["reproduction_sample"]["seeds"], sample),
            order="(1) The %d sample fits are trained. (2) The %d new fits are trained. (3) The reference source is "
                  "decided, once, from first-day information only. (4) Under REFIT the remaining %d reference fits "
                  "are trained. (5) Every model is frozen. (6) Second-day data are opened: the sample fits are "
                  "evaluated first and compared with the archive; then every other model is evaluated once."
                  % (sample, new, reference - sample),
            compared_training_side="For every sample fit: training-set outputs and training labels; in addition the "
                                   "last used target (W0, W1, W4) and the first-day normaliser (S0, W0, W1). Equality "
                                   "means the same dtype, shape and bytes.",
            linkage="For every W5 fit the mean target distance used in the third phase must equal the archived W4 "
                    "value of the same participant and seed (%d pairs). The first non-zero W5 update has label share "
                    "0.97 and is arithmetically the W4 update, so the two fits coincide up to that point if the "
                    "environment reproduces the archive." % (people * seeds),
            archive="ARCHIVE if every sample fit is identical on the training side and every linkage value is "
                    "identical: the reference is the archived %d fits and the campaign trains %d fits (%d sample + "
                    "%d new)." % (reference, new + sample, sample, new),
            refit="REFIT otherwise: all %d reference fits are trained in this campaign (%d fits in total) and the new "
                  "family is computed only from this campaign's fits; the differences are reported."
                  % (reference, new + reference),
            test_side="After the model freeze the sample fits are evaluated first and their second-day outputs are "
                      "compared with the archive, before any second-day output of S1 or W5 exists. Under ARCHIVE a "
                      "difference stops the campaign at that point. The fallback is fixed here: the reference source "
                      "becomes REFIT (the remaining reference fits are trained with this frozen code and the new "
                      "family uses campaign fits only), carried out under a recorded protocol amendment that is "
                      "written before any second-day output of S1 or W5 is produced. Under REFIT the comparison is "
                      "informational.",
            linkage_under_refit="Under REFIT each W5 fit is also compared with this campaign's own W4 fit; reported "
                                "descriptively, without consequence.",
            decided_by="code/campaign.py; the decision is written once and cannot be changed by a later run"),
        analysis=dict(
            contrasts=[c[0] for c in cond.CONTRASTS],
            meaning={
                "S1-S0": "effect of cumulative negotiation with softmax output",
                "(W1-W0)-(S1-S0)": "difference of the negotiation effect between Walsh and softmax output",
                "W1-W5": "accumulated earlier predictions versus current prediction only, at equal label share",
                "W5-W4": "larger prediction share within the label-anchored ungated rule"},
            unit="participant mean over the five seeds; n = 54",
            measure="test accuracy in percentage points (Walsh: nearest code word; softmax: larger probability)",
            test="two-sided paired t test, 53 degrees of freedom, for each of the four contrasts",
            multiplicity="Holm over exactly these four tests; one new family",
            intervals="pointwise 95% t intervals, not multiplicity adjusted",
            sensitivity="Wilcoxon signed-rank test, two-sided, zero differences dropped, normal approximation without "
                        "continuity correction (scipy.stats.wilcoxon, method='approx'), reported beside each "
                        "contrast; it cannot change the stated result",
            dependence="Contrasts 1 and 2 add up to W1-W0 and contrasts 3 and 4 add up to W1-W4, both reported "
                       "before; the family therefore adds two new pieces of information. It is the third family "
                       "evaluated on the same second-day data.",
            descriptive="No significance tests: NLL (class-probability floor 1e-12), ECE (15 bins), Brier score "
                        "(summed over both classes), mean confidence, bit-wise binary cross-entropy (Walsh), accuracy "
                        "of the most probable class and its agreement with the nearest-code-word decision, the same "
                        "three probability measures after dividing the two Walsh class scores by 8 (fixed, not "
                        "fitted), training accuracy, training-minus-test accuracy, and the measures of target "
                        "movement listed under manipulation_checks.",
            manipulation_checks="How far the last trained target lies from the label: mean absolute change per "
                                "output unit (softmax: 2 units; Walsh: all 16 bits and, separately, the 8 bits in "
                                "which the two code words differ), Euclidean target displacement, and the share of "
                                "training trials whose target decodes to the other class. For every participant and "
                                "seed, the mean absolute difference between the last trained targets of W1 and W5. "
                                "They show whether S1 moved its targets by an amount comparable with W1 and whether "
                                "the W1 and W5 targets differ; a contrast near zero is read together with them.",
            timing="Training seconds are written to a separate file; they are not a result.",
            earlier_families="The five-contrast Lee2019 family (primary W2-W0) and the two-contrast W4 family are "
                             "not recomputed, extended or re-adjusted.",
            status="Exploratory, added after the Lee2019 results of the earlier conditions had been examined. Not a "
                   "confirmatory test and not an independent validation.",
            reporting="All four contrasts, every participant, every seed and every measure are reported whatever "
                      "the outcome. No further condition, rate or budget is tried on the basis of these results."),
        gates=dict(
            before_freeze="on the campaign computer and device: software equal to that of the archived fits, source "
                          "bindings present, and the generated-data checks (training core, analysis, complete dry "
                          "run of the pipeline) pass; only then are the machine facts added and the protocol written",
            before_data="exact protocol, code and source-binding hashes; frozen runtime; the training-core and "
                        "analysis checks pass again at every start",
            before_day2="every fit record, checkpoint and training output of the campaign plus 54 normalisers form "
                        "one frozen list",
            before_new_condition_tests="the second-day outputs of the sample fits have been compared with the "
                                       "archive (a gate under ARCHIVE)",
            before_statistics="every test receipt and prediction file listed; label order identical across "
                              "conditions; consistent reference-source decision",
            protected="the six v1.7 delivery files keep their recorded SHA-256 before and after"),
        expectations_recorded_before_results=dict(
            S1="Training-set softmax probabilities are expected to be close to the labels (training accuracy near "
               "100% on Lee2019), so the negotiated target may move little; a difference near zero is plausible. "
               "No direction is predicted.",
            W5="If the W1 advantage comes from the size of the prediction share, W5 should resemble W1; if it comes "
               "from carrying earlier predictions forward, W5 should resemble W4. Not predicted.",
            general="Effects below one percentage point are expected; four non-significant contrasts would be a "
                    "valid and reportable outcome."),
        launch="BASLAT-V1.0.cmd, started by the user's own double click. First start: checks on this computer, "
               "protocol freeze, campaign. Later starts resume the same campaign.")


def freeze(runtime_json, prelaunch, expected_fixed):
    import campaign
    out = ROOT / "PROTOKOL-V1.0.json"
    record_path = ROOT / "records/PROTOCOL_FREEZE_RECORD-V1.0.json"
    need(not out.exists() and not record_path.exists(), "The protocol is written once")
    for folder in ("campaign", "final_analysis"):
        need(not (ROOT / folder).exists() or not any((ROOT / folder).rglob("*")), "No campaign output may exist")
    need(not campaign.FIXTURE_MARKER.exists(), "A real protocol is never frozen inside an engineering fixture")
    bindings = ROOT / "data/SOURCE_BINDINGS-V1.0.json"
    b = load(bindings)
    need(b["status"] == "BOUND_INPUTS_AND_ARCHIVED_REFERENCE_FITS_BEFORE_S1_W5"
         and b["counts"] == dict(subjects=54, prepared_files=162, archived_fits=1080, archived_files=2700,
                                 protected_files=6), "Complete source bindings")
    for relative, digest in EXPECTED_EARLIER_CODE.items():
        need(b["earlier_code_sha256"].get(relative) == digest and sha(ROOT.parent / relative) == digest,
             "Earlier code on this computer differs from the code the checks expect: " + relative)
    runtime = load(runtime_json)
    for key, value in EXPECTED_RUNTIME.items():
        need(runtime.get(key) == value, "Software differs from that of the archived fits: %s is %r, expected %r"
             % (key, runtime.get(key), value))
    need(isinstance(runtime.get("GPU"), str) and runtime["GPU"] and isinstance(runtime.get("scipy"), str)
         and runtime.get("threads") == 2 and set(runtime) == {"python", "numpy", "scipy", "torch", "cuda", "GPU", "threads"},
         "Runtime record of the campaign computer")
    need(runtime == campaign.runtime(), "The runtime record was not made by this interpreter on this computer")
    checks, seen = {}, {}
    for relative in prelaunch:
        value = load(ROOT / relative)
        need(value["status"].startswith("PASS"), "Check did not pass: " + relative)
        for code, digest in value["code_sha256"].items():
            need(sha(ROOT / code) == digest, "Check ran on other code: %s / %s" % (relative, code))
        checks[relative] = dict(sha256=sha(ROOT / relative), status=value["status"], checks=value["checks"],
                                device=value.get("device"))
        seen.setdefault(value["status"], set()).add(value.get("device"))
    for status, device in REQUIRED_RECEIPTS.items():
        need(status in seen and (device is None or device in seen[status]),
             "A passed check on the campaign device is missing: %s (%s)" % (status, device))
    fixed = fixed_content()
    need(tuple(fixed) == campaign.FIXED_KEYS, "The prespecified sections are exactly the hashed sections")
    digest_fixed = campaign.fixed_content_sha256(fixed)
    need(expected_fixed is None or expected_fixed == digest_fixed,
         "The prespecified content is not the one recorded before the launch")
    protocol = dict(fixed)
    protocol.update(
        fixed_content_sha256=digest_fixed,
        frozen_trt=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat(),
        runtime=runtime,
        software_of_archived_fits=EXPECTED_RUNTIME,
        code_sha256={relative: sha(ROOT / relative) for relative in CODE},
        source_bindings_sha256=sha(bindings),
        prelaunch_checks=dict(
            receipts=checks,
            note="Generated-data checks (no EEG, no archived result). Receipts with device 'cuda' were produced on "
                 "the campaign computer immediately before this freeze; receipts with device 'cpu' were produced "
                 "while the package was prepared. The training-core and analysis checks run again at every start."))
    raw = (json.dumps(protocol, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with out.open("xb") as stream:
        stream.write(raw)
    digest = sha(out)
    study = campaign.validate_protocol(out, digest, check_runtime=True, verify_sources=False)
    design = cond.REAL_DESIGN
    sample = len(study.sample_triples())
    need(not study.engineering and len(study.new_triples()) == 540 and sample == 72
         and len(study.campaign_triples("ARCHIVE")) == 612 and len(study.campaign_triples("REFIT")) == 1620
         and design == protocol["design"], "Frozen design counts")
    receipt = dict(status="PASS_S1_W5_PROTOCOL_FREEZE", protocol_sha256=digest, fixed_content_sha256=digest_fixed,
                   frozen_trt=protocol["frozen_trt"], code_files=len(protocol["code_sha256"]),
                   source_bindings_sha256=protocol["source_bindings_sha256"], prelaunch_receipts=len(checks),
                   runtime=runtime, real_fits=0, second_day_arrays_decoded=0, source_bytes_verified_here=False,
                   note="Source bytes are verified by the runner before any training.")
    with record_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--print-fixed-sha256", action="store_true")
    parser.add_argument("--runtime-json")
    parser.add_argument("--prelaunch", nargs="+",
                        help="generated-data check receipts (paths relative to the study folder)")
    parser.add_argument("--fixed-sha256", default=None, help="expected SHA-256 of the prespecified content")
    arguments = parser.parse_args()
    if arguments.print_fixed_sha256:
        import campaign
        print(campaign.fixed_content_sha256(fixed_content()))
    else:
        need(arguments.runtime_json and arguments.prelaunch, "--runtime-json and --prelaunch are required")
        freeze(arguments.runtime_json, arguments.prelaunch, arguments.fixed_sha256)
