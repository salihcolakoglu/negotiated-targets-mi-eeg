# Hazırlık sırasındaki kontrol makbuzları

Bu klasördeki dört makbuz, paket hazırlanırken bulut ortamında (Linux, ekran kartı yok) üretildi. Ortam, deney bilgisayarının sürümleriyle kuruldu: Python 3.12.3, numpy 2.2.6, scipy 1.15.3, torch 2.5.1 (işlemci üzerinde). Hepsi yapay veriyledir; gerçek EEG verisi ve arşiv sonuçları açılmadı.

| Dosya | Kontrol |
|---|---|
| `core-cpu.json` | Eğitim çekirdeği (341 kontrol) |
| `analysis.json` | Sonuç hesabı (75 kontrol) |
| `dryrun-cpu.json` | Baştan sona kuru deneme, beş senaryo (58 kontrol) |
| `launch-rehearsal.json` | Başlatıcı ve dondurma provası (17 kontrol) |

Her makbuz, sınadığı kod dosyalarının SHA-256 özetlerini içerir. Başlatıcı, yalnız bugünkü kodla birebir eşleşen makbuzları protokole yazar.

Bu makbuzlar deney bilgisayarındaki ön kontrolün yerini tutmaz. İlk başlatmada aynı üç kontrol o bilgisayarın ekran kartında yeniden koşulur; makbuzları `ops\preflight\` klasörüne yazılır.

— Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · 12.11.2026
