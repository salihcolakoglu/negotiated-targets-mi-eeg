"""Generated-data checks of the training core and the fit wrapper (no EEG, no archive result is opened).

What is established here, on the device that will run the campaign:
  A  the released training loop is unchanged for every previously used rule (old and new code give
     bit-identical models, optimizers, random states and outputs);
  B  the two new target rules do exactly what the protocol says (arithmetic, timing, label share,
     evaluation-mode predictions);
  C  S1 is identical to S0, and W5 to W4, up to the first phase in which their targets differ;
  D  the wrapper adds nothing numerically, resumes exactly after an interruption, and rejects
     foreign, corrupt or mismatching checkpoints;
  E  a reference fit made through the wrapper reproduces the earlier code paths bit for bit.
"""
from pathlib import Path
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
import copy
import importlib.util
import json
import sys
import tempfile
import time

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(ROOT / "code"))
import conditions as cond
import lee_core as core
import lee_data as data
import training as t

LEE = PROJECT / "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code"
W4 = PROJECT / "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code"
EXPECTED_SOURCES = {
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py": "5614c5fc08a1ed4e5f57596241d4dfafe5df5c027b8a17dce166108b8abd2638",
    "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_core.py": "bf1639f7afb931a2d7fa5c0ff7de10daaecd6b85a8ab539efd4809e0ca09ed48",
    "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_data.py": "49b4326d390f9f5d4bf363e829a41f8b8902bf668033fab3439ac61ca4184740",
}
checks = []


def check(value, name):
    if not bool(value):
        raise AssertionError(name)
    checks.append(name)


def reject(function, name, reason):
    """The call must be refused, and for the stated reason (a fragment of the error message)."""
    try:
        function()
    except (RuntimeError, ValueError) as error:
        if reason not in str(error):
            raise AssertionError("Refused for another reason: %s: %s" % (name, error))
        checks.append(name)
    else:
        raise AssertionError("Accepted: " + name)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def direct_fit(module, x, y, name, seed, dev, phases, epochs, capture=None):
    """The plain sequence used by the earlier campaigns: seed, build, move, train."""
    spec = cond.CONDITIONS[name]
    module.set_seed(seed)
    model = module.build_model("EEGNet", 62, 512, spec["n_out"], 0.5).to(dev)
    saved = []
    rec, arrays = module.fit_training_only(
        model, x, y, walsh=spec["walsh"], rule=spec["rule"], C=data.code_rows(), lr=0.001,
        epochs_per_phase=epochs, batch=16, seed=seed, dev=dev, phases=phases,
        checkpoint=lambda state: (saved.append(t.cpu_copy(state)), capture and capture(model, state)))
    return model, rec, arrays, saved


def state_signature(model, saved):
    last = saved[-1]
    return (t.model_hash(model), t.tree_hash(last["optimizer"]), t.tree_hash(last["rng"]),
            t.tree_hash(last["generator"]))


def identity(name, seed, scope="ENGINEERING"):
    return dict(study_id=t.STUDY_ID, scope=scope, subject=1, seed=seed, fit_id=cond.fit_id(1, name, seed),
                condition=name, rule=cond.CONDITIONS[name]["rule"], protocol_sha256="a" * 64,
                source_bindings_sha256="b" * 64, train_source_sha256="c" * 64, preprocessor_sha256="d" * 64)


def main(device, receipt):
    tick = time.perf_counter()
    for relative, digest in EXPECTED_SOURCES.items():
        check(t.sha(PROJECT / relative) == digest, "Earlier source file unchanged: " + relative)
    check((ROOT / "code/lee_data.py").read_bytes() == (LEE / "lee_data.py").read_bytes(),
          "lee_data.py is a byte copy of the released helper")
    lee_core_old = load_module("lee_core_original_reference", LEE / "lee_core.py")
    w4_core_old = load_module("lee_core_w4_reference", W4 / "lee_core.py")
    core.setup_torch(2)
    dev = torch.device(device)
    if dev.type == "cuda":
        check(torch.cuda.is_available(), "CUDA is available")
    rng = np.random.default_rng(20261112)
    C = data.code_rows()

    # ---------------------------------------------------------------- B: target-rule arithmetic
    y6 = np.tile(np.array([0, 1], dtype=np.int64), 3)
    Y = C[y6].copy()
    P = rng.random((6, 16), dtype=np.float32)
    previous = rng.random((6, 16), dtype=np.float32)
    for phase in range(10):
        for rule in ("hard", "neg_paper", "neg_anchor_gate", "smooth_class"):
            a, g = lee_core_old.update_targets(previous, Y, P, y6, C, phase, rule)
            b, h = core.update_targets(previous, Y, P, y6, C, phase, rule)
            check(np.array_equal(a, b) and ((g is h is None) or np.array_equal(g, h)),
                  "Released rule unchanged: %s phase %d" % (rule, phase))
        a, _ = w4_core_old.update_targets(previous, Y, P, y6, C, phase, "neg_anchor_all")
        b, _ = core.update_targets(previous, Y, P, y6, C, phase, "neg_anchor_all")
        check(np.array_equal(a, b), "W4 rule unchanged phase %d" % phase)
        w5, gate = core.update_targets(previous, Y, P, y6, C, phase, "neg_anchor_all_matched")
        share = cond.label_share(phase)
        check(gate is None and w5.dtype == np.float32
              and np.array_equal(w5, (share * Y + (1 - share) * P).astype(np.float32)),
              "W5 target = share x label + (1 - share) x current prediction, phase %d" % phase)
        check(np.all(w5 >= 0) and np.all(w5 <= 1), "W5 targets stay in [0, 1], phase %d" % phase)
    w5_0, _ = core.update_targets(previous, Y, P, y6, C, 0, "neg_anchor_all_matched")
    check(np.array_equal(w5_0, Y), "W5 update after phase 0 leaves the label untouched")
    w5_1, _ = core.update_targets(previous, Y, P, y6, C, 1, "neg_anchor_all_matched")
    w4_1, _ = core.update_targets(previous, Y, P, y6, C, 1, "neg_anchor_all")
    check(np.array_equal(w5_1, w4_1), "First non-zero W5 update is bit-identical to the W4 update")
    w5_2, _ = core.update_targets(previous, Y, P, y6, C, 2, "neg_anchor_all_matched")
    w4_2, _ = core.update_targets(previous, Y, P, y6, C, 2, "neg_anchor_all")
    check(not np.array_equal(w5_2, w4_2), "From the second non-zero update on W5 differs from W4")
    # label share: run the cumulative recurrence with prediction 0 and label 1; what is left is the label share
    ones = np.ones((4, 16), dtype=np.float32)
    zeros = np.zeros((4, 16), dtype=np.float32)
    cumulative = ones.copy()
    for phase in range(10):
        cumulative, _ = core.update_targets(cumulative, ones, zeros, np.zeros(4, dtype=np.int64), C, phase, "neg_paper")
        matched, _ = core.update_targets(None, ones, zeros, np.zeros(4, dtype=np.int64), C, phase,
                                         "neg_anchor_all_matched")
        check(abs(float(cumulative[0, 0]) - cond.label_share(phase)) < 1e-6
              and abs(float(matched[0, 0]) - cond.label_share(phase)) < 1e-6,
              "Label share of W5 equals the label share left by the cumulative rule after update %d" % phase)
    check(abs(cond.label_share(8) - 0.305560431047872) < 1e-12 and abs(1 - cond.label_share(8) - 0.694439568952128) < 1e-12,
          "Label share of the last target that is trained against is 0.3056 (prediction share 0.6944)")
    check([round(cond.rate(p), 10) for p in range(10)] == [0.0, 0.03, 0.06, 0.09, 0.12, 0.15, 0.18, 0.21, 0.24, 0.27],
          "Negotiation rate after phase p is 0.03 x p: 0, 0.03, ..., 0.24 used for training, 0.27 never used")
    # softmax negotiation uses the same recurrence on two class probabilities
    T = np.eye(2, dtype=np.float32)[y6]
    Q = rng.random((6, 2), dtype=np.float32)
    Q /= Q.sum(1, keepdims=True)
    same, _ = core.update_targets(T, T, Q, y6, C, 0, "neg_paper")
    check(np.array_equal(same, T), "Softmax target is unchanged by the update after phase 0")
    moving = T.copy()
    for phase in range(1, 10):
        expected = (moving - (moving - Q) * data.R_RATE * phase).astype(np.float32)
        moving, _ = core.update_targets(moving, T, Q, y6, C, phase, "neg_paper")
        check(np.array_equal(moving, expected) and np.allclose(moving.sum(1), 1.0, atol=1e-6)
              and np.all(moving >= 0), "Softmax negotiation recurrence and simplex, update %d" % phase)

    # ---------------------------------------------------------------- loss definition
    logits = torch.from_numpy(rng.normal(size=(16, 2)).astype(np.float32)).to(dev)
    soft_targets = torch.from_numpy(Q[[0, 1, 2, 3] * 4]).to(dev)
    manual = -(soft_targets * F.log_softmax(logits, 1)).sum(1).mean()
    check(abs(float(F.cross_entropy(logits, soft_targets) - manual)) < 1e-6,
          "Soft-target loss is the cross-entropy between target and predicted class probabilities")
    index = torch.from_numpy(np.tile(np.array([0, 1], dtype=np.int64), 8)).to(dev)
    onehot = F.one_hot(index, 2).float()
    check(abs(float(F.cross_entropy(logits, onehot) - F.cross_entropy(logits, index))) < 1e-6,
          "With one-hot targets the soft-target loss equals the class-index loss")

    # ---------------------------------------------------------------- A: released loop unchanged
    x12 = rng.normal(size=(12, 62, 512)).astype(np.float32)
    y12 = np.tile(np.array([0, 1], dtype=np.int64), 6)
    for name, modules in (("S0", (lee_core_old, w4_core_old, core)), ("W0", (lee_core_old, w4_core_old, core)),
                          ("W1", (lee_core_old, w4_core_old, core)), ("W4", (w4_core_old, core))):
        results = []
        for module in modules:
            model, rec, arrays, saved = direct_fit(module, x12, y12, name, 4, dev, 4, 1)
            results.append((state_signature(model, saved), arrays, rec))
        for other in results[1:]:
            check(other[0] == results[0][0], "Old and new loop: identical model, Adam, RNG and sample order, " + name)
            check(set(other[1]) == set(results[0][1]) and all(
                np.array_equal(other[1][k], results[0][1][k]) for k in other[1]),
                "Old and new loop: identical outputs and targets, " + name)
    for rule, name in (("neg_anchor_gate", "W2"), ("smooth_class", "W3")):
        outputs = []
        for module in (lee_core_old, core):
            module.set_seed(4)
            model = module.build_model("EEGNet", 62, 512, 16, 0.5).to(dev)
            saved = []
            rec, arrays = module.fit_training_only(model, x12, y12, walsh=True, rule=rule, C=C, lr=0.001,
                                                   epochs_per_phase=1, batch=16, seed=4, dev=dev, phases=4,
                                                   checkpoint=lambda state: saved.append(t.cpu_copy(state)))
            outputs.append((state_signature(model, saved), arrays))
        check(outputs[0][0] == outputs[1][0] and all(np.array_equal(outputs[0][1][k], outputs[1][1][k])
                                                     for k in outputs[0][1]),
              "Old and new loop identical for the rule not used here: " + name)

    # ---------------------------------------------------------------- B: timing and evaluation-mode predictions
    x100 = rng.normal(size=(100, 62, 512)).astype(np.float32)
    y100 = np.tile(np.array([0, 1], dtype=np.int64), 50)
    x_t = torch.from_numpy(x100).to(dev)
    for name in ("S1", "W1", "W5"):
        spec = cond.CONDITIONS[name]
        trace = []

        def capture(model, state, spec=spec, trace=trace):
            keep = core._rng_state()                     # building the twin must not disturb the observed run
            twin = core.build_model("EEGNet", 62, 512, spec["n_out"], 0.5).to(dev)
            twin.load_state_dict(t.cpu_copy(state["model"]))
            trace.append(dict(P=core.predict(twin, x_t, spec["walsh"]), Yneg=state["Yneg"].copy(),
                              Y_used=state["Y_used"].copy(), next_phase=state["next_phase"]))
            core._restore_rng(keep)

        model, rec, arrays, saved = direct_fit(core, x100, y100, name, 2, dev, 5, 1, capture=capture)
        label = C[y100].astype(np.float32) if spec["walsh"] else np.eye(2, dtype=np.float32)[y100]
        check(np.array_equal(trace[0]["Y_used"], label) and np.array_equal(trace[1]["Y_used"], label)
              and rec["used_target_dist_by_phase"][:2] == [0.0, 0.0],
              "The first two phases are trained against the labels themselves, " + name)
        check(rec["used_target_dist_by_phase"][2] > 0, "The third phase is the first with a moved target, " + name)
        for p in range(1, 5):
            before, after, pred = trace[p]["Y_used"], trace[p]["Yneg"], trace[p]["P"]
            if name == "W5":
                share = cond.label_share(p)
                expected = (share * label + (1 - share) * pred).astype(np.float32)
            else:
                expected = (before - (before - pred) * data.R_RATE * p).astype(np.float32)
            check(np.array_equal(after, expected),
                  "Target written after phase %d uses the evaluation-mode prediction of that phase, %s" % (p, name))
            check(np.array_equal(trace[p]["Y_used"], trace[p - 1]["Yneg"]),
                  "Phase %d is trained against the target written after phase %d, %s" % (p, p - 1, name))
        check(np.array_equal(arrays["Y_used_last"], trace[-1]["Y_used"]),
              "The saved last used target is the target of the last trained phase, " + name)
        check(not np.array_equal(trace[-1]["Yneg"], trace[-1]["Y_used"]) and len(rec["used_target_dist_by_phase"]) == 5
              and set(arrays) == {"P_train", "y_train", "Y_used_last"},
              "The update written after the last phase is never trained against and is not a training output, " + name)

    # ---------------------------------------------------------------- C: shared beginnings
    s0 = direct_fit(core, x100, y100, "S0", 3, dev, 2, 1)
    s1 = direct_fit(core, x100, y100, "S1", 3, dev, 2, 1)
    check(state_signature(s0[0], s0[3]) == state_signature(s1[0], s1[3]) and np.array_equal(s0[2]["P_train"], s1[2]["P_train"]),
          "S1 is bit-identical to S0 until the first moved target (two phases)")
    s0 = direct_fit(core, x100, y100, "S0", 3, dev, 4, 1)
    s1 = direct_fit(core, x100, y100, "S1", 3, dev, 4, 1)
    check(t.model_hash(s0[0]) != t.model_hash(s1[0]), "S1 departs from S0 once its target has moved")
    w4 = direct_fit(core, x100, y100, "W4", 3, dev, 3, 1)
    w5 = direct_fit(core, x100, y100, "W5", 3, dev, 3, 1)
    check(state_signature(w4[0], w4[3]) == state_signature(w5[0], w5[3])
          and w4[1]["used_target_dist_by_phase"] == w5[1]["used_target_dist_by_phase"],
          "W5 is bit-identical to W4 through the third phase (first non-zero update is shared)")
    w0 = direct_fit(core, x100, y100, "W0", 3, dev, 2, 1)
    w1 = direct_fit(core, x100, y100, "W1", 3, dev, 2, 1)
    w5b = direct_fit(core, x100, y100, "W5", 3, dev, 2, 1)
    check(state_signature(w0[0], w0[3]) == state_signature(w1[0], w1[3]) == state_signature(w5b[0], w5b[3]),
          "W0, W1 and W5 are bit-identical through the first two phases")
    w4 = direct_fit(core, x100, y100, "W4", 3, dev, 5, 1)
    w5 = direct_fit(core, x100, y100, "W5", 3, dev, 5, 1)
    check(w4[1]["used_target_dist_by_phase"][2] == w5[1]["used_target_dist_by_phase"][2]
          and w4[1]["used_target_dist_by_phase"][3] != w5[1]["used_target_dist_by_phase"][3],
          "W5 and W4 share the third-phase target and differ from the fourth phase on")
    # tolerance version of "negotiation with rate zero is the hard softmax condition"
    kept = core.R_RATE
    try:
        core.R_RATE = 0.0
        zero_rate = direct_fit(core, x100, y100, "S1", 3, dev, 4, 1)
    finally:
        core.R_RATE = kept
    check(t.model_hash(zero_rate[0]) == t.model_hash(s0[0])
          and zero_rate[1]["used_target_dist_by_phase"] == [0.0, 0.0, 0.0, 0.0],
          "With rate zero the S1 target never moves and S1 equals S0 (class-index loss throughout)")
    # the soft-target loss path itself, fed one-hot targets, follows the class-index path
    core.set_seed(5)
    model_a = core.build_model("EEGNet", 62, 512, 2, 0.5).to(dev)
    model_b = copy.deepcopy(model_a)
    for model, target in ((model_a, torch.from_numpy(y100).to(dev)),
                          (model_b, torch.from_numpy(np.eye(2, dtype=np.float32)[y100]).to(dev))):
        core.set_seed(6)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        core.train_epochs(model, optimizer, x_t, target, 2, 16, torch.Generator().manual_seed(6), False)
    gap = max(float((a - b).abs().max()) for a, b in zip(model_a.state_dict().values(), model_b.state_dict().values())
              if a.dtype.is_floating_point)
    check(gap < 1e-4, "Soft-target loss with one-hot targets tracks the class-index loss (largest weight gap < 1e-4)")
    soft_path_bitwise = bool(gap == 0.0)

    # ---------------------------------------------------------------- F: the two new conditions against loops
    # written here from the protocol text. Only the model class, the seeding and the sample order are shared.
    def protocol_loop(kind, seed, phases, epochs):
        core.set_seed(seed)
        model = core.build_model("EEGNet", 62, 512, 2 if kind == "S1" else 16, 0.5).to(dev)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        order = torch.Generator().manual_seed(seed)
        labels = torch.from_numpy(y100).to(dev)
        label_target = np.eye(2, dtype=np.float32)[y100] if kind == "S1" else C[y100].astype(np.float32)
        target = label_target.copy()
        used, distances = [], []

        def outputs():
            model.eval()
            with torch.no_grad():
                z = model(x_t).float()
                return (torch.softmax(z, 1) if kind == "S1" else torch.sigmoid(z)).cpu().numpy()

        for p in range(phases):
            used.append(target.copy())
            distances.append(float(np.linalg.norm(target - label_target, axis=1).mean()))
            target_t = torch.from_numpy(target).to(dev)
            onehot = np.array_equal(target, label_target)
            model.train()
            for _ in range(epochs):
                batches = list(torch.randperm(100, generator=order).split(16))
                if len(batches) > 1 and len(batches[-1]) < 2:
                    batches[-2] = torch.cat([batches[-2], batches[-1]])
                    batches.pop()
                for index in batches:
                    index = index.to(dev)
                    logits = model(x_t[index])
                    if kind == "W5":
                        loss = F.binary_cross_entropy_with_logits(logits, target_t[index])
                    elif onehot:                         # S1 while its target is still the label: class-index loss
                        loss = F.cross_entropy(logits, labels[index])
                    else:                                # S1 afterwards: cross-entropy against the soft target
                        loss = F.cross_entropy(logits, target_t[index])
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    optimizer.step()
                    model.constrain()
            prediction = outputs()                       # evaluation mode, after the phase
            if kind == "S1":                             # cumulative: move the current target toward the prediction
                target = (target - (target - prediction) * 0.03 * p).astype(np.float32)
            else:                                        # anchored, matched share: label share left by the cumulative rule
                share = 1.0
                for k in range(1, p + 1):
                    share *= 1.0 - 0.03 * k
                target = (share * label_target + (1 - share) * prediction).astype(np.float32)
        return model, used, distances, outputs()

    for name in ("S1", "W5"):
        for seed in (2, 5):
            package_model, package_rec, package_arrays, _ = direct_fit(core, x100, y100, name, seed, dev, 6, 2)
            loop_model, loop_used, loop_distances, loop_outputs = protocol_loop(name, seed, 6, 2)
            check(t.model_hash(package_model) == t.model_hash(loop_model),
                  "Weights equal an independent loop written from the protocol, bit for bit: %s seed %d" % (name, seed))
            check(package_arrays["P_train"].tobytes() == loop_outputs.astype(np.float32).tobytes()
                  and package_arrays["Y_used_last"].tobytes() == loop_used[-1].tobytes()
                  and package_rec["used_target_dist_by_phase"] == loop_distances,
                  "Outputs, last used target and target distances equal the independent loop: %s seed %d" % (name, seed))
            check(loop_distances[0] == loop_distances[1] == 0.0 and all(d > 0 for d in loop_distances[2:]),
                  "In the independent loop the target moves from the third phase on: %s seed %d" % (name, seed))

    # ---------------------------------------------------------------- D/E: wrapper, resume, reproduction
    with tempfile.TemporaryDirectory(prefix="S1W5-QA-") as temporary:
        folder = Path(temporary).resolve()
        test_x = rng.normal(size=(100, 62, 512)).astype(np.float32)
        for name in cond.ALL:
            spec = cond.CONDITIONS[name]
            # the earlier campaigns' plain path (their own core where one exists)
            module = w4_core_old if name == "W4" else (lee_core_old if name in ("S0", "W0", "W1") else core)
            plain_model, plain_rec, plain_arrays, _ = direct_fit(module, x100, y100, name, 2, dev, 4, 1)
            plain_test, plain_test_arrays = module.evaluate_final(plain_model, test_x, y100, walsh=spec["walsh"], C=C, dev=dev)
            path = folder / (name + "-uninterrupted.ckpt")
            model, record, outputs = t.fit_engineering(x100, y100, identity(name, 2), device=device, checkpoint_path=path)
            check(np.array_equal(outputs["P_train_float32"], plain_arrays["P_train"])
                  and ("Y_used_last" in plain_arrays) == ("Y_used_last_float32" in outputs)
                  and ("Y_used_last" not in plain_arrays
                       or np.array_equal(outputs["Y_used_last_float32"], plain_arrays["Y_used_last"]))
                  and record["final_model_sha256"] == t.model_hash(plain_model),
                  "Wrapper fit reproduces the plain earlier code path bit for bit, " + name)
            # test exactly as the campaign does: fresh model from the checkpoint, evaluation mode
            cp = t.load_checkpoint(path, expected_identity=identity(name, 2), allow_engineering=True, require_complete=True)
            fresh = core.build_model("EEGNet", 62, 512, spec["n_out"], 0.5).to(dev)
            fresh.load_state_dict(cp["state"]["model"], strict=True)
            fresh.eval()
            before, rng_before = t.model_hash(fresh), t.tree_hash(core._rng_state())
            modes = {n: m.training for n, m in fresh.named_modules()}
            result, arrays = core.evaluate_final(fresh, test_x, y100, walsh=spec["walsh"], C=C, dev=dev)
            check(t.model_hash(fresh) == before and t.tree_hash(core._rng_state()) == rng_before
                  and modes == {n: m.training for n, m in fresh.named_modules()},
                  "Final evaluation leaves model, BatchNorm, RNG and modes untouched, " + name)
            check(np.array_equal(arrays["P_test"], plain_test_arrays["P_test"]) and result["acc_test"] == plain_test["acc_test"]
                  and result["nll_test"] == plain_test["nll_test"],
                  "Reloaded-checkpoint test outputs equal the plain path's test outputs, " + name)
            check(record["campaign_eligible"] is False and record["engineering_only"] is True
                  and record["actual_update_calls"] == 4 * 7, "Engineering fits are never campaign eligible, " + name)

            class Interrupt(RuntimeError):
                pass

            for stop_at in (1, 3):
                resumable = folder / ("%s-stop%d.ckpt" % (name, stop_at))

                def stop(phase, total, seconds, stop_at=stop_at):
                    if phase == stop_at:
                        raise Interrupt("generated interruption at a committed phase boundary")

                try:
                    t.fit_engineering(x100, y100, identity(name, 2), device=device, checkpoint_path=resumable, progress=stop)
                except Interrupt:
                    pass
                else:
                    raise AssertionError("Interruption was not triggered")
                _, resumed_record, resumed_outputs = t.fit_engineering(x100, y100, identity(name, 2), device=device,
                                                                       checkpoint_path=resumable, resume=True)
                a = t.load_checkpoint(path, allow_engineering=True, require_complete=True)
                b = t.load_checkpoint(resumable, allow_engineering=True, require_complete=True)
                for key in ("model", "optimizer", "generator", "rng", "Yneg", "Y_used", "gate", "used_dist", "used_gate"):
                    check(t.tree_hash(a["state"][key]) == t.tree_hash(b["state"][key]),
                          "Resume after phase %d is exact: %s, %s" % (stop_at, key, name))
                check(all(np.array_equal(outputs[k], resumed_outputs[k]) for k in outputs),
                      "Resume after phase %d gives identical outputs, %s" % (stop_at, name))
            digest = t.sha(path)
            t.fit_engineering(x100, y100, identity(name, 2), device=device, checkpoint_path=path, resume=True)
            check(t.sha(path) == digest, "Resuming a finished fit never rewrites its checkpoint, " + name)

        path = folder / "S1-uninterrupted.ckpt"
        reject(lambda: t.load_checkpoint(path), "Engineering checkpoint rejected by the campaign loader",
               "Wrong schema or engineering checkpoint")
        bad = identity("S1", 2)
        bad["protocol_sha256"] = "e" * 64
        reject(lambda: t.load_checkpoint(path, expected_identity=bad, allow_engineering=True), "Other protocol rejected",
               "Checkpoint belongs to another fit, source or protocol")
        bad = identity("S1", 2)
        bad["source_bindings_sha256"] = "e" * 64
        reject(lambda: t.load_checkpoint(path, expected_identity=bad, allow_engineering=True), "Other source binding rejected",
               "Checkpoint belongs to another fit, source or protocol")
        reject(lambda: t.load_checkpoint(path, expected_identity=identity("S0", 2), allow_engineering=True),
               "A checkpoint cannot be read as another condition", "Checkpoint belongs to another fit, source or protocol")
        bad = identity("S1", 2)
        bad["rule"] = "hard"
        reject(lambda: t.fit_engineering(x100, y100, bad, device=device, checkpoint_path=folder / "wrong-rule.ckpt"),
               "A condition cannot be paired with another rule", "rule not matching the condition")
        bad = identity("W5", 2)
        bad["condition"] = "W2"
        reject(lambda: t.fit_engineering(x100, y100, bad, device=device, checkpoint_path=folder / "w2.ckpt"),
               "Conditions outside this study are refused", "Unknown condition")
        changed = x100.copy()
        changed[0, 0, 0] += np.float32(0.01)
        reject(lambda: t.fit_engineering(changed, y100, identity("S1", 2), device=device, checkpoint_path=path, resume=True),
               "Changed input rejected at resume", "written for other data or another budget")
        reject(lambda: t.fit_engineering(x100, y100, identity("S1", 2), device=device, checkpoint_path=path),
               "An existing checkpoint is never overwritten without resume", "requires an explicit same-identity resume")
        reject(lambda: t.fit(x100, y100, identity("S1", 2), device=device, checkpoint_path=folder / "public.ckpt"),
               "The campaign entry point refuses engineering identities", "Wrong study or scope")
        reject(lambda: t.fit(x100, y100, identity("S1", 2, scope="CAMPAIGN"), device="cpu",
                             checkpoint_path=folder / "cpu.ckpt"), "The campaign entry point refuses the CPU",
               "No silent CPU fallback in the campaign")
        reject(lambda: t._fit(x100, y100, identity("S1", 2, scope="CAMPAIGN"), device, folder / "short.ckpt", False, None,
                              engineering=False, phases=4, epochs=1), "The campaign budget cannot be shortened",
               "Only the engineering path may shorten the 300-epoch budget")
        raw = path.read_bytes()
        corrupt = folder / "corrupt.ckpt"
        corrupt.write_bytes(raw[:-1] + bytes([raw[-1] ^ 1]))
        reject(lambda: t.load_checkpoint(corrupt, allow_engineering=True), "Corrupt payload rejected before unpickling",
               "Checkpoint size or payload SHA mismatch")
        foreign = folder / "foreign.ckpt"
        foreign.write_bytes(b"checkpoint of another study")
        reject(lambda: t.load_checkpoint(foreign, allow_engineering=True), "Foreign checkpoint format rejected",
               "Not a checkpoint of this study")
        w4_old = folder / "w4-format.ckpt"
        w4_old.write_bytes(b"LEE2019_W4_UNGATED_ANCHORED_PHASE_CHECKPOINT_V1\x00" + raw[len(t.MAGIC):])
        reject(lambda: t.load_checkpoint(w4_old, allow_engineering=True), "Checkpoints of the W4 study are rejected",
               "Not a checkpoint of this study")

    for relative, digest in EXPECTED_SOURCES.items():
        check(t.sha(PROJECT / relative) == digest, "Earlier source file still unchanged: " + relative)
    seconds = time.perf_counter() - tick
    value = dict(status="PASS_S1_W5_CORE_AND_TRAINING_GENERATED_QA", checks=len(checks), check_names=checks,
                 device=device, torch=str(torch.__version__), numpy=np.__version__,
                 cuda_device=torch.cuda.get_device_name(0) if dev.type == "cuda" else None,
                 seconds=seconds, soft_target_loss_path_bitwise_equal_to_index_path_on_onehot=soft_path_bitwise,
                 real_EEG_or_archive_results_opened=0,
                 code_sha256={rel: t.sha(ROOT / rel) for rel in ("code/lee_core.py", "code/lee_data.py",
                                                               "code/conditions.py", "code/training.py",
                                                               "qa/test_core_training-V1.0.py")},
                 earlier_sources_sha256=EXPECTED_SOURCES)
    Path(receipt).parent.mkdir(parents=True, exist_ok=True)
    Path(receipt).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(status=value["status"], checks=len(checks), device=device, seconds=round(seconds, 1))))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--receipt", required=True)
    arguments = parser.parse_args()
    main(arguments.device, arguments.receipt)
