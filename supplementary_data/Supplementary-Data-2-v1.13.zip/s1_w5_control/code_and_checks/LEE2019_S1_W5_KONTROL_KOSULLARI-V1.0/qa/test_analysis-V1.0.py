"""Generated-number checks of the analysis functions (no EEG, no trained model, no real result)."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import tempfile

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
import conditions as cond
import lee_core
import lee_data

checks = []


def ok(name, value):
    assert bool(value), name
    checks.append(name)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def main(receipt):
    a = module("s1w5_final_analysis", ROOT / "analysis/final_analysis.py")
    y = np.tile(np.array([0, 1], np.int64), 50)
    ok("Analysis code words equal the released code rows", np.array_equal(a.codebook(), lee_data.code_rows()))
    ok("Analysis contrast list equals the frozen contrast list",
       [(n, tuple(p), tuple(m)) for n, p, m in a.CONTRASTS] == [(n, tuple(p), tuple(m)) for n, p, m in cond.CONTRASTS])
    ok("Analysis condition table equals the frozen condition table",
       a.WALSH == {name: spec["walsh"] for name, spec in cond.CONDITIONS.items()}
       and a.REFERENCE == cond.REFERENCE and a.NEW == cond.NEW)
    uniform = np.full((100, 16), 0.5, np.float32)
    m = a.metric(uniform, y, True)
    ok("Uniform Walsh output: ties go to class 0, NLL log 2, Brier 0.5, ECE 0",
       m["accuracy"] == 0.5 and abs(m["nll_clipped"] - math.log(2)) < 1e-14 and m["brier_sum"] == 0.5 and m["ece15"] == 0)
    half = np.full((100, 2), 0.5, np.float32)
    m = a.metric(half, y, False)
    ok("Uniform softmax output: NLL log 2, Brier 0.5, ECE 0, no bit loss",
       abs(m["nll_clipped"] - math.log(2)) < 1e-14 and m["brier_sum"] == 0.5 and m["ece15"] == 0 and m["bce"] is None)
    for seed in range(9):
        rng = np.random.default_rng(seed)
        probs = rng.random((100, 16), dtype=np.float32)
        if seed == 0:
            probs[::3] = 0
        if seed == 1:
            probs[::3] = 1
        new = a.metric(probs, y, True)
        old = lee_core.walsh_metrics(probs, y, lee_data.code_rows())
        ok("Walsh metrics equal the training code's metrics, generated seed %d" % seed,
           all(abs(new[n] - old[o]) < 1e-12 for n, o in (("accuracy", "acc"), ("nll_clipped", "nll"), ("ece15", "ece"),
                                                         ("bce", "bce"), ("posterior_accuracy", "acc_post"))))
        direct = float(np.mean(lee_core.nearest(probs, lee_data.code_rows()) == np.asarray(old["pred"])))
        ok("Accuracy uses the nearest code word of the training code, generated seed %d" % seed,
           abs(new["accuracy"] - float(np.mean(lee_core.nearest(probs, lee_data.code_rows()) == y))) < 1e-15 and direct == 1.0)
        soft = rng.random((100, 2), dtype=np.float32)
        soft /= soft.sum(1, keepdims=True)
        if seed == 2:
            soft[::4] = np.array([1.0, 0.0], dtype=np.float32)
        new = a.metric(soft, y, False)
        old = lee_core.softmax_metrics(soft, y)
        ok("Softmax metrics equal the training code's metrics, generated seed %d" % seed,
           all(abs(new[n] - old[o]) < 1e-12 for n, o in (("accuracy", "acc"), ("nll_clipped", "nll"), ("ece15", "ece"),
                                                         ("posterior_accuracy", "acc_post")))
           and new["decision_rules_agree"] == 1.0)
        brier = float(np.mean(np.sum((soft.astype(np.float64) - np.eye(2)[y]) ** 2, axis=1)))
        ok("Softmax Brier score is the sum over both classes, seed %d" % seed, abs(new["brier_sum"] - brier) < 1e-14)
    confident = np.where(lee_data.code_rows()[y] > 0.5, 0.999, 0.001).astype(np.float32)
    m = a.metric(confident, y, True)
    ok("Confident correct Walsh output: accuracy 1, both decision rules agree, tiny NLL",
       m["accuracy"] == 1.0 and m["decision_rules_agree"] == 1.0 and m["nll_clipped"] < 1e-9
       and m["nll_scores_divided_by_8"] < 1e-2)
    # the two decision rules can disagree; the share of agreement must count exactly those trials
    crafted = confident.copy()
    odd = np.arange(1, 16, 2)                                   # the eight bits in which the two code words differ
    for trial in range(10):                                     # class-0 trials 0, 2, ..., 18 (label code word: all ones)
        row = 2 * trial
        crafted[row, odd] = 0.6                                 # seven differing bits lean to class 0 ...
        crafted[row, odd[0]] = 0.0                              # ... one is certain of class 1
    m = a.metric(crafted, y, True)
    ok("Constructed disagreement: nearest code word says class 0, bit product says class 1, in exactly 10 trials",
       abs(m["decision_rules_agree"] - 0.90) < 1e-15 and m["accuracy"] == 1.0 and abs(m["posterior_accuracy"] - 0.90) < 1e-15)
    # how far a target lies from its label, per output unit
    codes = lee_data.code_rows()
    moved = codes[y].astype(np.float32).copy()
    moved[:, odd] += np.where(codes[y][:, odd] > 0.5, -0.2, 0.2).astype(np.float32)     # differing bits move by 0.2
    moved[:, 0::2] -= np.float32(0.04)                                                   # shared bits move by 0.04
    change = a.target_change(moved, y, True)
    ok("Walsh target change: 0.2 on the differing bits, 0.12 over all sixteen",
       abs(change["differing_bits"] - 0.2) < 1e-6 and abs(change["per_output"] - 0.12) < 1e-6)
    soft_target = np.eye(2, dtype=np.float32)[y] * np.float32(0.7) + np.float32(0.15)    # 0.85 / 0.15
    change = a.target_change(soft_target, y, False)
    ok("Softmax target change: 0.15 per output, no differing-bit value",
       abs(change["per_output"] - 0.15) < 1e-6 and change["differing_bits"] is None)
    ok("Unmoved targets give zero; a condition without target arrays gives no value",
       a.target_change(codes[y].astype(np.float32), y, True) == dict(per_output=0.0, differing_bits=0.0)
       and a.target_change(None, y, False) == dict(per_output=None, differing_bits=None))
    # fixed-scale check: class log scores divided by 8, exactly as the SHU "T8" definition
    probs = np.random.default_rng(77).random((100, 16), dtype=np.float32)
    m = a.metric(probs, y, True)
    C = lee_data.code_rows().astype(np.float64)
    pc = np.clip(probs.astype(np.float64), 1e-7, 1 - 1e-7)
    scores = np.log(pc) @ C.T + np.log1p(-pc) @ (1 - C.T)
    scaled = scores / 8.0
    lp = scaled - np.log(np.exp(scaled - scaled.max(1, keepdims=True)).sum(1, keepdims=True)) - scaled.max(1, keepdims=True)
    ok("Scores divided by 8: NLL equals the direct log-sum-exp definition",
       abs(m["nll_scores_divided_by_8"] - float(-lp[np.arange(100), y].mean())) < 1e-12)
    ok("Scores divided by 8: Brier equals the direct definition",
       abs(m["brier_scores_divided_by_8"] - float(np.square(np.exp(lp) - np.eye(2)[y]).sum(1).mean())) < 1e-12)
    ok("Scores divided by 8 keep the order of the two class scores",
       np.array_equal(np.exp(lp).argmax(1), scores.argmax(1)))
    ok("Softmax outputs have no divided-by-8 values",
       a.metric(half, y, False)["nll_scores_divided_by_8"] is None)
    for bad, label in ((uniform.astype(np.float64), "float64 outputs"), (uniform[:99], "99 trials"), (half, "wrong width")):
        try:
            a.metric(bad, y, True)
        except ValueError:
            ok("Rejected: " + label, True)
        else:
            raise AssertionError(label)
    bad = uniform.copy()
    bad[0, 0] = np.nan
    try:
        a.metric(bad, y, True)
    except ValueError:
        ok("Rejected: non-finite output", True)
    else:
        raise AssertionError("non-finite")
    null = a.paired(np.zeros(54))
    ok("All-zero differences: t 0, p 1, zero-width interval, 54 ties",
       null["t"] == 0 and null["p_unadjusted"] == 1 and null["pointwise_95ci"] == [0, 0] and null["participants_tied"] == 54)
    d = np.arange(-26, 28, dtype=float)
    r = a.paired(d)
    reference = stats.ttest_1samp(d, 0)
    ok("Two-sided paired t with 53 degrees of freedom equals scipy",
       r["df"] == 53 and abs(r["p_unadjusted"] - float(reference.pvalue)) < 1e-14 and abs(r["t"] - float(reference.statistic)) < 1e-12)
    ok("Pointwise 95% interval equals scipy's t interval",
       np.max(np.abs(np.array(r["pointwise_95ci"]) - stats.t.interval(0.95, 53, loc=d.mean(), scale=stats.sem(d)))) < 1e-14)
    ok("Signs counted: 27 positive, 26 negative, 1 tie",
       r["participants_positive"] == 27 and r["participants_negative"] == 26 and r["participants_tied"] == 1)
    ok("Effect size d_z is mean over SD of the differences", abs(r["d_z"] - d.mean() / d.std(ddof=1)) < 1e-15)
    ok("Holm over four: known values", np.allclose(a.holm([0.01, 0.04, 0.03, 0.5]), [0.04, 0.09, 0.09, 0.5], rtol=0, atol=1e-15))
    ok("Holm keeps the order of the inputs",
       np.allclose(a.holm([0.2, 0.01, 0.9, 0.3]), [0.6, 0.04, 0.9, 0.6], rtol=0, atol=1e-15))
    ok("Holm is capped at 1", a.holm([0.8, 0.9, 0.7, 0.6]) == [1, 1, 1, 1])
    w = a.wilcoxon(d)
    # written out here: signed ranks of the non-zero differences (average ranks for ties), normal approximation
    # with tie correction and without continuity correction
    nonzero = d[d != 0]
    ranks = stats.rankdata(np.abs(nonzero))
    r_plus, r_minus = float(ranks[nonzero > 0].sum()), float(ranks[nonzero < 0].sum())
    count = len(nonzero)
    _, tie_sizes = np.unique(np.abs(nonzero), return_counts=True)
    variance = count * (count + 1) * (2 * count + 1) / 24.0 - float((tie_sizes ** 3 - tie_sizes).sum()) / 48.0
    z = (min(r_plus, r_minus) - count * (count + 1) / 4.0) / math.sqrt(variance)
    ok("Wilcoxon sensitivity check equals the written-out normal approximation (zeros dropped, ties corrected)",
       w["n_nonzero"] == 53 and abs(w["statistic"] - min(r_plus, r_minus)) < 1e-12
       and abs(w["p_two_sided"] - 2 * float(stats.norm.sf(abs(z)))) < 1e-12 and a.WILCOXON_METHOD == "approx")
    ok("Wilcoxon with only zeros reports p = 1", a.wilcoxon(np.zeros(54))["p_two_sided"] == 1.0)
    people = [1, 2, 3]
    indexed = {(s, c): dict(accuracy=v) for s in people for c, v in
               (("S0", 0.60 + 0.01 * s), ("S1", 0.62 + 0.01 * s), ("W0", 0.61), ("W1", 0.66 - 0.01 * s),
                ("W4", 0.63), ("W5", 0.64))}
    values = {name: a.contrast_values(indexed, people, plus, minus, "accuracy", scale=100.0, digits=10)
              for name, plus, minus in a.CONTRASTS}
    ok("Contrast arithmetic: S1-S0", values["S1-S0"] == [2.0, 2.0, 2.0])
    ok("Contrast arithmetic: (W1-W0)-(S1-S0)", values["(W1-W0)-(S1-S0)"] == [2.0, 1.0, 0.0])
    ok("Contrast arithmetic: W1-W5", values["W1-W5"] == [1.0, 0.0, -1.0])
    ok("Contrast arithmetic: W5-W4", values["W5-W4"] == [1.0, 1.0, 1.0])
    try:
        a.paired(np.array([1.0]))
    except ValueError:
        ok("A single participant cannot be tested", True)
    else:
        raise AssertionError("n=1")
    constant = a.paired(np.full(54, 0.2))
    ok("Equal non-zero differences: no t statistic, zero-width interval at the common value",
       constant["t"] is None and constant["sd_difference"] == 0.0 and constant["pointwise_95ci"] == [0.2, 0.2]
       and constant["mean_difference"] == 0.2 and constant["participants_positive"] == 54)
    for bad_p in ([0.1, float("nan"), 0.2, 0.3], [0.1, None, 0.2, 0.3], [0.1, 1.5, 0.2, 0.3]):
        try:
            a.holm(bad_p)
        except (ValueError, TypeError):
            ok("Holm refuses a missing or impossible p value: %r" % (bad_p[1],), True)
        else:
            raise AssertionError("Holm accepted %r" % (bad_p,))
    with tempfile.TemporaryDirectory(prefix="S1W5-QA-ANALYSIS-") as temporary:
        target = Path(temporary) / "sub" / "result.json"
        a.immutable(target, b"first")
        a.immutable(target, b"first")
        ok("An output file is written once; an identical second write is accepted",
           target.read_bytes() == b"first" and [q.name for q in target.parent.iterdir()] == ["result.json"])
        try:
            a.immutable(target, b"second")
        except ValueError:
            ok("A different second write of a complete output file is refused", target.read_bytes() == b"first")
        else:
            raise AssertionError("Overwrote an analysis output")
    path = ROOT / "analysis/final_analysis.py"
    value = dict(status="PASS_S1_W5_ANALYSIS_NUMERIC_QA", checks=len(checks), check_names=checks,
                 code_sha256={"analysis/final_analysis.py": hashlib.sha256(path.read_bytes()).hexdigest(),
                              "code/conditions.py": hashlib.sha256((ROOT / "code/conditions.py").read_bytes()).hexdigest(),
                              "qa/test_analysis-V1.0.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
                 actual_data_opened=0, new_fit_or_test=0)
    Path(receipt).parent.mkdir(parents=True, exist_ok=True)
    Path(receipt).write_text(json.dumps(value, indent=2) + "\n", "utf-8")
    print(json.dumps(dict(status=value["status"], checks=len(checks))))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    main(parser.parse_args().receipt)
