"""End-to-end dry run of the whole campaign on generated data (no EEG, no real archive).

A small fixture project is built in a temporary, marked folder: generated "prepared" inputs for a few
participants, an "archive" produced with the earlier code paths at a short budget, source bindings and
an engineering protocol. The real runner is then started as a separate process, exactly as the
launcher does. Scenarios:

  A  ARCHIVE         the archive reproduces -> only sample and new fits are trained; reference from the archive
  B  STOP, KILL      a stop request, then a hard kill mid-way, then a restart -> identical final numbers
  C  REFIT (sample)  an archived training output is altered -> every reference fit is trained again;
                     the archived test outputs are altered too, so that any use of the archive would show
  D  TEST MISMATCH   an archived test output of a sample fit is altered -> the campaign stops after the
                     sample tests, before any second-day output of S1 or W5 exists
  E  REFIT (link)    an archived W4 target distance is altered -> the W5/W4 linkage sends the references
                     to retraining

For A, C and E the four contrasts are recomputed here from the saved prediction files with separate
code (own decoder, own aggregation, scipy's t test, own Holm) and compared with the analysis output.

The fixture can never be mistaken for the real study: other protocol status, marker file, short
budget, records flagged engineering-only.
"""
from pathlib import Path
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
import csv
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np
import torch
from scipy import stats

SOURCE = Path(__file__).resolve().parents[1]
SOURCE_PROJECT = SOURCE.parent
STUDY = SOURCE.name
CODE = ("code/lee_core.py", "code/lee_data.py", "code/conditions.py", "code/training.py", "code/campaign.py",
        "ops/run_campaign-V1.0.py", "analysis/final_analysis.py", "qa/test_core_training-V1.0.py",
        "qa/test_analysis-V1.0.py")
EARLIER = ("LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py", "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py",
           "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_core.py", "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_data.py")
PEOPLE, SEEDS, PHASES, EPOCHS = [1, 2, 3], [1, 2], 4, 1
SAMPLE = dict(subjects=[2], seeds=[1])
REFERENCE, NEW = ("S0", "W0", "W1", "W4"), ("S1", "W5")
LEE, W4 = "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0", "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0"
checks = []


def check(value, name):
    if not bool(value):
        raise AssertionError(name)
    checks.append(name.split("\n")[0])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rel(path, project):
    return str(Path(path).relative_to(project)).replace("\\", "/")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def fit_id(subject, condition, seed):
    return "subject_%02d_train__%s__seed%d" % (subject, condition, seed)


def archive_files(project, subject, condition, seed):
    key = fit_id(subject, condition, seed)
    if condition == "W4":
        base = project / W4 / "campaign"
        return "w4", dict(fit_record=base / f"fit_records/{key}.json", fit_outputs=base / f"fit_outputs/{key}.npz",
                          test_record=base / f"test_records/{key}_day2.json",
                          prediction=base / f"predictions/{key}_day2.npz")
    base = project / LEE / "results/worker_01"
    return "lee", dict(record=base / f"records/{key}.json", prediction=base / f"predictions/{key}.npz")


def build_template(project, device):
    """Generated project without bindings and protocol: inputs and an archive made by the earlier code paths."""
    project = Path(project)
    project.mkdir(parents=True)
    (project / "ENGINEERING_FIXTURE_ROOT.txt").write_text("Generated engineering fixture. Not EEG, not a result.\n")
    root = project / STUDY
    for relative in CODE:
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / relative, target)
    for relative in EARLIER:
        target = project / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE_PROJECT / relative, target)
    sys.path.insert(0, str(root / "code"))
    for name in ("lee_core", "lee_data", "conditions", "training", "campaign"):
        sys.modules.pop(name, None)
    import conditions as cond
    import lee_data as data
    lee_core_old = load_module("fixture_lee_core_original", project / EARLIER[0])
    w4_core_old = load_module("fixture_lee_core_w4", project / EARLIER[2])
    lee_core_old.setup_torch(2)
    dev = torch.device(device)
    C = data.code_rows()
    for s in PEOPLE:
        rng = np.random.default_rng(1000 + s)
        y = np.tile(np.array([0, 1], dtype=np.int64), 50)
        raw = {}
        for part in ("train", "test"):
            x = (rng.normal(size=(100, 62, 512)) * 7.0 + 0.4 * y[:, None, None]).astype(np.float32)
            raw[part] = x
            q = project / LEE / f"data/prepared/subject_{s:02d}_{part}.npz"
            q.parent.mkdir(parents=True, exist_ok=True)
            with q.open("wb") as stream:
                np.savez_compressed(stream, **{f"X_{part}": x, f"y_{part}": y})
        meta = project / LEE / f"data/prepared/subject_{s:02d}_meta.json"
        meta.write_text(json.dumps(dict(subject=s, data_units="uV", fixture_only=True)))
        mean, sd = data.zscore_fit(raw["train"])
        xtr = data.zscore_apply(raw["train"], mean, sd)
        xte = data.zscore_apply(raw["test"], mean, sd)
        for k in SEEDS:
            for name in cond.REFERENCE:
                spec = cond.CONDITIONS[name]
                module = w4_core_old if name == "W4" else lee_core_old
                module.set_seed(k)
                model = module.build_model("EEGNet", 62, 512, spec["n_out"], 0.5).to(dev)
                rec, arrays = module.fit_training_only(model, xtr, y, walsh=spec["walsh"], rule=spec["rule"], C=C,
                                                       lr=0.001, epochs_per_phase=EPOCHS, batch=16, seed=k, dev=dev,
                                                       phases=PHASES, checkpoint=lambda state: None)
                final, test_arrays = module.evaluate_final(model, xte, y, walsh=spec["walsh"], C=C, dev=dev)
                key = fit_id(s, name, k)
                _, files = archive_files(project, s, name, k)
                for q in files.values():
                    q.parent.mkdir(parents=True, exist_ok=True)
                if name == "W4":
                    with files["fit_outputs"].open("wb") as stream:
                        np.savez_compressed(stream, P_train_float32=arrays["P_train"], y_train_int64=arrays["y_train"],
                                            Y_used_last_float32=arrays["Y_used_last"])
                    with files["prediction"].open("wb") as stream:
                        np.savez_compressed(stream, P_test_float32=test_arrays["P_test"], y_test_int64=test_arrays["y_test"])
                    files["fit_record"].write_text(json.dumps(dict(rec, id=key, fixture_only=True)))
                    files["test_record"].write_text(json.dumps(dict(final, id=key + "_day2", fixture_only=True)))
                else:
                    np.savez(files["prediction"], **dict(arrays, normalization_mean=mean, normalization_sd=sd, **test_arrays))
                    files["record"].write_text(json.dumps(dict(rec, **final, n_test=100, job=key, fixture_only=True)))
    protected = project / "IEEE_ACCESS_GONDERIM-v1.7/fixture-protected.txt"
    protected.parent.mkdir(parents=True)
    protected.write_text("Generated stand-in for a protected delivery file\n")
    for name in ("lee_core", "lee_data", "conditions", "training", "campaign"):
        sys.modules.pop(name, None)
    sys.path.remove(str(root / "code"))
    return project


def rewrite_npz(path, change, compressed):
    with np.load(path, allow_pickle=False) as z:
        arrays = {name: z[name] for name in z.files}
    change(arrays)
    with Path(path).open("wb") as stream:
        (np.savez_compressed if compressed else np.savez)(stream, **arrays)


def scenario(template, project, device, alter=None, skip_checks=True):
    """Copy the template, optionally alter archive files, then bind every file and write the engineering protocol."""
    project = Path(project)
    shutil.copytree(template, project)
    if alter is not None:
        alter(project)
    root = project / STUDY

    def leaf(path):
        return dict(path=rel(path, project), sha256=sha(path))

    subjects = {str(s): dict(train=leaf(project / LEE / f"data/prepared/subject_{s:02d}_train.npz"),
                             test=leaf(project / LEE / f"data/prepared/subject_{s:02d}_test.npz"),
                             meta=leaf(project / LEE / f"data/prepared/subject_{s:02d}_meta.json")) for s in PEOPLE}
    archive = {}
    for s in PEOPLE:
        for k in SEEDS:
            for name in REFERENCE:
                kind, files = archive_files(project, s, name, k)
                archive[fit_id(s, name, k)] = dict(format=kind, files={n: leaf(q) for n, q in files.items()})
    protected = project / "IEEE_ACCESS_GONDERIM-v1.7/fixture-protected.txt"
    bindings = dict(status="GENERATED_ENGINEERING_FIXTURE_ONLY", project_relative_paths=True, subjects=subjects,
                    archive=archive, protected={rel(protected, project): sha(protected)})
    bpath = root / "data/SOURCE_BINDINGS-V1.0.json"
    bpath.parent.mkdir(parents=True, exist_ok=True)
    bpath.write_text(json.dumps(bindings, indent=2) + "\n", encoding="utf8")
    protocol = dict(schema="lee2019-s1-w5-control-conditions-v1", study_id=STUDY,
                    status="ENGINEERING_FIXTURE_ONLY", engineering_device=device,
                    engineering_skip_generated_data_checks=bool(skip_checks),
                    design=dict(people=PEOPLE, seeds=SEEDS, phases=PHASES, epochs_per_phase=EPOCHS, train_trials=100,
                                test_trials=100, new_conditions=list(NEW), reference_conditions=list(REFERENCE),
                                reproduction_sample=SAMPLE),
                    analysis=dict(contrasts=["S1-S0", "(W1-W0)-(S1-S0)", "W1-W5", "W5-W4"]),
                    code_sha256={relative: sha(root / relative) for relative in CODE},
                    source_bindings_sha256=sha(bpath), runtime=dict(note="not checked in fixture mode"),
                    engineering_fixture_only="Generated arrays and short budget; no EEG, no result")
    ppath = root / "PROTOKOL-V1.0.json"
    ppath.write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf8")
    return root, sha(ppath)


def launch(root, protocol_sha, wait=True):
    argv = [sys.executable, "-X", "utf8", "-B", str(root / "ops/run_campaign-V1.0.py"), "--protocol",
            str(root / "PROTOKOL-V1.0.json"), "--protocol-sha256", protocol_sha, "--resume"]
    if wait:
        return subprocess.run(argv, cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace")
    return subprocess.Popen(argv, cwd=str(root), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def tail(done):
    return "\n" + done.stdout[-3000:] + done.stderr[-3000:]


def independent_contrasts(root):
    """Recompute the four contrasts from the saved prediction files, with code that shares nothing with
    the analysis script: own decoder, own aggregation, scipy's one-sample t test, own Holm."""
    project = root.parent
    bindings = read(root / "data/SOURCE_BINDINGS-V1.0.json")
    source = read(root / "campaign/REPRODUCTION_TRAIN-V1.0.json")["reference_source"]

    def correct(P, y, walsh):
        """Number of correctly decoded test trials (an integer, so that later arithmetic is exact)."""
        P = P.astype(np.float64)
        if not walsh:
            return int(np.sum(np.argmax(P, 1) == y))
        d0 = ((1 - P) ** 2).sum(1)                                   # code word of class 0: all ones
        d1 = ((1 - P[:, 0::2]) ** 2).sum(1) + (P[:, 1::2] ** 2).sum(1)   # class 1: 1,0,1,0,...
        return int(np.sum(np.where(d1 < d0, 1, 0) == y))

    hits, origin = {}, {}
    for c in REFERENCE + NEW:
        for s in PEOPLE:
            values = []
            for k in SEEDS:
                key = fit_id(s, c, k)
                if c in NEW or source == "REFIT":
                    with np.load(root / "campaign/predictions" / (key + "_day2.npz")) as z:
                        P, y = z["P_test_float32"], z["y_test_int64"]
                    origin[c] = "campaign"
                else:
                    entry = bindings["archive"][key]
                    with np.load(project / entry["files"]["prediction"]["path"]) as z:
                        P, y = (z["P_test"], z["y_test"]) if entry["format"] == "lee" else (z["P_test_float32"], z["y_test_int64"])
                    origin[c] = "archive"
                assert len(y) == 100
                values.append(correct(P, y, c.startswith("W")))
            hits[(s, c)] = sum(values)                               # correct trials over all seeds
    # A seed-mean accuracy difference in percentage points is (difference of hit counts) / (number of seeds).
    formulas = {"S1-S0": lambda s: hits[(s, "S1")] - hits[(s, "S0")],
                "(W1-W0)-(S1-S0)": lambda s: (hits[(s, "W1")] - hits[(s, "W0")]) - (hits[(s, "S1")] - hits[(s, "S0")]),
                "W1-W5": lambda s: hits[(s, "W1")] - hits[(s, "W5")],
                "W5-W4": lambda s: hits[(s, "W5")] - hits[(s, "W4")]}
    out = {}
    for name, formula in formulas.items():
        d = np.array([formula(s) / len(SEEDS) for s in PEOPLE])
        if np.ptp(d) == 0:
            p, ci = (1.0 if d[0] == 0 else 0.0), (float(d[0]), float(d[0]))
        else:
            p = float(stats.ttest_1samp(d, 0.0).pvalue)
            ci = tuple(float(v) for v in stats.t.interval(0.95, len(d) - 1, loc=d.mean(), scale=stats.sem(d)))
        out[name] = dict(values=d, mean=float(d.mean()), p=p, ci=ci)
    ranked = sorted(out, key=lambda n: out[n]["p"])
    running = 0.0
    for i, name in enumerate(ranked):
        running = max(running, (len(ranked) - i) * out[name]["p"])
        out[name]["holm"] = min(1.0, running)
    means = {c: sum(hits[(s, c)] for s in PEOPLE) / (100.0 * len(SEEDS) * len(PEOPLE)) for c in REFERENCE + NEW}
    return out, origin, means


SCIENCE_FILES = ("four_contrasts_holm.json", "run_metrics.csv", "participant_means.csv", "condition_summary.csv",
                 "participant_differences.csv", "W5_W4_first_update_linkage.csv", "W1_W5_last_target_difference.csv")


def science_files(root):
    """Result tables that carry no protocol identifier and no timing: equal campaigns give equal bytes."""
    return {name: (root / "final_analysis" / name).read_bytes() for name in SCIENCE_FILES}


def agrees_with_independent(root, label):
    results = read(root / "final_analysis/RESULTS-V1.0.json")
    mine, origin, means = independent_contrasts(root)
    for entry in results["contrasts"]:
        me = mine[entry["contrast"]]
        check(abs(entry["mean_difference"] - me["mean"]) < 1e-9 and abs(entry["p_unadjusted"] - me["p"]) < 1e-9
              and abs(entry["p_holm_four"] - me["holm"]) < 1e-9
              and abs(entry["pointwise_95ci"][0] - me["ci"][0]) < 1e-9
              and abs(entry["pointwise_95ci"][1] - me["ci"][1]) < 1e-9,
              "%s: analysis equals the independent recomputation, %s" % (label, entry["contrast"]))
    with (root / "final_analysis/participant_differences.csv").open(encoding="utf8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    check(len(rows) == 4 * len(PEOPLE) and all(
        abs(float(r["accuracy_difference_pp"]) - mine[r["contrast"]]["values"][PEOPLE.index(int(r["subject"]))]) < 1e-9
        for r in rows), "%s: every participant-level difference equals the independent recomputation" % label)
    check(all(abs(r["accuracy"] - means[r["condition"]]) < 1e-12 and r["origin"] == origin[r["condition"]]
              for r in results["summaries"]),
          "%s: condition means and their origin equal the independent recomputation" % label)
    with (root / "final_analysis/run_metrics.csv").open(encoding="utf8", newline="") as stream:
        per_fit = list(csv.DictReader(stream))
    check(len(per_fit) == 6 * len(PEOPLE) * len(SEEDS)
          and all(r["origin"] == origin[r["condition"]] for r in per_fit),
          "%s: every per-fit row names the place its numbers were read from" % label)
    return results


def main(device, receipt, keep):
    tick = time.perf_counter()
    base = Path(tempfile.mkdtemp(prefix="S1W5-DRY-")).resolve()
    try:
        template = build_template(base / "TEMPLATE/PROJECT", device)

        # ------------------------------------------------------------------ A: archive reproduces
        root, ps = scenario(template, base / "A/PROJECT", device, skip_checks=False)
        done = launch(root, ps)
        check(done.returncode == 0 and done.stdout.strip().endswith("COMPLETE"), "ARCHIVE scenario completes" + tail(done))
        check(len(list((root / "ops/qa").glob("test_core_training-*.json"))) == 1
              and len(list((root / "ops/qa").glob("test_analysis-*.json"))) == 1,
              "The runner ran both generated-data checks on its device before the campaign")
        decision = read(root / "campaign/REPRODUCTION_TRAIN-V1.0.json")
        check(decision["status"] == "PASS_SAMPLE_AND_LINKAGE_BITWISE_EQUAL" and decision["reference_source"] == "ARCHIVE"
              and decision["compared_fits"] == 4 and decision["linkage_pairs"] == 6
              and decision["second_day_arrays_decoded"] is False,
              "Reproduced archive -> reference comes from the archive")
        check(all(d["all_equal"] and d["max_abs_difference_P_train"] == 0.0 for d in decision["details"].values())
              and all(row["identical"] for row in decision["linkage"].values()),
              "Every sample fit and every W5/W4 linkage equals the archive bit for bit")
        freeze = read(root / "campaign/MODEL_FREEZE-V1.0.json")
        check(freeze["counts"] == dict(fits=16, preprocessors=3, artifacts=51)
              and freeze["status"] == "ALL_16_FITS_FROZEN_BEFORE_DAY2", "ARCHIVE scenario trains 12 new + 4 sample fits")
        rt = read(root / "campaign/REPRODUCTION_TEST-V1.0.json")
        check(rt["status"] == "PASS_ALL_SAMPLE_TEST_OUTPUTS_BITWISE_EQUAL" and rt["compared_fits"] == 4
              and rt["second_day_outputs_of_new_conditions_at_check"] == 0,
              "Sample test outputs equal the archive, compared before any new-condition test")
        results = agrees_with_independent(root, "ARCHIVE")
        check(results["status"] == "COMPLETE_S1_W5_CONTROL_ANALYSIS_VERIFIED" and results["reference_source"] == "ARCHIVE"
              and results["engineering_fixture_only"] is True
              and results["counts"]["reference_fits_from_archive"] == 24 and results["counts"]["new_fits"] == 12,
              "Analysis uses 24 archived reference fits and 12 new fits")
        check([c["contrast"] for c in results["contrasts"]] == ["S1-S0", "(W1-W0)-(S1-S0)", "W1-W5", "W5-W4"]
              and all("p_holm_four" in c for c in results["contrasts"]), "Exactly the four frozen contrasts, one Holm family")
        check(results["reproduction"]["W5_W4_first_update_linkage"]["pairs"] == 6
              and results["reproduction"]["W5_W4_first_update_linkage"]["identical_to_archived_W4"] == 6
              and results["reproduction"]["W5_W4_first_update_linkage"]["identical_to_campaign_W4"] is None,
              "Every W5 fit is bit-linked to its archived W4 fit through the first target update")
        summary = {r["condition"]: r for r in results["summaries"]}
        check(set(summary) == {"S0", "S1", "W0", "W1", "W4", "W5"} and summary["S1"]["origin"] == "campaign"
              and summary["W1"]["origin"] == "archive", "Six condition summaries with their origin")
        check(summary["S0"]["target_mean_abs_change_per_output"] is None
              and summary["W0"]["target_mean_abs_change_per_output"] == 0.0
              and all(summary[c]["target_mean_abs_change_per_output"] > 0 for c in ("S1", "W1", "W4", "W5"))
              and summary["S1"]["target_mean_abs_change_differing_bits"] is None
              and all(summary[c]["target_mean_abs_change_differing_bits"] > 0 for c in ("W1", "W4", "W5"))
              and results["W1_W5_last_target_difference"]["pairs"] == 6
              and results["W1_W5_last_target_difference"]["mean_abs_difference_per_output"] > 0,
              "Target-movement measures are reported for every condition with a moving target")
        check(not any("seconds" in name for name in summary["S1"])
              and (root / "final_analysis/fit_timing.csv").is_file(), "Timing is kept out of the result files")
        completion = read(root / "ops/CAMPAIGN_COMPLETION-V1.0.json")
        check(completion["status"] == "COMPLETE" and completion["engineering_fixture_only"] is True,
              "Completion record is flagged engineering-only")
        fit = read(root / "campaign/fit_records" / "subject_01_train__S1__seed1.json")
        check(fit["campaign_eligible"] is False and fit["scope"] == "ENGINEERING", "Fixture fits are never campaign eligible")
        status = read(root / "campaign/STATUS.json")
        check(status["status"] == "COMPLETE" and not (root / "campaign/RUNNING.lock").exists(), "Status complete, lock removed")
        outputs_a = science_files(root)
        everything = {q.name: q.read_bytes() for q in sorted((root / "final_analysis").iterdir())}
        again = launch(root, ps)
        check(again.returncode == 0
              and {q.name: q.read_bytes() for q in sorted((root / "final_analysis").iterdir())} == everything,
              "Starting a finished campaign again changes nothing" + tail(again))
        # the guard: without the model gate neither a second-day input nor an archived array file can be decoded
        probe = ("import sys; sys.path.insert(0, r'%s'); import campaign as c, numpy as np;"
                 "s = c.validate_protocol(c.PROTOCOL, '%s');"
                 "a = c.archive_train_arrays(s, 'subject_02_train__W1__seed1'); assert a['P_train'].shape == (100, 16);"
                 "print('TRAINING SIDE READ'); sys.stdout.flush();"
                 "p = c.project_path(s.b['%s']['%s']%s['path']);"
                 "np.load(p)") % (str(root / "code"), ps, "%s", "%s", "%s")
        for where, message in ((("subjects", "1", "['test']"), "Second-day arrays are closed"),
                               (("archive", "subject_02_train__W1__seed1", "['files']['prediction']"),
                                "Archived arrays are closed")):
            blocked = subprocess.run([sys.executable, "-X", "utf8", "-B", "-c", probe % where], cwd=str(root),
                                     capture_output=True, text=True, encoding="utf-8", errors="replace")
            check(blocked.returncode != 0 and "TRAINING SIDE READ" in blocked.stdout and message in blocked.stderr,
                  "Without the model gate this is refused: " + message + tail(blocked))

        # ------------------------------------------------------------------ B: stop request, hard kill, restart
        root2, ps2 = scenario(template, base / "B/PROJECT", device)
        (root2 / "campaign").mkdir(parents=True, exist_ok=True)
        (root2 / "campaign/STOP_AFTER_CURRENT_FIT").write_text("stop\n")
        stopped = launch(root2, ps2)
        check(stopped.returncode == 3 and stopped.stdout.strip().endswith("STOPPED_AFTER_CURRENT_FIT")
              and len(list((root2 / "campaign/fit_records").glob("*.json"))) == 1
              and not (root2 / "campaign/STOP_AFTER_CURRENT_FIT").exists()
              and len(list((root2 / "campaign").glob("STOP_AFTER_CURRENT_FIT.honoured-*"))) == 1
              and read(root2 / "campaign/STATUS.json")["status"] == "STOPPED_AFTER_CURRENT_FIT",
              "A stop request ends the run after the current fit, with its own exit code, and is used once" + tail(stopped))
        process = launch(root2, ps2, wait=False)
        deadline = time.time() + 1800
        while time.time() < deadline and len(list((root2 / "campaign/fit_records").glob("*.json"))) < 6:
            if process.poll() is not None:
                break
            time.sleep(0.5)
        check(process.poll() is None, "Campaign is still running when it is interrupted")
        process.kill()                                   # hard kill: no clean-up code runs, the lock file stays behind
        process.wait()
        partial = len(list((root2 / "campaign/fit_records").glob("*.json")))
        check(6 <= partial < 16 and not (root2 / "final_analysis/RESULTS-V1.0.json").exists()
              and (root2 / "campaign/RUNNING.lock").exists(), "Interrupted mid-way, lock left behind")
        resumed = launch(root2, ps2)
        check(resumed.returncode == 0 and resumed.stdout.strip().endswith("COMPLETE"),
              "Interrupted campaign completes after restart" + tail(resumed))
        results2 = read(root2 / "final_analysis/RESULTS-V1.0.json")
        check(science_files(root2) == outputs_a and results2["summaries"] == results["summaries"]
              and results2["contrasts"] == results["contrasts"],
              "Stopped, killed and uninterrupted campaigns give byte-identical result tables")

        # ------------------------------------------------------------------ C: sample does not reproduce
        def alter_c(project):
            _, files = archive_files(project, SAMPLE["subjects"][0], "W4", SAMPLE["seeds"][0])

            def training_output(arrays):
                arrays["P_train_float32"] = arrays["P_train_float32"].copy()
                arrays["P_train_float32"][0, 0] = np.float32(arrays["P_train_float32"][0, 0] * 0.5 + 0.25)
            rewrite_npz(files["fit_outputs"], training_output, True)
            for s in PEOPLE:                             # make any use of archived test outputs visible
                for k in SEEDS:
                    for name in REFERENCE:
                        kind, files = archive_files(project, s, name, k)
                        member = "P_test" if kind == "lee" else "P_test_float32"

                        def constant(arrays, member=member):
                            arrays[member] = np.ones_like(arrays[member])
                        rewrite_npz(files["prediction"], constant, kind == "w4")

        root3, ps3 = scenario(template, base / "C/PROJECT", device, alter=alter_c)
        done = launch(root3, ps3)
        check(done.returncode == 0 and done.stdout.strip().endswith("COMPLETE"), "REFIT scenario completes" + tail(done))
        decision = read(root3 / "campaign/REPRODUCTION_TRAIN-V1.0.json")
        check(decision["status"] == "FAIL_SAMPLE_DIFFERS" and decision["reference_source"] == "REFIT"
              and decision["mismatched_fits"] == ["subject_02_train__W4__seed1"]
              and decision["linkage_mismatched_fits"] == [],
              "A single differing sample fit sends every reference fit to retraining")
        freeze = read(root3 / "campaign/MODEL_FREEZE-V1.0.json")
        check(freeze["counts"] == dict(fits=36, preprocessors=3, artifacts=111), "REFIT scenario trains all 36 fits")
        results3 = agrees_with_independent(root3, "REFIT")
        check(results3["reference_source"] == "REFIT" and results3["counts"]["reference_fits_from_campaign"] == 24
              and results3["counts"]["reference_fits_from_archive"] == 0
              and all(r["origin"] == "campaign" for r in results3["summaries"]),
              "Under REFIT every number comes from this campaign")
        rt3 = read(root3 / "campaign/REPRODUCTION_TEST-V1.0.json")
        check(rt3["status"] == "INFORMATIONAL_SAMPLE_REFIT_VERSUS_ARCHIVE" and rt3["compared_fits"] == 4
              and len(rt3["mismatched_fits"]) == 4, "Under REFIT the sample test comparison is informational")
        versus = {r["condition"]: r for r in results3["reference_refit_versus_archive"]}
        check(set(versus) == set(REFERENCE) and all(r["accuracy_archive"] == 0.5 for r in versus.values())
              and all(r["fits_with_bit_identical_test_outputs"] == 0 and r["fits"] == 6 for r in versus.values()),
              "Under REFIT the altered archive appears only in the descriptive archive-versus-refit table")
        linkage3 = results3["reproduction"]["W5_W4_first_update_linkage"]
        check(linkage3["identical_to_archived_W4"] == 6 and linkage3["identical_to_campaign_W4"] == 6,
              "Under REFIT every W5 fit is also linked to this campaign's own W4 fit")
        check([c["mean_difference"] for c in results["contrasts"]] == [c["mean_difference"] for c in results3["contrasts"]]
              and [c["p_holm_four"] for c in results["contrasts"]] == [c["p_holm_four"] for c in results3["contrasts"]],
              "Archive-based and refit-based analyses agree when the refit reproduces the unaltered archive")

        # ------------------------------------------------------------------ D: sample test output differs
        def alter_d(project):
            _, files = archive_files(project, SAMPLE["subjects"][0], "W1", SAMPLE["seeds"][0])

            def test_output(arrays):
                arrays["P_test"] = arrays["P_test"].copy()
                arrays["P_test"][3, 5] = np.float32(1.0) - arrays["P_test"][3, 5]
            rewrite_npz(files["prediction"], test_output, False)

        root4, ps4 = scenario(template, base / "D/PROJECT", device, alter=alter_d)
        for attempt in ("first start", "second start"):
            done = launch(root4, ps4)
            rt4 = read(root4 / "campaign/REPRODUCTION_TEST-V1.0.json")
            tested = sorted(q.name for q in (root4 / "campaign/test_records").glob("*.json"))
            check(done.returncode == 1 and "second-day outputs of the sample do not" in done.stdout
                  and rt4["status"] == "FAIL_TEST_OUTPUTS_DIFFER" and rt4["mismatched_fits"] == ["subject_02_train__W1__seed1"]
                  and len(tested) == 4 and not any("__S1__" in name or "__W5__" in name for name in tested)
                  and not list((root4 / "campaign/predictions").glob("*__S1__*"))
                  and not list((root4 / "campaign/predictions").glob("*__W5__*"))
                  and not (root4 / "campaign/TEST_COMPLETION-V1.0.json").exists()
                  and not (root4 / "final_analysis").exists()
                  and read(root4 / "campaign/STATUS.json")["status"] == "FAILED"
                  and not (root4 / "campaign/RUNNING.lock").exists()
                  and list((root4 / "ops").glob("CAMPAIGN_FAILURE-*.json")),
                  "A sample test mismatch under ARCHIVE stops before any second-day output of S1 or W5 (%s)" % attempt
                  + tail(done))
        check(read(root4 / "campaign/REPRODUCTION_TRAIN-V1.0.json")["reference_source"] == "ARCHIVE",
              "The training-side decision of that campaign was ARCHIVE")

        # ------------------------------------------------------------------ E: linkage does not hold
        def alter_e(project):
            _, files = archive_files(project, 1, "W4", 2)            # a pair outside the reproduction sample
            record = read(files["fit_record"])
            record["used_target_dist_by_phase"][2] += 1e-6
            files["fit_record"].write_text(json.dumps(record))

        root5, ps5 = scenario(template, base / "E/PROJECT", device, alter=alter_e)
        done = launch(root5, ps5)
        check(done.returncode == 0 and done.stdout.strip().endswith("COMPLETE"), "Linkage scenario completes" + tail(done))
        decision = read(root5 / "campaign/REPRODUCTION_TRAIN-V1.0.json")
        check(decision["status"] == "FAIL_LINKAGE_DIFFERS" and decision["reference_source"] == "REFIT"
              and decision["mismatched_fits"] == [] and decision["linkage_mismatched_fits"] == ["subject_01_train__W5__seed2"],
              "A single unlinked W5/W4 pair sends every reference fit to retraining")
        results5 = agrees_with_independent(root5, "REFIT by linkage")
        linkage5 = results5["reproduction"]["W5_W4_first_update_linkage"]
        check(results5["reference_source"] == "REFIT" and linkage5["identical_to_archived_W4"] == 5
              and linkage5["identical_to_campaign_W4"] == 6
              and all(r["fits_with_bit_identical_test_outputs"] == 6 for r in results5["reference_refit_versus_archive"]),
              "The unlinked pair is reported; the refit itself reproduces the unaltered archive outputs")
    finally:
        if keep:
            print("Fixture kept at", base)
        else:
            shutil.rmtree(base, ignore_errors=True)
    seconds = time.perf_counter() - tick
    value = dict(status="PASS_S1_W5_FULL_PIPELINE_DRY_RUN", checks=len(checks), check_names=checks,
                 device=device, seconds=seconds, torch=str(torch.__version__), numpy=np.__version__,
                 scope="Generated arrays, short budget, real runner as a separate process; scenarios: archive, "
                       "stop/kill/restart, refit by sample, sample test mismatch, refit by linkage; independent "
                       "recomputation of the four contrasts", real_EEG_or_archive_results_opened=0,
                 code_sha256={relative: sha(SOURCE / relative) for relative in CODE + ("qa/test_campaign_dryrun-V1.0.py",)})
    Path(receipt).parent.mkdir(parents=True, exist_ok=True)
    Path(receipt).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(status=value["status"], checks=len(checks), device=device, seconds=round(seconds, 1))))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--keep", action="store_true")
    arguments = parser.parse_args()
    main(arguments.device, arguments.receipt, arguments.keep)
