"""Rehearsal of the launcher and of the protocol freeze, without the campaign computer.

Development check (run while the package was prepared; it is not run at the launch and its file is not
part of the frozen code list). The first real start does three things that cannot be tried on another
machine: it reads the software of the campaign computer, runs the checks on its GPU, and writes the
real protocol. Everything around those three points is exercised here on a stand-in project:

  * a complete copy of the package in a temporary folder that is NOT an engineering fixture;
  * stand-in source bindings with the real structure (54 participants, 1,080 archived fits) over small
    generated files, so that the hash gates run for real;
  * the three machine facts are substituted in this process only: the expected software is set to the
    software of this machine, the check device is "cpu", and the GPU name is a marked stand-in.

What is established: receipts are reused or re-run correctly; the freeze writes the protocol once, with
the prespecified content identified by its SHA-256; every refusal happens before anything is written;
an interrupted freeze is repaired; the runner is started with the frozen protocol and, in a fresh
process without the substitutions, refuses to train (runtime gate) and records why.
"""
from pathlib import Path
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
import time

SOURCE = Path(__file__).resolve().parents[1]
SOURCE_PROJECT = SOURCE.parent
STUDY = SOURCE.name
PACKAGE = ("code/lee_core.py", "code/lee_data.py", "code/conditions.py", "code/training.py", "code/campaign.py",
           "ops/run_campaign-V1.0.py", "ops/launch-V1.0.py", "analysis/final_analysis.py",
           "qa/test_core_training-V1.0.py", "qa/test_analysis-V1.0.py", "qa/test_campaign_dryrun-V1.0.py",
           "records/build_source_bindings-V1.0.py", "records/freeze_protocol-V1.0.py")
EARLIER = ("LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_core.py", "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/code/lee_data.py",
           "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_core.py", "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/code/lee_data.py")
MODULES = ("campaign", "conditions", "lee_core", "lee_data", "training")
STAND_IN_GPU = "REHEARSAL STAND-IN (no GPU on this machine)"
checks = []


def check(value, name):
    if not bool(value):
        raise AssertionError(name)
    checks.append(name.split("\n")[0])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def fit_id(subject, condition, seed):
    return "subject_%02d_train__%s__seed%d" % (subject, condition, seed)


def build(project, receipts):
    """Stand-in project: package copy, earlier code, generated source files with real-structure bindings."""
    project = Path(project)
    root = project / STUDY
    for relative in PACKAGE:
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / relative, target)
    for relative in EARLIER:
        target = project / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE_PROJECT / relative, target)

    def leaf(relative, text):
        path = project / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
        return dict(path=relative, sha256=sha(path))

    subjects, archive = {}, {}
    for s in range(1, 55):
        subjects[str(s)] = {part: leaf("LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/data/prepared/subject_%02d_%s.%s" % (s, part, ext),
                                       "stand-in %d %s" % (s, part))
                            for part, ext in (("train", "npz"), ("test", "npz"), ("meta", "json"))}
        for k in range(1, 6):
            for name in ("S0", "W0", "W1"):
                key = fit_id(s, name, k)
                archive[key] = dict(format="lee", files=dict(
                    record=leaf("LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/results/worker_01/records/%s.json" % key, "{}"),
                    prediction=leaf("LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/results/worker_01/predictions/%s.npz" % key, key)))
            key = fit_id(s, "W4", k)
            base = "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/campaign/"
            archive[key] = dict(format="w4", files=dict(
                fit_record=leaf(base + "fit_records/%s.json" % key, "{}"),
                fit_outputs=leaf(base + "fit_outputs/%s.npz" % key, key + " outputs"),
                test_record=leaf(base + "test_records/%s_day2.json" % key, "{}"),
                prediction=leaf(base + "predictions/%s_day2.npz" % key, key + " prediction")))
    protected = {}
    for index in range(6):
        entry = leaf("IEEE_ACCESS_GONDERIM-v1.7/stand-in-%d.txt" % index, "stand-in delivery file %d" % index)
        protected[entry["path"]] = entry["sha256"]
    bindings = dict(status="BOUND_INPUTS_AND_ARCHIVED_REFERENCE_FITS_BEFORE_S1_W5", project_relative_paths=True,
                    rehearsal_stand_in=True,
                    earlier_code_sha256={relative: sha(project / relative) for relative in EARLIER},
                    subjects=subjects, archive=archive, protected=protected,
                    counts=dict(subjects=54, prepared_files=162, archived_fits=1080, archived_files=2700,
                                protected_files=6))
    path = root / "data/SOURCE_BINDINGS-V1.0.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(bindings, indent=1) + "\n", encoding="utf8")
    for name, source in receipts.items():
        target = root / "ops/preflight" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    return root


def load(root):
    """Import the launcher of this stand-in project and substitute the three machine facts (this process only)."""
    for name in MODULES + ("s1w5_freeze_protocol",):
        sys.modules.pop(name, None)
    sys.path[:] = [entry for entry in sys.path if not entry.endswith(os.sep + "code") or STUDY not in entry]
    spec = importlib.util.spec_from_file_location("s1w5_launch_rehearsal", root / "ops/launch-V1.0.py")
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)                    # puts <root>/code first on sys.path
    import campaign
    assert Path(campaign.__file__).resolve() == (root / "code/campaign.py").resolve(), "stand-in project's own code"
    real_runtime = campaign.runtime
    campaign.runtime = lambda: dict(real_runtime(), GPU=STAND_IN_GPU)
    campaign.core.setup_torch = lambda threads: "cuda"      # only the device name; nothing is trained in this process
    freezer = launcher.load_freezer()
    freezer.EXPECTED_RUNTIME = {key: campaign.runtime()[key] for key in freezer.EXPECTED_RUNTIME}
    freezer.REQUIRED_RECEIPTS = {status: (None if device is None else "cpu") for status, device in freezer.REQUIRED_RECEIPTS.items()}
    launcher.load_freezer = lambda: freezer
    launcher.DEVICE = "cpu"
    return launcher, campaign, freezer


def main(receipt, core, analysis, dryrun, keep):
    tick = time.perf_counter()
    base = Path(tempfile.mkdtemp(prefix="S1W5-REH-")).resolve()
    receipts = {"core-cpu.json": core, "analysis.json": analysis, "dryrun-cpu.json": dryrun}
    try:
        # ------------------------------------------------------------------ 1: a clean first start
        root = build(base / "1/PROJECT", receipts)
        (root / "ops/preflight/analysis.json").unlink()          # this check must really be run by the launcher
        shipped = root / "records/prelaunch"                     # receipts shipped with the package (preparation machine)
        shipped.mkdir(parents=True)
        shutil.copyfile(core, shipped / "core-cpu.json")
        shutil.copyfile(dryrun, shipped / "dryrun-cpu.json")
        (shipped / "not-a-receipt.json").write_text("{\"note\": \"ignored\"}")
        stale = read(core)
        stale["code_sha256"]["code/lee_core.py"] = "0" * 64
        (shipped / "stale.json").write_text(json.dumps(stale))
        launcher, c, freezer = load(root)
        fixed = c.fixed_content_sha256(freezer.fixed_content())
        code = launcher.main(fixed)
        protocol_path = root / "PROTOKOL-V1.0.json"
        record = read(root / "records/PROTOCOL_FREEZE_RECORD-V1.0.json")
        protocol = read(protocol_path)
        check(protocol["status"] == "FROZEN_BEFORE_S1_W5_CONTROL_CONDITIONS" and protocol["fixed_content_sha256"] == fixed
              and c.fixed_content_sha256(protocol) == fixed and record["fixed_content_sha256"] == fixed
              and record["protocol_sha256"] == sha(protocol_path) and record["real_fits"] == 0,
              "First start: the protocol is frozen with the prespecified content identified by its SHA-256")
        check(set(protocol["code_sha256"]) == set(freezer.CODE)
              and all(protocol["code_sha256"][rel] == sha(root / rel) for rel in freezer.CODE)
              and protocol["source_bindings_sha256"] == sha(root / "data/SOURCE_BINDINGS-V1.0.json")
              and protocol["runtime"]["GPU"] == STAND_IN_GPU and protocol["runtime"] == read(root / "ops/preflight/RUNTIME.json"),
              "The machine facts are those observed at the start: code, bindings, runtime")
        used = protocol["prelaunch_checks"]["receipts"]
        check(set(used) == {"ops/preflight/core-cpu.json", "ops/preflight/analysis.json", "ops/preflight/dryrun-cpu.json",
                            "records/prelaunch/core-cpu.json", "records/prelaunch/dryrun-cpu.json"}
              and all(v["status"].startswith("PASS") for v in used.values())
              and len(list((root / "ops/preflight").glob("analysis-*.output.txt"))) == 1
              and not list((root / "ops/preflight").glob("core-*.output.txt")),
              "Valid receipts are reused; the missing check was run by the launcher; shipped receipts are listed "
              "only when they are passes of exactly the present code")
        failures = sorted((root / "ops").glob("CAMPAIGN_FAILURE-*.json"))
        check(code == 1 and len(failures) == 1 and "frozen runtime" in read(failures[0])["error"]
              and read(failures[0])["held_the_lock"] is False
              and read(root / "campaign/STATUS.json")["status"] == "FAILED"
              and not (root / "campaign/RUNNING.lock").exists() and not (root / "campaign/fit_records").exists()
              and not (root / "data/preprocessors").exists(),
              "The runner, in a fresh process, verifies every bound file and then refuses the foreign runtime; "
              "nothing is trained and the reason is on file")
        logs = "\n".join(q.read_text(encoding="utf8") for q in sorted((root / "logs").glob("*.log")))
        check("Protokol donduruldu" in logs and "DURDU (hata)" in logs and "frozen runtime" in logs,
              "Launcher log and run log tell what happened")
        before = protocol_path.read_bytes()
        code = launcher.main(fixed)
        check(code == 1 and protocol_path.read_bytes() == before and record == read(root / "records/PROTOCOL_FREEZE_RECORD-V1.0.json")
              and len(list((root / "ops/preflight").glob("*.output.txt"))) == 1,
              "A second start reuses the frozen protocol and repeats no check")
        check(launcher.main("0" * 64) == 2 and protocol_path.read_bytes() == before,
              "A launcher written for other prespecified content is refused")

        # ------------------------------------------------------------------ 2: refusals before anything is written
        def refused(label, expect, prepare=None, mutate=None, fixed_value=None, campaign_untouched=True):
            folder = base / ("2-%d/PROJECT" % len(checks))
            root = build(folder, receipts)
            if prepare:
                prepare(root)
            launcher, c, freezer = load(root)
            if mutate:
                mutate(launcher, c, freezer)
            code = launcher.main(fixed_value or c.fixed_content_sha256(freezer.fixed_content()))
            text = "\n".join(q.read_text(encoding="utf8") for q in sorted((root / "logs").glob("launch-*.log")))
            check(code == 2 and expect in text and not (root / "PROTOKOL-V1.0.json").exists()
                  and not (root / "records/PROTOCOL_FREEZE_RECORD-V1.0.json").exists()
                  and not (campaign_untouched and (root / "campaign").exists())
                  and not (root / "campaign/STATUS.json").exists(),
                  "Refused before the freeze: " + label + "\n" + text[-1500:])

        refused("other prespecified content than the launcher expects", "baslaticinin bekledigi icerik degil",
                fixed_value="f" * 64)
        refused("software differs from that of the archived fits", "eski egitimlerin yapildigi yazilimdan farkli",
                mutate=lambda launcher, c, freezer: freezer.EXPECTED_RUNTIME.update(numpy="0.0.0"))
        refused("no usable GPU", "Ekran karti",
                mutate=lambda launcher, c, freezer: setattr(c, "runtime", lambda: dict(freezer.EXPECTED_RUNTIME, GPU=None, threads=2, scipy="x")))
        refused("source bindings missing", "Kaynak baglari dosyasi yok",
                prepare=lambda root: (root / "data/SOURCE_BINDINGS-V1.0.json").unlink())
        refused("earlier code changed", "Onceki calismanin kod dosyasi degismis",
                prepare=lambda root: (root.parent / EARLIER[0]).write_bytes((root.parent / EARLIER[0]).read_bytes() + b"\n"))

        def leftover(root):
            (root / "campaign/fit_records").mkdir(parents=True)
            (root / "campaign/fit_records/leftover.json").write_text("{}")
        refused("campaign output exists before the freeze", "kampanya ciktisi bulunamaz", prepare=leftover,
                campaign_untouched=False)
        refused("a check passed only on another device", "A passed check on the campaign device is missing",
                mutate=lambda launcher, c, freezer: freezer.REQUIRED_RECEIPTS.update(
                    {"PASS_S1_W5_CORE_AND_TRAINING_GENERATED_QA": "cuda"}))

        # a receipt that belongs to other code is set aside and its check is run again
        root = build(base / "2-stale/PROJECT", receipts)
        value = read(root / "ops/preflight/analysis.json")
        value["code_sha256"]["analysis/final_analysis.py"] = "0" * 64
        (root / "ops/preflight/analysis.json").write_text(json.dumps(value))
        launcher, c, freezer = load(root)
        code = launcher.main(c.fixed_content_sha256(freezer.fixed_content()))
        fresh = read(root / "ops/preflight/analysis.json")
        check(code == 1 and (root / "PROTOKOL-V1.0.json").exists()
              and fresh["code_sha256"]["analysis/final_analysis.py"] == sha(root / "analysis/final_analysis.py")
              and len(list((root / "ops/orphans").glob("analysis.json-*.bin"))) == 1
              and len(list((root / "ops/preflight").glob("analysis-*.output.txt"))) == 1,
              "A receipt that belongs to other code is set aside and the check is run again before the freeze")

        # ------------------------------------------------------------------ 3: an interrupted freeze is repaired
        root = build(base / "3/PROJECT", receipts)
        launcher, c, freezer = load(root)
        fixed = c.fixed_content_sha256(freezer.fixed_content())
        (root / "PROTOKOL-V1.0.json").write_text("{\"half\": \"written")
        code = launcher.main(fixed)
        check(code == 1 and read(root / "PROTOKOL-V1.0.json")["fixed_content_sha256"] == fixed
              and (root / "records/PROTOCOL_FREEZE_RECORD-V1.0.json").exists()
              and len(list((root / "ops/orphans").glob("PROTOKOL-V1.0.json-*.bin"))) == 1,
              "A protocol file without its freeze record is set aside and the freeze is repeated")
        # the freeze itself is write-once
        try:
            freezer.freeze(str(root / "ops/preflight/RUNTIME.json"), ["ops/preflight/core-cpu.json"], fixed)
        except RuntimeError as error:
            check("written once" in str(error), "A second freeze is refused")
        else:
            raise AssertionError("A second freeze was accepted")
    finally:
        if keep:
            print("Rehearsal kept at", base)
        else:
            shutil.rmtree(base, ignore_errors=True)
    value = dict(status="PASS_S1_W5_LAUNCH_AND_FREEZE_REHEARSAL", checks=len(checks), check_names=checks,
                 seconds=time.perf_counter() - tick,
                 scope="Stand-in project on the preparation machine; machine facts substituted in the test process "
                       "only; no EEG, no archived result, no GPU, no real protocol",
                 code_sha256={relative: sha(SOURCE / relative) for relative in PACKAGE + ("qa/test_launch_rehearsal-V1.0.py",)})
    Path(receipt).parent.mkdir(parents=True, exist_ok=True)
    Path(receipt).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(status=value["status"], checks=len(checks), seconds=round(value["seconds"], 1))))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--core", required=True, help="passed CPU receipt of the training-core check")
    parser.add_argument("--analysis", required=True, help="passed receipt of the analysis check")
    parser.add_argument("--dryrun", required=True, help="passed CPU receipt of the dry run")
    parser.add_argument("--keep", action="store_true")
    arguments = parser.parse_args()
    main(arguments.receipt, arguments.core, arguments.analysis, arguments.dryrun, arguments.keep)
