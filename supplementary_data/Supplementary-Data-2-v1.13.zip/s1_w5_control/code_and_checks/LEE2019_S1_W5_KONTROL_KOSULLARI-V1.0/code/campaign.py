"""Campaign logic of the S1/W5 control study on Lee2019 (EEGNet-8,2).

Order of work, fixed before any real training:

  1. REPRODUCTION SAMPLE  A prespecified sample of previously reported fits (S0, W0, W1, W4) is trained
                          again with this code.
  2. NEW CONDITIONS       All new fits (S1, W5) are trained.
  3. REFERENCE SOURCE     Decided once, from first-day (training-side) information only:
                          "ARCHIVE" if (a) every sample fit reproduces its archived training-side arrays
                          bit for bit and (b) every W5 fit has the same third-phase target distance as the
                          archived W4 fit of the same participant and seed (their first non-zero update is
                          arithmetically the same). Otherwise "REFIT": every reference fit is trained again
                          here and the new family uses only this campaign's fits.
  4. MODEL FREEZE         Every model, checkpoint and training output is listed with its SHA-256.
  5. TEST, SAMPLE FIRST   Only now is second-day data opened. The re-trained sample fits are evaluated first
                          and their test outputs are compared with the archive. Under ARCHIVE a difference
                          stops the campaign before any second-day output of S1 or W5 exists; the fallback
                          written in the protocol is REFIT, by a recorded amendment.
  6. TEST, ALL            One final evaluation per remaining model.
  7. ANALYSIS             Separate script; four contrasts, one Holm family.

No second-day array is decoded before step 4 is complete. The engineering fixture mode exists only
for generated-data dry runs in a marked folder and can never produce campaign-eligible records.
"""
from pathlib import Path
import os
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_key] = "2"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import datetime
import hashlib
import json
import sys
import time
import uuid

import numpy as np
import torch

import conditions as cond
import lee_core as core
import lee_data as data
import training

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
PROTOCOL = ROOT / "PROTOKOL-V1.0.json"
BINDINGS = ROOT / "data/SOURCE_BINDINGS-V1.0.json"
REPRO_TRAIN = ROOT / "campaign/REPRODUCTION_TRAIN-V1.0.json"
MODEL_FREEZE = ROOT / "campaign/MODEL_FREEZE-V1.0.json"
TEST_COMPLETION = ROOT / "campaign/TEST_COMPLETION-V1.0.json"
REPRO_TEST = ROOT / "campaign/REPRODUCTION_TEST-V1.0.json"
STOP_FILE = ROOT / "campaign/STOP_AFTER_CURRENT_FIT"
FIXTURE_MARKER = PROJECT / "ENGINEERING_FIXTURE_ROOT.txt"
REAL_STATUS = "FROZEN_BEFORE_S1_W5_CONTROL_CONDITIONS"
ENGINEERING_STATUS = "ENGINEERING_FIXTURE_ONLY"

# Everything in a real protocol that is fixed before the launch (design, rules, analysis). The machine
# facts added at the launch (runtime, code and source hashes, check receipts, time) are outside this hash.
FIXED_KEYS = ("schema", "study_id", "status", "timezone", "authorization", "research_questions", "design", "counts",
              "data_and_information", "conditions", "schedule", "training", "reference_source_rule", "analysis",
              "gates", "expectations_recorded_before_results", "launch")

_STUDY = None            # set by validate_protocol
_MODEL_GATE = None       # (protocol sha, model freeze sha) once every model is frozen
_HASH_DEPTH = 0
_ARCHIVE_TRAIN_DEPTH = 0
_GUARD = False


def require(value, message):
    if not bool(value):
        raise RuntimeError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def now_utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def fixed_content_sha256(protocol):
    """SHA-256 of the prespecified part of a protocol (canonical JSON of the FIXED_KEYS sections)."""
    require(all(key in protocol for key in FIXED_KEYS), "Protocol misses a prespecified section")
    raw = json.dumps({key: protocol[key] for key in FIXED_KEYS}, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":"), allow_nan=False).encode("utf8")
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    """SHA-256 of the file bytes. Hashing is integrity checking, not decoding; the guard allows it."""
    global _HASH_DEPTH
    _HASH_DEPTH += 1
    try:
        digest = hashlib.sha256()
        with Path(path).open("rb") as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    finally:
        _HASH_DEPTH -= 1


def _replace(temporary, path, what):
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except OSError as error:
            if not isinstance(error, PermissionError) and getattr(error, "winerror", None) not in (5, 32, 33):
                raise
            if attempt == 5:
                raise RuntimeError("Atomic %s replacement failed after 6 bounded attempts" % what) from error
            time.sleep(0.1 * 2 ** attempt)


def atomic_json(path, value, immutable=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf8")
    if immutable and path.exists():
        require(path.read_bytes() == raw, "Immutable JSON differs " + str(path))
        return
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        _replace(temporary, path, "JSON")
    finally:
        if temporary.exists():
            temporary.unlink()


def save_npz(path, **arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.resolve().is_relative_to((ROOT / "campaign/predictions").resolve()):
        require_model_gate()
    require(not path.exists(), "An existing array file must be preserved before replacement")
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            np.savez_compressed(stream, **arrays)
            stream.flush()
            os.fsync(stream.fileno())
        _replace(temporary, path, "NPZ")
    finally:
        if temporary.exists():
            temporary.unlink()


def local(relative):
    """A path inside this study folder, given relative to it."""
    raw = Path(relative)
    require(not raw.is_absolute() and ".." not in raw.parts, "Only relative paths inside the study")
    resolved = (ROOT / raw).resolve()
    require(resolved.is_relative_to(ROOT.resolve()), "Path escaped the study folder")
    return resolved


def project_path(relative):
    """A bound source path, given relative to the project root (forward slashes)."""
    raw = Path(relative)
    require(not raw.is_absolute() and ".." not in raw.parts, "Only relative paths inside the project")
    resolved = (PROJECT / raw).resolve()
    require(resolved.is_relative_to(PROJECT.resolve()), "Path escaped the project folder")
    return resolved


def fit_paths(key):
    return dict(record=f"campaign/fit_records/{key}.json", checkpoint=f"campaign/checkpoints/{key}.ckpt",
                fit_outputs=f"campaign/fit_outputs/{key}.npz")


def test_paths(key):
    return dict(record=f"campaign/test_records/{key}_day2.json", predictions=f"campaign/predictions/{key}_day2.npz")


def prep_path(subject):
    return f"data/preprocessors/subject_{subject:02d}.json"


def runtime():
    import scipy
    return dict(python=sys.version.split()[0], numpy=np.__version__, scipy=scipy.__version__,
                torch=str(torch.__version__), cuda=torch.version.cuda,
                GPU=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None, threads=2)


# --------------------------------------------------------------------------------------------------
# Study definition: protocol, design, source bindings
# --------------------------------------------------------------------------------------------------
class Study:
    def __init__(self, protocol, protocol_sha256, bindings):
        self.p = protocol
        self.ps = protocol_sha256
        self.b = bindings
        self.engineering = protocol["status"] == ENGINEERING_STATUS
        design = protocol["design"]
        self.people = tuple(design["people"])
        self.seeds = tuple(design["seeds"])
        self.phases = design["phases"]
        self.epochs = design["epochs_per_phase"]
        self.sample_subjects = tuple(design["reproduction_sample"]["subjects"])
        self.sample_seeds = tuple(design["reproduction_sample"]["seeds"])
        self.device = protocol.get("engineering_device", "cpu") if self.engineering else "cuda"
        self.scope = "ENGINEERING" if self.engineering else "CAMPAIGN"

    def triples(self, conditions, people=None, seeds=None):
        people = self.people if people is None else people
        seeds = self.seeds if seeds is None else seeds
        return [(s, c, k) for s in people for k in seeds for c in conditions]

    def sample_triples(self):
        return self.triples(cond.REFERENCE, self.sample_subjects, self.sample_seeds)

    def new_triples(self):
        return self.triples(cond.NEW)

    def reference_triples(self):
        return self.triples(cond.REFERENCE)

    def campaign_triples(self, reference_source):
        """Every fit trained in this campaign, in training order (participant, seed, condition)."""
        require(reference_source in ("ARCHIVE", "REFIT"), "Unknown reference source")
        sample = set(self.sample_triples())
        wanted = []
        for s in self.people:
            for k in self.seeds:
                for c in cond.ALL:
                    if c in cond.NEW or reference_source == "REFIT" or (s, c, k) in sample:
                        wanted.append((s, c, k))
        return wanted


def _check_design(p):
    design = p["design"]
    if p["status"] == REAL_STATUS:
        require(design == cond.REAL_DESIGN, "The real campaign design is fixed in code and may not be altered")
        require(not FIXTURE_MARKER.exists(), "A real protocol may not run inside an engineering fixture folder")
    else:
        require(p["status"] == ENGINEERING_STATUS, "Unknown protocol status")
        require(FIXTURE_MARKER.is_file(), "Engineering protocols run only inside a marked fixture folder")
        require(set(design["people"]) <= set(range(1, 55)) and set(design["seeds"]) <= set(range(1, 6)),
                "Fixture participants and seeds must be valid identifiers")
        require(design["new_conditions"] == list(cond.NEW)
                and design["reference_conditions"] == list(cond.REFERENCE), "Fixture keeps the six conditions")
        sample = design["reproduction_sample"]
        require(set(sample["subjects"]) <= set(design["people"]) and set(sample["seeds"]) <= set(design["seeds"])
                and sample["subjects"] and sample["seeds"], "Fixture sample must lie inside the fixture design")
    require(p["analysis"]["contrasts"] == [c[0] for c in cond.CONTRASTS], "Fixed four-contrast family")


def read_bindings(p):
    require(sha(BINDINGS) == p["source_bindings_sha256"], "Source bindings changed")
    b = read(BINDINGS)
    design = p["design"]
    require(set(b["subjects"]) == {str(s) for s in design["people"]}, "Bindings must cover exactly the participants")
    expected = {cond.fit_id(s, c, k) for s in design["people"] for k in design["seeds"] for c in cond.REFERENCE}
    require(set(b["archive"]) == expected, "Bindings must cover exactly the archived reference fits")
    for key, entry in b["archive"].items():
        condition = key.split("__")[1]
        if cond.CONDITIONS[condition]["archive"] == "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0":
            require(entry["format"] == "lee" and set(entry["files"]) == {"record", "prediction"}, "Lee archive leaf")
        else:
            require(entry["format"] == "w4" and set(entry["files"]) == {"fit_record", "fit_outputs", "test_record",
                                                                          "prediction"}, "W4 archive leaf")
    return b


def bound_files(b):
    """Every bound source file as {project-relative path: sha256}."""
    files = {}
    for parts in b["subjects"].values():
        for leaf in parts.values():
            files[leaf["path"]] = leaf["sha256"]
    for entry in b["archive"].values():
        for leaf in entry["files"].values():
            files[leaf["path"]] = leaf["sha256"]
    for path, digest in b.get("protected", {}).items():
        files[path] = digest
    return files


def install_guard(b):
    """Refuse to open second-day arrays before every model is frozen.

    Closed until the model gate: the bound second-day inputs, this study's prediction files, and every
    archived array file. The one exception is archive_train_arrays(), which reads only the named
    first-day (training-side) members of an archived file. Hashing is always allowed.
    """
    global _GUARD
    if _GUARD:
        return
    test_inputs = {project_path(parts["test"]["path"]) for parts in b["subjects"].values()}
    archived = {project_path(leaf["path"]) for entry in b["archive"].values() for leaf in entry["files"].values()
                if leaf["path"].lower().endswith(".npz")}
    predictions = (ROOT / "campaign/predictions").resolve()

    def audit(event, args):
        if event != "open" or not args or not isinstance(args[0], (str, bytes, os.PathLike)):
            return
        name = os.fsdecode(args[0])
        if not name.lower().endswith(".npz") or _HASH_DEPTH > 0:
            return
        resolved = Path(name).resolve()
        if resolved in test_inputs or predictions in resolved.parents:
            require(_MODEL_GATE is not None, "Second-day arrays are closed until every model is frozen")
        elif resolved in archived:
            require(_MODEL_GATE is not None or _ARCHIVE_TRAIN_DEPTH > 0,
                    "Archived arrays are closed until every model is frozen (first-day members excepted)")

    sys.addaudithook(audit)
    _GUARD = True


def validate_protocol(path, protocol_sha256, check_runtime=False, verify_sources=True):
    """Load and check the frozen protocol; returns the Study. Nothing is trained or decoded here."""
    global _STUDY
    require(Path(path).resolve() == PROTOCOL.resolve() and sha(path) == protocol_sha256,
            "Exact frozen protocol path and SHA-256 required")
    p = read(path)
    require(p["study_id"] == cond.STUDY_ID, "Protocol of another study")
    _check_design(p)
    if p["status"] == REAL_STATUS:
        require(p.get("fixed_content_sha256") == fixed_content_sha256(p),
                "The prespecified part of the protocol does not match its recorded SHA-256")
    for relative, digest in p["code_sha256"].items():
        require(sha(local(relative)) == digest, "Frozen code changed: " + relative)
    b = read_bindings(p)
    if verify_sources:
        for relative, digest in bound_files(b).items():
            require(sha(project_path(relative)) == digest, "Bound source file changed: " + relative)
    install_guard(b)
    study = Study(p, protocol_sha256, b)
    if study.engineering:
        core.setup_torch(2)
    elif check_runtime:
        require(p["runtime"] == runtime(), "Software or GPU differs from the frozen runtime: %r" % (runtime(),))
        require(str(core.setup_torch(2)) == "cuda", "The campaign requires the CUDA device")
    _STUDY = study
    return study


# --------------------------------------------------------------------------------------------------
# Archive access (previously reported fits). Training-side members may be read at any time;
# test-side members only after the model gate.
# --------------------------------------------------------------------------------------------------
def archive_entry(study, key):
    return study.b["archive"][key]


def archive_train_arrays(study, key):
    """First-day (training-side) arrays of an archived fit. Only the named members are read."""
    global _ARCHIVE_TRAIN_DEPTH
    entry = archive_entry(study, key)
    walsh = cond.CONDITIONS[key.split("__")[1]]["walsh"]
    _ARCHIVE_TRAIN_DEPTH += 1
    try:
        if entry["format"] == "lee":
            with np.load(project_path(entry["files"]["prediction"]["path"]), allow_pickle=False) as z:
                out = dict(P_train=z["P_train"], y_train=z["y_train"], mean=z["normalization_mean"],
                           sd=z["normalization_sd"], Y_used_last=z["Y_used_last"] if walsh else None)
        else:
            with np.load(project_path(entry["files"]["fit_outputs"]["path"]), allow_pickle=False) as z:
                out = dict(P_train=z["P_train_float32"], y_train=z["y_train_int64"], mean=None, sd=None,
                           Y_used_last=z["Y_used_last_float32"])
    finally:
        _ARCHIVE_TRAIN_DEPTH -= 1
    return out


def archive_test_arrays(study, key):
    require_model_gate()
    entry = archive_entry(study, key)
    with np.load(project_path(entry["files"]["prediction"]["path"]), allow_pickle=False) as z:
        if entry["format"] == "lee":
            return z["P_test"], z["y_test"]
        return z["P_test_float32"], z["y_test_int64"]


def archived_w4_target_distances(study, subject, seed):
    """Per-phase target distances of an archived W4 fit (a first-day quantity; its fit record holds no test value)."""
    entry = archive_entry(study, cond.fit_id(subject, "W4", seed))
    require(entry["format"] == "w4", "W4 fits are archived in the W4 study format")
    record = read(project_path(entry["files"]["fit_record"]["path"]))
    require(not any(name.endswith("_test") for name in record), "A W4 fit record must not hold test values")
    return record["used_target_dist_by_phase"]


# --------------------------------------------------------------------------------------------------
# Records and gates
# --------------------------------------------------------------------------------------------------
def archive_orphan(path, reason):
    """Move an unreceipted leftover aside (never delete evidence, never touch files outside the study)."""
    q = Path(path)
    if not q.exists():
        return
    require(q.resolve().is_relative_to(ROOT.resolve()), "Never move source files")
    digest = sha(q)
    target = ROOT / "ops/orphans" / (q.name[:60] + "-" + digest[:16] + ".bin")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        require(target.read_bytes() == q.read_bytes(), "Orphan evidence collision")
        for attempt in range(6):
            try:
                q.unlink()
                break
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.1 * 2 ** attempt)
    else:
        _replace(q, target, "orphan")
    atomic_json(target.with_suffix(".json"), dict(original_relative=str(q.relative_to(ROOT)).replace("\\", "/"),
                                                  sha256=digest, reason=reason), immutable=True)


def fit_identity(study, subject, condition, seed):
    return dict(study_id=training.STUDY_ID, scope=study.scope, fit_id=cond.fit_id(subject, condition, seed),
                subject=subject, seed=seed, condition=condition, rule=cond.CONDITIONS[condition]["rule"],
                protocol_sha256=study.ps, source_bindings_sha256=study.p["source_bindings_sha256"],
                train_source_sha256=study.b["subjects"][str(subject)]["train"]["sha256"],
                preprocessor_sha256=sha(local(prep_path(subject))))


def expected_updates(study):
    return study.phases * study.epochs * training.batches_per_epoch(100)


def validate_fit_record(study, r, key):
    """Check a fit record against the fit the caller expects (never against the record's own claim)."""
    subject, condition, seed = r["subject"], r["condition"], r["seed"]
    require(type(subject) is int and type(seed) is int and r["id"] == key and r["fit_id"] == key
            and key == cond.fit_id(subject, condition, seed)
            and subject in study.people and seed in study.seeds and condition in cond.ALL,
            "Fit record does not belong to the expected fit")
    require(r["rule"] == cond.CONDITIONS[condition]["rule"] and r["protocol_sha256"] == study.ps
            and r["source_bindings_sha256"] == study.p["source_bindings_sha256"], "Fit provenance")
    require(r["campaign_eligible"] is (not study.engineering) and r["engineering_only"] is study.engineering
            and r["epochs_completed"] == study.phases * study.epochs and r["next_phase"] == study.phases
            and r["actual_update_calls"] == expected_updates(study) and r["terminal_model"] is True
            and r["no_test_arrays_accepted"] is True and r["phase_test_metrics_computed"] is False,
            "Fixed terminal training budget")
    require(r["identity"]["caller"] == fit_identity(study, subject, condition, seed), "Exact fit identity")
    expected = fit_paths(key)
    require(set(r["files"]) == {"checkpoint", "fit_outputs"}, "Exactly checkpoint and training-output leaves")
    for name, leaf in r["files"].items():
        require(leaf["path"] == expected[name] and sha(local(leaf["path"])) == leaf["sha256"],
                "Fit artifact path or SHA")
    return r


def model_files(study, triples):
    files = {}
    for subject in study.people:
        q = local(prep_path(subject))
        r = read(q)
        require(r["subject"] == subject and r["protocol_sha256"] == study.ps and r["fit_trials"] == 100
                and r["train_source_sha256"] == study.b["subjects"][str(subject)]["train"]["sha256"]
                and r["meta_source_sha256"] == study.b["subjects"][str(subject)]["meta"]["sha256"],
                "First-day normalizer metadata")
        for name in ("mean", "sd"):
            v = np.asarray(r[name], dtype=np.float64)
            require(v.shape == (1, 62, 1) and np.isfinite(v).all() and (name != "sd" or np.all(v > 0)),
                    "Normalizer shape or value")
        files[prep_path(subject)] = sha(q)
    for subject, condition, seed in triples:
        key = cond.fit_id(subject, condition, seed)
        relative = fit_paths(key)["record"]
        r = validate_fit_record(study, read(local(relative)), key)
        files[relative] = sha(local(relative))
        for leaf in r["files"].values():
            files[leaf["path"]] = leaf["sha256"]
    require(len(files) == 3 * len(triples) + len(study.people), "Complete model and normalizer artifact union")
    return files


def freeze_status(study):
    return "ALL_%d_FITS_FROZEN_BEFORE_DAY2" % len(study.campaign_triples(reference_source(study)))


def validate_model_freeze(study):
    global _MODEL_GATE
    r = read(MODEL_FREEZE)
    triples = study.campaign_triples(reference_source(study))
    require(r["status"] == freeze_status(study) and r["protocol_sha256"] == study.ps
            and r["reference_source"] == reference_source(study)
            and r["fit_ids"] == [cond.fit_id(*t) for t in triples]
            and r["Day2_arrays_decoded_before_freeze"] is False, "Complete model gate identity")
    require(r["files"] == model_files(study, triples), "Complete immutable artifact union")
    _MODEL_GATE = (study.ps, sha(MODEL_FREEZE))
    return r


def create_model_freeze(study):
    if MODEL_FREEZE.exists():
        return validate_model_freeze(study)
    require(not list((ROOT / "campaign/test_records").glob("*.json"))
            and not list((ROOT / "campaign/predictions").glob("*.npz")), "No second-day outcome before the freeze")
    triples = study.campaign_triples(reference_source(study))
    value = dict(status=freeze_status(study), protocol_sha256=study.ps, reference_source=reference_source(study),
                 source_bindings_sha256=study.p["source_bindings_sha256"],
                 counts=dict(fits=len(triples), preprocessors=len(study.people),
                             artifacts=3 * len(triples) + len(study.people)),
                 fit_ids=[cond.fit_id(*t) for t in triples], files=model_files(study, triples),
                 Day2_arrays_decoded_before_freeze=False)
    atomic_json(MODEL_FREEZE, value, immutable=True)
    return validate_model_freeze(study)


def require_model_gate():
    require(_STUDY is not None and _MODEL_GATE is not None and MODEL_FREEZE.is_file()
            and _MODEL_GATE == (_STUDY.ps, sha(MODEL_FREEZE)), "The complete model gate is required")


def metrics_of(P, y, walsh):
    return core.walsh_metrics(P, y, data.code_rows()) if walsh else core.softmax_metrics(P, y)


def validate_test_receipt(study, r, key, decode=True):
    """Check a test receipt against the fit the caller expects."""
    subject, condition, seed = r["subject"], r["condition"], r["seed"]
    paths = test_paths(key)
    walsh = cond.CONDITIONS[condition]["walsh"]
    require(r["fit_id"] == key and key == cond.fit_id(subject, condition, seed) and r["id"] == key + "_day2"
            and r["protocol_sha256"] == study.ps and r["model_freeze_sha256"] == sha(MODEL_FREEZE)
            and r["source_fit_sha256"] == sha(local(fit_paths(key)["record"])), "Test identity and frozen model")
    require(r["predictions_path"] == paths["predictions"]
            and r["prediction_sha256"] == sha(local(paths["predictions"]))
            and r["n_test"] == 100 and r["final_test_evaluations"] == 1, "One fixed final 100-trial test")
    require(r["evaluation"] == dict(model_state_unchanged=True, BN_unchanged=True, RNG_unchanged=True,
                                    eval_modes_unchanged=True, no_test_statistics_or_gradients=True),
            "Pure terminal evaluation proof")
    if not decode:
        return r
    with np.load(local(paths["predictions"]), allow_pickle=False) as z:
        require(set(z.files) == {"P_test_float32", "y_test_int64"}, "Exact prediction archive members")
        P, y = z["P_test_float32"], z["y_test_int64"]
    require(P.dtype == np.float32 and P.shape == (100, 16 if walsh else 2) and np.isfinite(P).all()
            and np.all((P >= 0) & (P <= 1)) and y.dtype == np.int64 and y.shape == (100,)
            and np.bincount(y, minlength=2).tolist() == [50, 50], "Saved outputs and labels")
    m = metrics_of(P, y, walsh)
    for target, source in (("acc_test", "acc"), ("nll_test", "nll"), ("ece_test", "ece"), ("bce_test", "bce")):
        require(r[target] == m[source], "Metric replay " + target)
    require(r["pred_test"] == m["pred"], "Decision replay")
    return r


def validate_test_manifest(study):
    require_model_gate()
    r = read(TEST_COMPLETION)
    triples = study.campaign_triples(reference_source(study))
    require(r["status"] == "TESTS_COMPLETE" and r["protocol_sha256"] == study.ps
            and r["model_freeze_sha256"] == sha(MODEL_FREEZE)
            and r["counts"] == dict(tests=len(triples), artifacts=2 * len(triples)), "Complete test gate")
    files = {}
    for t in triples:
        key = cond.fit_id(*t)
        paths = test_paths(key)
        record = validate_test_receipt(study, read(local(paths["record"])), key)
        files[paths["record"]] = sha(local(paths["record"]))
        files[paths["predictions"]] = record["prediction_sha256"]
    require(len(files) == 2 * len(triples) and r["files"] == files, "All test receipts and predictions")
    return r


# --------------------------------------------------------------------------------------------------
# Reproduction of archived fits
# --------------------------------------------------------------------------------------------------
def _same(a, b):
    """Bit equality: same dtype, same shape, same bytes (so -0.0 differs from 0.0 and NaN equals itself)."""
    return bool(a.dtype == b.dtype and a.shape == b.shape
                and np.ascontiguousarray(a).tobytes() == np.ascontiguousarray(b).tobytes())


def compare_training_side(study, key):
    """Bitwise comparison of a re-trained reference fit with its archived training-side outputs.

    Compared for every sample fit: training-set outputs and training labels. Also the last used target
    (Walsh conditions) and the first-day normaliser (fits archived in the first Lee2019 study format).
    """
    subject = int(key.split("_")[1])
    old = archive_train_arrays(study, key)
    with np.load(local(fit_paths(key)["fit_outputs"]), allow_pickle=False) as z:
        new = {name: z[name] for name in z.files}
    detail = dict(P_train_equal=_same(new["P_train_float32"], old["P_train"]),
                  labels_equal=_same(new["y_train_int64"], old["y_train"]))
    if old["Y_used_last"] is not None:
        detail["Y_used_last_equal"] = ("Y_used_last_float32" in new
                                       and _same(new["Y_used_last_float32"], old["Y_used_last"]))
    if old["mean"] is not None:
        prep = read(local(prep_path(subject)))
        detail["normalizer_equal"] = (_same(np.asarray(prep["mean"], dtype=np.float64), old["mean"])
                                      and _same(np.asarray(prep["sd"], dtype=np.float64), old["sd"]))
    if new["P_train_float32"].shape == old["P_train"].shape:
        detail["max_abs_difference_P_train"] = float(np.max(np.abs(
            new["P_train_float32"].astype(np.float64) - old["P_train"].astype(np.float64))))
    detail["all_equal"] = all(v for k, v in detail.items() if k.endswith("_equal"))
    return detail


def linkage_with_archived_w4(study):
    """First-day check for every W5 fit of this campaign against the archived W4 fit of the same
    participant and seed: the first non-zero W5 update (label share 0.97) is arithmetically the W4 update,
    so the mean target distance used in the third phase must be the same number in both records."""
    require(study.phases >= 3, "The linkage needs at least three phases")
    rows = {}
    for subject in study.people:
        for seed in study.seeds:
            key = cond.fit_id(subject, "W5", seed)
            new = validate_fit_record(study, read(local(fit_paths(key)["record"])), key)["used_target_dist_by_phase"]
            old = archived_w4_target_distances(study, subject, seed)
            require(len(new) == study.phases and len(old) >= 3, "Target-distance history")
            rows[key] = dict(W5_phase2_target_distance=new[2], archived_W4_phase2_target_distance=old[2],
                             identical=bool(new[2] == old[2]))
    return rows


def decide_reference_source(study):
    """After the sample and the new fits are trained: write (once) where the reference conditions come from.

    Only first-day information is used. ARCHIVE requires both (a) every sample fit bit-identical to its
    archived training-side arrays and (b) every W5 fit linked to its archived W4 fit; otherwise REFIT.
    """
    details = {cond.fit_id(*t): compare_training_side(study, cond.fit_id(*t)) for t in study.sample_triples()}
    mismatches = sorted(key for key, d in details.items() if not d["all_equal"])
    linkage = linkage_with_archived_w4(study)
    unlinked = sorted(key for key, row in linkage.items() if not row["identical"])
    if not mismatches and not unlinked:
        status = "PASS_SAMPLE_AND_LINKAGE_BITWISE_EQUAL"
    elif mismatches and unlinked:
        status = "FAIL_SAMPLE_AND_LINKAGE_DIFFER"
    else:
        status = "FAIL_SAMPLE_DIFFERS" if mismatches else "FAIL_LINKAGE_DIFFERS"
    outcome = dict(status=status, reference_source="ARCHIVE" if status.startswith("PASS") else "REFIT",
                   compared_fits=len(details), mismatched_fits=mismatches,
                   linkage_pairs=len(linkage), linkage_mismatched_fits=unlinked)
    if REPRO_TRAIN.exists():
        saved = read(REPRO_TRAIN)
        require(saved["protocol_sha256"] == study.ps and all(saved[k] == v for k, v in outcome.items()),
                "A repeated comparison must reach the recorded decision")
        return saved
    value = dict(outcome, protocol_sha256=study.ps, decided_utc=now_utc(),
                 sample=dict(subjects=list(study.sample_subjects), seeds=list(study.sample_seeds),
                             conditions=list(cond.REFERENCE)),
                 rule="ARCHIVE only if every sample fit reproduces its archived training-side arrays bit for bit "
                      "and every W5 fit has the archived W4 third-phase target distance of the same participant "
                      "and seed; otherwise every reference fit is trained again in this campaign.",
                 second_day_arrays_decoded=False, details=details, linkage=linkage)
    atomic_json(REPRO_TRAIN, value)
    return value


def reference_source(study):
    require(REPRO_TRAIN.is_file(), "The reference-source decision has not been made yet")
    r = read(REPRO_TRAIN)
    require(r["protocol_sha256"] == study.ps and r["reference_source"] in ("ARCHIVE", "REFIT")
            and (r["reference_source"] == "ARCHIVE") == (not r["mismatched_fits"] and not r["linkage_mismatched_fits"])
            and r["compared_fits"] == len(study.sample_triples())
            and r["linkage_pairs"] == len(study.people) * len(study.seeds), "Decision record")
    return r["reference_source"]


def reproduction_test_check(study):
    """After the sample fits are tested: compare their second-day outputs with the archive.

    Under ARCHIVE this is a gate. It runs before any second-day output of S1 or W5 exists, so that the
    fallback written in the protocol (REFIT, by a recorded amendment) cannot depend on those outputs.
    Under REFIT the comparison is informational.
    """
    require_model_gate()
    source = reference_source(study)
    triples = study.sample_triples()
    details, mismatches = {}, []
    for t in triples:
        key = cond.fit_id(*t)
        with np.load(local(test_paths(key)["predictions"]), allow_pickle=False) as z:
            P, y = z["P_test_float32"], z["y_test_int64"]
        P_old, y_old = archive_test_arrays(study, key)
        equal = _same(P, P_old) and _same(y, y_old)
        details[key] = equal
        if not equal:
            mismatches.append(key)
    if source == "ARCHIVE":
        status = "PASS_ALL_SAMPLE_TEST_OUTPUTS_BITWISE_EQUAL" if not mismatches else "FAIL_TEST_OUTPUTS_DIFFER"
    else:
        status = "INFORMATIONAL_SAMPLE_REFIT_VERSUS_ARCHIVE"
    outcome = dict(status=status, reference_source=source, compared_fits=len(triples),
                   mismatched_fits=sorted(mismatches))
    if REPRO_TEST.exists():
        saved = read(REPRO_TEST)
        require(all(saved[k] == v for k, v in outcome.items()), "A repeated comparison must reach the recorded result")
    else:
        new_outputs = [t for t in study.new_triples() if local(test_paths(cond.fit_id(*t))["record"]).exists()
                       or local(test_paths(cond.fit_id(*t))["predictions"]).exists()]
        require(not new_outputs, "The sample comparison must precede every second-day output of S1 and W5")
        atomic_json(REPRO_TEST, dict(outcome, protocol_sha256=study.ps, checked_utc=now_utc(),
                                     model_freeze_sha256=sha(MODEL_FREEZE),
                                     second_day_outputs_of_new_conditions_at_check=0, details=details))
    require(source != "ARCHIVE" or not mismatches,
            "Training-side outputs matched the archive but second-day outputs of the sample do not. The campaign "
            "stops here; no second-day output of S1 or W5 exists. The protocol's fallback is REFIT, by a recorded "
            "amendment.")
    return outcome


def require_reproduction_test(study):
    """Second-day evaluation beyond the sample needs the recorded, passed sample comparison."""
    require(REPRO_TEST.is_file(), "The sample test comparison has not been made yet")
    r = read(REPRO_TEST)
    source = reference_source(study)
    require(r["protocol_sha256"] == study.ps and r["reference_source"] == source
            and r["model_freeze_sha256"] == sha(MODEL_FREEZE) and r["compared_fits"] == len(study.sample_triples())
            and (source != "ARCHIVE" or (r["status"] == "PASS_ALL_SAMPLE_TEST_OUTPUTS_BITWISE_EQUAL"
                                         and not r["mismatched_fits"])), "Sample test comparison record")


# --------------------------------------------------------------------------------------------------
# The campaign
# --------------------------------------------------------------------------------------------------
class Campaign:
    def __init__(self, study, status=None):
        self.study = study
        self.status = status or (lambda **fields: None)

    def prepare_subject(self, subject):
        study = self.study
        source = study.b["subjects"][str(subject)]
        for leaf in source.values():
            require(sha(project_path(leaf["path"])) == leaf["sha256"], "Prepared source bytes changed")
        meta = read(project_path(source["meta"]["path"]))
        require(meta.get("data_units", meta.get("units")) == "uV" and meta["subject"] == subject,
                "Participant and unit contract")
        x, y = data.load_part(project_path(source["train"]["path"]), "train")
        require(x.shape == (100, 62, 512), "Exact 100 x 62 x 512 first-day input")
        mean, sd = data.zscore_fit(x)
        prep = dict(subject=subject, protocol_sha256=study.ps,
                    source_bindings_sha256=study.p["source_bindings_sha256"],
                    train_source_sha256=source["train"]["sha256"], meta_source_sha256=source["meta"]["sha256"],
                    fit_trials=100, input_unit="uV", mean=mean.tolist(), sd=sd.tolist(),
                    recipe="Original float64 channel mean and population SD + 1e-6 over trials and time; "
                           "float32 transformed input")
        atomic_json(local(prep_path(subject)), prep, immutable=True)
        return data.zscore_apply(x, mean, sd), y

    def train(self, triples, stage):
        """Train every listed fit that has no record yet. Returns False if a stop was requested."""
        study = self.study
        todo = [t for t in triples if not local(fit_paths(cond.fit_id(*t))["record"]).exists()]
        pending = set(todo)
        for t in triples:
            if t not in pending:
                validate_fit_record(study, read(local(fit_paths(cond.fit_id(*t))["record"])), cond.fit_id(*t))
        done, total = len(triples) - len(todo), len(triples)
        started = time.time()
        current, x, y = None, None, None
        for index, (subject, condition, seed) in enumerate(todo):
            if subject != current:
                x, y = self.prepare_subject(subject)
                current = subject
            key = cond.fit_id(subject, condition, seed)
            paths = fit_paths(key)
            archive_orphan(local(paths["fit_outputs"]), "Unreceipted training output of the same fixed fit")
            elapsed = time.time() - started
            eta = None if index == 0 else elapsed / index * (len(todo) - index)
            self.status(stage=stage, fit_id=key, phase=0, stage_done=done + index, stage_total=total,
                        stage_eta_seconds=eta)

            def progress(phase, phases, seconds, key=key, index=index, eta=eta):
                self.status(stage=stage, fit_id=key, phase=phase, total_phases=phases, train_seconds=seconds,
                            stage_done=done + index, stage_total=total, stage_eta_seconds=eta)

            identity = fit_identity(study, subject, condition, seed)
            checkpoint = local(paths["checkpoint"])
            if study.engineering:
                model, record, outputs = training.fit_engineering(
                    x, y, identity, device=study.device, checkpoint_path=checkpoint, resume=checkpoint.exists(),
                    progress=progress, phases=study.phases, epochs=study.epochs)
            else:
                model, record, outputs = training.fit(x, y, identity, device="cuda", checkpoint_path=checkpoint,
                                                      resume=checkpoint.exists(), progress=progress)
            save_npz(local(paths["fit_outputs"]), **outputs)
            record.update(id=key, n_train=100, preprocessor_path=prep_path(subject),
                          files={name: dict(path=paths[name], sha256=sha(local(paths[name])))
                                 for name in ("checkpoint", "fit_outputs")})
            atomic_json(local(paths["record"]), record, immutable=True)
            validate_fit_record(study, record, key)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            if STOP_FILE.exists():
                return False
        return True

    def test(self, triples, stage):
        """One final second-day evaluation for every listed fit that has no test receipt yet."""
        study = self.study
        require_model_gate()
        sample = set(study.sample_triples())
        if any(t not in sample for t in triples):
            require_reproduction_test(study)
        device = torch.device(study.device)
        by_subject = {}
        for t in triples:
            by_subject.setdefault(t[0], []).append(t)
        done = 0
        for subject in study.people:
            if subject not in by_subject:
                continue
            source = study.b["subjects"][str(subject)]
            require(sha(project_path(source["test"]["path"])) == source["test"]["sha256"],
                    "Bound second-day source changed before decoding")
            pending = [t for t in by_subject[subject]
                       if not local(test_paths(cond.fit_id(*t))["record"]).exists()]
            for t in by_subject[subject]:
                if t not in pending:
                    validate_test_receipt(study, read(local(test_paths(cond.fit_id(*t))["record"])), cond.fit_id(*t))
                    done += 1
            if not pending:
                continue
            xraw, y = data.load_part(project_path(source["test"]["path"]), "test")
            require(xraw.shape == (100, 62, 512), "Exact prepared second-day shape")
            prep = read(local(prep_path(subject)))
            x = data.zscore_apply(xraw, np.asarray(prep["mean"], dtype=np.float64),
                                  np.asarray(prep["sd"], dtype=np.float64))
            for _, condition, seed in pending:
                key = cond.fit_id(subject, condition, seed)
                spec = cond.CONDITIONS[condition]
                paths = test_paths(key)
                archive_orphan(local(paths["predictions"]), "Unreceipted fixed terminal prediction")
                fit = validate_fit_record(study, read(local(fit_paths(key)["record"])), key)
                cp = training.load_checkpoint(local(fit_paths(key)["checkpoint"]),
                                              expected_identity=fit["identity"]["caller"],
                                              expected_sha256=fit["files"]["checkpoint"]["sha256"],
                                              allow_engineering=study.engineering, require_complete=True)
                model = core.build_model("EEGNet", 62, 512, spec["n_out"], data.PARAMS["dropout"]).to(device)
                model.load_state_dict(cp["state"]["model"], strict=True)
                model.eval()
                require(training.model_hash(model) == fit["final_model_sha256"], "Frozen model and fit record linkage")
                before = training.model_hash(model)
                rng = training.tree_hash(core._rng_state())
                modes = {name: m.training for name, m in model.named_modules()}
                self.status(stage=stage, fit_id=key, stage_done=done, stage_total=len(triples))
                result, arrays = core.evaluate_final(model, x, y, walsh=spec["walsh"], C=data.code_rows(), dev=device)
                require(training.model_hash(model) == before and training.tree_hash(core._rng_state()) == rng
                        and modes == {name: m.training for name, m in model.named_modules()},
                        "Evaluation must leave model, BatchNorm, RNG and modes unchanged")
                save_npz(local(paths["predictions"]), P_test_float32=arrays["P_test"], y_test_int64=arrays["y_test"])
                result.update(id=key + "_day2", fit_id=key, subject=subject, seed=seed, condition=condition,
                              n_test=100, protocol_sha256=study.ps,
                              source_bindings_sha256=study.p["source_bindings_sha256"],
                              model_freeze_sha256=sha(MODEL_FREEZE),
                              source_fit_sha256=sha(local(fit_paths(key)["record"])),
                              predictions_path=paths["predictions"],
                              prediction_sha256=sha(local(paths["predictions"])),
                              evaluation=dict(model_state_unchanged=True, BN_unchanged=True, RNG_unchanged=True,
                                              eval_modes_unchanged=True, no_test_statistics_or_gradients=True),
                              decoder=("Walsh: nearest code word on float64 outputs" if spec["walsh"]
                                       else "Softmax: largest class probability"))
                atomic_json(local(paths["record"]), result, immutable=True)
                validate_test_receipt(study, result, key)
                done += 1
                del cp, model
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

    def complete_tests(self):
        """List every test receipt and prediction file of the campaign (written once)."""
        study = self.study
        require_model_gate()
        require_reproduction_test(study)
        triples = study.campaign_triples(reference_source(study))
        files = {}
        for t in triples:
            key = cond.fit_id(*t)
            paths = test_paths(key)
            r = validate_test_receipt(study, read(local(paths["record"])), key)
            files[paths["record"]] = sha(local(paths["record"]))
            files[paths["predictions"]] = r["prediction_sha256"]
        atomic_json(TEST_COMPLETION, dict(status="TESTS_COMPLETE", protocol_sha256=study.ps,
                                          model_freeze_sha256=sha(MODEL_FREEZE),
                                          counts=dict(tests=len(triples), artifacts=2 * len(triples)), files=files),
                    immutable=True)
        return validate_test_manifest(study)

    def run(self):
        study = self.study
        if MODEL_FREEZE.exists():
            validate_model_freeze(study)
        else:
            if not self.train(study.sample_triples(), "TRAIN_REPRODUCTION_SAMPLE"):
                return "STOPPED_AFTER_CURRENT_FIT"
            if not self.train(study.new_triples(), "TRAIN_NEW_CONDITIONS"):
                return "STOPPED_AFTER_CURRENT_FIT"
            decision = decide_reference_source(study)
            source = decision["reference_source"]
            self.status(stage="REFERENCE_SOURCE_DECIDED", reference_source=source, decision_status=decision["status"],
                        remaining_reference_fits=len(study.campaign_triples(source)) - len(study.sample_triples())
                        - len(study.new_triples()))
            if not self.train(study.campaign_triples(source), "TRAIN_REFERENCE_CONDITIONS"):
                return "STOPPED_AFTER_CURRENT_FIT"
            create_model_freeze(study)
        self.status(stage="MODELS_FROZEN", fits=len(study.campaign_triples(reference_source(study))))
        self.test(study.sample_triples(), "TEST_REPRODUCTION_SAMPLE")
        outcome = reproduction_test_check(study)
        self.status(stage="SAMPLE_TEST_COMPARED", comparison_status=outcome["status"])
        self.test(study.campaign_triples(reference_source(study)), "TEST_DAY2")
        self.complete_tests()
        return "TESTS_COMPLETE"
