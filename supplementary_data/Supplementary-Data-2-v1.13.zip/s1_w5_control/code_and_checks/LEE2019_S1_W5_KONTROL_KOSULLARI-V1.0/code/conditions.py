"""Condition table and fixed design constants of the S1/W5 control study.

Six conditions share one model family, one data split and one training budget.
Four of them (S0, W0, W1, W4) were reported before and are "reference"
conditions here; two (S1, W5) are new. Nothing in this module reads data.
"""
from lee_data import R_RATE, PHASES

STUDY_ID = "LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0"

# walsh  : 16 sigmoid outputs trained with bit-wise binary cross-entropy against a 16-bit Walsh code word;
#          otherwise 2 softmax outputs trained with cross-entropy.
# rule   : target-update rule applied after every training phase (lee_core.update_targets).
# archive: where the previously reported fits of a reference condition are stored.
CONDITIONS = {
    "S0": dict(walsh=False, rule="hard", n_out=2, role="reference", archive="LEE2019_BAGIMSIZ_DOGRULAMA-V1.0"),
    "W0": dict(walsh=True, rule="hard", n_out=16, role="reference", archive="LEE2019_BAGIMSIZ_DOGRULAMA-V1.0"),
    "W1": dict(walsh=True, rule="neg_paper", n_out=16, role="reference", archive="LEE2019_BAGIMSIZ_DOGRULAMA-V1.0"),
    "W4": dict(walsh=True, rule="neg_anchor_all", n_out=16, role="reference",
               archive="LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0"),
    "S1": dict(walsh=False, rule="neg_paper", n_out=2, role="new", archive=None),
    "W5": dict(walsh=True, rule="neg_anchor_all_matched", n_out=16, role="new", archive=None),
}
NEW = ("S1", "W5")
REFERENCE = ("S0", "W0", "W1", "W4")
ALL = REFERENCE + NEW

# The complete, fixed design of the real campaign. An engineering fixture may use a smaller design,
# but only under a different protocol status and inside a marked fixture folder (see campaign.py).
REAL_DESIGN = dict(
    people=list(range(1, 55)),
    seeds=[1, 2, 3, 4, 5],
    phases=10,
    epochs_per_phase=30,
    train_trials=100,
    test_trials=100,
    new_conditions=list(NEW),
    reference_conditions=list(REFERENCE),
    reproduction_sample=dict(subjects=[3, 9, 15, 21, 27, 33, 39, 45, 51], seeds=[1, 5]),
)

# The four contrasts of the single new exploratory family, as (name, plus terms, minus terms).
CONTRASTS = (
    ("S1-S0", ("S1",), ("S0",)),
    ("(W1-W0)-(S1-S0)", ("W1", "S0"), ("W0", "S1")),
    ("W1-W5", ("W1",), ("W5",)),
    ("W5-W4", ("W5",), ("W4",)),
)


def rate(p):
    """Negotiation rate of the update made after zero-based phase p (first used in phase p+1)."""
    return R_RATE * p


def label_share(p):
    """Share of the original label left in the cumulative (W1/S1) target after the updates of phases 1..p.

    W5 uses this value directly as the weight of the label, so that its target used in phase p+1 holds
    the same label share as the W1 target, with the remainder taken from the current prediction only.
    """
    share = 1.0
    for k in range(1, p + 1):
        share *= 1.0 - R_RATE * k
    return share


def schedule(phases=PHASES):
    """Per training phase: rate of the update that produced its target and the label share of that target."""
    rows = []
    for phase in range(phases):
        update = phase - 1                      # the target used in `phase` was written after phase-1
        rows.append(dict(phase=phase,
                         rate_of_update=0.0 if update < 0 else rate(update),
                         label_share_cumulative_and_matched=1.0 if update < 0 else label_share(update),
                         prediction_share_anchored_W4=0.0 if update < 0 else rate(update)))
    return rows


def fit_id(subject, condition, seed):
    return f"subject_{subject:02d}_train__{condition}__seed{seed}"
