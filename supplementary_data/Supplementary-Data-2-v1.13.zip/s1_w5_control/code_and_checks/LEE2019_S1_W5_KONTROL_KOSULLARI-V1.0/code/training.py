"""Checkpointed, resumable fit of one model for the S1/W5 control study.

The training loop itself is lee_core.fit_training_only (the released loop plus the
two declared additions). This wrapper only adds: a strict identity, an integrity-
checked checkpoint at every phase boundary, exact resume, and a fit record.

No test array or test label is accepted here. The short engineering path can
never produce a campaign-eligible fit.
"""
from pathlib import Path
import copy
import hashlib
import io
import json
import os
import struct
import time
import uuid

import numpy as np
import torch

import conditions as cond
import lee_core as core
import lee_data as data

STUDY_ID = cond.STUDY_ID
MAGIC = b"LEE2019_S1_W5_PHASE_CHECKPOINT_V1\x00"
SCHEMA = "lee2019-s1-w5-full-phase-state-v1"
PARAMS = dict(data.PARAMS)
STATE_KEYS = {"model", "optimizer", "generator", "rng", "next_phase", "Yneg", "Y_used", "gate",
              "used_dist", "used_gate", "phase_seconds", "train_seconds"}
HEX = set("0123456789abcdef")


def need(value, message):
    if not bool(value):
        raise RuntimeError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(value):
    """Order- and type-aware SHA-256 of nested tensors, arrays, dicts, lists and scalars."""
    digest = hashlib.sha256()

    def frame(raw):
        digest.update(len(raw).to_bytes(8, "big"))
        digest.update(raw)

    def visit(v):
        if torch.is_tensor(v):
            frame(b"tensor")
            frame(str(v.dtype).encode())
            frame(str(tuple(v.shape)).encode())
            frame(v.detach().cpu().contiguous().numpy().tobytes())
        elif isinstance(v, np.ndarray):
            frame(b"array")
            frame(str(v.dtype).encode())
            frame(str(v.shape).encode())
            frame(np.ascontiguousarray(v).tobytes())
        elif isinstance(v, dict):
            frame(b"dict")
            for key in sorted(v, key=lambda x: (str(type(x)), repr(x))):
                visit(key)
                visit(v[key])
        elif isinstance(v, (tuple, list)):
            frame(type(v).__name__.encode())
            frame(str(len(v)).encode())
            for item in v:
                visit(item)
        else:
            frame(type(v).__name__.encode())
            frame(repr(v).encode())

    visit(value)
    return digest.hexdigest()


def cpu_copy(value):
    if torch.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, np.ndarray):
        return value.copy()
    if isinstance(value, dict):
        return {key: cpu_copy(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(cpu_copy(item) for item in value)
    if isinstance(value, list):
        return [cpu_copy(item) for item in value]
    return copy.deepcopy(value)


def model_hash(model):
    return tree_hash(model.state_dict())


def validate_identity(identity, engineering=False):
    c = json.loads(canonical(identity))
    need(c.get("study_id") == STUDY_ID and c.get("scope") == ("ENGINEERING" if engineering else "CAMPAIGN"),
         "Wrong study or scope")
    subject, seed, condition = c.get("subject"), c.get("seed"), c.get("condition")
    need(type(subject) is int and 1 <= subject <= 54 and type(seed) is int and 1 <= seed <= 5,
         "Wrong participant or seed")
    need(condition in cond.CONDITIONS and c.get("rule") == cond.CONDITIONS[condition]["rule"],
         "Unknown condition or rule not matching the condition")
    need(c.get("fit_id") == cond.fit_id(subject, condition, seed), "Fit id does not match its fields")
    for key in ("protocol_sha256", "source_bindings_sha256", "train_source_sha256", "preprocessor_sha256"):
        v = c.get(key)
        need(isinstance(v, str) and len(v) == 64 and set(v) <= HEX, "Missing provenance " + key)
    need(set(c) == {"study_id", "scope", "fit_id", "subject", "seed", "condition", "rule", "protocol_sha256",
                    "source_bindings_sha256", "train_source_sha256", "preprocessor_sha256"},
         "Unexpected identity fields")
    return c


def batches_per_epoch(n, batch=None):
    batch = PARAMS["batch"] if batch is None else batch
    count = (n + batch - 1) // batch
    if count > 1 and n % batch == 1:          # lee_core._batches merges a final single-sample batch
        count -= 1
    return count


def _atomic_checkpoint(path, payload):
    stream = io.BytesIO()
    torch.save(payload, stream)
    body = stream.getvalue()
    raw = MAGIC + struct.pack(">Q", len(body)) + hashlib.sha256(body).digest() + body
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                break
            except OSError as error:
                if not isinstance(error, PermissionError) and getattr(error, "winerror", None) not in (5, 32, 33):
                    raise
                if attempt == 5:
                    raise RuntimeError("Phase checkpoint replace failed after 6 bounded attempts") from error
                time.sleep(0.1 * 2 ** attempt)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_checkpoint(path, *, expected_identity=None, expected_sha256=None, allow_engineering=False,
                    require_complete=False):
    raw = Path(path).read_bytes()
    if expected_sha256 is not None:
        need(hashlib.sha256(raw).hexdigest() == expected_sha256, "Checkpoint file SHA changed")
    header = len(MAGIC) + 40
    need(len(raw) >= header and raw[:len(MAGIC)] == MAGIC, "Not a checkpoint of this study")
    body = raw[header:]
    need(struct.unpack(">Q", raw[len(MAGIC):len(MAGIC) + 8])[0] == len(body)
         and hashlib.sha256(body).digest() == raw[len(MAGIC) + 8:header], "Checkpoint size or payload SHA mismatch")
    cp = torch.load(io.BytesIO(body), map_location="cpu", weights_only=False)
    need(cp.get("schema") == SCHEMA and type(cp.get("engineering")) is bool
         and (not cp["engineering"] or allow_engineering), "Wrong schema or engineering checkpoint")
    identity = validate_identity(cp["identity"]["caller"], cp["engineering"])
    if expected_identity is not None:
        need(identity == expected_identity, "Checkpoint belongs to another fit, source or protocol")
    need(cp["identity_canonical"] == canonical(cp["identity"]) and tree_hash(cp["state"]) == cp["state_sha256"],
         "Checkpoint state or identity changed")
    spec = cond.CONDITIONS[identity["condition"]]
    phases, epochs = cp["identity"]["phases"], cp["identity"]["epochs_per_phase"]
    state = cp["state"]
    n = cp["identity"]["input_shape"][0]
    need(cp["identity"]["input_shape"][1:] == [62, 512]
         and (cp["engineering"] or (n == 100 and phases == 10 and epochs == 30)), "Wrong fixed dimensions or budget")
    need(set(state) == STATE_KEYS, "Incomplete phase checkpoint state")
    done = state["next_phase"]
    need(type(done) is int and 1 <= done <= phases and len(state["phase_seconds"]) == done, "Incomplete phase history")
    has_targets = spec["walsh"] or spec["rule"] != "hard"
    if has_targets:
        width = 16 if spec["walsh"] else 2
        need(len(state["used_dist"]) == len(state["used_gate"]) == done, "Incomplete target history")
        need(all(v is None for v in state["used_gate"]) and state["gate"] is None,
             "No condition of this study uses a correctness gate")
        for key in ("Yneg", "Y_used"):
            v = state[key]
            need(isinstance(v, np.ndarray) and v.dtype == np.float32 and v.shape == (n, width)
                 and np.isfinite(v).all() and np.all(v >= 0) and np.all(v <= 1), "Invalid float32 targets")
    else:
        need(state["Yneg"] is None and state["Y_used"] is None and state["gate"] is None
             and state["used_dist"] == [] and state["used_gate"] == [], "Hard softmax keeps no target arrays")
    need(torch.is_tensor(state["generator"]) and state["generator"].dtype == torch.uint8
         and set(state["rng"]) == {"python", "numpy", "torch", "cuda"}, "Missing sample-order or global RNG state")
    model = state["model"]
    need(model["dw.weight"].shape == (16, 1, 62, 1) and model["fc.weight"].shape == (spec["n_out"], 256),
         "Wrong EEGNet or classifier shape")
    need(all(torch.is_tensor(v) and torch.isfinite(v).all().item() for v in model.values()),
         "Non-finite model or BatchNorm value")
    calls = done * epochs * batches_per_epoch(n)
    steps = [int(v["step"].item()) if torch.is_tensor(v["step"]) else int(v["step"])
             for v in state["optimizer"]["state"].values()]
    need(len(steps) == 12 and set(steps) == {calls}, "Adam step counter mismatch")
    for key in ("bn1.num_batches_tracked", "bn2.num_batches_tracked", "bn3.num_batches_tracked"):
        need(int(model[key]) == 1 + calls, "BatchNorm counter must equal the constructor pass plus training batches")
    need(cp["complete"] == (done == phases), "Completion flag mismatch")
    if require_complete:
        need(cp["complete"] is True, "A complete full-budget checkpoint is required")
    return cp


def _fit(X, y, identity, device, checkpoint_path, resume, progress, *, engineering, phases, epochs):
    c = validate_identity(identity, engineering)
    spec = cond.CONDITIONS[c["condition"]]
    x = np.asarray(X)
    labels = np.asarray(y)
    need(x.dtype == np.float32 and x.ndim == 3 and x.shape[1:] == (62, 512) and np.isfinite(x).all(),
         "Only finite normalized float32 N x 62 x 512 training input")
    n = len(x)
    need(n == 100 and labels.dtype == np.int64 and labels.shape == (n,) and np.isin(labels, [0, 1]).all()
         and np.bincount(labels, minlength=2).tolist() == [50, 50], "Fixed balanced first-day training labels")
    need((phases == 10 and epochs == 30) if not engineering else (1 <= phases <= 10 and 1 <= epochs <= 2),
         "Only the engineering path may shorten the 300-epoch budget")
    dev = torch.device(device)
    need(dev.type in ("cpu", "cuda") and (engineering or dev.type == "cuda"), "No silent CPU fallback in the campaign")
    if dev.type == "cuda":
        need(torch.cuda.is_available(), "CUDA requested but unavailable")
    core.set_seed(c["seed"])
    model = core.build_model("EEGNet", 62, 512, spec["n_out"], PARAMS["dropout"]).to(dev)
    initial = model_hash(model)
    immutable = dict(caller=c, input_shape=list(x.shape), input_sha256=tree_hash(x), labels_sha256=tree_hash(labels),
                     phases=phases, epochs_per_phase=epochs, parameters=PARAMS,
                     initialization="Original constructor and draw order; no extra initial constraint")
    path = Path(checkpoint_path)
    saved = None
    if resume:
        cp = load_checkpoint(path, expected_identity=c, allow_engineering=engineering)
        need(cp["identity"] == immutable, "Checkpoint was written for other data or another budget")
        saved = cp["state"]
    else:
        need(not path.exists(), "An existing checkpoint requires an explicit same-identity resume")

    def checkpoint(state):
        payload = dict(schema=SCHEMA, engineering=engineering, identity=immutable,
                       identity_canonical=canonical(immutable), state=cpu_copy(state),
                       complete=state["next_phase"] == phases)
        payload["state_sha256"] = tree_hash(payload["state"])
        _atomic_checkpoint(path, payload)

    rec, arrays = core.fit_training_only(
        model, x, labels, walsh=spec["walsh"], rule=spec["rule"], C=data.code_rows(), lr=PARAMS["lr"],
        epochs_per_phase=epochs, batch=PARAMS["batch"], seed=c["seed"], dev=dev, phases=phases,
        resume=saved, checkpoint=checkpoint, progress=progress)
    cp = load_checkpoint(path, expected_identity=c, allow_engineering=engineering, require_complete=True)
    need(model_hash(model) == tree_hash(cp["state"]["model"]) and tree_hash(x) == immutable["input_sha256"]
         and tree_hash(labels) == immutable["labels_sha256"], "Final model or input does not match its checkpoint")
    record = dict(rec, **c, identity=immutable, initial_model_sha256=initial,
                  final_model_sha256=model_hash(model),
                  final_optimizer_sha256=tree_hash(cp["state"]["optimizer"]),
                  final_RNG_sha256=tree_hash(cp["state"]["rng"]),
                  final_generator_sha256=tree_hash(cp["state"]["generator"]),
                  final_target_sha256=tree_hash(cp["state"]["Yneg"]),
                  last_used_target_sha256=tree_hash(cp["state"]["Y_used"]),
                  next_phase=phases, campaign_eligible=not engineering, engineering_only=engineering,
                  output_type="walsh16_sigmoid" if spec["walsh"] else "softmax2",
                  target_rule=spec["rule"],
                  checkpoint_sha256=sha(path), checkpoint_schema=SCHEMA,
                  actual_update_calls=phases * epochs * batches_per_epoch(n),
                  no_test_arrays_accepted=True, terminal_model=True, selection_or_temperature=False,
                  training_time_scope="Elapsed phase loop including checkpoint overhead; not a controlled speed comparison")
    outputs = dict(P_train_float32=arrays["P_train"], y_train_int64=arrays["y_train"])
    if "Y_used_last" in arrays:
        outputs["Y_used_last_float32"] = arrays["Y_used_last"]
    return model, record, outputs


def fit(X, y, identity, *, device="cuda", checkpoint_path, resume=False, progress=None):
    """The only campaign entry point: fixed 10 phases x 30 epochs on CUDA."""
    return _fit(X, y, identity, device, checkpoint_path, resume, progress, engineering=False, phases=10, epochs=30)


def fit_engineering(X, y, identity, *, device="cpu", checkpoint_path, resume=False, progress=None, phases=4, epochs=1):
    """Shortened budget for generated-data checks only; its fits are never campaign eligible."""
    return _fit(X, y, identity, device, checkpoint_path, resume, progress, engineering=True, phases=phases,
                epochs=epochs)
