"""Final analysis of the S1/W5 control study (standalone; does not import the campaign code).

Unit of analysis: the participant (mean over the five seeds). One new exploratory family of four
accuracy contrasts, Holm-adjusted over exactly these four:

    1. S1 - S0                 negotiation with ordinary softmax output
    2. (W1 - W0) - (S1 - S0)   does the effect of negotiation depend on the output type
    3. W1 - W5                 accumulated history versus current prediction at equal label share
    4. W5 - W4                 larger prediction share within the anchored, ungated rule

Everything else (probability measures, training accuracy, how far the targets moved) is descriptive.
Reference conditions (S0, W0, W1, W4) come from the archive or from this campaign, exactly as the
recorded reference-source decision says. No array is opened before every gate has been verified.
"""
import os
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_key] = "2"
from pathlib import Path
import argparse
import csv
import hashlib
import io
import json
import math
import time
import uuid

import numpy as np
import scipy
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
STUDY_ID = "LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0"
REAL_STATUS = "FROZEN_BEFORE_S1_W5_CONTROL_CONDITIONS"
ENGINEERING_STATUS = "ENGINEERING_FIXTURE_ONLY"
WALSH = {"S0": False, "S1": False, "W0": True, "W1": True, "W4": True, "W5": True}
REFERENCE = ("S0", "W0", "W1", "W4")
NEW = ("S1", "W5")
ORDER = ("S0", "S1", "W0", "W1", "W4", "W5")
# name, conditions added, conditions subtracted
CONTRASTS = (("S1-S0", ("S1",), ("S0",)),
             ("(W1-W0)-(S1-S0)", ("W1", "S0"), ("W0", "S1")),
             ("W1-W5", ("W1",), ("W5",)),
             ("W5-W4", ("W5",), ("W4",)))
DESCRIPTIVE = ("nll_clipped", "ece15", "brier_sum", "mean_confidence", "train_accuracy", "train_minus_test_accuracy")
WILCOXON_METHOD = "approx"       # fixed: normal approximation, zeros dropped, no continuity correction


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text("utf-8"))


def local(relative):
    path = (ROOT / relative).resolve()
    require(path.is_relative_to(ROOT.resolve()), "Path outside the study: %s" % relative)
    return path


def project_path(relative):
    raw = Path(relative)
    require(not raw.is_absolute() and ".." not in raw.parts, "Only project-relative source paths")
    path = (PROJECT / raw).resolve()
    require(path.is_relative_to(PROJECT.resolve()), "Path outside the project: %s" % relative)
    return path


def fit_id(subject, condition, seed):
    return f"subject_{subject:02d}_train__{condition}__seed{seed}"


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def immutable(path, raw):
    """Write once, atomically (temporary file, flush to disk, rename). A complete earlier file must be identical."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        require(path.read_bytes() == raw, "Analysis output differs from an earlier run: %s" % path)
        return
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):          # Windows: another program may hold the new file open for a moment
            try:
                os.replace(temporary, path)
                break
            except OSError as error:
                if not isinstance(error, PermissionError) and getattr(error, "winerror", None) not in (5, 32, 33):
                    raise
                if attempt == 5:
                    raise
                time.sleep(0.1 * 2 ** attempt)
    finally:
        if temporary.exists():
            temporary.unlink()


def csv_bytes(rows):
    out = io.StringIO(newline="")
    writer = csv.DictWriter(out, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue().encode("utf-8")


# --------------------------------------------------------------------------------------------------
# Metrics, written independently of lee_core and checked against its recorded values
# --------------------------------------------------------------------------------------------------
def codebook():
    """The two 16-bit Walsh rows used for left and right (first two rows of the Sylvester matrix)."""
    return np.array([[1] * 16, [1, 0] * 8], dtype=np.float32)


def ece15(posterior, y):
    confidence = posterior.max(1)
    predicted = posterior.argmax(1)
    edges = np.linspace(0, 1, 16)
    total = 0.0
    for i in range(15):
        if i == 0:
            mask = (confidence >= edges[i]) & (confidence <= edges[i + 1])
        else:
            mask = (confidence > edges[i]) & (confidence <= edges[i + 1])
        if mask.any():
            total += mask.mean() * abs((predicted[mask] == y[mask]).mean() - confidence[mask].mean())
    return float(total)


def metric(P, y, walsh):
    """Per-fit test metrics from the saved float32 outputs."""
    width = 16 if walsh else 2
    require(P.dtype == np.float32 and P.shape == (100, width), "Saved output dtype and shape")
    require(y.dtype == np.int64 and y.shape == (100,), "Saved labels")
    require(np.isfinite(P).all() and np.all((P >= 0) & (P <= 1)), "Finite outputs in [0, 1]")
    require(set(y.tolist()) == {0, 1} and np.bincount(y).tolist() == [50, 50], "Balanced binary test set")
    p = P.astype(np.float64)
    if walsh:
        C = codebook().astype(np.float64)
        decision = ((p[:, None, :] - C[None, :, :]) ** 2).sum(2).argmin(1)      # reported accuracy rule
        pc = np.clip(p, 1e-7, 1 - 1e-7)
        logp = np.log(pc) @ C.T + np.log(1 - pc) @ (1 - C.T)
        logp -= logp.max(1, keepdims=True)
        posterior = np.exp(logp)
        posterior /= posterior.sum(1, keepdims=True)
        Y = C[y]
        bce = float(-(Y * np.log(pc) + (1 - Y) * np.log(1 - pc)).mean())
        # Fixed-scale check (not fitted): the two class log scores divided by 8, the number of bits in
        # which the two code words differ; same definition as the "T8" column of the SHU comparison.
        tempered = np.exp(logp / 8.0)
        tempered /= tempered.sum(1, keepdims=True)
        div8 = dict(nll=float(-np.log(np.clip(tempered[np.arange(100), y], 1e-12, 1)).mean()),
                    ece=ece15(tempered, y),
                    brier=float(np.mean(np.sum((tempered - np.eye(2)[y]) ** 2, axis=1))))
    else:
        posterior = p
        decision = p.argmax(1)
        bce = None
        div8 = dict(nll=None, ece=None, brier=None)
    most_probable = posterior.argmax(1)
    return dict(accuracy=float((decision == y).mean()),
                nll_clipped=float(-np.log(np.clip(posterior[np.arange(100), y], 1e-12, 1)).mean()),
                ece15=ece15(posterior, y), bce=bce,
                brier_sum=float(np.mean(np.sum((posterior - np.eye(2)[y]) ** 2, axis=1))),
                mean_confidence=float(posterior.max(1).mean()),
                posterior_accuracy=float((most_probable == y).mean()),
                decision_rules_agree=float((most_probable == decision).mean()),
                nll_scores_divided_by_8=div8["nll"], ece15_scores_divided_by_8=div8["ece"],
                brier_scores_divided_by_8=div8["brier"])


def target_change(T, y, walsh):
    """How far the last trained target lies from the label, per output unit.

    per_output: mean absolute change over all trials and output units (2 for softmax, 16 for Walsh).
    differing_bits: Walsh only, the same mean over the 8 bits in which the two code words differ. For a
    comparison between output types, the softmax per-output value corresponds to the Walsh differing-bit
    value: both are the average movement of the units that carry the class.
    """
    if T is None:
        return dict(per_output=None, differing_bits=None)
    width = 16 if walsh else 2
    require(T.dtype == np.float32 and T.shape == (100, width) and np.isfinite(T).all(), "Saved last used target")
    require(y.dtype == np.int64 and y.shape == (100,) and set(y.tolist()) <= {0, 1}, "Saved training labels")
    t = T.astype(np.float64)
    if walsh:
        C = codebook().astype(np.float64)
        change = np.abs(t - C[y])
        return dict(per_output=float(change.mean()), differing_bits=float(change[:, C[0] != C[1]].mean()))
    return dict(per_output=float(np.abs(t - np.eye(2)[y]).mean()), differing_bits=None)


def compare_metric(record, m):
    for field, key in (("acc_test", "accuracy"), ("nll_test", "nll_clipped"), ("ece_test", "ece15"),
                       ("bce_test", "bce")):
        require(field in record, "Receipt misses %s" % field)
        if m[key] is None:
            require(record[field] is None, "Unexpected %s in a softmax receipt" % field)
        else:
            require(abs(float(record[field]) - m[key]) < 1e-11, "Metric mismatch %s" % field)


def paired(values):
    """Two-sided paired t test of participant-level differences (percentage points)."""
    d = np.asarray(values, dtype=np.float64)
    n = d.size
    require(d.ndim == 1 and n >= 2 and np.isfinite(d).all(), "Finite participant differences required")
    mean = float(d.mean())
    sd = float(d.std(ddof=1))
    if bool(np.all(d == d[0])):                  # every participant has the same difference: no variance to test
        mean, sd = float(d[0]), 0.0
        t = 0.0 if mean == 0 else None
        p = 1.0 if mean == 0 else 0.0
        ci = [mean, mean]
        dz = 0.0 if mean == 0 else None
    else:
        t = mean / (sd / math.sqrt(n))
        p = float(2 * stats.t.sf(abs(t), n - 1))
        half = float(stats.t.ppf(0.975, n - 1)) * sd / math.sqrt(n)
        ci = [mean - half, mean + half]
        dz = mean / sd
    return dict(mean_difference=mean, pointwise_95ci=ci, sd_difference=sd, t=t, df=n - 1, p_unadjusted=p, d_z=dz,
                participants_positive=int((d > 0).sum()), participants_negative=int((d < 0).sum()),
                participants_tied=int((d == 0).sum()), n=int(n))


def wilcoxon(values):
    """Sensitivity check only: two-sided Wilcoxon signed-rank test, zero differences dropped."""
    d = np.asarray(values, dtype=np.float64)
    nonzero = int((d != 0).sum())
    if nonzero == 0:
        return dict(statistic=None, p_two_sided=1.0, n_nonzero=0, note="All differences are zero")
    result = stats.wilcoxon(d, zero_method="wilcox", alternative="two-sided", correction=False, method=WILCOXON_METHOD)
    return dict(statistic=float(result.statistic), p_two_sided=float(result.pvalue), n_nonzero=nonzero,
                note="scipy.stats.wilcoxon, zero_method='wilcox', correction=False, method='%s'" % WILCOXON_METHOD)


def holm(pvalues):
    p = np.asarray(pvalues, dtype=float)
    require(p.ndim == 1 and p.size > 0 and np.isfinite(p).all() and np.all((p >= 0) & (p <= 1)),
            "Holm needs finite p values in [0, 1]")
    order = np.argsort(p, kind="stable")
    out = np.empty_like(p)
    running = 0.0
    for i, j in enumerate(order):
        running = max(running, float((len(p) - i) * p[j]))
        out[j] = min(1.0, running)
    return out.tolist()


def contrast_values(indexed, people, plus, minus, key, scale=1.0, digits=None):
    values = []
    for s in people:
        v = sum(indexed[(s, c)][key] for c in plus) - sum(indexed[(s, c)][key] for c in minus)
        v *= scale
        values.append(round(v, digits) if digits is not None else v)
    return values


def mean_or_none(values):
    return None if any(v is None for v in values) else float(np.mean(values))


# --------------------------------------------------------------------------------------------------
def run(protocol, expected):
    protocol = Path(protocol).resolve()
    require(protocol == (ROOT / "PROTOKOL-V1.0.json").resolve() and sha(protocol) == expected, "Protocol path and SHA")
    p = load(protocol)
    require(p["study_id"] == STUDY_ID and p["status"] in (REAL_STATUS, ENGINEERING_STATUS), "Protocol status")
    engineering = p["status"] == ENGINEERING_STATUS
    marker = PROJECT / "ENGINEERING_FIXTURE_ROOT.txt"
    require(marker.is_file() if engineering else not marker.exists(), "Fixture marker and protocol status disagree")
    require(p["analysis"]["contrasts"] == [c[0] for c in CONTRASTS], "Fixed four-contrast family")
    design = p["design"]
    people, seeds = list(design["people"]), list(design["seeds"])
    if not engineering:
        require(people == list(range(1, 55)) and seeds == [1, 2, 3, 4, 5] and design["phases"] == 10
                and design["epochs_per_phase"] == 30, "Fixed real design")
    for rel, digest in p["code_sha256"].items():
        require(sha(local(rel)) == digest, "Code changed: %s" % rel)
    bpath = ROOT / "data/SOURCE_BINDINGS-V1.0.json"
    require(sha(bpath) == p["source_bindings_sha256"], "Source bindings SHA")
    b = load(bpath)
    bound = {}
    for parts in b["subjects"].values():
        for leaf in parts.values():
            bound[leaf["path"]] = leaf["sha256"]
    for entry in b["archive"].values():
        for leaf in entry["files"].values():
            bound[leaf["path"]] = leaf["sha256"]
    bound.update(b.get("protected", {}))
    for rel, digest in bound.items():
        require(sha(project_path(rel)) == digest, "Bound source changed: %s" % rel)

    # ---- reference-source decision (first-day information only) ---------------------------------------
    decision = load(ROOT / "campaign/REPRODUCTION_TRAIN-V1.0.json")
    require(decision["protocol_sha256"] == expected and decision["reference_source"] in ("ARCHIVE", "REFIT"),
            "Reference-source decision")
    source = decision["reference_source"]
    sample = {(s, c, k) for s in design["reproduction_sample"]["subjects"]
              for k in design["reproduction_sample"]["seeds"] for c in REFERENCE}
    pairs = [(s, k) for s in people for k in seeds]
    require(decision["compared_fits"] == len(sample) and set(decision["details"]) == {fit_id(*t) for t in sample}
            and decision["linkage_pairs"] == len(pairs)
            and set(decision["linkage"]) == {fit_id(s, "W5", k) for s, k in pairs}
            and decision["mismatched_fits"] == sorted(k for k, d in decision["details"].items() if not d["all_equal"])
            and decision["linkage_mismatched_fits"] == sorted(k for k, d in decision["linkage"].items()
                                                              if not d["identical"])
            and (source == "ARCHIVE") == (not decision["mismatched_fits"] and not decision["linkage_mismatched_fits"])
            and decision["second_day_arrays_decoded"] is False,
            "The reference-source decision record is not consistent with its own details")
    campaign = [(s, c, k) for s in people for k in seeds for c in REFERENCE + NEW
                if c in NEW or source == "REFIT" or (s, c, k) in sample]
    ids = [fit_id(*t) for t in campaign]

    # ---- model gate and test gate --------------------------------------------------------------------
    freeze_path = ROOT / "campaign/MODEL_FREEZE-V1.0.json"
    freeze = load(freeze_path)
    freeze_sha = sha(freeze_path)
    require(freeze["status"] == "ALL_%d_FITS_FROZEN_BEFORE_DAY2" % len(campaign)
            and freeze["protocol_sha256"] == expected and freeze["reference_source"] == source
            and freeze["fit_ids"] == ids and freeze["Day2_arrays_decoded_before_freeze"] is False, "Model gate")
    model_paths = {f"data/preprocessors/subject_{s:02d}.json" for s in people}
    for key in ids:
        model_paths |= {f"campaign/fit_records/{key}.json", f"campaign/checkpoints/{key}.ckpt",
                        f"campaign/fit_outputs/{key}.npz"}
    require(set(freeze["files"]) == model_paths, "The model gate lists exactly the expected artifacts")
    for rel, digest in freeze["files"].items():
        require(sha(local(rel)) == digest, "Frozen artifact changed: %s" % rel)
    tc_path = ROOT / "campaign/TEST_COMPLETION-V1.0.json"
    tc = load(tc_path)
    test_paths = set()
    for key in ids:
        test_paths |= {f"campaign/test_records/{key}_day2.json", f"campaign/predictions/{key}_day2.npz"}
    require(tc["status"] == "TESTS_COMPLETE" and tc["protocol_sha256"] == expected
            and tc["model_freeze_sha256"] == freeze_sha
            and tc["counts"] == dict(tests=len(campaign), artifacts=2 * len(campaign))
            and set(tc["files"]) == test_paths, "Test gate")
    for rel, digest in tc["files"].items():
        require(sha(local(rel)) == digest, "Test artifact changed: %s" % rel)
    rt = load(ROOT / "campaign/REPRODUCTION_TEST-V1.0.json")
    require(rt["protocol_sha256"] == expected and rt["reference_source"] == source
            and rt["model_freeze_sha256"] == freeze_sha and rt["compared_fits"] == len(sample)
            and set(rt["details"]) == {fit_id(*t) for t in sample}
            and rt["mismatched_fits"] == sorted(k for k, equal in rt["details"].items() if not equal),
            "Sample test comparison record")
    require(source != "ARCHIVE" or (rt["status"] == "PASS_ALL_SAMPLE_TEST_OUTPUTS_BITWISE_EQUAL"
                                    and not rt["mismatched_fits"]), "Archive reference requires matching test outputs")

    fits, tests = {}, {}
    for key in ids:
        f = load(ROOT / f"campaign/fit_records/{key}.json")
        t = load(ROOT / f"campaign/test_records/{key}_day2.json")
        subject, condition, seed = f["subject"], f["condition"], f["seed"]
        require(key == fit_id(subject, condition, seed) and f["id"] == key and f["protocol_sha256"] == expected
                and f["epochs_completed"] == design["phases"] * design["epochs_per_phase"]
                and f["campaign_eligible"] is (not engineering)
                and f["files"]["fit_outputs"]["path"] == f"campaign/fit_outputs/{key}.npz",
                "Fit record identity and budget")
        require(t["id"] == key + "_day2" and t["fit_id"] == key and t["protocol_sha256"] == expected
                and t["model_freeze_sha256"] == freeze_sha
                and t["source_fit_sha256"] == sha(ROOT / f"campaign/fit_records/{key}.json")
                and t["predictions_path"] == f"campaign/predictions/{key}_day2.npz"
                and sha(local(t["predictions_path"])) == t["prediction_sha256"], "Test record identity and binding")
        fits[key], tests[key] = f, t

    def campaign_arrays(key):
        with np.load(local(f"campaign/predictions/{key}_day2.npz"), allow_pickle=False) as z:
            require(set(z.files) == {"P_test_float32", "y_test_int64"}, "Prediction members")
            P, y = z["P_test_float32"], z["y_test_int64"]
        with np.load(local(f"campaign/fit_outputs/{key}.npz"), allow_pickle=False) as z:
            y_train = z["y_train_int64"]
            target = z["Y_used_last_float32"] if "Y_used_last_float32" in z.files else None
        return P, y, y_train, target

    def archive_arrays(key, walsh):
        entry = b["archive"][key]
        with np.load(project_path(entry["files"]["prediction"]["path"]), allow_pickle=False) as z:
            if entry["format"] == "lee":
                P, y, y_train = z["P_test"], z["y_test"], z["y_train"]
                target = z["Y_used_last"] if walsh else None
            else:
                P, y = z["P_test_float32"], z["y_test_int64"]
        if entry["format"] == "lee":
            receipt = f = load(project_path(entry["files"]["record"]["path"]))
        else:
            with np.load(project_path(entry["files"]["fit_outputs"]["path"]), allow_pickle=False) as z:
                y_train, target = z["y_train_int64"], z["Y_used_last_float32"]
            receipt = load(project_path(entry["files"]["test_record"]["path"]))
            f = load(project_path(entry["files"]["fit_record"]["path"]))
        return P, y, y_train, target, receipt, f

    # ---- only now are result arrays opened -----------------------------------------------------------
    rows, timing, label_order, last_target = [], [], {}, {}
    for condition in ORDER:
        from_campaign = condition in NEW or source == "REFIT"
        for s in people:
            for k in seeds:
                key = fit_id(s, condition, k)
                if from_campaign:
                    P, y, y_train, target = campaign_arrays(key)
                    receipt, f, origin = tests[key], fits[key], "campaign"
                else:
                    P, y, y_train, target, receipt, f = archive_arrays(key, WALSH[condition])
                    origin = "archive"
                m = metric(P, y, WALSH[condition])
                if s not in label_order:
                    label_order[s] = y.copy()
                require(np.array_equal(y, label_order[s]), "Test-label order must be identical across conditions")
                compare_metric(receipt, m)
                change = target_change(target, y_train, WALSH[condition])
                if condition in ("W1", "W5"):
                    last_target[(s, k, condition)] = target
                displacement = f.get("last_target_dist")
                other_class = f.get("last_target_wrong_frac")
                rows.append(dict(subject=s, seed=k, condition=condition, origin=origin, **m,
                                 train_accuracy=float(f["acc_train"]),
                                 train_minus_test_accuracy=float(f["acc_train"]) - m["accuracy"],
                                 target_displacement=None if displacement is None else float(displacement),
                                 target_mean_abs_change_per_output=change["per_output"],
                                 target_mean_abs_change_differing_bits=change["differing_bits"],
                                 target_other_class_share=None if other_class is None else float(other_class)))
                timing.append(dict(subject=s, seed=k, condition=condition, origin=origin,
                                   train_seconds=float(f["train_seconds"])))

    # ---- how different are the last trained targets of W1 and W5 (same participant and seed) ----------
    differing = codebook()[0] != codebook()[1]
    target_pairs = []
    for s, k in pairs:
        a = last_target[(s, k, "W1")].astype(np.float64)
        w = last_target[(s, k, "W5")].astype(np.float64)
        target_pairs.append(dict(subject=s, seed=k,
                                 W1_W5_mean_abs_difference_per_output=float(np.abs(a - w).mean()),
                                 W1_W5_mean_abs_difference_differing_bits=float(np.abs(a - w)[:, differing].mean()),
                                 W1_W5_mean_euclidean_distance=float(np.linalg.norm(a - w, axis=1).mean())))

    # ---- first-update linkage of W5 and W4 -----------------------------------------------------------
    linkage = []
    for s, k in pairs:
        recorded = decision["linkage"][fit_id(s, "W5", k)]
        new = fits[fit_id(s, "W5", k)]["used_target_dist_by_phase"]
        require(len(new) > 2 and new[2] == recorded["W5_phase2_target_distance"], "Linkage record and fit record agree")
        row = dict(subject=s, seed=k, W5_phase2_target_distance=new[2],
                   archived_W4_phase2_target_distance=recorded["archived_W4_phase2_target_distance"],
                   identical_to_archived_W4=bool(recorded["identical"]))
        if source == "REFIT":
            own = fits[fit_id(s, "W4", k)]["used_target_dist_by_phase"]
            row.update(campaign_W4_phase2_target_distance=own[2], identical_to_campaign_W4=bool(new[2] == own[2]))
        linkage.append(row)
    linked_archive = sum(1 for r in linkage if r["identical_to_archived_W4"])
    require(source != "ARCHIVE" or linked_archive == len(pairs), "The archive reference requires every W5/W4 linkage")
    linkage_summary = dict(pairs=len(pairs), identical_to_archived_W4=linked_archive,
                           identical_to_campaign_W4=(sum(1 for r in linkage if r["identical_to_campaign_W4"])
                                                     if source == "REFIT" else None),
                           role="Part of the reference-source decision (archived W4). Under REFIT the comparison "
                                "with this campaign's own W4 is a descriptive self-check.")

    # ---- participant and condition summaries ---------------------------------------------------------
    numeric = [k for k in rows[0] if k not in ("subject", "seed", "condition", "origin")]
    participants = []
    for s in people:
        for condition in ORDER:
            group = [r for r in rows if r["subject"] == s and r["condition"] == condition]
            require(len(group) == len(seeds) and len({r["seed"] for r in group}) == len(seeds),
                    "Every seed for every participant and condition")
            participants.append(dict(subject=s, condition=condition,
                                     **{name: mean_or_none([r[name] for r in group]) for name in numeric}))
    indexed = {(r["subject"], r["condition"]): r for r in participants}
    summaries = []
    for condition in ORDER:
        group = [r for r in participants if r["condition"] == condition]
        origins = {r["origin"] for r in rows if r["condition"] == condition}
        require(len(origins) == 1, "One origin per condition")
        row = dict(condition=condition, n_participants=len(people), seeds_per_participant=len(seeds),
                   origin=origins.pop())
        for name in numeric:
            row[name] = mean_or_none([r[name] for r in group])
        row["accuracy_sd_between_participants"] = float(np.std([r["accuracy"] for r in group], ddof=1))
        summaries.append(row)

    # ---- the four contrasts ---------------------------------------------------------------------------
    contrasts, differences = [], []
    for name, plus, minus in CONTRASTS:
        d = contrast_values(indexed, people, plus, minus, "accuracy", scale=100.0, digits=10)
        entry = dict(contrast=name, measure="accuracy difference in percentage points", **paired(d))
        entry["wilcoxon_sensitivity"] = wilcoxon(d)
        entry["descriptive_other_measures"] = {}
        for key in DESCRIPTIVE:
            stat = paired(contrast_values(indexed, people, plus, minus, key))
            entry["descriptive_other_measures"][key] = dict(mean_difference=stat["mean_difference"],
                                                           pointwise_95ci=stat["pointwise_95ci"],
                                                           note="descriptive; no significance test")
        contrasts.append(entry)
        for s, value in zip(people, d):
            differences.append(dict(subject=s, contrast=name, accuracy_difference_pp=value))
    for entry, adjusted in zip(contrasts, holm([c["p_unadjusted"] for c in contrasts])):
        entry["p_holm_four"] = adjusted
        entry["significant_after_holm_0_05"] = bool(adjusted < 0.05)

    # ---- under REFIT: how the retrained reference conditions compare with the archived ones (descriptive)
    refit_versus_archive = []
    if source == "REFIT":
        for condition in REFERENCE:
            archived, identical = [], 0
            for s in people:
                values = []
                for k in seeds:
                    key = fit_id(s, condition, k)
                    P_old, y_old = archive_arrays(key, WALSH[condition])[:2]
                    values.append(metric(P_old, y_old, WALSH[condition])["accuracy"])
                    P_new = campaign_arrays(key)[0]
                    identical += int(P_new.dtype == P_old.dtype and P_new.shape == P_old.shape
                                     and P_new.tobytes() == P_old.tobytes())
                archived.append(float(np.mean(values)))
            mine = [indexed[(s, condition)]["accuracy"] for s in people]
            refit_versus_archive.append(dict(
                condition=condition, accuracy_archive=float(np.mean(archived)), accuracy_campaign=float(np.mean(mine)),
                mean_difference_pp=float(100 * (np.mean(mine) - np.mean(archived))),
                fits_with_bit_identical_test_outputs=identical, fits=len(people) * len(seeds),
                note="descriptive; the new family uses campaign fits only"))

    results = dict(
        status="COMPLETE_S1_W5_CONTROL_ANALYSIS_VERIFIED", protocol_sha256=expected,
        engineering_fixture_only=engineering, reference_source=source,
        source_bindings_sha256=p["source_bindings_sha256"], model_freeze_sha256=freeze_sha,
        test_completion_sha256=sha(tc_path),
        counts=dict(campaign_fits=len(campaign), new_fits=len(people) * len(seeds) * len(NEW),
                    reference_fits_from_archive=0 if source == "REFIT" else len(people) * len(seeds) * len(REFERENCE),
                    reference_fits_from_campaign=len(people) * len(seeds) * len(REFERENCE) if source == "REFIT" else 0,
                    reproduction_sample_fits=len(sample), participants=len(people), seeds=len(seeds)),
        unit="participants; each condition is averaged over the seeds of the same participant",
        scope="Exploratory control conditions added after the Lee2019 results had been examined; one new "
              "four-contrast Holm family. The earlier five-contrast and two-contrast families are unchanged.",
        uncertainty_note="Pointwise 95% t intervals, not multiplicity adjusted. Holm adjustment covers exactly the "
                         "four accuracy contrasts. Wilcoxon is a sensitivity check and cannot change the result.",
        dependence_note="The four contrasts are not four independent pieces of evidence: contrasts 1 and 2 add up "
                        "to W1-W0, and contrasts 3 and 4 add up to W1-W4, both of which were reported before.",
        metrics_note="Walsh accuracy: nearest code word on float64 outputs. Walsh class posterior: product of the "
                     "16 bit probabilities restricted to the two code words (bit clip 1e-7); NLL floor 1e-12. "
                     "Softmax: the two class probabilities as saved.",
        target_change_note="target_mean_abs_change_per_output averages |last trained target - label| over all "
                           "output units; target_mean_abs_change_differing_bits (Walsh) averages over the 8 bits "
                           "in which the two code words differ. Compare the softmax per-output value with the "
                           "Walsh differing-bit value. target_displacement is the Euclidean distance over all "
                           "output units and is not comparable between output types.",
        software=dict(numpy=np.__version__, scipy=scipy.__version__, wilcoxon_method=WILCOXON_METHOD),
        reproduction=dict(training_side=dict(status=decision["status"], compared_fits=decision["compared_fits"],
                                             mismatched_fits=decision["mismatched_fits"]),
                          test_side=dict(status=rt["status"], compared_fits=rt["compared_fits"],
                                         mismatched_fits=rt["mismatched_fits"]),
                          W5_W4_first_update_linkage=linkage_summary),
        W1_W5_last_target_difference=dict(
            pairs=len(target_pairs),
            mean_abs_difference_per_output=float(np.mean([r["W1_W5_mean_abs_difference_per_output"]
                                                          for r in target_pairs])),
            mean_abs_difference_differing_bits=float(np.mean([r["W1_W5_mean_abs_difference_differing_bits"]
                                                              for r in target_pairs])),
            mean_euclidean_distance=float(np.mean([r["W1_W5_mean_euclidean_distance"] for r in target_pairs])),
            note="descriptive; how different the last trained targets of the two rules are"),
        reference_refit_versus_archive=refit_versus_archive,
        summaries=summaries, contrasts=contrasts)
    out = ROOT / "final_analysis"
    files = {"RESULTS-V1.0.json": encoded(results), "run_metrics.csv": csv_bytes(rows),
             "participant_means.csv": csv_bytes(participants), "condition_summary.csv": csv_bytes(summaries),
             "participant_differences.csv": csv_bytes(differences),
             "four_contrasts_holm.json": encoded(contrasts),
             "W5_W4_first_update_linkage.csv": csv_bytes(linkage),
             "W1_W5_last_target_difference.csv": csv_bytes(target_pairs),
             "fit_timing.csv": csv_bytes(timing)}
    for name, raw in files.items():
        immutable(out / name, raw)
    report = dict(status="COMPLETE_S1_W5_CONTROL_ANALYSIS", protocol_sha256=expected,
                  files={name: sha(out / name) for name in files})
    immutable(out / "ANALYSIS_COMPLETION-V1.0.json", encoded(report))
    print(json.dumps(dict(status=results["status"], reference_source=source, counts=results["counts"])))
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--protocol-sha256", required=True)
    arguments = parser.parse_args()
    run(arguments.protocol, arguments.protocol_sha256)
