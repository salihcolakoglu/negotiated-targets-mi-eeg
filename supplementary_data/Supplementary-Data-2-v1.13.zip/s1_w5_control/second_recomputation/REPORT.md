# REPORT — independent recomputation of the S1/W5 control-condition results (Lee2019)

Own code (`recompute.py`), numpy 2.2.6, scipy 1.15.3, Python 3.12.3. Reference source according to the decision file: **ARCHIVE** (confirmed, §2-F). Tolerance: exact for counts, labels, booleans and hashes; 1e-9 absolute for every other number.

## 1. Plain statement

**Do the published result files agree with my recomputation? YES — with one exception.**

**The exception is the measure `target_displacement`.** The published values are single-precision numbers; my recomputation evaluates the stored target arrays in double precision. They differ by more than 1e-9 in:

| Published file | Values beyond 1e-9 | Largest absolute difference |
|---|---:|---|
| `run_metrics.csv`, column `target_displacement` | 851 of 1,350 non-blank (S1 211, W1 243, W4 153, W5 244, W0 0) | 6.144e-08 (participant 27, seed 5, W1: recomputed 0.3414945322703056, published 0.34149447083473206) |
| `participant_means.csv`, column `target_displacement` | 136 of 270 non-blank (S1 34, W1 46, W4 15, W5 41, W0 0) | 1.952e-08 (participant 53, W1: recomputed 0.29629542096914707, published 0.2962954014539719) |
| `condition_summary.csv`, `target_displacement` of S1 | 1 of 5 non-blank | 1.077e-09 (recomputed 0.08469733657026059, published 0.08469733764693418) |
| `RESULTS-V1.0.json`, `summaries`, `target_displacement` of S1 | 1 of 5 non-blank | 1.077e-09 (the same two numbers) |

That is 989 published values. Every one is listed with both numbers in `COMPARISON.md`.

Everything else agrees:

- 36,371 values of the published result files were compared with values recomputed from the stored arrays. Apart from the 989 above, the largest absolute difference is 5.3e-15 (one `nll_clipped` cell), and every count, label and flag is identical.
- The four contrasts agree to 8.3e-16 in every statistic (mean, SD, t, p, interval, d_z, Holm p, Wilcoxon statistic and p) and exactly in every count.
- The linkage file and the timing file can only be compared with the records, not recomputed (811 and 3,241 values): all identical.

The exception touches no accuracy, no contrast and no test. It is a precision difference in one descriptive measure; its relative size is at most 2.4e-07.

## 2. What was checked

Codes in brackets are the groups of `COMPARISON.md`.

**A. Inventory and integrity — no exception**

- Fits used: 270 for each of S0, S1, W0, W1, W4, W5. S0, W0, W1, W4 come from the archive (1,080 fits), S1 and W5 from this campaign (540). The `origin` column of `run_metrics.csv` says the same in all 1,620 rows [A02, A03, A14].
- Campaign folders: 612 fit records, 612 fit outputs, 612 test records, 612 prediction files; exactly the expected ids (540 new + 72 sample), none missing, unexpected or duplicated [A04]. Bindings: 270 fits per reference condition, all 2,700 bound files present [A05].
- SHA-256 of all 2,700 bound archive files equals `SOURCE_BINDINGS` [A06].
- SHA-256 of the 1,278 files named in `MODEL_FREEZE` that exist in the data folder (612 fit outputs, 612 fit records, 54 normalisers) and of all 1,224 files named in `TEST_COMPLETION` equals those lists [A07].
- 6,624 hash references inside records are correct (fit record → fit outputs and normaliser; test record → predictions and fit record; records → bound first-day / second-day data hashes) [A08].
- 29 hashes named in gate and completion files equal the files, including the nine result files in `ANALYSIS_COMPLETION-V1.0.json` and `results_sha256` in `CAMPAIGN_COMPLETION` [A09].
- Transfer: 5,236 files have exactly the SHA-256 and size of the three members lists; none missing, none extra. The other 4 of the 5,240 listed files lie in `ops/qa` and were not opened [A10].
- Arrays of all 1,692 stored copies (612 campaign + 1,080 archive): expected keys; float32 outputs and targets, int64 labels; shapes 100×2 (softmax), 100×16 (Walsh), 100 labels; no NaN or infinite value; all outputs and targets inside [0, 1]; labels only 0 and 1; 100 training and 100 test trials; 50/50 training classes; a target array for every condition except S0 — no violation [A12, A15]. The test sets are also 50/50 for all 54 participants.
- Softmax rows sum to 1 only within single-precision rounding: largest deviation of the float64 sum 8.9e-08; 101,306 of 111,600 rows do not sum to exactly 1.0. I applied a limit of 1e-6; no row exceeds it.
- Test labels and training labels are byte-identical for all conditions, seeds and copies of a participant [A13]. No two fits used have byte-identical output arrays [A16].
- Record fields (identity, 300 epochs, terminal model, one final test evaluation, protocol / bindings / freeze hashes, output type): no deviation in 1,692 records [A18, A19].
- The stored last trained targets lie inside the range the protocol schedule implies for the last trained phase: largest |target − label| is 0.186 for W4 (bound 0.24) and 0.503, 0.479, 0.604 for S1, W1, W5 (bound 0.694) [A17].

**B. Per fit** — all 17 measures of `run_metrics.csv` for 1,620 fits [B01]. Sixteen columns agree (largest difference 5.3e-15); `target_displacement` is the exception. Blank cells coincide (BCE and the three "/8" measures for softmax; all four target measures for S0; the differing-bit measure for S1).

- Test accuracy equals `acc_test` of the test record for all 1,620 fits, and all 162,000 per-trial decisions equal `pred_test` [B02, B03]. The same holds for the campaign copy of the 72 sample fits [B13, B14], whose 17 measures equal those of the archive copy exactly [B12].
- Against the records (informational): posterior accuracy, training accuracy, NLL, ECE, BCE, training NLL and other-class share agree (largest difference 5.3e-15) [B05–B09, B11, B17].
- `last_target_dist` of the fit records shows the same 851 single-precision differences as the published column [B10]. The published column is bit-identical with that record field in all 1,350 non-blank cases [B18].
- `fit_timing.csv` is a transcription of `train_seconds` of the records: identical in 1,620 rows [B15, B16].

**C. Participant level** — `participant_means.csv` (324 rows × 17 measures), `participant_differences.csv` (216 values, all exactly equal), `condition_summary.csv` and the `summaries` of `RESULTS-V1.0.json` (6 conditions × 18 numbers plus counts and labels): agree, except `target_displacement` [C01–C09].

**D. Contrasts** — `four_contrasts_holm.json` and the `contrasts` of `RESULTS-V1.0.json`: all statistics, counts, flags and the six descriptive other measures agree (largest difference 8.3e-16) [D01–D06]. My own Wilcoxon and t-test code gives the same numbers as `scipy.stats.wilcoxon` (approx, no correction, zeros dropped) and `scipy.stats.ttest_1samp` [D07, D08]. Both identities hold: the sums of the published participant differences equal my W1−W0 and W1−W4 for all 54 participants (largest difference 4.4e-16), and exactly in integer arithmetic [D09, D10]. The two published contrast lists are identical to each other, and the summaries are identical in the CSV and the JSON [D11].

**E. Linkage and target differences**

- `W1_W5_last_target_difference.csv` (270 × 3 values) and the three means in `RESULTS-V1.0.json`: recomputed from the stored targets (W1 archive, W5 campaign); all agree (largest difference 1.4e-17) [E08–E11]. Means over 270 pairs: 0.0174208 per output, 0.0264484 over the 8 differing bits, mean Euclidean distance 0.0809910.
- `W5_W4_first_update_linkage.csv`: **cannot be recomputed from the stored arrays** (§6, item 1). I transcribed the third-phase value from each W5 fit record and each archived W4 fit record. The CSV, the `linkage` block of `REPRODUCTION_TRAIN-V1.0.json` and the counts in `RESULTS-V1.0.json` equal the records in all 270 pairs, and the two record values are identical in 270 of 270 pairs [E01–E05]. In the 18 pairs where the campaign holds its own W4 refit, that record carries the same value [E07].

**F. Reproduction checks (ARCHIVE)** — `REPRODUCTION_TRAIN`, `REPRODUCTION_TEST`, `MODEL_FREEZE`, `RESULTS` and `CAMPAIGN_COMPLETION` all say ARCHIVE [A01]. For the 72 sample fits I compared campaign arrays with the bound archive arrays by dtype, shape and bytes:

- training side: `P_train` 72/72 identical, training labels 72/72, last used target 54/54 (W0, W1, W4), first-day normaliser 54/54 (S0, W0, W1); largest absolute difference of `P_train`: 0;
- test side: `P_test` 72/72 identical, test labels 72/72; largest absolute difference: 0;
- for W4 the campaign npz files have the SHA-256 of the archived files (18/18 fit outputs and predictions);
- nine record fields of the campaign copy equal the archived records in all 72 fits [F05].

This is what `REPRODUCTION_TRAIN-V1.0.json` (72 fits, every flag, `max_abs_difference_P_train` 0, no mismatched fit, PASS), `REPRODUCTION_TEST-V1.0.json` (72 true, no mismatched fit, PASS) and the `reproduction` block of `RESULTS-V1.0.json` state [F01–F04]. `reference_refit_versus_archive` is empty, as it must be under ARCHIVE. Beyond the sample: the normaliser of every participant equals the normalisation arrays of all 810 archived S0/W0/W1 fits [F06].

## 3. The exception in detail

- **Sentences followed:** protocol `analysis.manipulation_checks` ("How far the last trained target lies from the label: … Euclidean target displacement …") and the last sentence of `target_change_note` ("target_displacement is the Euclidean distance over all output units …"). Neither states the arithmetic precision.
- **My definition:** for each training trial the Euclidean norm of (last trained target − label target) over all output units, averaged over the 100 trials, with the stored float32 arrays converted to float64. This is the exact value of the stored numbers to about 1e-15.
- **What the published column is:** all 1,350 non-blank published values are float32 numbers. They are bit-identical with `last_target_dist` of the fit record (1,350 of 1,350), and the same formula evaluated in float32 reproduces them bit for bit (1,350 of 1,350). So the definition is the same and only the precision differs. I cannot tell from the data whether the analysis copied the record field or evaluated the arrays in single precision.
- **Size:** all 1,080 values of S1, W1, W4 and W5 differ from the double-precision value: 851 by more than 1e-9, 207 by more than 1e-8; largest 6.144e-08, median 3.3e-09. W0 is exactly 0 on both sides; S0 is blank on both sides.
- **Condition means, recomputed / published:** S1 0.08469733657026059 / 0.08469733764693418 (1.08e-09, beyond); W1 0.20532235979909774 / 0.20532235918497596 (6.1e-10, inside); W4 0.031995352028878946 / 0.031995352054083784 (2.5e-11, inside); W5 0.1301843568071292 / 0.1301843574477567 (6.4e-10, inside).
- **The published file is not uniform in precision:** the two neighbouring target measures (`target_mean_abs_change_per_output`, `target_mean_abs_change_differing_bits`) and the W1–W5 Euclidean distances equal my double-precision values to 0 and 3e-17.

## 4. Results as recomputed

Mean test accuracy (mean of 54 participant means; equal to correct trials / 27,000):

| Condition | Origin | Correct of 27,000 | Mean test accuracy | SD between participants (n−1) |
|---|---|---:|---:|---:|
| S0 | archive | 17,160 | 63.5556 % | 14.6033 pp |
| S1 | campaign | 17,248 | 63.8815 % | 14.7589 pp |
| W0 | archive | 17,079 | 63.2556 % | 14.7821 pp |
| W1 | archive | 17,222 | 63.7852 % | 15.0096 pp |
| W4 | archive | 17,126 | 63.4296 % | 14.7348 pp |
| W5 | campaign | 17,176 | 63.6148 % | 14.8932 pp |

Four contrasts, test accuracy in percentage points, n = 54, df = 53, t(0.975, 53) = 2.005746:

| Contrast | Mean | 95 % interval | SD | SE | t | p | Holm p | d_z | Wilcoxon statistic | Wilcoxon p | n ≠ 0 | + / − / 0 |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| S1−S0 | 0.325926 | [−0.198247, 0.850098] | 1.920415 | 0.261335 | 1.247156 | 0.217824 | 0.653471 | 0.169716 | 530.0 | 0.299039 | 50 | 28 / 22 / 4 |
| (W1−W0)−(S1−S0) | 0.203704 | [−0.535910, 0.943317] | 2.709728 | 0.368747 | 0.552421 | 0.582982 | 0.653471 | 0.075175 | 583.0 | 0.453110 | 51 | 28 / 23 / 3 |
| W1−W5 | 0.170370 | [−0.152395, 0.493136] | 1.182519 | 0.160920 | 1.058724 | 0.294527 | 0.653471 | 0.144074 | 608.5 | 0.608689 | 51 | 28 / 23 / 3 |
| W5−W4 | 0.185185 | [−0.036457, 0.406828] | 0.812034 | 0.110504 | 1.675826 | 0.099663 | 0.398651 | 0.228051 | 405.5 | 0.138902 | 46 | 27 / 19 / 8 |

No contrast is significant after Holm at 0.05, and none before. Identities: contrast 1 + 2 = W1−W0 = 0.529630 pp (t = 2.365663, p = 0.021688, interval [0.080579, 0.978680]); contrast 3 + 4 = W1−W4 = 0.355556 pp (t = 1.861149, p = 0.068274, interval [−0.027624, 0.738735]). Full precision, the six other measures of each contrast and all participant-level values are in `RECOMPUTED.json`.

## 5. Code words

Derived from `Y_used_last` of every stored W0 fit (270 archive fits and 18 campaign sample fits): exactly one distinct row per class in all 288 fits, and every W0 target is exactly the code word of its label.

- class 0: `1111111111111111`
- class 1: `1010101010101010`

They differ in 8 bits (zero-based positions 1, 3, 5, 7, 9, 11, 13, 15), where class 0 has 1 and class 1 has 0. With these code words the nearest-code-word decisions reproduce `pred_test` of every Walsh test record (108,000 trials).

## 6. What I could not check, and why

1. **The third-phase target distances of the linkage file.** Only the target of the last trained phase and the terminal outputs are stored. The third-phase target (0.97 × label + 0.03 × prediction after the second phase) and that prediction are not. The 540 distances are transcribed from the fit records; whether the records are right cannot be verified from the data folder.
2. **Training itself.** No checkpoints are in the data folder; the 612 checkpoint hashes of `MODEL_FREEZE` could not be verified. Target rules, schedule, seeds, number of updates, determinism and "terminal model only" are known to me only as record fields. I cannot verify that the stored outputs come from the frozen models.
3. **The EEG data.** No raw or prepared EEG is in the data folder. I cannot verify that the test arrays belong to the second day, that the labels are the true labels, or how the normaliser was computed. I verified only that labels, normalisers and data hashes are the same everywhere they appear.
4. **Order of events and gates.** Freeze before second-day data, sample tests before any S1/W5 test output, one decision from first-day information, one evaluation per model: these are stated in the files (`Day2_arrays_decoded_before_freeze: false`, `second_day_outputs_of_new_conditions_at_check: 0`, `final_test_evaluations: 1`) and nothing in the data contradicts them, but stored arrays cannot prove them. I did not audit the logs.
5. **Record hashes with an undefined recipe.** `labels_sha256`, `input_sha256`, `last_used_target_sha256`, `final_target_sha256` and the model, optimiser and random-state hashes are not the plain SHA-256 of the stored array bytes (tried for labels and targets on four fits: no match), and the protocol does not define the recipe. I did not guess further. I checked only their consistency (one input hash and one label hash per participant; one initial model per output type and seed).
6. **The four files in `ops/qa`** (two JSON receipts and two stdout texts of generated-data checks, by their names in the members list): not opened, by rule; their SHA-256 and size are unverified. The analysis, campaign and QA code were not read, so I know nothing about how the published numbers were produced; the `code_sha256` block of the protocol is unverified.
7. **Protocol self-description.** `fixed_content_sha256` and `frozen_trt` could not be verified. Of the seven prelaunch receipts named in the protocol, the three under `ops/preflight` have the stated SHA-256 (hash only; not read); the four under `records/prelaunch` are not in the data folder.
8. **The earlier families.** W1−W0 and W1−W4 "were reported before", but the earlier result files are not in the data folder. I could not compare my 0.529630 pp and 0.355556 pp with the earlier reports.
9. **Target movement of S0.** No target array is stored for S0. Its four target measures are not available; the published files leave them blank as well. By the rule they would be 0.
10. **Authenticity of the archive.** The archived fits equal the bindings, and the bindings file has the SHA-256 named in the protocol. Whether the bindings describe the fits of the earlier studies cannot be verified here.
11. **REFIT branch of section F.** Not applicable: the reference source is ARCHIVE.

## 7. Ambiguities in the definitions and how I resolved them

The primary reading was fixed in `recompute.py` before the first run; I changed no primary definition afterwards. The alternative was computed too. "Published" says which reading the published files follow within 1e-9. Per-condition values under both readings are in `RECOMPUTED.json` (`alternative_readings`, `alternative_contrasts`, `contrasts.*.alternative_float_route`).

1. **"Nearest code word"** (protocol `analysis.measure`; `metrics_note`: "on float64 outputs"). Primary: Euclidean distance on the float64 outputs; the `decoder` text of the test records also says Euclidean / float64. City-block distance gives identical decisions in all 1,080 Walsh fits. Alternative: Hamming distance after thresholding the 16 outputs at 0.5. It changes 23 fits by one trial each: W0 63.2556 % (same), W1 63.7741 instead of 63.7852, W4 63.4370 instead of 63.4296, W5 63.6000 instead of 63.6148. Contrasts under it: S1−S0 unchanged; (W1−W0)−(S1−S0) 0.192593 (p 0.602882); W1−W5 0.174074 (p 0.276341); W5−W4 0.162963 (p 0.154373); Holm p 0.653471, 0.653471, 0.653471, 0.617491. Published: Euclidean (1,080 of 1,080).
2. **Ties.** Equal distances or probabilities would go to class 0. None occurs: no equal softmax probabilities, no equal distances, no equal posteriors (smallest gap of squared distances on test: 1.3e-04).
3. **Bit clip 1e-7** (`metrics_note`). Primary: clip to [1e-7, 1 − 1e-7] in float64. Alternative: clip in float32, where the upper bound becomes 0.99999988. NLL, ECE, Brier and mean confidence are identical under both in all 1,080 fits. BCE differs in 16 fits (up to 6.8e-03), NLL "/8" in 11 fits (up to 1.4e-02), ECE "/8" and Brier "/8" in 3 fits (up to 6e-09). Published: float64 clip.
4. **Bit-wise BCE** (protocol `analysis.descriptive`; no clip stated for it). Primary: the clipped bit probabilities of the posterior. Alternative: no clip, logarithms bounded at −100 (the convention of `torch.nn.BCELoss`). It differs in 57 fits (up to 3.25): W0 0.495635 instead of 0.480668, W1 0.407167 instead of 0.404882, W4 0.483773 instead of 0.467607, W5 0.442584 instead of 0.435715. Published: clipped.
5. **ECE, 15 bins.** Primary: bins (lo, hi], confidence = largest class probability, correctness of the most probable class. Alternatives: bins [lo, hi); correctness of the nearest-code-word decision. Both give identical values in every fit (no confidence lies on a bin edge; the two decisions never differ).
6. **"The two Walsh class scores" divided by 8.** Read as the two log products of bit probabilities (the logits of the posterior). Published agrees.
7. **"Euclidean target displacement".** Primary: mean over trials of the per-trial Euclidean norm, float64. Alternative A: the same in float32 arithmetic — this is the published column (§3). Alternative B: root mean square over trials — S1 0.105316, W1 0.233392, W4 0.039717, W5 0.160599 instead of 0.084697, 0.205322, 0.031995, 0.130184; not what is published.
8. **"Share of training trials whose target decodes to the other class".** Decoded with the decision rule of the condition. Published agrees.
9. **Participant differences.** Primary: exact, from integer numbers of correct trials. Alternative: differences of the floating-point participant means. The values differ by at most 2.6e-14 pp, but exact zeros and exact ties are lost, which changes the counts and the Wilcoxon test:

   | Contrast | Exact: + / − / 0, W, p | Float route: + / − / 0, W, p |
   |---|---|---|
   | S1−S0 | 28/22/4, 530.0, 0.299039 | 28/22/4, 523.5, 0.271006 |
   | (W1−W0)−(S1−S0) | 28/23/3, 583.0, 0.453110 | 28/24/2, 608.0, 0.460681 |
   | W1−W5 | 28/23/3, 608.5, 0.608689 | 29/23/2, 632.5, 0.606525 |
   | W5−W4 | 27/19/8, 405.5, 0.138902 | 27/20/7, 421.5, 0.131119 |

   Published: the exact reading, in every count and every Wilcoxon number.
10. **Wilcoxon.** Zeros dropped, average ranks, tie-corrected variance, no continuity correction, statistic = smaller rank sum; identical to `scipy.stats.wilcoxon(..., method='approx')`.
11. **SD between participants.** Primary: divisor n−1 (published agrees). With divisor n: S0 14.4674, S1 14.6216, W0 14.6445, W1 14.8699, W4 14.5977, W5 14.7546 pp.
12. **Units.** Accuracy columns of the CSV files are fractions; contrasts are in percentage points; the descriptive other measures are in the units of the CSV columns. Published agrees.
13. **"Softmax rows summing to 1".** Not exact in float32; I used a limit of 1e-6 (largest deviation 8.9e-08).
14. **"Byte for byte"** in section F. The archived S0, W0 and W1 files use another container (one npz, other key names), so I compared the decoded arrays (dtype, shape, bytes), and for W4 also the files.
15. **Which copy of the 72 sample fits.** The archive copy, as the `origin` column says. The campaign copy gives identical values.

## 8. Observations that are not differences

- The brief says the data folder contains nothing inside a folder named `qa`. It does: `LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0/ops/qa` holds 4 files. I did not open them. The folder name appeared in my first directory listing, and the four file names appear in the members list I was allowed to read.
- `posterior_accuracy` equals `accuracy` and `decision_rules_agree` is 1 in all 1,620 fits: in 108,000 Walsh test trials the most probable class never differs from the nearest code word. These two columns carry no additional information here.
- The NLL floor of 1e-12 is active in many Walsh test trials: W0 1,582, W1 703, W4 1,439, W5 1,066 of 27,000 (S0 7, S1 1). Each contributes 27.63. The Walsh values of `nll_clipped`, and the NLL rows of the descriptive other measures, depend strongly on the chosen floor.
- Training accuracy is below 1 in 8 (S0), 45 (S1), 6 (W0), 31 (W1), 7 (W4) and 36 (W5) of 270 fits.
- `target_other_class_share` is non-zero in exactly two fits, one training trial each: S1 participant 47 seed 4, and W5 participant 4 seed 5.
- The third-phase target distance of W1 is never bit-identical with that of W4 (0 of 270 pairs in the archived records; largest difference 9.5e-08). This does not contradict the protocol, which claims arithmetic identity only between the first W5 update and the W4 update.
- This check ran with Python 3.12.3; the protocol names 3.12.14. numpy and scipy are the versions named in the results.

## 9. How the check was done

- Read: the brief; the protocol; `SOURCE_BINDINGS`; the campaign decision and gate files; `STATUS.json`; fit and test records; all arrays; the 54 normaliser files; the files in `final_analysis`; `ops/CAMPAIGN_COMPLETION-V1.0.json`; the one-line `logs/analysis-*.txt`; the archived records and arrays; the three members lists. Hashed but not read: `README`, `PROTOKOL_OZETI`, the other logs, `ops/ENVIRONMENT-*`, `ops/preflight/*`, `records/*`. Not opened: `ops/qa/*`.
- Outside the allowed folders: one determinism test wrote a second set of output files to the session scratch folder (deleted since), and I listed that folder once, names only. No file there was opened. No other folder was opened, listed or searched.
- Definitions came from the protocol sections `design`, `conditions`, `analysis`, `reference_source_rule`, from the two notes of `RESULTS-V1.0.json`, and — for the word "nearest" — also from the `decoder` text in the test records. I looked at the column names and a few rows of the published CSV files to learn their format before writing the comparison.
- The first run of the script produced exactly the differences reported here. Afterwards I added checks, the named alternative readings and the table layout; I changed no primary definition.
- The script is deterministic: two runs from different working directories gave byte-identical outputs.

## 10. The three files

- `recompute.py` — `python recompute.py DATA_ROOT OUT_DIR [MEMBERS_DIR]`; standard library, numpy, scipy; no absolute paths; writes `RECOMPUTED.json` (every recomputed number, the inventory, the alternative readings), `COMPARISON.json` and `COMPARISON.md`.
- `COMPARISON.md` — one table of 109 groups (255,759 values compared, 1,840 beyond tolerance: 989 in published result files, all `target_displacement`, and the same 851 fits once more against the fit-record field), followed by the full list of the 1,840 values with both numbers.
- `REPORT.md` — this text.
