#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
recompute.py -- independent recomputation of the S1/W5 control-condition results (Lee2019).

    python recompute.py DATA_ROOT OUT_DIR [MEMBERS_DIR]

DATA_ROOT    folder with the project-relative paths (the three study folders)
OUT_DIR      folder that receives RECOMPUTED.json, COMPARISON.json and COMPARISON.md
MEMBERS_DIR  optional folder with the three *.members.tsv transfer lists
             (default: the folder "transfer" beside DATA_ROOT; skipped when absent)

Standard library, numpy and scipy only.  Deterministic: no clock, no random numbers.

Everything is computed from the stored model outputs with definitions taken from the
frozen protocol (sections design, conditions, analysis, reference_source_rule) and from
the two notes of RESULTS-V1.0.json (metrics_note, target_change_note).  The analysis
code of the campaign was not read.  Files inside folders named "qa" or "analysis" and
files named final_analysis.py / campaign.py are never opened by this script.

PRIMARY DEFINITIONS (fixed before any number was compared)
----------------------------------------------------------
 D1  Walsh decision: nearest of the two code words, Euclidean distance, outputs cast to
     float64; equal distances -> class 0.            Softmax decision: larger of the two
     saved probabilities (float64 cast); equal probabilities -> class 0.
 D2  Walsh class posterior: bit probabilities p clipped to [1e-7, 1-1e-7] in float64;
     score_c = sum_j log(p_j if C_cj = 1 else 1 - p_j)  (log of the product of the 16
     bit probabilities of code word c); posterior = softmax(score_0, score_1).
     Softmax networks: the two saved probabilities as they are (no renormalisation).
 D3  NLL = - mean_i log(max(q_i[y_i], 1e-12)), natural logarithm.
 D4  ECE, 15 equal-width bins on [0, 1], bin b = (b/15, (b+1)/15]; confidence = largest
     class probability; correctness = most probable class equals the label;
     ECE = sum_b n_b/N * |accuracy_b - mean confidence_b|.
 D5  Brier = mean_i sum_c (q_ic - 1[y_i = c])^2 ; mean confidence = mean_i max_c q_ic.
 D6  Bit-wise BCE (Walsh) = - mean over trials and 16 bits of
     [C_yj log p_j + (1 - C_yj) log(1 - p_j)] with the clipped p of D2.
 D7  Posterior accuracy = share of trials whose most probable class is the label;
     agreement = share of trials where most probable class = decision of D1.
 D8  "/8" measures: posterior = softmax(score_0 / 8, score_1 / 8); NLL, ECE, Brier as above.
 D9  Training accuracy with D1 on the training outputs; train minus test accuracy.
 D10 Target movement (last trained target T, label target L = one-hot (softmax) or code
     word (Walsh), both float64): mean |T - L| over trials and all units; the same over
     the 8 bits in which the code words differ (Walsh); displacement = mean over trials of
     the Euclidean norm of T_i - L_i; other-class share = share of trials whose T decodes
     (D1) to the other class.  S0 has no stored target array: not available.
 D11 W1 versus W5 last trained targets per participant and seed: mean |T_W1 - T_W5| over
     trials and 16 units; over the 8 differing bits; mean over trials of the Euclidean
     norm of the difference.
 D12 Participant value = mean over the five seeds.  Accuracy differences are formed
     exactly (integer numbers of correct trials), in percentage points.
 D13 Contrast statistics on the 54 participant differences: mean, SD (n-1), SE, t = mean/SE,
     df = 53, two-sided p, mean -/+ t(0.975, 53) * SE, d_z = mean / SD, Holm step-down over
     the four p values, Wilcoxon signed-rank (zeros dropped, average ranks, tie-corrected
     normal approximation, no continuity correction; statistic = min(W+, W-)).
 D14 Condition summary = mean over the 54 participant values; between-participant SD of
     accuracy with n-1.
"""
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter, OrderedDict
from fractions import Fraction

import numpy as np
import scipy
from scipy import stats as sps

TOL = 1e-9
STUDY = 'LEE2019_S1_W5_KONTROL_KOSULLARI-V1.0'
FORBIDDEN_DIRS = ('qa', 'analysis')
FORBIDDEN_FILES = ('final_analysis.py', 'campaign.py')

METRIC_COLS = [
    'accuracy', 'nll_clipped', 'ece15', 'bce', 'brier_sum', 'mean_confidence',
    'posterior_accuracy', 'decision_rules_agree', 'nll_scores_divided_by_8',
    'ece15_scores_divided_by_8', 'brier_scores_divided_by_8', 'train_accuracy',
    'train_minus_test_accuracy', 'target_displacement', 'target_mean_abs_change_per_output',
    'target_mean_abs_change_differing_bits', 'target_other_class_share']
OTHER_MEASURES = ['nll_clipped', 'ece15', 'brier_sum', 'mean_confidence', 'train_accuracy',
                  'train_minus_test_accuracy']
CONTRAST_WEIGHTS = OrderedDict([
    ('S1-S0', OrderedDict([('S1', 1), ('S0', -1)])),
    ('(W1-W0)-(S1-S0)', OrderedDict([('W1', 1), ('W0', -1), ('S1', -1), ('S0', 1)])),
    ('W1-W5', OrderedDict([('W1', 1), ('W5', -1)])),
    ('W5-W4', OrderedDict([('W5', 1), ('W4', -1)])),
])


# --------------------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------------------
def fit_id(subject, cond, seed):
    return 'subject_%02d_train__%s__seed%d' % (subject, cond, seed)


_DATA_ROOT_ABS = [None]


def is_forbidden(path):
    """True for anything inside a folder named qa / analysis (below the data root) and for the two script names."""
    p = path
    root = _DATA_ROOT_ABS[0]
    if root is not None and os.path.isabs(os.path.abspath(p)):
        ap = os.path.abspath(p)
        if ap == root or ap.startswith(root + os.sep):
            p = os.path.relpath(ap, root)
    parts = p.replace('\\', '/').split('/')
    return any(q in FORBIDDEN_DIRS for q in parts[:-1]) or parts[-1] in FORBIDDEN_FILES


_HASH_CACHE = {}


def sha256_file(path):
    if is_forbidden(path):
        raise RuntimeError('refusing to open a forbidden file: %s' % path)
    key = os.path.abspath(path)
    if key not in _HASH_CACHE:
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(1 << 20), b''):
                h.update(chunk)
        _HASH_CACHE[key] = h.hexdigest()
    return _HASH_CACHE[key]


def load_json(path):
    if is_forbidden(path):
        raise RuntimeError('refusing to open a forbidden file: %s' % path)
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_npz(path):
    with np.load(path, allow_pickle=False) as z:
        return OrderedDict((k, z[k]) for k in z.files)


def read_csv(path):
    with open(path, 'r', encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    return rows


def pfloat(s):
    """published CSV cell -> float or None (blank)"""
    if s is None:
        return None
    s = s.strip()
    if s == '' or s.lower() in ('none', 'null'):
        return None
    return float(s)


def isblank(x):
    return x is None or (isinstance(x, float) and math.isnan(x))


def jsonable(o):
    if isinstance(o, dict):
        return OrderedDict((str(k), jsonable(v)) for k, v in o.items())
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, (float, np.floating)):
        o = float(o)
        if math.isnan(o):
            return None
        if math.isinf(o):
            return 'Infinity' if o > 0 else '-Infinity'
        return o
    if isinstance(o, Fraction):
        return '%d/%d' % (o.numerator, o.denominator)
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    return o


def fmean(vals):
    return math.fsum(vals) / len(vals)


def mean_or_none(vals):
    blanks = [isblank(v) for v in vals]
    if all(blanks):
        return None
    if any(blanks):
        raise RuntimeError('mixture of available and unavailable values in one mean')
    return fmean([float(v) for v in vals])


def sd_n1(vals):
    m = fmean(vals)
    return math.sqrt(math.fsum((v - m) ** 2 for v in vals) / (len(vals) - 1))


# --------------------------------------------------------------------------------------
# comparison bookkeeping
# --------------------------------------------------------------------------------------
GROUP_CLASS_TEXT = OrderedDict([
    ('P', 'recomputed from the stored arrays versus a published result file (final_analysis)'),
    ('D', 'recomputed from the stored arrays versus a record or a decision / reproduction file'),
    ('T', 'transcription only: a value read from records or files versus a published or decision file (not recomputable from the stored arrays)'),
    ('I', 'inventory and integrity: stored data versus the expectation of protocol / brief, or SHA-256 / size'),
    ('O', 'own consistency (two routes of this script) or published file versus published file')])
GROUP_CLASS = {
    'A01': 'I', 'A02': 'P', 'A03': 'P', 'A04': 'I', 'A05': 'I', 'A06': 'I', 'A07': 'I', 'A08': 'I', 'A09': 'I', 'A10': 'I',
    'A11': 'I', 'A12': 'I', 'A13': 'I', 'A14': 'I', 'A15': 'I', 'A16': 'I', 'A17': 'I', 'A18': 'I', 'A19': 'I',
    'B01': 'P', 'B02': 'D', 'B03': 'D', 'B04': 'D', 'B05': 'D', 'B06': 'D', 'B07': 'D', 'B08': 'D', 'B09': 'D', 'B10': 'D',
    'B11': 'D', 'B12': 'O', 'B13': 'D', 'B14': 'D', 'B15': 'T', 'B16': 'T', 'B17': 'D', 'B18': 'T',
    'C01': 'P', 'C02': 'P', 'C03': 'O', 'C04': 'P', 'C05': 'P', 'C06': 'P', 'C07': 'P', 'C08': 'P', 'C09': 'P',
    'D01': 'P', 'D02': 'P', 'D03': 'P', 'D04': 'P', 'D05': 'P', 'D06': 'P', 'D07': 'O', 'D08': 'O', 'D09': 'P', 'D10': 'O',
    'D11': 'O',
    'E01': 'T', 'E02': 'T', 'E03': 'T', 'E04': 'T', 'E05': 'T', 'E06': 'T', 'E07': 'T', 'E08': 'P', 'E09': 'P', 'E10': 'P',
    'E11': 'P',
    'F01': 'D', 'F02': 'D', 'F03': 'D', 'F04': 'D', 'F05': 'T', 'F06': 'I',
    'G01': 'P', 'G02': 'I', 'G03': 'I'}


class Comparison(object):
    def __init__(self, tol):
        self.tol = tol
        self.groups = OrderedDict()

    def _group(self, name, kind, against, note):
        if name not in self.groups:
            self.groups[name] = OrderedDict([
                ('group', name), ('kind', kind), ('compared_against', against),
                ('n_compared', 0), ('n_both_blank', 0),
                ('max_abs_difference', 0.0 if kind == 'numeric' else None),
                ('max_abs_difference_at', None),
                ('n_beyond_tolerance', 0), ('note', note), ('beyond', [])])
        g = self.groups[name]
        if g['kind'] != kind:
            raise RuntimeError('group %s used with two kinds' % name)
        return g

    def declare(self, name, kind, against, note=''):
        self._group(name, kind, against, note)

    def num(self, name, key, mine, pub, against='', note=''):
        """numeric comparison, absolute tolerance self.tol; blanks must coincide"""
        g = self._group(name, 'numeric', against, note)
        g['n_compared'] += 1
        mb, pb = isblank(mine), isblank(pub)
        if mb and pb:
            g['n_both_blank'] += 1
            return True
        if mb != pb:
            g['n_beyond_tolerance'] += 1
            g['beyond'].append(OrderedDict([('key', key), ('recomputed', None if mb else float(mine)),
                                            ('published', None if pb else float(pub)),
                                            ('abs_difference', None),
                                            ('reason', 'value present on one side only')]))
            return False
        mine, pub = float(mine), float(pub)
        if math.isinf(mine) or math.isinf(pub):
            d = 0.0 if mine == pub else float('inf')
        else:
            d = abs(mine - pub)
        if d > g['max_abs_difference']:
            g['max_abs_difference'] = d
            g['max_abs_difference_at'] = key
        if d > self.tol:
            g['n_beyond_tolerance'] += 1
            g['beyond'].append(OrderedDict([('key', key), ('recomputed', mine), ('published', pub),
                                            ('abs_difference', d)]))
            return False
        return True

    def exact(self, name, key, mine, pub, against='', note=''):
        """exact comparison for counts, labels, booleans, hashes"""
        g = self._group(name, 'exact', against, note)
        g['n_compared'] += 1
        both_int = (isinstance(mine, (int, np.integer)) and isinstance(pub, (int, np.integer))
                    and not isinstance(mine, (bool, np.bool_)) and not isinstance(pub, (bool, np.bool_)))
        if both_int:
            d = abs(int(mine) - int(pub))
            if g['max_abs_difference'] is None or d > g['max_abs_difference']:
                g['max_abs_difference'] = d
                g['max_abs_difference_at'] = key
        if mine is None and pub is None:
            g['n_both_blank'] += 1
            return True
        same = (mine == pub) and (type(mine) == type(pub) or both_int
                                  or (isinstance(mine, (bool, np.bool_)) and isinstance(pub, (bool, np.bool_))))
        if not same:
            g['n_beyond_tolerance'] += 1
            g['beyond'].append(OrderedDict([('key', key), ('recomputed', jsonable(mine)),
                                            ('published', jsonable(pub)),
                                            ('abs_difference', abs(int(mine) - int(pub)) if both_int else None)]))
            return False
        return True


# --------------------------------------------------------------------------------------
# definitions D1 .. D11
# --------------------------------------------------------------------------------------
def nearest_codeword(P64, C):
    """D1 (Walsh): squared Euclidean distance to both code words, argmin (ties -> class 0)."""
    d2 = np.stack([np.sum((P64 - C[0]) ** 2, axis=1), np.sum((P64 - C[1]) ** 2, axis=1)], axis=1)
    return np.argmin(d2, axis=1).astype(np.int64), d2


def larger_probability(P64):
    """D1 (softmax): argmax of the two saved probabilities (ties -> class 0)."""
    return np.argmax(P64, axis=1).astype(np.int64)


def softmax_rows(s):
    m = np.max(s, axis=1, keepdims=True)
    e = np.exp(s - m)
    return e / np.sum(e, axis=1, keepdims=True)


def walsh_scores(pc, C):
    """D2: log of the product of the 16 (clipped) bit probabilities of each code word."""
    lp = np.log(pc)
    lq = np.log(1.0 - pc)
    return np.stack([np.sum(np.where(C[0] == 1.0, lp, lq), axis=1),
                     np.sum(np.where(C[1] == 1.0, lp, lq), axis=1)], axis=1)


def ece_bins(conf, correct, nbins=15, right_closed=True):
    """D4."""
    edges = np.linspace(0.0, 1.0, nbins + 1)
    n = conf.shape[0]
    total = 0.0
    for b in range(nbins):
        lo, hi = edges[b], edges[b + 1]
        if right_closed:
            m = (conf > lo) & (conf <= hi)
        else:
            m = (conf >= lo) & (conf < hi) if b < nbins - 1 else (conf >= lo) & (conf <= hi)
        k = int(np.count_nonzero(m))
        if k:
            total += (k / n) * abs(float(np.mean(correct[m])) - float(np.mean(conf[m])))
    return total


def prob_measures(q, y, correct_for_ece=None, right_closed=True):
    """D3, D4, D5, D7 for an (N, 2) matrix of class probabilities."""
    n = y.shape[0]
    idx = np.arange(n)
    qy = q[idx, y]
    nll = -float(np.mean(np.log(np.maximum(qy, 1e-12))))
    onehot = np.zeros((n, 2), dtype=np.float64)
    onehot[idx, y] = 1.0
    brier = float(np.mean(np.sum((q - onehot) ** 2, axis=1)))
    conf = np.max(q, axis=1)
    top = np.argmax(q, axis=1).astype(np.int64)
    correct = (top == y) if correct_for_ece is None else correct_for_ece
    ece = ece_bins(conf, correct.astype(np.float64), 15, right_closed)
    return OrderedDict([('nll', nll), ('ece', ece), ('brier', brier),
                        ('mean_confidence', float(np.mean(conf))), ('top', top), ('conf', conf)])


def label_targets(cond, y, C):
    if cond[0] == 'W':
        return C[y]
    L = np.zeros((y.shape[0], 2), dtype=np.float64)
    L[np.arange(y.shape[0]), y] = 1.0
    return L


def decode(cond, X64, C):
    return nearest_codeword(X64, C)[0] if cond[0] == 'W' else larger_probability(X64)


def compute_fit(cond, A, C, D):
    """All primary per-fit quantities.  A: arrays of one fit; C: (2,16) code words; D: differing bits."""
    walsh = cond[0] == 'W'
    y_te = A['y_test'].astype(np.int64)
    y_tr = A['y_train'].astype(np.int64)
    Pte = A['P_test'].astype(np.float64)
    Ptr = A['P_train'].astype(np.float64)
    n_te, n_tr = int(y_te.shape[0]), int(y_tr.shape[0])
    r = OrderedDict()
    x = OrderedDict()      # things that are not written per fit (arrays, diagnostics)

    if walsh:
        pred_te, d2 = nearest_codeword(Pte, C)
        pred_tr, d2tr = nearest_codeword(Ptr, C)
        pc = np.clip(Pte, 1e-7, 1.0 - 1e-7)
        s = walsh_scores(pc, C)
        q = softmax_rows(s)
        q8 = softmax_rows(s / 8.0)
        Cy = C[y_te]
        bce = -float(np.mean(Cy * np.log(pc) + (1.0 - Cy) * np.log(1.0 - pc)))
        x['min_abs_distance_gap_test'] = float(np.min(np.abs(d2[:, 0] - d2[:, 1])))
        x['min_abs_distance_gap_train'] = float(np.min(np.abs(d2tr[:, 0] - d2tr[:, 1])))
        x['n_distance_ties_test'] = int(np.count_nonzero(d2[:, 0] == d2[:, 1]))
        x['n_distance_ties_train'] = int(np.count_nonzero(d2tr[:, 0] == d2tr[:, 1]))
        x['min_abs_score_gap_test'] = float(np.min(np.abs(s[:, 0] - s[:, 1])))
        x['n_posterior_ties_test'] = int(np.count_nonzero(q[:, 0] == q[:, 1]))
        # literal product form of D2 as a numerical cross-check of the log form
        prod = np.stack([np.prod(np.where(C[0] == 1.0, pc, 1.0 - pc), axis=1),
                         np.prod(np.where(C[1] == 1.0, pc, 1.0 - pc), axis=1)], axis=1)
        qprod = prod / np.sum(prod, axis=1, keepdims=True)
        x['max_abs_posterior_product_form_minus_log_form'] = float(np.max(np.abs(qprod - q)))
        x['scores'] = s
    else:
        pred_te = larger_probability(Pte)
        pred_tr = larger_probability(Ptr)
        q = Pte
        q8 = None
        bce = None
        x['n_probability_ties_test'] = int(np.count_nonzero(Pte[:, 0] == Pte[:, 1]))
        x['n_probability_ties_train'] = int(np.count_nonzero(Ptr[:, 0] == Ptr[:, 1]))

    pm = prob_measures(q, y_te)
    x['n_test_trials_true_class_probability_below_floor'] = int(np.count_nonzero(q[np.arange(n_te), y_te] < 1e-12))
    if walsh:
        x['n_test_outputs_exactly_1'] = int(np.count_nonzero(A['P_test'] == 1.0))
        x['n_test_outputs_exactly_0'] = int(np.count_nonzero(A['P_test'] == 0.0))
        x['n_test_outputs_above_upper_clip'] = int(np.count_nonzero(Pte > 1.0 - 1e-7))
        x['n_test_outputs_below_lower_clip'] = int(np.count_nonzero(Pte < 1e-7))
    n_correct_te = int(np.count_nonzero(pred_te == y_te))
    n_correct_tr = int(np.count_nonzero(pred_tr == y_tr))
    n_post_correct = int(np.count_nonzero(pm['top'] == y_te))
    n_agree = int(np.count_nonzero(pm['top'] == pred_te))

    r['n_test'] = n_te
    r['n_train'] = n_tr
    r['n_correct_test'] = n_correct_te
    r['n_correct_train'] = n_correct_tr
    r['accuracy'] = n_correct_te / n_te
    r['nll_clipped'] = pm['nll']
    r['ece15'] = pm['ece']
    r['bce'] = bce
    r['brier_sum'] = pm['brier']
    r['mean_confidence'] = pm['mean_confidence']
    r['posterior_accuracy'] = n_post_correct / n_te
    r['decision_rules_agree'] = n_agree / n_te
    if walsh:
        pm8 = prob_measures(q8, y_te)
        r['nll_scores_divided_by_8'] = pm8['nll']
        r['ece15_scores_divided_by_8'] = pm8['ece']
        r['brier_scores_divided_by_8'] = pm8['brier']
    else:
        r['nll_scores_divided_by_8'] = None
        r['ece15_scores_divided_by_8'] = None
        r['brier_scores_divided_by_8'] = None
    r['train_accuracy'] = n_correct_tr / n_tr
    r['train_minus_test_accuracy'] = r['train_accuracy'] - r['accuracy']

    T = A.get('Y_last')
    if T is None:
        r['target_displacement'] = None
        r['target_mean_abs_change_per_output'] = None
        r['target_mean_abs_change_differing_bits'] = None
        r['target_other_class_share'] = None
        x['n_target_other_class'] = None
    else:
        T64 = T.astype(np.float64)
        L = label_targets(cond, y_tr, C)
        diff = T64 - L
        r['target_displacement'] = float(np.mean(np.sqrt(np.sum(diff ** 2, axis=1))))
        r['target_mean_abs_change_per_output'] = float(np.mean(np.abs(diff)))
        r['target_mean_abs_change_differing_bits'] = float(np.mean(np.abs(diff[:, D]))) if walsh else None
        dec = decode(cond, T64, C)
        n_other = int(np.count_nonzero(dec != y_tr))
        r['target_other_class_share'] = n_other / n_tr
        x['n_target_other_class'] = n_other
        x['target_rms_displacement'] = float(np.sqrt(np.mean(np.sum(diff ** 2, axis=1))))
    if walsh:
        qtr = softmax_rows(walsh_scores(np.clip(Ptr, 1e-7, 1.0 - 1e-7), C))
    else:
        qtr = Ptr
    x['nll_train'] = -float(np.mean(np.log(np.maximum(qtr[np.arange(n_tr), y_tr], 1e-12))))
    x['max_abs_target_minus_label'] = None if T is None else float(np.max(np.abs(T.astype(np.float64) - label_targets(cond, y_tr, C))))
    x['pred_test'] = pred_te
    x['pred_train'] = pred_tr
    x['top_test'] = pm['top']
    x['q'] = q
    x['q8'] = q8
    return r, x


def compute_alternatives(cond, A, C, D, r, x):
    """Named alternative readings (never used for the primary comparison)."""
    walsh = cond[0] == 'W'
    y_te = A['y_test'].astype(np.int64)
    Pte = A['P_test'].astype(np.float64)
    a = OrderedDict()
    q = x['q']
    # ECE with bins [lo, hi) (last bin closed) instead of (lo, hi]
    a['ece15__bins_left_closed'] = prob_measures(q, y_te, right_closed=False)['ece']
    if walsh:
        # ECE with correctness of the nearest-code-word decision instead of the most probable class
        a['ece15__correctness_of_nearest_code_word'] = prob_measures(
            q, y_te, correct_for_ece=(x['pred_test'] == y_te))['ece']
        a['ece15_scores_divided_by_8__bins_left_closed'] = prob_measures(x['q8'], y_te, right_closed=False)['ece']
        # nearest code word by Hamming distance after thresholding at 0.5 (ties -> class 0)
        bits = (Pte > 0.5).astype(np.float64)
        ham = np.stack([np.sum(bits != C[0], axis=1), np.sum(bits != C[1], axis=1)], axis=1)
        a['accuracy__hamming_after_threshold'] = float(np.mean(np.argmin(ham, axis=1) == y_te))
        # nearest code word by city-block distance
        l1 = np.stack([np.sum(np.abs(Pte - C[0]), axis=1), np.sum(np.abs(Pte - C[1]), axis=1)], axis=1)
        a['accuracy__city_block'] = float(np.mean(np.argmin(l1, axis=1) == y_te))
        # bit clip applied in float32 (the saved precision) instead of float64
        p32 = np.clip(A['P_test'].astype(np.float32), np.float32(1e-7), np.float32(1.0 - 1e-7)).astype(np.float64)
        s32 = walsh_scores(p32, C)
        q32 = softmax_rows(s32)
        pm = prob_measures(q32, y_te)
        pm8 = prob_measures(softmax_rows(s32 / 8.0), y_te)
        Cy = C[y_te]
        a['nll_clipped__clip_in_float32'] = pm['nll']
        a['ece15__clip_in_float32'] = pm['ece']
        a['brier_sum__clip_in_float32'] = pm['brier']
        a['mean_confidence__clip_in_float32'] = pm['mean_confidence']
        a['bce__clip_in_float32'] = -float(np.mean(Cy * np.log(p32) + (1.0 - Cy) * np.log(1.0 - p32)))
        a['nll_scores_divided_by_8__clip_in_float32'] = pm8['nll']
        a['ece15_scores_divided_by_8__clip_in_float32'] = pm8['ece']
        a['brier_scores_divided_by_8__clip_in_float32'] = pm8['brier']
        # BCE without bit clip, logarithms bounded below by -100 (convention of torch.nn.BCELoss)
        with np.errstate(divide='ignore'):
            lp = np.maximum(np.log(Pte), -100.0)
            lq = np.maximum(np.log(1.0 - Pte), -100.0)
        a['bce__no_clip_log_floor_minus_100'] = -float(np.mean(Cy * lp + (1.0 - Cy) * lq))
    if A.get('Y_last') is not None:
        a['target_displacement__root_mean_square'] = x['target_rms_displacement']
        # the same definition evaluated in single precision (the precision of the stored arrays)
        T32 = A['Y_last'].astype(np.float32)
        L32 = label_targets(cond, A['y_train'].astype(np.int64), C).astype(np.float32)
        d32 = T32 - L32
        a['target_displacement__float32_arithmetic'] = float(
            np.mean(np.sqrt(np.sum(d32 * d32, axis=1, dtype=np.float32)), dtype=np.float32))
    return a


# --------------------------------------------------------------------------------------
# statistics D13
# --------------------------------------------------------------------------------------
def paired_summary(d):
    n = len(d)
    mean = fmean(d)
    sd = sd_n1(d)
    se = sd / math.sqrt(n)
    df = n - 1
    out = OrderedDict([('n', n), ('mean_difference', mean), ('sd_difference', sd), ('se', se), ('df', df)])
    if sd > 0:
        t = mean / se
        out['t'] = t
        out['p_unadjusted'] = float(2.0 * sps.t.sf(abs(t), df))
        out['d_z'] = mean / sd
    else:
        out['t'] = None
        out['p_unadjusted'] = None
        out['d_z'] = None
    tcrit = float(sps.t.ppf(0.975, df))
    out['t_critical_0_975'] = tcrit
    out['pointwise_95ci'] = [mean - tcrit * se, mean + tcrit * se]
    return out


def wilcoxon_own(d_exact):
    """Signed-rank test on exact (Fraction/int) differences: zeros dropped, average ranks,
    tie-corrected normal approximation, no continuity correction, two-sided."""
    nz = [v for v in d_exact if v != 0]
    n = len(nz)
    absv = sorted(abs(v) for v in nz)
    rank = {}
    tie_term = 0
    i = 0
    while i < n:
        j = i
        while j < n and absv[j] == absv[i]:
            j += 1
        rank[absv[i]] = Fraction(i + 1 + j, 2)
        t = j - i
        tie_term += t ** 3 - t
        i = j
    r_plus = sum((rank[abs(v)] for v in nz if v > 0), Fraction(0))
    r_minus = sum((rank[abs(v)] for v in nz if v < 0), Fraction(0))
    stat = min(r_plus, r_minus)
    mn = Fraction(n * (n + 1), 4)
    var = Fraction(n * (n + 1) * (2 * n + 1), 24) - Fraction(tie_term, 48)
    out = OrderedDict([('n_nonzero', n), ('r_plus', float(r_plus)), ('r_minus', float(r_minus)),
                       ('statistic', float(stat)), ('mean_under_h0', float(mn)), ('variance_under_h0', float(var)),
                       ('n_tie_groups_larger_than_1', sum(1 for c in Counter(absv).values() if c > 1))])
    if n > 0 and var > 0:
        z = (float(stat) - float(mn)) / math.sqrt(float(var))
        out['z'] = z
        out['p_two_sided'] = float(2.0 * sps.norm.sf(abs(z)))
    else:
        out['z'] = None
        out['p_two_sided'] = None
    return out


def holm(pvals):
    m = len(pvals)
    order = sorted(range(m), key=lambda k: (pvals[k], k))
    adj = [None] * m
    running = 0.0
    for rank_, k in enumerate(order):
        val = min(1.0, (m - rank_) * pvals[k])
        running = max(running, val)
        adj[k] = running
    return adj


# --------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------
def main(argv):
    if len(argv) < 3:
        sys.stderr.write(__doc__)
        return 2
    data_root = argv[1]
    out_dir = argv[2]
    members_dir = argv[3] if len(argv) > 3 else os.path.join(os.path.dirname(os.path.abspath(data_root)), 'transfer')
    os.makedirs(out_dir, exist_ok=True)
    _DATA_ROOT_ABS[0] = os.path.abspath(data_root)

    def P(*parts):
        return os.path.join(data_root, *[p for part in parts for p in part.split('/')])

    cmp_ = Comparison(TOL)
    R = OrderedDict()            # everything that goes to RECOMPUTED.json
    notes = []                   # free-text findings produced by the script

    # ---------------------------------------------------------------- protocol and decision files
    proto = load_json(P(STUDY, 'PROTOKOL-V1.0.json'))
    people = list(proto['design']['people'])
    seeds = list(proto['design']['seeds'])
    n_train_expected = int(proto['design']['train_trials'])
    n_test_expected = int(proto['design']['test_trials'])
    new_conds = list(proto['design']['new_conditions'])
    ref_conds = list(proto['design']['reference_conditions'])
    conds = sorted(new_conds + ref_conds)
    sample_subjects = list(proto['design']['reproduction_sample']['subjects'])
    sample_seeds = list(proto['design']['reproduction_sample']['seeds'])
    contrast_names = list(proto['analysis']['contrasts'])
    if contrast_names != list(CONTRAST_WEIGHTS.keys()):
        raise RuntimeError('protocol contrasts differ from the four contrasts implemented here')
    n_fits_per_cond = len(people) * len(seeds)

    bindings = load_json(P(STUDY, 'data/SOURCE_BINDINGS-V1.0.json'))
    archive = bindings['archive']
    rep_train = load_json(P(STUDY, 'campaign/REPRODUCTION_TRAIN-V1.0.json'))
    rep_test = load_json(P(STUDY, 'campaign/REPRODUCTION_TEST-V1.0.json'))
    freeze = load_json(P(STUDY, 'campaign/MODEL_FREEZE-V1.0.json'))
    test_completion = load_json(P(STUDY, 'campaign/TEST_COMPLETION-V1.0.json'))
    results = load_json(P(STUDY, 'final_analysis/RESULTS-V1.0.json'))
    pub_contrasts = load_json(P(STUDY, 'final_analysis/four_contrasts_holm.json'))
    analysis_completion_path = P(STUDY, 'final_analysis/ANALYSIS_COMPLETION-V1.0.json')
    analysis_completion = load_json(analysis_completion_path) if os.path.exists(analysis_completion_path) else None
    campaign_completion_path = P(STUDY, 'ops/CAMPAIGN_COMPLETION-V1.0.json')
    campaign_completion = load_json(campaign_completion_path) if os.path.exists(campaign_completion_path) else None

    reference_source = rep_train['reference_source']
    R['meta'] = OrderedDict([
        ('script', 'recompute.py'), ('tolerance_absolute', TOL),
        ('python', '%d.%d.%d' % sys.version_info[:3]), ('numpy', np.__version__), ('scipy', scipy.__version__),
        ('study', STUDY), ('participants', len(people)), ('seeds', seeds), ('conditions', conds),
        ('train_trials', n_train_expected), ('test_trials', n_test_expected),
        ('reference_source_in_decision_file', reference_source)])

    g = 'A01 reference source: decision file versus other files (label)'
    against = 'REPRODUCTION_TRAIN-V1.0.json reference_source'
    cmp_.exact(g, 'brief (ARCHIVE)', reference_source, 'ARCHIVE', against)
    cmp_.exact(g, 'REPRODUCTION_TEST', reference_source, rep_test.get('reference_source'), against)
    cmp_.exact(g, 'MODEL_FREEZE', reference_source, freeze.get('reference_source'), against)
    cmp_.exact(g, 'RESULTS', reference_source, results.get('reference_source'), against)
    if campaign_completion is not None:
        cmp_.exact(g, 'CAMPAIGN_COMPLETION', reference_source, campaign_completion.get('reference_source'), against)

    # ---------------------------------------------------------------- which copy did the analysis use
    pub_run = read_csv(P(STUDY, 'final_analysis/run_metrics.csv'))
    pub_run_by_key = OrderedDict()
    dup_run_keys = []
    for row in pub_run:
        k = (int(row['subject']), int(row['seed']), row['condition'])
        if k in pub_run_by_key:
            dup_run_keys.append(k)
        pub_run_by_key[k] = row
    expected_keys = [(s, k, c) for c in conds for s in people for k in seeds]

    def rule_origin(cond):
        if cond in new_conds:
            return 'campaign'
        return 'archive' if reference_source == 'ARCHIVE' else 'campaign'

    origin_used = OrderedDict()
    for (s, k, c) in expected_keys:
        row = pub_run_by_key.get((s, k, c))
        origin_used[(s, k, c)] = row['origin'] if row is not None and row.get('origin') in ('archive', 'campaign') \
            else rule_origin(c)

    g = 'A02 run_metrics.csv: set of rows (subject, seed, condition)'
    cmp_.exact(g, 'number of rows', len(expected_keys), len(pub_run), 'run_metrics.csv')
    cmp_.exact(g, 'number of duplicate keys', 0, len(dup_run_keys), 'run_metrics.csv')
    cmp_.exact(g, 'expected keys missing in file', 0, len([k for k in expected_keys if k not in pub_run_by_key]),
               'run_metrics.csv')
    cmp_.exact(g, 'unexpected keys in file', 0, len([k for k in pub_run_by_key if k not in set(expected_keys)]),
               'run_metrics.csv')
    g = 'A03 origin of each fit: reference-source rule versus run_metrics.csv origin (label)'
    for key in expected_keys:
        row = pub_run_by_key.get(key)
        cmp_.exact(g, '%d/%d/%s' % key, rule_origin(key[2]), row['origin'] if row is not None else None,
                   'run_metrics.csv origin')

    # ---------------------------------------------------------------- A. inventory: file sets
    camp = P(STUDY, 'campaign')
    expected_campaign = set(fit_id(s, c, k) for c in new_conds for s in people for k in seeds)
    sample_ids = [fit_id(s, c, k) for s in sample_subjects for c in ref_conds for k in sample_seeds]
    if reference_source == 'ARCHIVE':
        expected_campaign |= set(sample_ids)
    else:
        expected_campaign |= set(fit_id(s, c, k) for c in ref_conds for s in people for k in seeds)
    inv = OrderedDict()
    g = 'A04 campaign file sets (counts; missing / unexpected fit ids)'
    file_sets = OrderedDict()
    for folder, suffix in (('fit_records', '.json'), ('fit_outputs', '.npz'),
                           ('test_records', '_day2.json'), ('predictions', '_day2.npz')):
        names = sorted(os.listdir(os.path.join(camp, folder)))
        ids = [n[:-len(suffix)] for n in names if n.endswith(suffix)]
        other = [n for n in names if not n.endswith(suffix)]
        file_sets[folder] = OrderedDict([
            ('files', len(names)), ('fit_ids', len(set(ids))),
            ('missing', sorted(expected_campaign - set(ids))), ('unexpected', sorted(set(ids) - expected_campaign)),
            ('files_with_other_names', other)])
        cmp_.exact(g, folder + ': files', len(names), len(expected_campaign), 'protocol counts / brief')
        cmp_.exact(g, folder + ': missing fit ids', len(file_sets[folder]['missing']), 0, 'protocol counts / brief')
        cmp_.exact(g, folder + ': unexpected fit ids', len(file_sets[folder]['unexpected']), 0, 'protocol counts / brief')
        cmp_.exact(g, folder + ': files with other names', len(other), 0, 'protocol counts / brief')
    cmp_.exact(g, 'MODEL_FREEZE fit_ids equal expected set', sorted(freeze.get('fit_ids', [])) == sorted(expected_campaign),
               True, 'protocol counts / brief')
    cmp_.exact(g, 'protocol counts.campaign_fits_if_archive', len(expected_campaign),
               int(proto['counts']['campaign_fits_if_archive' if reference_source == 'ARCHIVE' else 'campaign_fits_if_refit']),
               'protocol counts / brief')
    inv['campaign_file_sets'] = file_sets

    g = 'A05 archive bindings: fits per reference condition and bound files present'
    arch_counts = Counter(fid.split('__')[1] for fid in archive)
    for c in ref_conds:
        cmp_.exact(g, 'bound fits ' + c, arch_counts.get(c, 0), n_fits_per_cond, 'protocol design (54 x 5)')
        ids_c = set(fit_id(s, c, k) for s in people for k in seeds)
        cmp_.exact(g, 'missing bound fit ids ' + c, len(ids_c - set(archive)), 0, 'protocol design (54 x 5)')
    cmp_.exact(g, 'bound fits in total', len(archive), n_fits_per_cond * len(ref_conds), 'protocol design (54 x 5)')
    missing_bound = [e['path'] for fid in sorted(archive) for e in archive[fid]['files'].values()
                     if not os.path.exists(P(e['path']))]
    cmp_.exact(g, 'bound files not found in data folder', len(missing_bound), 0, 'protocol design (54 x 5)')
    inv['archive_formats'] = dict(Counter('%s:%s' % (fid.split('__')[1], archive[fid]['format']) for fid in archive))

    # ---------------------------------------------------------------- A. integrity: SHA-256
    g = 'A06 SHA-256 of every bound archive file versus SOURCE_BINDINGS (label)'
    n_bound = 0
    for fid in sorted(archive):
        for name in sorted(archive[fid]['files']):
            e = archive[fid]['files'][name]
            if os.path.exists(P(e['path'])):
                cmp_.exact(g, '%s:%s' % (fid, name), sha256_file(P(e['path'])), e['sha256'], 'SOURCE_BINDINGS-V1.0.json')
                n_bound += 1
    inv['bound_archive_files_hashed'] = n_bound

    g = 'A07 SHA-256 of campaign files versus MODEL_FREEZE / TEST_COMPLETION lists (label)'
    absent_freeze = Counter()
    for rel, sha in sorted(freeze['files'].items()):
        path = P(STUDY, rel)
        if os.path.exists(path):
            cmp_.exact(g, 'freeze:' + rel, sha256_file(path), sha, 'MODEL_FREEZE-V1.0.json, TEST_COMPLETION-V1.0.json')
        else:
            absent_freeze[rel.split('/')[1] if '/' in rel else rel] += 1
    absent_tc = Counter()
    for rel, sha in sorted(test_completion['files'].items()):
        path = P(STUDY, rel)
        if os.path.exists(path):
            cmp_.exact(g, 'tests:' + rel, sha256_file(path), sha, 'MODEL_FREEZE-V1.0.json, TEST_COMPLETION-V1.0.json')
        else:
            absent_tc[rel.split('/')[1] if '/' in rel else rel] += 1
    inv['model_freeze_entries'] = len(freeze['files'])
    inv['model_freeze_entries_not_in_data_folder'] = dict(absent_freeze)
    inv['test_completion_entries'] = len(test_completion['files'])
    inv['test_completion_entries_not_in_data_folder'] = dict(absent_tc)

    g = 'A08 SHA-256 cross-references inside records (label)'
    against = 'fit / test records'
    for fid in sorted(expected_campaign):
        fr_path = os.path.join(camp, 'fit_records', fid + '.json')
        tr_path = os.path.join(camp, 'test_records', fid + '_day2.json')
        fo_path = os.path.join(camp, 'fit_outputs', fid + '.npz')
        pr_path = os.path.join(camp, 'predictions', fid + '_day2.npz')
        if not (os.path.exists(fr_path) and os.path.exists(tr_path) and os.path.exists(fo_path) and os.path.exists(pr_path)):
            continue
        fr, tr = load_json(fr_path), load_json(tr_path)
        cmp_.exact(g, fid + ': fit record -> fit_outputs', sha256_file(fo_path), fr['files']['fit_outputs']['sha256'], against)
        cmp_.exact(g, fid + ': test record -> prediction', sha256_file(pr_path), tr['prediction_sha256'], against)
        cmp_.exact(g, fid + ': test record -> fit record', sha256_file(fr_path), tr['source_fit_sha256'], against)
    for fid in sorted(archive):
        e = archive[fid]
        f = e['files']
        if e['format'] == 'lee':
            rec = load_json(P(f['record']['path']))
            cmp_.exact(g, fid + ': archive record -> prediction', sha256_file(P(f['prediction']['path'])),
                       rec.get('prediction_sha256'), against)
        else:
            fr, tr = load_json(P(f['fit_record']['path'])), load_json(P(f['test_record']['path']))
            cmp_.exact(g, fid + ': archive fit record -> fit_outputs', sha256_file(P(f['fit_outputs']['path'])),
                       fr['files']['fit_outputs']['sha256'], against)
            cmp_.exact(g, fid + ': archive test record -> prediction', sha256_file(P(f['prediction']['path'])),
                       tr['prediction_sha256'], against)
            cmp_.exact(g, fid + ': archive test record -> fit record', sha256_file(P(f['fit_record']['path'])),
                       tr['source_fit_sha256'], against)

    g = 'A08 SHA-256 cross-references inside records (label)'
    subj_bind = bindings.get('subjects') or {}
    for fid in sorted(expected_campaign):
        fr_path = os.path.join(camp, 'fit_records', fid + '.json')
        if not os.path.exists(fr_path):
            continue
        fr = load_json(fr_path)
        s_ = int(fid[8:10])
        pre_path = P(STUDY, fr.get('preprocessor_path', 'data/preprocessors/subject_%02d.json' % s_))
        cmp_.exact(g, fid + ': fit record -> preprocessor file', sha256_file(pre_path) if os.path.exists(pre_path) else None,
                   fr.get('preprocessor_sha256'), against)
        cmp_.exact(g, fid + ': fit record train_source -> bound first-day file', fr.get('train_source_sha256'),
                   ((subj_bind.get(str(s_)) or {}).get('train') or {}).get('sha256'), against)
    for s_ in people:
        pre_path = P(STUDY, 'data/preprocessors', 'subject_%02d.json' % s_)
        if os.path.exists(pre_path):
            pre = load_json(pre_path)
            cmp_.exact(g, 'preprocessor %02d: train_source -> bound first-day file' % s_, pre.get('train_source_sha256'),
                       ((subj_bind.get(str(s_)) or {}).get('train') or {}).get('sha256'), against)
    for fid in sorted(archive):
        e = archive[fid]
        s_ = int(fid[8:10])
        sb = subj_bind.get(str(s_)) or {}
        if e['format'] == 'lee':
            rec = load_json(P(e['files']['record']['path']))
            ds = (rec.get('identity') or {}).get('data_sha256') or {}
            cmp_.exact(g, fid + ': archive record first-day data -> bound file', ds.get('train'), (sb.get('train') or {}).get('sha256'), against)
            cmp_.exact(g, fid + ': archive record second-day data -> bound file', ds.get('test'), (sb.get('test') or {}).get('sha256'), against)
        else:
            fr = load_json(P(e['files']['fit_record']['path']))
            cmp_.exact(g, fid + ': archive fit record train_source -> bound first-day file', fr.get('train_source_sha256'),
                       (sb.get('train') or {}).get('sha256'), against)

    g = 'A09 SHA-256 named in gate / completion files versus the files themselves (label)'
    against = 'RESULTS / TEST_COMPLETION / REPRODUCTION / ANALYSIS_COMPLETION / CAMPAIGN_COMPLETION'
    sha_proto = sha256_file(P(STUDY, 'PROTOKOL-V1.0.json'))
    sha_bind = sha256_file(P(STUDY, 'data/SOURCE_BINDINGS-V1.0.json'))
    sha_freeze = sha256_file(P(STUDY, 'campaign/MODEL_FREEZE-V1.0.json'))
    sha_tc = sha256_file(P(STUDY, 'campaign/TEST_COMPLETION-V1.0.json'))
    sha_results = sha256_file(P(STUDY, 'final_analysis/RESULTS-V1.0.json'))
    cmp_.exact(g, 'protocol source_bindings_sha256', sha_bind, proto.get('source_bindings_sha256'), against)
    cmp_.exact(g, 'RESULTS protocol_sha256', sha_proto, results.get('protocol_sha256'), against)
    cmp_.exact(g, 'RESULTS source_bindings_sha256', sha_bind, results.get('source_bindings_sha256'), against)
    cmp_.exact(g, 'RESULTS model_freeze_sha256', sha_freeze, results.get('model_freeze_sha256'), against)
    cmp_.exact(g, 'RESULTS test_completion_sha256', sha_tc, results.get('test_completion_sha256'), against)
    cmp_.exact(g, 'TEST_COMPLETION model_freeze_sha256', sha_freeze, test_completion.get('model_freeze_sha256'), against)
    cmp_.exact(g, 'TEST_COMPLETION protocol_sha256', sha_proto, test_completion.get('protocol_sha256'), against)
    cmp_.exact(g, 'MODEL_FREEZE protocol_sha256', sha_proto, freeze.get('protocol_sha256'), against)
    cmp_.exact(g, 'MODEL_FREEZE source_bindings_sha256', sha_bind, freeze.get('source_bindings_sha256'), against)
    cmp_.exact(g, 'REPRODUCTION_TRAIN protocol_sha256', sha_proto, rep_train.get('protocol_sha256'), against)
    cmp_.exact(g, 'REPRODUCTION_TEST protocol_sha256', sha_proto, rep_test.get('protocol_sha256'), against)
    cmp_.exact(g, 'REPRODUCTION_TEST model_freeze_sha256', sha_freeze, rep_test.get('model_freeze_sha256'), against)
    receipts_absent = []
    for rel, e in sorted(((proto.get('prelaunch_checks') or {}).get('receipts') or {}).items()):
        path = P(STUDY, rel)
        if os.path.exists(path) and not is_forbidden(path):
            cmp_.exact(g, 'protocol prelaunch receipt ' + rel, sha256_file(path), e.get('sha256'), against)
        else:
            receipts_absent.append(rel)
    inv['protocol_prelaunch_receipts_not_in_data_folder'] = receipts_absent
    if analysis_completion is not None:
        cmp_.exact(g, 'ANALYSIS_COMPLETION protocol_sha256', sha_proto, analysis_completion.get('protocol_sha256'), against)
        for name, sha in sorted(analysis_completion.get('files', {}).items()):
            path = P(STUDY, 'final_analysis', name)
            cmp_.exact(g, 'ANALYSIS_COMPLETION ' + name, sha256_file(path) if os.path.exists(path) else None, sha, against)
    if campaign_completion is not None:
        cmp_.exact(g, 'CAMPAIGN_COMPLETION results_sha256', sha_results, campaign_completion.get('results_sha256'), against)
        cmp_.exact(g, 'CAMPAIGN_COMPLETION model_freeze_sha256', sha_freeze, campaign_completion.get('model_freeze_sha256'), against)
        cmp_.exact(g, 'CAMPAIGN_COMPLETION test_completion_sha256', sha_tc, campaign_completion.get('test_completion_sha256'), against)
        cmp_.exact(g, 'CAMPAIGN_COMPLETION protocol_sha256', sha_proto, campaign_completion.get('protocol_sha256'), against)

    # transfer lists (optional)
    g = 'A10 transferred files versus the three members lists (SHA-256 and size, label)'
    members = OrderedDict()
    if os.path.isdir(members_dir):
        for name in ('campaign_records.members.tsv', 'campaign_arrays.members.tsv', 'reference_fits.members.tsv'):
            path = os.path.join(members_dir, name)
            if not os.path.exists(path):
                continue
            with open(path, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.rstrip('\n').split('\t')
                    if len(parts) >= 3:
                        members[parts[2]] = (parts[0], int(parts[1]), name)
    walked, pruned = [], []
    for dirpath, dirnames, filenames in os.walk(data_root):
        keep = []
        for d in sorted(dirnames):
            if d in FORBIDDEN_DIRS:
                pruned.append(os.path.relpath(os.path.join(dirpath, d), data_root).replace(os.sep, '/'))
            else:
                keep.append(d)
        dirnames[:] = keep
        for fn in sorted(filenames):
            rel = os.path.relpath(os.path.join(dirpath, fn), data_root).replace(os.sep, '/')
            if not is_forbidden(rel):
                walked.append(rel)
    walked.sort()
    inv['files_in_data_folder_outside_folders_named_qa_or_analysis'] = len(walked)
    inv['folders_not_entered_by_rule'] = pruned
    if members:
        not_opened = sorted(p for p in members if is_forbidden(p))
        usable = OrderedDict((p, v) for p, v in members.items() if not is_forbidden(p))
        inv['members_list_entries'] = len(members)
        inv['members_list_entries_not_opened_by_rule'] = not_opened
        cmp_.exact(g, 'files walked + entries not opened by rule', len(walked) + len(not_opened), len(members),
                   'transfer/*.members.tsv')
        cmp_.exact(g, 'listed files missing in data folder', len([p for p in usable if p not in set(walked)]), 0,
                   'transfer/*.members.tsv')
        cmp_.exact(g, 'files in data folder that are not listed', len([p for p in walked if p not in usable]), 0,
                   'transfer/*.members.tsv')
        for p in sorted(usable):
            if os.path.exists(P(p)):
                cmp_.exact(g, 'sha256:' + p, sha256_file(P(p)), usable[p][0], 'transfer/*.members.tsv')
                cmp_.exact(g, 'size:' + p, os.path.getsize(P(p)), usable[p][1], 'transfer/*.members.tsv')
    else:
        inv['members_list_entries'] = None
        notes.append('members lists not found: transfer check skipped')

    # ---------------------------------------------------------------- loading of fits
    def load_copy(fid, origin):
        """arrays and records of one stored copy of a fit"""
        c = fid.split('__')[1]
        out = OrderedDict([('fit_id', fid), ('origin', origin), ('condition', c)])
        if origin == 'campaign':
            fo = load_npz(os.path.join(camp, 'fit_outputs', fid + '.npz'))
            pr = load_npz(os.path.join(camp, 'predictions', fid + '_day2.npz'))
            out['format'] = 'campaign'
            out['array_keys'] = sorted(list(fo.keys()) + list(pr.keys()))
            out['P_train'] = fo.get('P_train_float32')
            out['y_train'] = fo.get('y_train_int64')
            out['Y_last'] = fo.get('Y_used_last_float32')
            out['P_test'] = pr.get('P_test_float32')
            out['y_test'] = pr.get('y_test_int64')
            out['rec_train'] = load_json(os.path.join(camp, 'fit_records', fid + '.json'))
            out['rec_test'] = load_json(os.path.join(camp, 'test_records', fid + '_day2.json'))
            out['normalization_mean'] = None
            out['normalization_sd'] = None
        else:
            e = archive[fid]
            f = e['files']
            out['format'] = e['format']
            if e['format'] == 'lee':
                z = load_npz(P(f['prediction']['path']))
                out['array_keys'] = sorted(z.keys())
                out['P_train'] = z.get('P_train')
                out['y_train'] = z.get('y_train')
                out['Y_last'] = z.get('Y_used_last')
                out['P_test'] = z.get('P_test')
                out['y_test'] = z.get('y_test')
                out['normalization_mean'] = z.get('normalization_mean')
                out['normalization_sd'] = z.get('normalization_sd')
                rec = load_json(P(f['record']['path']))
                out['rec_train'] = rec
                out['rec_test'] = rec
            elif e['format'] == 'w4':
                fo = load_npz(P(f['fit_outputs']['path']))
                pr = load_npz(P(f['prediction']['path']))
                out['array_keys'] = sorted(list(fo.keys()) + list(pr.keys()))
                out['P_train'] = fo.get('P_train_float32')
                out['y_train'] = fo.get('y_train_int64')
                out['Y_last'] = fo.get('Y_used_last_float32')
                out['P_test'] = pr.get('P_test_float32')
                out['y_test'] = pr.get('y_test_int64')
                out['normalization_mean'] = None
                out['normalization_sd'] = None
                out['rec_train'] = load_json(P(f['fit_record']['path']))
                out['rec_test'] = load_json(P(f['test_record']['path']))
            else:
                raise RuntimeError('unknown archive format %r' % e['format'])
        return out

    copies = OrderedDict()       # (fit id, origin) -> copy
    for fid in sorted(expected_campaign):
        copies[(fid, 'campaign')] = load_copy(fid, 'campaign')
    for fid in sorted(archive):
        copies[(fid, 'archive')] = load_copy(fid, 'archive')
    inv['stored_copies_loaded'] = OrderedDict([('campaign', len(expected_campaign)), ('archive', len(archive))])

    # ---------------------------------------------------------------- code words from W0
    w0_rows = {0: Counter(), 1: Counter()}
    for (fid, origin), cp in copies.items():
        if cp['condition'] == 'W0' and cp['Y_last'] is not None:
            T = cp['Y_last']
            y = cp['y_train']
            for cls in (0, 1):
                for row in np.unique(T[y == cls], axis=0):
                    w0_rows[cls][tuple(float(v) for v in row)] += 1
    if len(w0_rows[0]) != 1 or len(w0_rows[1]) != 1:
        raise RuntimeError('W0 targets do not give exactly one code word per class: %d / %d'
                           % (len(w0_rows[0]), len(w0_rows[1])))
    cw0 = list(w0_rows[0].keys())[0]
    cw1 = list(w0_rows[1].keys())[0]
    C = np.array([cw0, cw1], dtype=np.float64)
    if not np.all((C == 0.0) | (C == 1.0)):
        raise RuntimeError('code words are not binary')
    D = np.nonzero(C[0] != C[1])[0]
    R['code_words'] = OrderedDict([
        ('class_0', ''.join(str(int(v)) for v in C[0])), ('class_1', ''.join(str(int(v)) for v in C[1])),
        ('bits_that_differ_zero_based', [int(v) for v in D]), ('number_of_differing_bits', int(D.shape[0])),
        ('W0_fits_supporting_class_0', int(list(w0_rows[0].values())[0])),
        ('W0_fits_supporting_class_1', int(list(w0_rows[1].values())[0])),
        ('derived_from', 'Y_used_last of every stored W0 fit (archive and campaign copies): one distinct row per class')])
    g = 'A11 code words derived from W0 targets'
    cmp_.exact(g, 'number of differing bits', int(D.shape[0]), 8, 'protocol manipulation_checks (8 differing bits)')
    cmp_.exact(g, 'code word length', int(C.shape[1]), 16, 'protocol manipulation_checks (8 differing bits)')

    # ---------------------------------------------------------------- A. array checks on every stored copy
    viol = OrderedDict((k, []) for k in (
        'array keys', 'dtype', 'shape', 'non-finite values', 'values outside [0, 1]', 'softmax row sum',
        'labels not in {0, 1}', 'training classes not 50/50', 'target array presence'))
    max_rowsum_dev = 0.0
    max_target_rowsum_dev = 0.0
    softmax_rows_total = 0
    softmax_rows_not_exactly_one = 0
    lee_keys = {False: ['P_test', 'P_train', 'normalization_mean', 'normalization_sd', 'y_test', 'y_train'],
                True: ['P_test', 'P_train', 'Y_used_last', 'normalization_mean', 'normalization_sd', 'y_test', 'y_train']}
    own_keys = {False: ['P_test_float32', 'P_train_float32', 'y_test_int64', 'y_train_int64'],
                True: ['P_test_float32', 'P_train_float32', 'Y_used_last_float32', 'y_test_int64', 'y_train_int64']}
    test_class_counts = Counter()
    for (fid, origin), cp in copies.items():
        c = cp['condition']
        tag = '%s [%s]' % (fid, origin)
        K = 16 if c[0] == 'W' else 2
        has_target = (c != 'S0')
        exp_keys = (lee_keys if cp['format'] == 'lee' else own_keys)[has_target]
        if cp['array_keys'] != exp_keys:
            viol['array keys'].append(tag)
        if (cp['Y_last'] is not None) != has_target:
            viol['target array presence'].append(tag)
        spec = [('P_train', np.float32, (n_train_expected, K)), ('y_train', np.int64, (n_train_expected,)),
                ('P_test', np.float32, (n_test_expected, K)), ('y_test', np.int64, (n_test_expected,))]
        if cp['Y_last'] is not None:
            spec.append(('Y_last', np.float32, (n_train_expected, K)))
        for name, dt, shape in spec:
            arr = cp[name]
            if arr is None:
                viol['array keys'].append(tag + ':' + name)
                continue
            if arr.dtype != np.dtype(dt):
                viol['dtype'].append(tag + ':' + name)
            if arr.shape != shape:
                viol['shape'].append(tag + ':' + name)
            if not np.all(np.isfinite(arr)):
                viol['non-finite values'].append(tag + ':' + name)
            if name in ('P_train', 'P_test', 'Y_last') and (np.min(arr) < 0 or np.max(arr) > 1):
                viol['values outside [0, 1]'].append(tag + ':' + name)
            if name in ('y_train', 'y_test') and not np.all((arr == 0) | (arr == 1)):
                viol['labels not in {0, 1}'].append(tag + ':' + name)
        if c[0] == 'S':
            for name in ('P_train', 'P_test'):
                rowsum = np.sum(cp[name].astype(np.float64), axis=1)
                dev = float(np.max(np.abs(rowsum - 1.0)))
                max_rowsum_dev = max(max_rowsum_dev, dev)
                softmax_rows_total += int(rowsum.shape[0])
                softmax_rows_not_exactly_one += int(np.count_nonzero(rowsum != 1.0))
                if dev > 1e-6:
                    viol['softmax row sum'].append(tag + ':' + name)
            if cp['Y_last'] is not None:
                max_target_rowsum_dev = max(max_target_rowsum_dev, float(np.max(np.abs(
                    np.sum(cp['Y_last'].astype(np.float64), axis=1) - 1.0))))
        if int(np.sum(cp['y_train'] == 0)) != n_train_expected // 2:
            viol['training classes not 50/50'].append(tag)
        if origin == origin_used.get((int(fid[8:10]), int(fid.split('seed')[1]), c)):
            test_class_counts[(int(np.sum(cp['y_test'] == 0)), int(np.sum(cp['y_test'] == 1)))] += 1
    g = 'A12 stored arrays of all %d stored copies: violations per check (count)' % len(copies)
    for k, v in viol.items():
        cmp_.exact(g, k, len(v), 0, 'brief section A / protocol design')
    inv['array_check_violations'] = viol
    inv['softmax_rows_max_abs_deviation_of_sum_from_1'] = max_rowsum_dev
    inv['softmax_row_sum_tolerance_used'] = 1e-6
    inv['softmax_rows_checked_in_all_stored_copies'] = softmax_rows_total
    inv['softmax_rows_whose_float64_sum_is_not_exactly_1'] = softmax_rows_not_exactly_one
    inv['S1_last_target_rows_max_abs_deviation_of_sum_from_1'] = max_target_rowsum_dev
    inv['test_class_counts_(n0,n1)_over_used_fits'] = OrderedDict(('%d/%d' % k, v) for k, v in sorted(test_class_counts.items()))

    # labels identical within participant
    g = 'A13 labels identical across all conditions, seeds and copies of a participant (deviating copies)'
    label_dev = OrderedDict([('y_test', []), ('y_train', [])])
    for s in people:
        ref = None
        for (fid, origin), cp in copies.items():
            if int(fid[8:10]) != s:
                continue
            if ref is None:
                ref = cp
                continue
            for name in ('y_test', 'y_train'):
                if cp[name].dtype != ref[name].dtype or cp[name].shape != ref[name].shape \
                        or cp[name].tobytes() != ref[name].tobytes():
                    label_dev[name].append('%s [%s]' % (fid, origin))
    cmp_.exact(g, 'test labels', len(label_dev['y_test']), 0, 'brief section A')
    cmp_.exact(g, 'training labels', len(label_dev['y_train']), 0, 'brief section A')
    inv['label_identity_deviations'] = label_dev

    # W0 targets equal the code word of each label (all stored W0 copies), exact
    n_w0_bad = 0
    for (fid, origin), cp in copies.items():
        if cp['condition'] == 'W0':
            if not np.array_equal(cp['Y_last'].astype(np.float64), C[cp['y_train']]):
                n_w0_bad += 1
    cmp_.exact('A11 code words derived from W0 targets', 'W0 copies whose target is not exactly the code word of the label',
               n_w0_bad, 0, 'protocol manipulation_checks (8 differing bits)')

    # ---------------------------------------------------------------- B. per-fit quantities
    per_fit = OrderedDict()       # (s, k, c) -> metrics of the copy used by the analysis
    extra = OrderedDict()
    alts = OrderedDict()
    for key in expected_keys:
        s, k, c = key
        fid = fit_id(s, c, k)
        cp = copies.get((fid, origin_used[key]))
        if cp is None:
            raise RuntimeError('no stored copy for %s (%s)' % (fid, origin_used[key]))
        r, x = compute_fit(c, cp, C, D)
        per_fit[key] = r
        extra[key] = x
        alts[key] = compute_alternatives(c, cp, C, D, r, x)

    used_counts = Counter((c, origin_used[(s, k, c)]) for (s, k, c) in expected_keys)
    g = 'A14 fits per condition used in sections B-D (count)'
    for c in conds:
        cmp_.exact(g, c, sum(v for (cc, o), v in used_counts.items() if cc == c), n_fits_per_cond,
                   'brief (270 = 54 x 5)')
    g = 'A15 trials per fit (count of fits that do not have 100 training / 100 test trials)'
    cmp_.exact(g, 'training trials', sum(1 for r in per_fit.values() if r['n_train'] != n_train_expected), 0, 'protocol design')
    cmp_.exact(g, 'test trials', sum(1 for r in per_fit.values() if r['n_test'] != n_test_expected), 0, 'protocol design')
    inv['fits_used_by_condition_and_origin'] = OrderedDict(('%s:%s' % k, v) for k, v in sorted(used_counts.items()))

    # byte-identical output arrays under different fit ids (a duplicated fit would show up here)
    g = 'A16 byte-identical output arrays under different fit ids among the fits used (surplus copies)'
    for name in ('P_test', 'P_train'):
        seen = Counter()
        for key in expected_keys:
            cp = copies[(fit_id(key[0], key[2], key[1]), origin_used[key])]
            seen[hashlib.sha256(cp[name].tobytes()).hexdigest()] += 1
        cmp_.exact(g, name, sum(v - 1 for v in seen.values() if v > 1), 0, 'brief section A (no duplicate fit)')

    # plausibility of the stored last trained targets against the protocol schedule (last trained phase)
    last_row = sorted(proto['schedule']['rows'], key=lambda r_: r_['phase'])[-1]
    share_pred_cum = 1.0 - float(last_row['label_share_cumulative_and_matched'])
    bound = {'S1': share_pred_cum, 'W1': share_pred_cum, 'W5': share_pred_cum,
             'W4': float(last_row['prediction_share_anchored_W4']), 'W0': 0.0}
    g = 'A17 [plausibility] largest abs(last trained target - label) within the prediction share of the last trained phase (fits above bound + 1e-6)'
    tb = OrderedDict()
    for c in conds:
        if c not in bound:
            continue
        vals = [extra[(s, k, c)]['max_abs_target_minus_label'] for s in people for k in seeds]
        tb[c] = OrderedDict([('bound_from_schedule_phase_%d' % last_row['phase'], bound[c]), ('largest_observed', max(vals)),
                             ('fits_above_bound', sum(1 for v in vals if v > bound[c] + 1e-6))])
        cmp_.exact(g, c, tb[c]['fits_above_bound'], 0, 'protocol schedule, last trained phase')
    inv['last_target_range_check'] = tb

    # identity and gate fields of the records of every stored copy
    g = 'A18 identity and gate fields of the records of all %d stored copies (count of deviating records)' % len(copies)
    recv = OrderedDict((kk, []) for kk in ('fit record identity', 'fit record gate fields', 'test record identity',
                                           'test record gate fields', 'output type named in campaign fit record',
                                           'protocol / bindings / freeze hashes in campaign records'))
    rules_seen = OrderedDict()
    epochs_total = int(proto['design']['phases']) * int(proto['design']['epochs_per_phase'])
    for (fid, origin), cp in copies.items():
        c = cp['condition']
        s_ = int(fid[8:10])
        k_ = int(fid.split('seed')[1])
        tag = '%s [%s]' % (fid, origin)
        rf, rt = cp['rec_train'], cp['rec_test']
        if cp['format'] == 'lee':
            idn = rf.get('identity') or {}
            if not (rf.get('job') == fid and idn.get('subject') == s_ and idn.get('condition') == c and idn.get('seed') == k_):
                recv['fit record identity'].append(tag)
            if not (rf.get('epochs_completed') == epochs_total and rf.get('n_train') == n_train_expected
                    and rf.get('phase_test_metrics_computed') is False):
                recv['fit record gate fields'].append(tag)
            if not (rt.get('n_test') == n_test_expected and rt.get('final_test_evaluations') == 1):
                recv['test record gate fields'].append(tag)
        else:
            rules_seen.setdefault(c, set()).add(str(rf.get('rule')))
            if not (rf.get('fit_id') == fid and rf.get('condition') == c and rf.get('subject') == s_ and rf.get('seed') == k_):
                recv['fit record identity'].append(tag)
            if not (rf.get('epochs_completed') == epochs_total and rf.get('n_train') == n_train_expected
                    and rf.get('terminal_model') is True and rf.get('selection_or_temperature') is False
                    and rf.get('engineering_only') is False and rf.get('campaign_eligible') is True
                    and rf.get('no_test_arrays_accepted') is True and rf.get('phase_test_metrics_computed') is False):
                recv['fit record gate fields'].append(tag)
            if not (rt.get('fit_id') == fid and rt.get('condition') == c and rt.get('subject') == s_ and rt.get('seed') == k_):
                recv['test record identity'].append(tag)
            ev = rt.get('evaluation') or {}
            if not (rt.get('n_test') == n_test_expected and rt.get('final_test_evaluations') == 1 and len(ev) > 0
                    and all(v is True for v in ev.values())):
                recv['test record gate fields'].append(tag)
            if origin == 'campaign':
                ot = str(rf.get('output_type', ''))
                if not ((c[0] == 'S' and ot.startswith('softmax')) or (c[0] == 'W' and ot.startswith('walsh'))):
                    recv['output type named in campaign fit record'].append(tag)
                if not (rf.get('protocol_sha256') == sha_proto and rf.get('source_bindings_sha256') == sha_bind
                        and rt.get('protocol_sha256') == sha_proto and rt.get('source_bindings_sha256') == sha_bind
                        and rt.get('model_freeze_sha256') == sha_freeze):
                    recv['protocol / bindings / freeze hashes in campaign records'].append(tag)
    for kk, v in recv.items():
        cmp_.exact(g, kk, len(v), 0, 'protocol design and gates')
    inv['record_field_deviations'] = recv

    g = 'A19 [records only] one initial model per output type and seed; one input and one label hash per participant; target distance 0 in phases 0-1 (deviations)'
    init_models, inputs, labels_h = OrderedDict(), OrderedDict(), OrderedDict()
    n_sched = 0
    for (fid, origin), cp in copies.items():
        rf = cp['rec_train']
        c = cp['condition']
        dist = rf.get('used_target_dist_by_phase')
        if dist is not None and not (len(dist) == int(proto['design']['phases']) and dist[0] == 0.0 and dist[1] == 0.0):
            n_sched += 1
        if cp['format'] == 'lee':
            continue
        idn = rf.get('identity') or {}
        init_models.setdefault((c[0], int(fid.split('seed')[1])), set()).add(rf.get('initial_model_sha256'))
        inputs.setdefault(int(fid[8:10]), set()).add(idn.get('input_sha256'))
        labels_h.setdefault(int(fid[8:10]), set()).add(idn.get('labels_sha256'))
    cmp_.exact(g, '(output type, seed) pairs with more than one initial model hash',
               sum(1 for v in init_models.values() if len(v) != 1), 0, 'fit records (campaign and archived W4)')
    cmp_.exact(g, '(output type, seed) pairs found', len(init_models), 2 * len(seeds), 'fit records (campaign and archived W4)')
    cmp_.exact(g, 'participants with more than one input hash', sum(1 for v in inputs.values() if len(v) != 1), 0,
               'fit records (campaign and archived W4)')
    cmp_.exact(g, 'participants with more than one label hash', sum(1 for v in labels_h.values() if len(v) != 1), 0,
               'fit records (campaign and archived W4)')
    cmp_.exact(g, 'records whose target distance is not 0 in phases 0 and 1 or that do not list 10 phases', n_sched, 0,
               'fit records (campaign and archived W4)')
    inv['target_rule_named_in_records_by_condition'] = OrderedDict((c, sorted(v)) for c, v in sorted(rules_seen.items()))

    # run_metrics.csv
    for col in METRIC_COLS:
        g = 'B01 run_metrics.csv: ' + col
        for key in expected_keys:
            row = pub_run_by_key.get(key)
            cmp_.num(g, '%d/%d/%s' % key, per_fit[key][col], pfloat(row[col]) if row is not None else None, 'run_metrics.csv')

    # records of the copy that was used
    g_acc = 'B02 test accuracy versus the test record of the same copy (acc_test)'
    g_pred = 'B03 per-trial test decisions versus pred_test in the test record (label)'
    g_ntest = 'B04 n_test in the test record (count)'
    g_post = 'B05 posterior accuracy versus acc_test_post in the test record'
    g_tr = 'B06 training accuracy versus acc_train in the fit record'
    g_nll = 'B07 [informational] NLL versus nll_test in the test record'
    g_ece = 'B08 [informational] ECE versus ece_test in the test record'
    g_bce = 'B09 [informational] bit-wise BCE versus bce_test in the test record'
    g_dist = 'B10 [informational] target displacement versus last_target_dist in the fit record'
    g_wrong = 'B11 [informational] other-class share versus last_target_wrong_frac in the fit record'
    g_nlltr = 'B17 [informational] training NLL (same definition on the training outputs) versus nll_train in the fit record'
    g_pubrec = 'B18 [published versus record] run_metrics.csv target_displacement versus last_target_dist in the fit record'
    against = 'test / fit record of the copy used'
    for key in expected_keys:
        s, k, c = key
        fid = fit_id(s, c, k)
        cp = copies[(fid, origin_used[key])]
        r, x = per_fit[key], extra[key]
        rt, rf = cp['rec_test'], cp['rec_train']
        tag = '%d/%d/%s' % key
        cmp_.num(g_acc, tag, r['accuracy'], rt.get('acc_test'), against)
        pt = rt.get('pred_test')
        if pt is None or len(pt) != r['n_test']:
            cmp_.exact(g_pred, tag + ': length', r['n_test'], None if pt is None else len(pt), against)
        else:
            for i in range(r['n_test']):
                cmp_.exact(g_pred, '%s trial %d' % (tag, i), int(x['pred_test'][i]), int(pt[i]), against)
        cmp_.exact(g_ntest, tag, r['n_test'], rt.get('n_test'), against)
        cmp_.num(g_post, tag, r['posterior_accuracy'], rt.get('acc_test_post'), against)
        cmp_.num(g_tr, tag, r['train_accuracy'], rf.get('acc_train'), against)
        cmp_.num(g_nll, tag, r['nll_clipped'], rt.get('nll_test'), against)
        cmp_.num(g_ece, tag, r['ece15'], rt.get('ece_test'), against)
        cmp_.num(g_bce, tag, r['bce'], rt.get('bce_test'), against)
        cmp_.num(g_dist, tag, r['target_displacement'], rf.get('last_target_dist'), against)
        cmp_.num(g_wrong, tag, r['target_other_class_share'], rf.get('last_target_wrong_frac'), against)
        cmp_.num(g_nlltr, tag, x['nll_train'], rf.get('nll_train'), against)
        row = pub_run_by_key.get(key)
        cmp_.num(g_pubrec, tag, rf.get('last_target_dist'), pfloat(row['target_displacement']) if row is not None else None,
                 'run_metrics.csv (left value: fit record, not a recomputation)')

    # the second (campaign) copy of the sample fits: same quantities, and its own records
    sample_keys = [(s, k, c) for s in sample_subjects for c in ref_conds for k in sample_seeds]
    per_fit_campaign_copy = OrderedDict()
    g1 = 'B12 sample fits: campaign copy versus copy used (all 17 per-fit measures)'
    g2 = 'B13 sample fits, campaign copy: test accuracy versus its own test record (acc_test)'
    g3 = 'B14 sample fits, campaign copy: per-trial test decisions versus its own pred_test (label)'
    if reference_source == 'ARCHIVE':
        for key in sample_keys:
            s, k, c = key
            fid = fit_id(s, c, k)
            cp = copies.get((fid, 'campaign'))
            if cp is None:
                continue
            r2, x2 = compute_fit(c, cp, C, D)
            per_fit_campaign_copy[key] = r2
            tag = '%d/%d/%s' % key
            for col in METRIC_COLS:
                cmp_.num(g1, tag + ':' + col, r2[col], per_fit[key][col], 'own recomputation on the archive copy')
            cmp_.num(g2, tag, r2['accuracy'], cp['rec_test'].get('acc_test'), 'campaign test record')
            pt = cp['rec_test'].get('pred_test') or []
            for i in range(min(len(pt), r2['n_test'])):
                cmp_.exact(g3, '%s trial %d' % (tag, i), int(x2['pred_test'][i]), int(pt[i]), 'campaign test record')

    # fit_timing.csv (records only)
    timing_path = P(STUDY, 'final_analysis/fit_timing.csv')
    if os.path.exists(timing_path):
        g = 'B15 [records only] fit_timing.csv train_seconds versus the fit record of the copy used'
        g_o = 'B16 [records only] fit_timing.csv origin versus origin in run_metrics.csv (label)'
        trows = read_csv(timing_path)
        tby = OrderedDict(((int(r_['subject']), int(r_['seed']), r_['condition']), r_) for r_ in trows)
        cmp_.exact(g_o, 'number of rows', len(trows), len(expected_keys), 'fit_timing.csv')
        for key in expected_keys:
            row = tby.get(key)
            cp = copies[(fit_id(key[0], key[2], key[1]), origin_used[key])]
            cmp_.num(g, '%d/%d/%s' % key, cp['rec_train'].get('train_seconds'),
                     pfloat(row['train_seconds']) if row else None, 'fit_timing.csv')
            cmp_.exact(g_o, '%d/%d/%s' % key, origin_used[key], row['origin'] if row else None, 'fit_timing.csv')

    # ---------------------------------------------------------------- C. participant level
    part = OrderedDict()          # (s, c) -> participant means
    acc_exact = OrderedDict()     # (s, c) -> Fraction
    for c in conds:
        for s in people:
            rows = [per_fit[(s, k, c)] for k in seeds]
            m = OrderedDict((col, mean_or_none([r[col] for r in rows])) for col in METRIC_COLS)
            part[(s, c)] = m
            acc_exact[(s, c)] = Fraction(sum(r['n_correct_test'] for r in rows), sum(r['n_test'] for r in rows))
    pub_part = read_csv(P(STUDY, 'final_analysis/participant_means.csv'))
    pub_part_by = OrderedDict(((int(r['subject']), r['condition']), r) for r in pub_part)
    g = 'C01 participant_means.csv: set of rows (count)'
    cmp_.exact(g, 'number of rows', len(part), len(pub_part), 'participant_means.csv')
    cmp_.exact(g, 'expected keys missing in file', 0, len([k for k in part if k not in pub_part_by]), 'participant_means.csv')
    for col in METRIC_COLS:
        g = 'C02 participant_means.csv: ' + col
        for key in part:
            row = pub_part_by.get(key)
            cmp_.num(g, '%d/%s' % key, part[key][col], pfloat(row[col]) if row is not None else None, 'participant_means.csv')
    g = 'C03 participant accuracy: mean of five seed accuracies versus exact count ratio (own consistency)'
    for key in part:
        cmp_.num(g, '%d/%s' % key, part[key]['accuracy'], float(acc_exact[key]), 'own exact integer arithmetic')

    # participant differences (exact) and the float route as a named alternative
    diffs_exact = OrderedDict()
    diffs_float_route = OrderedDict()
    for name, w in CONTRAST_WEIGHTS.items():
        diffs_exact[name] = OrderedDict()
        diffs_float_route[name] = OrderedDict()
        for s in people:
            diffs_exact[name][s] = 100 * sum((wt * acc_exact[(s, c)] for c, wt in w.items()), Fraction(0))
            diffs_float_route[name][s] = 100.0 * sum(wt * part[(s, c)]['accuracy'] for c, wt in w.items())
    pub_diff = read_csv(P(STUDY, 'final_analysis/participant_differences.csv'))
    pub_diff_by = OrderedDict(((int(r['subject']), r['contrast']), r) for r in pub_diff)
    g = 'C04 participant_differences.csv: accuracy_difference_pp'
    cmp_.exact('C05 participant_differences.csv: set of rows (count)', 'number of rows', len(people) * len(CONTRAST_WEIGHTS),
               len(pub_diff), 'participant_differences.csv')
    cmp_.exact('C05 participant_differences.csv: set of rows (count)', 'expected keys missing in file', 0,
               len([1 for name in CONTRAST_WEIGHTS for s in people if (s, name) not in pub_diff_by]),
               'participant_differences.csv')
    for name in CONTRAST_WEIGHTS:
        for s in people:
            row = pub_diff_by.get((s, name))
            cmp_.num(g, '%d/%s' % (s, name), float(diffs_exact[name][s]),
                     pfloat(row['accuracy_difference_pp']) if row is not None else None, 'participant_differences.csv')

    # condition summaries
    summ = OrderedDict()
    for c in conds:
        d = OrderedDict()
        d['condition'] = c
        d['n_participants'] = len(people)
        d['seeds_per_participant'] = len(seeds)
        origins = sorted(set(origin_used[(s, k, c)] for s in people for k in seeds))
        d['origin'] = origins[0] if len(origins) == 1 else 'mixed'
        for col in METRIC_COLS:
            d[col] = mean_or_none([part[(s, c)][col] for s in people])
        d['accuracy_sd_between_participants'] = sd_n1([part[(s, c)]['accuracy'] for s in people])
        d['accuracy_exact'] = Fraction(sum(per_fit[(s, k, c)]['n_correct_test'] for s in people for k in seeds),
                                       sum(per_fit[(s, k, c)]['n_test'] for s in people for k in seeds))
        d['accuracy_percent'] = 100.0 * float(d['accuracy_exact'])
        d['accuracy_sd_between_participants__divisor_n'] = math.sqrt(
            math.fsum((part[(s, c)]['accuracy'] - d['accuracy']) ** 2 for s in people) / len(people))
        summ[c] = d
    pub_summ = read_csv(P(STUDY, 'final_analysis/condition_summary.csv'))
    pub_summ_by = OrderedDict((r['condition'], r) for r in pub_summ)
    res_summ_by = OrderedDict((r['condition'], r) for r in results.get('summaries', []))
    cmp_.exact('C06 condition_summary.csv: counts and labels', 'number of rows', len(conds), len(pub_summ), 'condition_summary.csv')
    cmp_.exact('C08 RESULTS-V1.0.json summaries: counts and labels', 'number of entries', len(conds),
               len(results.get('summaries', [])), 'RESULTS-V1.0.json summaries')
    for c in conds:
        row = pub_summ_by.get(c)
        rs = res_summ_by.get(c)
        for col in ('n_participants', 'seeds_per_participant'):
            cmp_.exact('C06 condition_summary.csv: counts and labels', c + ':' + col, summ[c][col],
                       int(row[col]) if row is not None else None, 'condition_summary.csv')
            cmp_.exact('C08 RESULTS-V1.0.json summaries: counts and labels', c + ':' + col, summ[c][col],
                       rs.get(col) if rs is not None else None, 'RESULTS-V1.0.json summaries')
        cmp_.exact('C06 condition_summary.csv: counts and labels', c + ':origin', summ[c]['origin'],
                   row['origin'] if row is not None else None, 'condition_summary.csv')
        cmp_.exact('C08 RESULTS-V1.0.json summaries: counts and labels', c + ':origin', summ[c]['origin'],
                   rs.get('origin') if rs is not None else None, 'RESULTS-V1.0.json summaries')
        for col in METRIC_COLS + ['accuracy_sd_between_participants']:
            cmp_.num('C07 condition_summary.csv: 17 measures and between-participant SD', c + ':' + col, summ[c][col],
                     pfloat(row[col]) if row is not None else None, 'condition_summary.csv')
            cmp_.num('C09 RESULTS-V1.0.json summaries: 17 measures and between-participant SD', c + ':' + col, summ[c][col],
                     rs.get(col) if rs is not None else None, 'RESULTS-V1.0.json summaries')

    # ---------------------------------------------------------------- D. contrasts
    contrasts = OrderedDict()
    for name, w in CONTRAST_WEIGHTS.items():
        dx = [diffs_exact[name][s] for s in people]
        d = [float(v) for v in dx]
        st = paired_summary(d)
        st['contrast'] = name
        st['participants_positive'] = sum(1 for v in dx if v > 0)
        st['participants_negative'] = sum(1 for v in dx if v < 0)
        st['participants_tied'] = sum(1 for v in dx if v == 0)
        own = wilcoxon_own(dx)
        nz = [v for v in d if v != 0.0]
        try:
            sc = sps.wilcoxon(np.array(d, dtype=np.float64), zero_method='wilcox', correction=False,
                              alternative='two-sided', method='approx')
            own['scipy_statistic'] = float(sc.statistic)
            own['scipy_p_two_sided'] = float(sc.pvalue)
        except Exception as exc:        # pragma: no cover
            own['scipy_statistic'] = None
            own['scipy_p_two_sided'] = None
            own['scipy_error'] = repr(exc)
        own['n_nonzero_float'] = len(nz)
        st['wilcoxon_sensitivity'] = own
        tt = sps.ttest_1samp(np.array(d, dtype=np.float64), 0.0)
        st['scipy_ttest_1samp'] = OrderedDict([('t', float(tt.statistic)), ('p', float(tt.pvalue))])
        # the six other measures, descriptive
        st['descriptive_other_measures'] = OrderedDict()
        for m in OTHER_MEASURES:
            dm = [sum(wt * part[(s, c)][m] for c, wt in w.items()) for s in people]
            sm = paired_summary(dm)
            st['descriptive_other_measures'][m] = OrderedDict([('mean_difference', sm['mean_difference']),
                                                               ('pointwise_95ci', sm['pointwise_95ci'])])
        # float route (named alternative): differences of the float participant means
        df_ = [diffs_float_route[name][s] for s in people]
        alt = OrderedDict()
        alt['participants_positive'] = sum(1 for v in df_ if v > 0)
        alt['participants_negative'] = sum(1 for v in df_ if v < 0)
        alt['participants_tied'] = sum(1 for v in df_ if v == 0)
        alt['max_abs_difference_to_exact_pp'] = max(abs(a - float(b)) for a, b in zip(df_, dx))
        try:
            sc2 = sps.wilcoxon(np.array(df_, dtype=np.float64), zero_method='wilcox', correction=False,
                               alternative='two-sided', method='approx')
            alt['wilcoxon_statistic'] = float(sc2.statistic)
            alt['wilcoxon_p_two_sided'] = float(sc2.pvalue)
        except Exception as exc:        # pragma: no cover
            alt['wilcoxon_error'] = repr(exc)
        st['alternative_float_route'] = alt
        contrasts[name] = st
    ph = holm([contrasts[n]['p_unadjusted'] for n in CONTRAST_WEIGHTS])
    for name, p_adj in zip(CONTRAST_WEIGHTS, ph):
        contrasts[name]['p_holm_four'] = p_adj
        contrasts[name]['significant_after_holm_0_05'] = bool(p_adj < 0.05)

    # named alternative reading of "nearest code word": Hamming distance after thresholding the 16 outputs at 0.5
    alt_acc = OrderedDict()
    for c in conds:
        for s in people:
            num, den = 0, 0
            for k in seeds:
                key = (s, k, c)
                if c[0] == 'W':
                    num += int(round(alts[key]['accuracy__hamming_after_threshold'] * per_fit[key]['n_test']))
                else:
                    num += per_fit[key]['n_correct_test']
                den += per_fit[key]['n_test']
            alt_acc[(s, c)] = Fraction(num, den)
    alt_contrasts = OrderedDict()
    for name, w in CONTRAST_WEIGHTS.items():
        dx = [100 * sum((wt * alt_acc[(s, c)] for c, wt in w.items()), Fraction(0)) for s in people]
        st = paired_summary([float(v) for v in dx])
        wl = wilcoxon_own(dx)
        alt_contrasts[name] = OrderedDict([
            ('mean_difference', st['mean_difference']), ('pointwise_95ci', st['pointwise_95ci']), ('t', st['t']),
            ('p_unadjusted', st['p_unadjusted']), ('participants_positive', sum(1 for v in dx if v > 0)),
            ('participants_negative', sum(1 for v in dx if v < 0)), ('participants_tied', sum(1 for v in dx if v == 0)),
            ('wilcoxon_p_two_sided', wl['p_two_sided'])])
    for name, p_adj in zip(CONTRAST_WEIGHTS, holm([alt_contrasts[n]['p_unadjusted'] for n in CONTRAST_WEIGHTS])):
        alt_contrasts[name]['p_holm_four'] = p_adj
    alt_condition_accuracy = OrderedDict(
        (c, 100.0 * float(sum((alt_acc[(s, c)] for s in people), Fraction(0)) / len(people))) for c in conds)

    def compare_contrasts(pub_list, label, prefix):
        pub_by = OrderedDict((e.get('contrast'), e) for e in pub_list)
        gn = '%s %s: statistics of the four contrasts' % (prefix, label)
        gc = '%s %s: counts, df, n, labels' % (prefix[:-1] + chr(ord(prefix[-1]) + 1), label)
        go = '%s %s: descriptive other measures (mean difference, interval)' % (prefix[:-1] + chr(ord(prefix[-1]) + 2), label)
        cmp_.exact(gc, 'number of contrasts', len(CONTRAST_WEIGHTS), len(pub_list), label)
        cmp_.exact(gc, 'order of contrasts', list(CONTRAST_WEIGHTS.keys()), [e.get('contrast') for e in pub_list], label)
        for name in CONTRAST_WEIGHTS:
            mine, pub = contrasts[name], pub_by.get(name)
            if pub is None:
                cmp_.exact(gc, name + ': present', True, False, label)
                continue
            ci = pub.get('pointwise_95ci') or [None, None]
            wl = pub.get('wilcoxon_sensitivity') or {}
            cmp_.num(gn, name + ': mean_difference', mine['mean_difference'], pub.get('mean_difference'), label)
            cmp_.num(gn, name + ': pointwise_95ci low', mine['pointwise_95ci'][0], ci[0], label)
            cmp_.num(gn, name + ': pointwise_95ci high', mine['pointwise_95ci'][1], ci[1], label)
            cmp_.num(gn, name + ': sd_difference', mine['sd_difference'], pub.get('sd_difference'), label)
            cmp_.num(gn, name + ': t', mine['t'], pub.get('t'), label)
            cmp_.num(gn, name + ': p_unadjusted', mine['p_unadjusted'], pub.get('p_unadjusted'), label)
            cmp_.num(gn, name + ': d_z', mine['d_z'], pub.get('d_z'), label)
            cmp_.num(gn, name + ': p_holm_four', mine['p_holm_four'], pub.get('p_holm_four'), label)
            cmp_.num(gn, name + ': wilcoxon statistic', mine['wilcoxon_sensitivity']['statistic'], wl.get('statistic'), label)
            cmp_.num(gn, name + ': wilcoxon p_two_sided', mine['wilcoxon_sensitivity']['p_two_sided'], wl.get('p_two_sided'), label)
            cmp_.exact(gc, name + ': df', mine['df'], pub.get('df'), label)
            cmp_.exact(gc, name + ': n', mine['n'], pub.get('n'), label)
            cmp_.exact(gc, name + ': participants_positive', mine['participants_positive'], pub.get('participants_positive'), label)
            cmp_.exact(gc, name + ': participants_negative', mine['participants_negative'], pub.get('participants_negative'), label)
            cmp_.exact(gc, name + ': participants_tied', mine['participants_tied'], pub.get('participants_tied'), label)
            cmp_.exact(gc, name + ': wilcoxon n_nonzero', mine['wilcoxon_sensitivity']['n_nonzero'], wl.get('n_nonzero'), label)
            cmp_.exact(gc, name + ': significant_after_holm_0_05', mine['significant_after_holm_0_05'],
                       pub.get('significant_after_holm_0_05'), label)
            po = pub.get('descriptive_other_measures') or {}
            cmp_.exact(gc, name + ': set of other measures', sorted(OTHER_MEASURES), sorted(po.keys()), label)
            for m in OTHER_MEASURES:
                pm_ = po.get(m) or {}
                pci = pm_.get('pointwise_95ci') or [None, None]
                mm = mine['descriptive_other_measures'][m]
                cmp_.num(go, '%s: %s mean_difference' % (name, m), mm['mean_difference'], pm_.get('mean_difference'), label)
                cmp_.num(go, '%s: %s interval low' % (name, m), mm['pointwise_95ci'][0], pci[0], label)
                cmp_.num(go, '%s: %s interval high' % (name, m), mm['pointwise_95ci'][1], pci[1], label)

    compare_contrasts(pub_contrasts, 'four_contrasts_holm.json', 'D01')
    compare_contrasts(results.get('contrasts', []), 'RESULTS-V1.0.json contrasts', 'D04')
    g = 'D07 own Wilcoxon implementation versus scipy.stats.wilcoxon on the same differences (own consistency)'
    g2 = 'D08 own t test versus scipy.stats.ttest_1samp (own consistency)'
    for name in CONTRAST_WEIGHTS:
        w_ = contrasts[name]['wilcoxon_sensitivity']
        cmp_.num(g, name + ': statistic', w_['statistic'], w_['scipy_statistic'], 'scipy 1.15.3 on own differences')
        cmp_.num(g, name + ': p', w_['p_two_sided'], w_['scipy_p_two_sided'], 'scipy 1.15.3 on own differences')
        cmp_.num(g2, name + ': t', contrasts[name]['t'], contrasts[name]['scipy_ttest_1samp']['t'], 'scipy 1.15.3 on own differences')
        cmp_.num(g2, name + ': p', contrasts[name]['p_unadjusted'], contrasts[name]['scipy_ttest_1samp']['p'],
                 'scipy 1.15.3 on own differences')

    # identities
    identities = OrderedDict()
    g = 'D09 identities 1+2 = W1-W0 and 3+4 = W1-W4: sums of the published differences and means versus own W1-W0 and W1-W4'
    for label, a, b, w in (('W1-W0', 'S1-S0', '(W1-W0)-(S1-S0)', OrderedDict([('W1', 1), ('W0', -1)])),
                           ('W1-W4', 'W1-W5', 'W5-W4', OrderedDict([('W1', 1), ('W4', -1)]))):
        direct = OrderedDict((s, 100 * sum((wt * acc_exact[(s, c)] for c, wt in w.items()), Fraction(0))) for s in people)
        own_sum_ok = all(diffs_exact[a][s] + diffs_exact[b][s] == direct[s] for s in people)
        for s in people:
            ra, rb = pub_diff_by.get((s, a)), pub_diff_by.get((s, b))
            pub_sum = (pfloat(ra['accuracy_difference_pp']) + pfloat(rb['accuracy_difference_pp'])) \
                if ra is not None and rb is not None else None
            cmp_.num(g, '%s participant %d' % (label, s), float(direct[s]), pub_sum, 'participant_differences.csv')
        st = paired_summary([float(direct[s]) for s in people])
        pub_by = OrderedDict((e.get('contrast'), e) for e in pub_contrasts)
        pub_mean_sum = (pub_by[a]['mean_difference'] + pub_by[b]['mean_difference']) if a in pub_by and b in pub_by else None
        cmp_.num(g, '%s mean (sum of the two published mean differences)' % label, st['mean_difference'], pub_mean_sum,
                 'four_contrasts_holm.json')
        identities[label] = OrderedDict([
            ('sum_of', [a, b]), ('own_exact_identity_holds_for_every_participant', bool(own_sum_ok)),
            ('mean_difference_pp', st['mean_difference']), ('sd_difference', st['sd_difference']),
            ('pointwise_95ci', st['pointwise_95ci']), ('t', st['t']), ('df', st['df']), ('p_unadjusted', st['p_unadjusted']),
            ('own_sum_of_the_two_contrast_means', contrasts[a]['mean_difference'] + contrasts[b]['mean_difference'])])
    cmp_.exact('D10 identities hold exactly in own integer arithmetic (label)', 'W1-W0',
               identities['W1-W0']['own_exact_identity_holds_for_every_participant'], True, 'algebra')
    cmp_.exact('D10 identities hold exactly in own integer arithmetic (label)', 'W1-W4',
               identities['W1-W4']['own_exact_identity_holds_for_every_participant'], True, 'algebra')

    # internal consistency of the two published contrast files
    g = 'D11 published files agree with each other (RESULTS contrasts = four_contrasts_holm.json; RESULTS summaries = condition_summary.csv)'
    cmp_.exact(g, 'contrasts: deep equality', True, results.get('contrasts') == pub_contrasts, 'published files')
    same_summ = True
    for c in conds:
        row, rs = pub_summ_by.get(c), res_summ_by.get(c)
        if row is None or rs is None:
            same_summ = False
            continue
        for col in METRIC_COLS + ['accuracy_sd_between_participants']:
            a_, b_ = pfloat(row[col]), rs.get(col)
            if isblank(a_) != isblank(b_) or (not isblank(a_) and a_ != b_):
                same_summ = False
    cmp_.exact(g, 'summaries: every value identical', True, same_summ, 'published files')

    # ---------------------------------------------------------------- E. linkage and W1 versus W5 targets
    link = OrderedDict()
    pub_link = read_csv(P(STUDY, 'final_analysis/W5_W4_first_update_linkage.csv'))
    pub_link_by = OrderedDict(((int(r['subject']), int(r['seed'])), r) for r in pub_link)
    g_n = 'E01 [records only] W5_W4_first_update_linkage.csv: the two third-phase target distances versus the fit records'
    g_l = 'E02 [records only] W5_W4_first_update_linkage.csv: rows and identical flag (count / label)'
    g_r = 'E03 [records only] REPRODUCTION_TRAIN linkage: the two distances versus the fit records'
    g_rl = 'E04 [records only] REPRODUCTION_TRAIN linkage: entries and identical flag (count / label)'
    cmp_.exact(g_l, 'number of rows', len(people) * len(seeds), len(pub_link), 'W5_W4_first_update_linkage.csv')
    cmp_.exact(g_rl, 'number of entries', len(people) * len(seeds), len(rep_train.get('linkage', {})), 'REPRODUCTION_TRAIN-V1.0.json')
    n_identical = 0
    for s in people:
        for k in seeds:
            w5 = copies[(fit_id(s, 'W5', k), 'campaign')]['rec_train']
            w4 = copies[(fit_id(s, 'W4', k), 'archive')]['rec_train']
            a = w5['used_target_dist_by_phase'][2]
            b = w4['used_target_dist_by_phase'][2]
            ident = bool(a == b)
            n_identical += int(ident)
            link[(s, k)] = OrderedDict([('W5_phase2_target_distance_in_W5_fit_record', a),
                                        ('archived_W4_phase2_target_distance_in_archived_fit_record', b),
                                        ('identical', ident)])
            row = pub_link_by.get((s, k))
            tag = '%d/%d' % (s, k)
            cmp_.num(g_n, tag + ': W5', a, pfloat(row['W5_phase2_target_distance']) if row else None, 'W5_W4_first_update_linkage.csv')
            cmp_.num(g_n, tag + ': archived W4', b, pfloat(row['archived_W4_phase2_target_distance']) if row else None,
                     'W5_W4_first_update_linkage.csv')
            cmp_.exact(g_l, tag + ': identical', ident,
                       {'True': True, 'False': False}.get(row['identical_to_archived_W4']) if row else None,
                       'W5_W4_first_update_linkage.csv')
            e = rep_train.get('linkage', {}).get(fit_id(s, 'W5', k))
            cmp_.num(g_r, tag + ': W5', a, e.get('W5_phase2_target_distance') if e else None, 'REPRODUCTION_TRAIN-V1.0.json')
            cmp_.num(g_r, tag + ': archived W4', b, e.get('archived_W4_phase2_target_distance') if e else None,
                     'REPRODUCTION_TRAIN-V1.0.json')
            cmp_.exact(g_rl, tag + ': identical', ident, e.get('identical') if e else None, 'REPRODUCTION_TRAIN-V1.0.json')
    rl = (results.get('reproduction') or {}).get('W5_W4_first_update_linkage') or {}
    g = 'E05 [records only] RESULTS reproduction.W5_W4_first_update_linkage and decision-file linkage counts (count)'
    cmp_.exact(g, 'RESULTS pairs', len(link), rl.get('pairs'), 'RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json')
    cmp_.exact(g, 'RESULTS identical_to_archived_W4', n_identical, rl.get('identical_to_archived_W4'),
               'RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json')
    cmp_.exact(g, 'RESULTS identical_to_campaign_W4 (not applicable under ARCHIVE)', None, rl.get('identical_to_campaign_W4'),
               'RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json')
    cmp_.exact(g, 'REPRODUCTION_TRAIN linkage_pairs', len(link), rep_train.get('linkage_pairs'),
               'RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json')
    cmp_.exact(g, 'REPRODUCTION_TRAIN linkage_mismatched_fits',
               sorted(fit_id(s, 'W5', k) for (s, k), v in link.items() if not v['identical']),
               sorted(rep_train.get('linkage_mismatched_fits', [])), 'RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json')

    # what the stored arrays do allow: the last trained phase (phase index 9)
    g = 'E06 [records only] last entry of used_target_dist_by_phase versus last_target_dist in the same fit record'
    for (fid, origin), cp in copies.items():
        rf = cp['rec_train']
        if rf.get('used_target_dist_by_phase') is not None and rf.get('last_target_dist') is not None:
            cmp_.num(g, '%s [%s]' % (fid, origin), rf['used_target_dist_by_phase'][-1], rf['last_target_dist'], 'fit records')
    # campaign sample W4 refits: third-phase distance versus archived W4 and versus W5 (18 pairs)
    g = 'E07 [records only] third-phase target distance of the 18 campaign W4 sample refits versus archived W4 and versus W5 (label)'
    if reference_source == 'ARCHIVE':
        for s in sample_subjects:
            for k in sample_seeds:
                cw4 = copies.get((fit_id(s, 'W4', k), 'campaign'))
                if cw4 is None:
                    continue
                v = cw4['rec_train']['used_target_dist_by_phase'][2]
                cmp_.exact(g, '%d/%d: campaign W4 = archived W4' % (s, k), v,
                           link[(s, k)]['archived_W4_phase2_target_distance_in_archived_fit_record'], 'fit records')
                cmp_.exact(g, '%d/%d: campaign W4 = campaign W5' % (s, k), v,
                           link[(s, k)]['W5_phase2_target_distance_in_W5_fit_record'], 'fit records')

    # W1 versus W5 last trained targets (from arrays)
    w1w5 = OrderedDict()
    pub_tw = read_csv(P(STUDY, 'final_analysis/W1_W5_last_target_difference.csv'))
    pub_tw_by = OrderedDict(((int(r['subject']), int(r['seed'])), r) for r in pub_tw)
    g = 'E08 W1_W5_last_target_difference.csv: three measures per participant and seed'
    cmp_.exact('E09 W1_W5_last_target_difference.csv: rows (count)', 'number of rows', len(people) * len(seeds), len(pub_tw),
               'W1_W5_last_target_difference.csv')
    n_label_mismatch = 0
    for s in people:
        for k in seeds:
            a = copies[(fit_id(s, 'W1', k), origin_used[(s, k, 'W1')])]
            b = copies[(fit_id(s, 'W5', k), origin_used[(s, k, 'W5')])]
            if a['y_train'].tobytes() != b['y_train'].tobytes():
                n_label_mismatch += 1
            dT = a['Y_last'].astype(np.float64) - b['Y_last'].astype(np.float64)
            e = OrderedDict([
                ('W1_W5_mean_abs_difference_per_output', float(np.mean(np.abs(dT)))),
                ('W1_W5_mean_abs_difference_differing_bits', float(np.mean(np.abs(dT[:, D])))),
                ('W1_W5_mean_euclidean_distance', float(np.mean(np.sqrt(np.sum(dT ** 2, axis=1))))),
                ('alternative__root_mean_square_distance', float(np.sqrt(np.mean(np.sum(dT ** 2, axis=1)))))])
            w1w5[(s, k)] = e
            row = pub_tw_by.get((s, k))
            for col in ('W1_W5_mean_abs_difference_per_output', 'W1_W5_mean_abs_difference_differing_bits',
                        'W1_W5_mean_euclidean_distance'):
                cmp_.num(g, '%d/%d: %s' % (s, k, col), e[col], pfloat(row[col]) if row else None,
                         'W1_W5_last_target_difference.csv')
    cmp_.exact('E09 W1_W5_last_target_difference.csv: rows (count)', 'pairs with different training label order', n_label_mismatch, 0,
               'W1_W5_last_target_difference.csv')
    w1w5_overall = OrderedDict([
        ('pairs', len(w1w5)),
        ('mean_abs_difference_per_output', fmean([v['W1_W5_mean_abs_difference_per_output'] for v in w1w5.values()])),
        ('mean_abs_difference_differing_bits', fmean([v['W1_W5_mean_abs_difference_differing_bits'] for v in w1w5.values()])),
        ('mean_euclidean_distance', fmean([v['W1_W5_mean_euclidean_distance'] for v in w1w5.values()]))])
    rw = results.get('W1_W5_last_target_difference') or {}
    g = 'E10 RESULTS W1_W5_last_target_difference: means over the 270 pairs'
    cmp_.exact('E11 RESULTS W1_W5_last_target_difference: pairs (count)', 'pairs', w1w5_overall['pairs'], rw.get('pairs'),
               'RESULTS-V1.0.json')
    for col in ('mean_abs_difference_per_output', 'mean_abs_difference_differing_bits', 'mean_euclidean_distance'):
        cmp_.num(g, col, w1w5_overall[col], rw.get(col), 'RESULTS-V1.0.json')

    # ---------------------------------------------------------------- F. reproduction checks
    def same_bytes(a, b):
        return (a is not None and b is not None and a.dtype == b.dtype and a.shape == b.shape
                and a.tobytes() == b.tobytes())

    repro = OrderedDict()
    if reference_source == 'ARCHIVE':
        g_tr = 'F01 REPRODUCTION_TRAIN details: equality flags per sample fit versus own byte comparison (label)'
        g_mx = 'F02 REPRODUCTION_TRAIN details: max_abs_difference_P_train versus own value'
        g_te = 'F03 REPRODUCTION_TEST details: flag per sample fit versus own byte comparison (label)'
        g_ct = 'F04 reproduction counts, mismatch lists and statuses in decision files and RESULTS (count / label)'
        my_train_mismatch, my_test_mismatch = [], []
        for fid in sample_ids:
            c = fid.split('__')[1]
            s = int(fid[8:10])
            a = copies.get((fid, 'campaign'))
            b = copies.get((fid, 'archive'))
            e = OrderedDict()
            if a is None or b is None:
                e['both_copies_present'] = False
                repro[fid] = e
                my_train_mismatch.append(fid)
                my_test_mismatch.append(fid)
                continue
            e['P_train_equal'] = same_bytes(a['P_train'], b['P_train'])
            e['labels_equal'] = same_bytes(a['y_train'], b['y_train'])
            if c != 'S0':
                e['Y_used_last_equal'] = same_bytes(a['Y_last'], b['Y_last'])
            if b['normalization_mean'] is not None:
                pre = load_json(P(STUDY, 'data/preprocessors', 'subject_%02d.json' % s))
                nm = np.array(pre['mean'], dtype=np.float64)
                ns = np.array(pre['sd'], dtype=np.float64)
                e['normalizer_equal'] = bool(same_bytes(nm, b['normalization_mean']) and same_bytes(ns, b['normalization_sd']))
                e['normalizer_max_abs_difference'] = float(max(
                    np.max(np.abs(nm - b['normalization_mean'])) if nm.shape == b['normalization_mean'].shape else np.inf,
                    np.max(np.abs(ns - b['normalization_sd'])) if ns.shape == b['normalization_sd'].shape else np.inf))
            e['all_equal'] = bool(all(v for kk, v in e.items() if kk.endswith('_equal')))
            e['max_abs_difference_P_train'] = float(np.max(np.abs(
                a['P_train'].astype(np.float64) - b['P_train'].astype(np.float64)))) \
                if a['P_train'].shape == b['P_train'].shape else None
            e['P_test_equal'] = same_bytes(a['P_test'], b['P_test'])
            e['y_test_equal'] = same_bytes(a['y_test'], b['y_test'])
            e['test_side_equal'] = bool(e['P_test_equal'] and e['y_test_equal'])
            e['max_abs_difference_P_test'] = float(np.max(np.abs(
                a['P_test'].astype(np.float64) - b['P_test'].astype(np.float64)))) \
                if a['P_test'].shape == b['P_test'].shape else None
            if b['format'] == 'w4':
                f = archive[fid]['files']
                e['fit_outputs_file_sha256_equal'] = bool(
                    sha256_file(os.path.join(camp, 'fit_outputs', fid + '.npz')) == sha256_file(P(f['fit_outputs']['path'])))
                e['prediction_file_sha256_equal'] = bool(
                    sha256_file(os.path.join(camp, 'predictions', fid + '_day2.npz')) == sha256_file(P(f['prediction']['path'])))
            # records of both copies (informational)
            ra, rb = a['rec_train'], b['rec_train']
            ta, tb = a['rec_test'], b['rec_test']
            e['records_equal'] = OrderedDict([
                ('acc_train', ra.get('acc_train') == rb.get('acc_train')),
                ('nll_train', ra.get('nll_train') == rb.get('nll_train')),
                ('used_target_dist_by_phase', ra.get('used_target_dist_by_phase') == rb.get('used_target_dist_by_phase')),
                ('last_target_dist', ra.get('last_target_dist') == rb.get('last_target_dist')),
                ('acc_test', ta.get('acc_test') == tb.get('acc_test')),
                ('nll_test', ta.get('nll_test') == tb.get('nll_test')),
                ('ece_test', ta.get('ece_test') == tb.get('ece_test')),
                ('bce_test', ta.get('bce_test') == tb.get('bce_test')),
                ('pred_test', ta.get('pred_test') == tb.get('pred_test'))])
            repro[fid] = e
            if not e['all_equal']:
                my_train_mismatch.append(fid)
            if not e['test_side_equal']:
                my_test_mismatch.append(fid)
            pd_ = rep_train.get('details', {}).get(fid)
            if pd_ is None:
                cmp_.exact(g_tr, fid + ': present in decision file', True, False, 'REPRODUCTION_TRAIN-V1.0.json')
            else:
                mine_flags = OrderedDict((kk, v) for kk, v in e.items()
                                         if kk in ('P_train_equal', 'labels_equal', 'Y_used_last_equal', 'normalizer_equal', 'all_equal'))
                cmp_.exact(g_tr, fid + ': set of flags', sorted(mine_flags.keys()),
                           sorted(kk for kk in pd_ if kk != 'max_abs_difference_P_train'), 'REPRODUCTION_TRAIN-V1.0.json')
                for kk, v in mine_flags.items():
                    cmp_.exact(g_tr, fid + ': ' + kk, v, pd_.get(kk), 'REPRODUCTION_TRAIN-V1.0.json')
                cmp_.num(g_mx, fid, e['max_abs_difference_P_train'], pd_.get('max_abs_difference_P_train'),
                         'REPRODUCTION_TRAIN-V1.0.json')
            cmp_.exact(g_te, fid, e['test_side_equal'], rep_test.get('details', {}).get(fid), 'REPRODUCTION_TEST-V1.0.json')
        cmp_.exact(g_ct, 'REPRODUCTION_TRAIN compared_fits', len(sample_ids), rep_train.get('compared_fits'), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TRAIN details entries', len(sample_ids), len(rep_train.get('details', {})), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TRAIN mismatched_fits', sorted(my_train_mismatch), sorted(rep_train.get('mismatched_fits', [])),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TRAIN status says PASS', len(my_train_mismatch) == 0 and n_identical == len(link),
                   str(rep_train.get('status', '')).startswith('PASS'), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TRAIN sample (subjects, seeds, conditions)',
                   [sample_subjects, sample_seeds, sorted(ref_conds)],
                   [rep_train.get('sample', {}).get('subjects'), rep_train.get('sample', {}).get('seeds'),
                    sorted(rep_train.get('sample', {}).get('conditions', []))], 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TEST compared_fits', len(sample_ids), rep_test.get('compared_fits'), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TEST details entries', len(sample_ids), len(rep_test.get('details', {})), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TEST mismatched_fits', sorted(my_test_mismatch), sorted(rep_test.get('mismatched_fits', [])),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'REPRODUCTION_TEST status says PASS', len(my_test_mismatch) == 0,
                   str(rep_test.get('status', '')).startswith('PASS'), 'decision files / RESULTS')
        rr = results.get('reproduction') or {}
        cmp_.exact(g_ct, 'RESULTS training_side compared_fits', len(sample_ids), (rr.get('training_side') or {}).get('compared_fits'),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS training_side mismatched_fits', sorted(my_train_mismatch),
                   sorted((rr.get('training_side') or {}).get('mismatched_fits', [])), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS training_side status', rep_train.get('status'), (rr.get('training_side') or {}).get('status'),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS test_side compared_fits', len(sample_ids), (rr.get('test_side') or {}).get('compared_fits'),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS test_side mismatched_fits', sorted(my_test_mismatch),
                   sorted((rr.get('test_side') or {}).get('mismatched_fits', [])), 'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS test_side status', rep_test.get('status'), (rr.get('test_side') or {}).get('status'),
                   'decision files / RESULTS')
        cmp_.exact(g_ct, 'RESULTS reference_refit_versus_archive is empty under ARCHIVE', 0,
                   len(results.get('reference_refit_versus_archive', [])), 'decision files / RESULTS')
        g = 'F06 [informational] normaliser of every participant (data/preprocessors) versus the normalisation arrays of every archived S0/W0/W1 fit (bytes)'
        pre_cache = {}
        for (fid, origin), cp in copies.items():
            if origin != 'archive' or cp['normalization_mean'] is None:
                continue
            s_ = int(fid[8:10])
            if s_ not in pre_cache:
                pre = load_json(P(STUDY, 'data/preprocessors', 'subject_%02d.json' % s_))
                pre_cache[s_] = (np.array(pre['mean'], dtype=np.float64), np.array(pre['sd'], dtype=np.float64))
            cmp_.exact(g, fid, bool(same_bytes(pre_cache[s_][0], cp['normalization_mean'])
                                    and same_bytes(pre_cache[s_][1], cp['normalization_sd'])), True,
                       'archived fits (lee format)')
        g = 'F05 [informational] sample fits: records of the campaign copy equal the archived records (9 fields, label)'
        for fid in sample_ids:
            for kk, v in (repro.get(fid, {}).get('records_equal') or {}).items():
                cmp_.exact(g, fid + ': ' + kk, bool(v), True, 'campaign and archive records')
        R_repro_summary = OrderedDict([
            ('sample_fits', len(sample_ids)),
            ('training_side_all_equal', sum(1 for e in repro.values() if e.get('all_equal'))),
            ('test_side_equal', sum(1 for e in repro.values() if e.get('test_side_equal'))),
            ('training_side_mismatched_fits', my_train_mismatch), ('test_side_mismatched_fits', my_test_mismatch),
            ('max_abs_difference_P_train_over_sample', max([e.get('max_abs_difference_P_train') or 0.0 for e in repro.values()])),
            ('max_abs_difference_P_test_over_sample', max([e.get('max_abs_difference_P_test') or 0.0 for e in repro.values()])),
            ('normalizer_compared_fits', sum(1 for e in repro.values() if 'normalizer_equal' in e)),
            ('normalizer_equal_fits', sum(1 for e in repro.values() if e.get('normalizer_equal'))),
            ('W4_npz_files_identical_by_sha256', sum(1 for e in repro.values()
                                                    if e.get('fit_outputs_file_sha256_equal') and e.get('prediction_file_sha256_equal')))])
    else:
        R_repro_summary = OrderedDict([('note', 'reference source is REFIT: refit-versus-archive table not implemented in this run')])
        notes.append('reference source is not ARCHIVE: section F (REFIT branch) was not computed')

    # RESULTS counts
    g = 'G01 RESULTS-V1.0.json counts (count)'
    rc = results.get('counts') or {}
    my_counts = OrderedDict([
        ('campaign_fits', len(expected_campaign)),
        ('new_fits', len(new_conds) * n_fits_per_cond),
        ('reference_fits_from_archive', sum(1 for kk in expected_keys if kk[2] in ref_conds and origin_used[kk] == 'archive')),
        ('reference_fits_from_campaign', sum(1 for kk in expected_keys if kk[2] in ref_conds and origin_used[kk] == 'campaign')),
        ('reproduction_sample_fits', len(sample_ids)), ('participants', len(people)), ('seeds', len(seeds))])
    for kk, v in my_counts.items():
        cmp_.exact(g, kk, v, rc.get(kk), 'RESULTS-V1.0.json counts')
    cmp_.exact('G03 RESULTS-V1.0.json engineering_fixture_only is false (label)', 'engineering_fixture_only', False,
               results.get('engineering_fixture_only'), 'RESULTS-V1.0.json')
    g = 'G02 [informational] software versions named in RESULTS versus this run (label)'
    cmp_.exact(g, 'numpy', np.__version__, (results.get('software') or {}).get('numpy'), 'RESULTS-V1.0.json software')
    cmp_.exact(g, 'scipy', scipy.__version__, (results.get('software') or {}).get('scipy'), 'RESULTS-V1.0.json software')

    # ---------------------------------------------------------------- alternative readings (summary)
    alt_names = sorted(set(n for a in alts.values() for n in a))
    alt_summary = OrderedDict()
    for an in alt_names:
        base = an.split('__')[0]
        e = OrderedDict()
        e['primary_column'] = base
        n_diff = 0
        mx = 0.0
        n_match_pub_primary = 0
        n_match_pub_alt = 0
        n_total = 0
        for key in expected_keys:
            if an not in alts[key]:
                continue
            n_total += 1
            av, pv = alts[key][an], per_fit[key][base]
            d = abs(av - pv)
            mx = max(mx, d)
            if d > TOL:
                n_diff += 1
            row = pub_run_by_key.get(key)
            pubv = pfloat(row[base]) if row is not None else None
            if pubv is not None:
                if abs(pv - pubv) <= TOL:
                    n_match_pub_primary += 1
                if abs(av - pubv) <= TOL:
                    n_match_pub_alt += 1
        e['fits_with_this_alternative'] = n_total
        e['fits_where_alternative_differs_from_primary_by_more_than_tolerance'] = n_diff
        e['largest_abs_difference_alternative_minus_primary'] = mx
        e['fits_where_published_equals_primary_within_tolerance'] = n_match_pub_primary
        e['fits_where_published_equals_alternative_within_tolerance'] = n_match_pub_alt
        e['condition_means_primary'] = OrderedDict()
        e['condition_means_alternative'] = OrderedDict()
        for c in conds:
            keys_c = [(s, k, c) for s in people for k in seeds if an in alts[(s, k, c)]]
            if keys_c:
                e['condition_means_primary'][c] = fmean(
                    [fmean([per_fit[(s, k, c)][base] for k in seeds]) for s in people])
                e['condition_means_alternative'][c] = fmean(
                    [fmean([alts[(s, k, c)][an] for k in seeds]) for s in people])
        alt_summary[an] = e

    diag = OrderedDict()
    diag['softmax_fits_with_equal_probabilities_test'] = sum(x.get('n_probability_ties_test', 0) for x in extra.values())
    diag['softmax_fits_with_equal_probabilities_train'] = sum(x.get('n_probability_ties_train', 0) for x in extra.values())
    diag['walsh_trials_with_equal_distances_test'] = sum(x.get('n_distance_ties_test', 0) for x in extra.values())
    diag['walsh_trials_with_equal_distances_train'] = sum(x.get('n_distance_ties_train', 0) for x in extra.values())
    diag['walsh_trials_with_equal_posteriors_test'] = sum(x.get('n_posterior_ties_test', 0) for x in extra.values())
    diag['walsh_smallest_abs_gap_of_squared_distances_test'] = min(
        [x['min_abs_distance_gap_test'] for x in extra.values() if 'min_abs_distance_gap_test' in x])
    diag['walsh_smallest_abs_gap_of_squared_distances_train'] = min(
        [x['min_abs_distance_gap_train'] for x in extra.values() if 'min_abs_distance_gap_train' in x])
    diag['walsh_smallest_abs_gap_of_class_scores_test'] = min(
        [x['min_abs_score_gap_test'] for x in extra.values() if 'min_abs_score_gap_test' in x])
    diag['walsh_largest_abs_difference_posterior_product_form_minus_log_form'] = max(
        [x['max_abs_posterior_product_form_minus_log_form'] for x in extra.values()
         if 'max_abs_posterior_product_form_minus_log_form' in x])
    diag['walsh_test_trials_where_most_probable_class_differs_from_nearest_code_word'] = sum(
        int(np.count_nonzero(x['top_test'] != x['pred_test'])) for (s, k, c), x in extra.items() if c[0] == 'W')
    for name in ('n_test_trials_true_class_probability_below_floor', 'n_test_outputs_exactly_1', 'n_test_outputs_exactly_0',
                 'n_test_outputs_above_upper_clip', 'n_test_outputs_below_lower_clip'):
        diag[name + '_by_condition'] = OrderedDict(
            (c, sum(extra[(s, k, c)][name] for s in people for k in seeds))
            for c in conds if name in extra[(people[0], seeds[0], c)])
    diag['test_trials_per_condition'] = OrderedDict((c, sum(per_fit[(s, k, c)]['n_test'] for s in people for k in seeds))
                                                    for c in conds)
    diag['fits_with_training_accuracy_below_1'] = OrderedDict(
        (c, sum(1 for s in people for k in seeds if per_fit[(s, k, c)]['n_correct_train'] != per_fit[(s, k, c)]['n_train']))
        for c in conds)
    diag['training_trials_whose_last_target_decodes_to_other_class'] = OrderedDict(
        (c, sum((extra[(s, k, c)]['n_target_other_class'] or 0) for s in people for k in seeds)) for c in conds)

    # ---------------------------------------------------------------- RECOMPUTED.json
    R['inventory'] = inv
    R['diagnostics'] = diag
    R['condition_summaries'] = OrderedDict((c, summ[c]) for c in conds)
    R['contrasts'] = contrasts
    R['identities'] = identities
    R['alternative_contrasts'] = OrderedDict([
        ('walsh_decision_by_hamming_distance_after_threshold_0_5', OrderedDict([
            ('note', 'named alternative reading of "nearest code word"; not the primary reading and not the published one'),
            ('mean_test_accuracy_percent', alt_condition_accuracy), ('contrasts', alt_contrasts)]))])
    R['participant_differences_pp'] = OrderedDict(
        (name, OrderedDict((str(s), OrderedDict([('exact', diffs_exact[name][s]), ('value', float(diffs_exact[name][s])),
                                                 ('alternative_float_route', diffs_float_route[name][s])]))
                           for s in people)) for name in CONTRAST_WEIGHTS)
    R['participant_means'] = [OrderedDict([('subject', s), ('condition', c), ('accuracy_exact', acc_exact[(s, c)])]
                                          + [(col, part[(s, c)][col]) for col in METRIC_COLS])
                              for c in conds for s in people]
    R['per_fit'] = [OrderedDict([('subject', s), ('seed', k), ('condition', c), ('origin', origin_used[(s, k, c)])]
                                + list(per_fit[(s, k, c)].items())
                                + [('alternatives', alts[(s, k, c)])])
                    for (s, k, c) in expected_keys]
    R['per_fit_campaign_copy_of_sample_fits'] = [
        OrderedDict([('subject', s), ('seed', k), ('condition', c), ('origin', 'campaign')] + list(r.items()))
        for (s, k, c), r in per_fit_campaign_copy.items()]
    R['linkage_from_records'] = OrderedDict([
        ('pairs', len(link)), ('identical', n_identical),
        ('note', 'third-phase (phase index 2) target distances are read from the fit records; the third-phase targets are not stored'),
        ('rows', [OrderedDict([('subject', s), ('seed', k)] + list(v.items())) for (s, k), v in link.items()])])
    R['W1_W5_last_target_difference'] = OrderedDict([
        ('overall', w1w5_overall),
        ('rows', [OrderedDict([('subject', s), ('seed', k)] + list(v.items())) for (s, k), v in w1w5.items()])])
    R['reproduction'] = OrderedDict([('summary', R_repro_summary), ('sample_fits', repro)])
    R['alternative_readings'] = alt_summary
    R['notes'] = notes

    with open(os.path.join(out_dir, 'RECOMPUTED.json'), 'w', encoding='utf-8', newline='\n') as f:
        json.dump(jsonable(R), f, indent=1, ensure_ascii=True)
        f.write('\n')

    # ---------------------------------------------------------------- COMPARISON.json / COMPARISON.md
    groups = sorted(cmp_.groups.values(), key=lambda g_: g_['group'].split(' ')[0])
    for g_ in groups:
        g_['class'] = GROUP_CLASS.get(g_['group'].split(' ')[0], '?')
    n_beyond_total = sum(g_['n_beyond_tolerance'] for g_ in groups)
    class_totals = OrderedDict()
    for cl, text in GROUP_CLASS_TEXT.items():
        gs = [g_ for g_ in groups if g_['class'] == cl]
        nums = [g_['max_abs_difference'] for g_ in gs if g_['kind'] == 'numeric']
        class_totals[cl] = OrderedDict([
            ('meaning', text), ('groups', len(gs)), ('values_compared', sum(g_['n_compared'] for g_ in gs)),
            ('largest_abs_difference_numeric', max(nums) if nums else None),
            ('values_beyond_tolerance', sum(g_['n_beyond_tolerance'] for g_ in gs))])
    comp = OrderedDict([
        ('tolerance', OrderedDict([('numeric', 'absolute %g' % TOL), ('exact', 'counts, labels, booleans, hashes: identical')])),
        ('reference_source', reference_source),
        ('groups', len(groups)), ('values_compared', sum(g_['n_compared'] for g_ in groups)),
        ('values_beyond_tolerance', n_beyond_total),
        ('totals_by_class', class_totals),
        ('table', [OrderedDict((kk, g_[kk]) for kk in ('group', 'class', 'kind', 'compared_against', 'n_compared', 'n_both_blank',
                                                         'max_abs_difference', 'max_abs_difference_at', 'n_beyond_tolerance'))
                   for g_ in groups]),
        ('beyond_tolerance', [OrderedDict([('group', g_['group'])] + list(b.items())) for g_ in groups for b in g_['beyond']])])
    with open(os.path.join(out_dir, 'COMPARISON.json'), 'w', encoding='utf-8', newline='\n') as f:
        json.dump(jsonable(comp), f, indent=1, ensure_ascii=True)
        f.write('\n')

    def fmt_max(g_):
        v = g_['max_abs_difference']
        if v is None:
            return 'n/a (labels)'
        if g_['kind'] == 'exact':
            return '%d' % v
        if v == 0.0:
            return '0'
        return '%.3e' % v

    lines = []
    lines.append('# COMPARISON - recomputation versus published files')
    lines.append('')
    lines.append('Reference source: **%s**. Tolerance: exact for counts, labels, booleans and hashes; absolute %g for every '
                 'other value. "Largest absolute difference" is the real maximum over the group, whether or not it exceeds '
                 'the tolerance. "Both blank" counts cells that are empty / null on both sides (they are part of the values '
                 'compared). Groups marked [informational], [records only] or (own consistency) are not comparisons of a '
                 'recomputed value with a published result file; see REPORT.md.' % (reference_source, TOL))
    lines.append('')
    lines.append('Totals: %d groups, %d values compared, **%d beyond tolerance**.'
                 % (len(groups), sum(g_['n_compared'] for g_ in groups), n_beyond_total))
    lines.append('')
    lines.append('Class of a group (column "Cl."):')
    lines.append('')
    for cl, e in class_totals.items():
        lines.append('- **%s** = %s: %d groups, %d values, largest numeric difference %s, **%d beyond tolerance**'
                     % (cl, e['meaning'], e['groups'], e['values_compared'],
                        'n/a' if e['largest_abs_difference_numeric'] is None else
                        ('0' if e['largest_abs_difference_numeric'] == 0 else '%.3e' % e['largest_abs_difference_numeric']),
                        e['values_beyond_tolerance']))
    lines.append('')
    lines.append('| Group of quantities | Cl. | Compared against | Values compared | of which both blank | Largest absolute difference | Beyond tolerance |')
    lines.append('|---|:-:|---|---:|---:|---:|---:|')
    for g_ in groups:
        lines.append('| %s | %s | %s | %d | %d | %s | %d |' % (g_['group'].replace('|', '/'), g_['class'],
                                                             g_['compared_against'].replace('|', '/'),
                                                             g_['n_compared'], g_['n_both_blank'], fmt_max(g_), g_['n_beyond_tolerance']))
    lines.append('')
    lines.append('## Every value beyond tolerance')
    lines.append('')
    if n_beyond_total == 0:
        lines.append('None.')
    else:
        lines.append('| Group | Key | Recomputed | Compared value | Absolute difference |')
        lines.append('|---|---|---|---|---|')
        for g_ in groups:
            for b in g_['beyond']:
                def fv(v):
                    if v is None:
                        return 'blank'
                    if isinstance(v, float):
                        return repr(v)
                    return str(jsonable(v))
                d = b.get('abs_difference')
                lines.append('| %s | %s | %s | %s | %s |' % (g_['group'].replace('|', '/'), str(b['key']).replace('|', '/'),
                                                          fv(b['recomputed']), fv(b['published']),
                                                          ('%.3e' % d) if isinstance(d, float) else ('n/a' if d is None else str(d))))
    lines.append('')
    with open(os.path.join(out_dir, 'COMPARISON.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(lines))

    sys.stdout.write('reference source: %s\n' % reference_source)
    sys.stdout.write('groups: %d   values compared: %d   beyond tolerance: %d\n'
                     % (len(groups), sum(g_['n_compared'] for g_ in groups), n_beyond_total))
    for g_ in groups:
        if g_['n_beyond_tolerance']:
            sys.stdout.write('  BEYOND  %-90s %d of %d\n' % (g_['group'][:90], g_['n_beyond_tolerance'], g_['n_compared']))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
