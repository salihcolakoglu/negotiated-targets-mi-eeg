# COMPARISON - recomputation versus published files

Reference source: **ARCHIVE**. Tolerance: exact for counts, labels, booleans and hashes; absolute 1e-09 for every other value. "Largest absolute difference" is the real maximum over the group, whether or not it exceeds the tolerance. "Both blank" counts cells that are empty / null on both sides (they are part of the values compared). Groups marked [informational], [records only] or (own consistency) are not comparisons of a recomputed value with a published result file; see REPORT.md.

Totals: 109 groups, 255759 values compared, **1840 beyond tolerance**.

Class of a group (column "Cl."):

- **P** = recomputed from the stored arrays versus a published result file (final_analysis): 55 groups, 36371 values, largest numeric difference 6.144e-08, **989 beyond tolerance**
- **D** = recomputed from the stored arrays versus a record or a decision / reproduction file: 17 groups, 186028 values, largest numeric difference 6.144e-08, **851 beyond tolerance**
- **T** = transcription only: a value read from records or files versus a published or decision file (not recomputable from the stored arrays): 11 groups, 8576 values, largest numeric difference 0, **0 beyond tolerance**
- **I** = inventory and integrity: stored data versus the expectation of protocol / brief, or SHA-256 / size: 20 groups, 23216 values, largest numeric difference n/a, **0 beyond tolerance**
- **O** = own consistency (two routes of this script) or published file versus published file: 6 groups, 1568 values, largest numeric difference 2.220e-16, **0 beyond tolerance**

| Group of quantities | Cl. | Compared against | Values compared | of which both blank | Largest absolute difference | Beyond tolerance |
|---|:-:|---|---:|---:|---:|---:|
| A01 reference source: decision file versus other files (label) | I | REPRODUCTION_TRAIN-V1.0.json reference_source | 5 | 0 | n/a (labels) | 0 |
| A02 run_metrics.csv: set of rows (subject, seed, condition) | P | run_metrics.csv | 4 | 0 | 0 | 0 |
| A03 origin of each fit: reference-source rule versus run_metrics.csv origin (label) | P | run_metrics.csv origin | 1620 | 0 | n/a (labels) | 0 |
| A04 campaign file sets (counts; missing / unexpected fit ids) | I | protocol counts / brief | 18 | 0 | 0 | 0 |
| A05 archive bindings: fits per reference condition and bound files present | I | protocol design (54 x 5) | 10 | 0 | 0 | 0 |
| A06 SHA-256 of every bound archive file versus SOURCE_BINDINGS (label) | I | SOURCE_BINDINGS-V1.0.json | 2700 | 0 | n/a (labels) | 0 |
| A07 SHA-256 of campaign files versus MODEL_FREEZE / TEST_COMPLETION lists (label) | I | MODEL_FREEZE-V1.0.json, TEST_COMPLETION-V1.0.json | 2502 | 0 | n/a (labels) | 0 |
| A08 SHA-256 cross-references inside records (label) | I | fit / test records | 6624 | 0 | n/a (labels) | 0 |
| A09 SHA-256 named in gate / completion files versus the files themselves (label) | I | RESULTS / TEST_COMPLETION / REPRODUCTION / ANALYSIS_COMPLETION / CAMPAIGN_COMPLETION | 29 | 0 | n/a (labels) | 0 |
| A10 transferred files versus the three members lists (SHA-256 and size, label) | I | transfer/*.members.tsv | 10475 | 0 | 0 | 0 |
| A11 code words derived from W0 targets | I | protocol manipulation_checks (8 differing bits) | 3 | 0 | 0 | 0 |
| A12 stored arrays of all 1692 stored copies: violations per check (count) | I | brief section A / protocol design | 9 | 0 | 0 | 0 |
| A13 labels identical across all conditions, seeds and copies of a participant (deviating copies) | I | brief section A | 2 | 0 | 0 | 0 |
| A14 fits per condition used in sections B-D (count) | I | brief (270 = 54 x 5) | 6 | 0 | 0 | 0 |
| A15 trials per fit (count of fits that do not have 100 training / 100 test trials) | I | protocol design | 2 | 0 | 0 | 0 |
| A16 byte-identical output arrays under different fit ids among the fits used (surplus copies) | I | brief section A (no duplicate fit) | 2 | 0 | 0 | 0 |
| A17 [plausibility] largest abs(last trained target - label) within the prediction share of the last trained phase (fits above bound + 1e-6) | I | protocol schedule, last trained phase | 5 | 0 | 0 | 0 |
| A18 identity and gate fields of the records of all 1692 stored copies (count of deviating records) | I | protocol design and gates | 6 | 0 | 0 | 0 |
| A19 [records only] one initial model per output type and seed; one input and one label hash per participant; target distance 0 in phases 0-1 (deviations) | I | fit records (campaign and archived W4) | 5 | 0 | 0 | 0 |
| B01 run_metrics.csv: accuracy | P | run_metrics.csv | 1620 | 0 | 0 | 0 |
| B01 run_metrics.csv: nll_clipped | P | run_metrics.csv | 1620 | 0 | 5.329e-15 | 0 |
| B01 run_metrics.csv: ece15 | P | run_metrics.csv | 1620 | 0 | 2.776e-16 | 0 |
| B01 run_metrics.csv: bce | P | run_metrics.csv | 1620 | 540 | 1.110e-16 | 0 |
| B01 run_metrics.csv: brier_sum | P | run_metrics.csv | 1620 | 0 | 3.331e-16 | 0 |
| B01 run_metrics.csv: mean_confidence | P | run_metrics.csv | 1620 | 0 | 3.331e-16 | 0 |
| B01 run_metrics.csv: posterior_accuracy | P | run_metrics.csv | 1620 | 0 | 0 | 0 |
| B01 run_metrics.csv: decision_rules_agree | P | run_metrics.csv | 1620 | 0 | 0 | 0 |
| B01 run_metrics.csv: nll_scores_divided_by_8 | P | run_metrics.csv | 1620 | 540 | 1.776e-15 | 0 |
| B01 run_metrics.csv: ece15_scores_divided_by_8 | P | run_metrics.csv | 1620 | 540 | 2.012e-16 | 0 |
| B01 run_metrics.csv: brier_scores_divided_by_8 | P | run_metrics.csv | 1620 | 540 | 3.331e-16 | 0 |
| B01 run_metrics.csv: train_accuracy | P | run_metrics.csv | 1620 | 0 | 0 | 0 |
| B01 run_metrics.csv: train_minus_test_accuracy | P | run_metrics.csv | 1620 | 0 | 0 | 0 |
| B01 run_metrics.csv: target_displacement | P | run_metrics.csv | 1620 | 270 | 6.144e-08 | 851 |
| B01 run_metrics.csv: target_mean_abs_change_per_output | P | run_metrics.csv | 1620 | 270 | 0 | 0 |
| B01 run_metrics.csv: target_mean_abs_change_differing_bits | P | run_metrics.csv | 1620 | 540 | 0 | 0 |
| B01 run_metrics.csv: target_other_class_share | P | run_metrics.csv | 1620 | 270 | 0 | 0 |
| B02 test accuracy versus the test record of the same copy (acc_test) | D | test / fit record of the copy used | 1620 | 0 | 0 | 0 |
| B03 per-trial test decisions versus pred_test in the test record (label) | D | test / fit record of the copy used | 162000 | 0 | 0 | 0 |
| B04 n_test in the test record (count) | D | test / fit record of the copy used | 1620 | 0 | 0 | 0 |
| B05 posterior accuracy versus acc_test_post in the test record | D | test / fit record of the copy used | 1620 | 0 | 0 | 0 |
| B06 training accuracy versus acc_train in the fit record | D | test / fit record of the copy used | 1620 | 0 | 0 | 0 |
| B07 [informational] NLL versus nll_test in the test record | D | test / fit record of the copy used | 1620 | 0 | 5.329e-15 | 0 |
| B08 [informational] ECE versus ece_test in the test record | D | test / fit record of the copy used | 1620 | 0 | 2.776e-16 | 0 |
| B09 [informational] bit-wise BCE versus bce_test in the test record | D | test / fit record of the copy used | 1620 | 540 | 1.110e-16 | 0 |
| B10 [informational] target displacement versus last_target_dist in the fit record | D | test / fit record of the copy used | 1620 | 270 | 6.144e-08 | 851 |
| B11 [informational] other-class share versus last_target_wrong_frac in the fit record | D | test / fit record of the copy used | 1620 | 270 | 0 | 0 |
| B12 sample fits: campaign copy versus copy used (all 17 per-fit measures) | O | own recomputation on the archive copy | 1224 | 144 | 0 | 0 |
| B13 sample fits, campaign copy: test accuracy versus its own test record (acc_test) | D | campaign test record | 72 | 0 | 0 | 0 |
| B14 sample fits, campaign copy: per-trial test decisions versus its own pred_test (label) | D | campaign test record | 7200 | 0 | 0 | 0 |
| B15 [records only] fit_timing.csv train_seconds versus the fit record of the copy used | T | fit_timing.csv | 1620 | 0 | 0 | 0 |
| B16 [records only] fit_timing.csv origin versus origin in run_metrics.csv (label) | T | fit_timing.csv | 1621 | 0 | 0 | 0 |
| B17 [informational] training NLL (same definition on the training outputs) versus nll_train in the fit record | D | test / fit record of the copy used | 1620 | 0 | 2.776e-17 | 0 |
| B18 [published versus record] run_metrics.csv target_displacement versus last_target_dist in the fit record | T | run_metrics.csv (left value: fit record, not a recomputation) | 1620 | 270 | 0 | 0 |
| C01 participant_means.csv: set of rows (count) | P | participant_means.csv | 2 | 0 | 0 | 0 |
| C02 participant_means.csv: accuracy | P | participant_means.csv | 324 | 0 | 2.220e-16 | 0 |
| C02 participant_means.csv: nll_clipped | P | participant_means.csv | 324 | 0 | 1.776e-15 | 0 |
| C02 participant_means.csv: ece15 | P | participant_means.csv | 324 | 0 | 1.110e-16 | 0 |
| C02 participant_means.csv: bce | P | participant_means.csv | 324 | 108 | 2.220e-16 | 0 |
| C02 participant_means.csv: brier_sum | P | participant_means.csv | 324 | 0 | 2.220e-16 | 0 |
| C02 participant_means.csv: mean_confidence | P | participant_means.csv | 324 | 0 | 2.220e-16 | 0 |
| C02 participant_means.csv: posterior_accuracy | P | participant_means.csv | 324 | 0 | 2.220e-16 | 0 |
| C02 participant_means.csv: decision_rules_agree | P | participant_means.csv | 324 | 0 | 0 | 0 |
| C02 participant_means.csv: nll_scores_divided_by_8 | P | participant_means.csv | 324 | 108 | 8.882e-16 | 0 |
| C02 participant_means.csv: ece15_scores_divided_by_8 | P | participant_means.csv | 324 | 108 | 1.110e-16 | 0 |
| C02 participant_means.csv: brier_scores_divided_by_8 | P | participant_means.csv | 324 | 108 | 2.220e-16 | 0 |
| C02 participant_means.csv: train_accuracy | P | participant_means.csv | 324 | 0 | 2.220e-16 | 0 |
| C02 participant_means.csv: train_minus_test_accuracy | P | participant_means.csv | 324 | 0 | 1.110e-16 | 0 |
| C02 participant_means.csv: target_displacement | P | participant_means.csv | 324 | 54 | 1.952e-08 | 136 |
| C02 participant_means.csv: target_mean_abs_change_per_output | P | participant_means.csv | 324 | 54 | 2.776e-17 | 0 |
| C02 participant_means.csv: target_mean_abs_change_differing_bits | P | participant_means.csv | 324 | 108 | 2.776e-17 | 0 |
| C02 participant_means.csv: target_other_class_share | P | participant_means.csv | 324 | 54 | 0 | 0 |
| C03 participant accuracy: mean of five seed accuracies versus exact count ratio (own consistency) | O | own exact integer arithmetic | 324 | 0 | 1.110e-16 | 0 |
| C04 participant_differences.csv: accuracy_difference_pp | P | participant_differences.csv | 216 | 0 | 0 | 0 |
| C05 participant_differences.csv: set of rows (count) | P | participant_differences.csv | 2 | 0 | 0 | 0 |
| C06 condition_summary.csv: counts and labels | P | condition_summary.csv | 19 | 0 | 0 | 0 |
| C07 condition_summary.csv: 17 measures and between-participant SD | P | condition_summary.csv | 108 | 13 | 1.077e-09 | 1 |
| C08 RESULTS-V1.0.json summaries: counts and labels | P | RESULTS-V1.0.json summaries | 19 | 0 | 0 | 0 |
| C09 RESULTS-V1.0.json summaries: 17 measures and between-participant SD | P | RESULTS-V1.0.json summaries | 108 | 13 | 1.077e-09 | 1 |
| D01 four_contrasts_holm.json: statistics of the four contrasts | P | four_contrasts_holm.json | 40 | 0 | 8.327e-16 | 0 |
| D02 four_contrasts_holm.json: counts, df, n, labels | P | four_contrasts_holm.json | 34 | 0 | 0 | 0 |
| D03 four_contrasts_holm.json: descriptive other measures (mean difference, interval) | P | four_contrasts_holm.json | 72 | 0 | 2.220e-16 | 0 |
| D04 RESULTS-V1.0.json contrasts: statistics of the four contrasts | P | RESULTS-V1.0.json contrasts | 40 | 0 | 8.327e-16 | 0 |
| D05 RESULTS-V1.0.json contrasts: counts, df, n, labels | P | RESULTS-V1.0.json contrasts | 34 | 0 | 0 | 0 |
| D06 RESULTS-V1.0.json contrasts: descriptive other measures (mean difference, interval) | P | RESULTS-V1.0.json contrasts | 72 | 0 | 2.220e-16 | 0 |
| D07 own Wilcoxon implementation versus scipy.stats.wilcoxon on the same differences (own consistency) | O | scipy 1.15.3 on own differences | 8 | 0 | 0 | 0 |
| D08 own t test versus scipy.stats.ttest_1samp (own consistency) | O | scipy 1.15.3 on own differences | 8 | 0 | 2.220e-16 | 0 |
| D09 identities 1+2 = W1-W0 and 3+4 = W1-W4: sums of the published differences and means versus own W1-W0 and W1-W4 | P | participant_differences.csv | 110 | 0 | 4.441e-16 | 0 |
| D10 identities hold exactly in own integer arithmetic (label) | O | algebra | 2 | 0 | n/a (labels) | 0 |
| D11 published files agree with each other (RESULTS contrasts = four_contrasts_holm.json; RESULTS summaries = condition_summary.csv) | O | published files | 2 | 0 | n/a (labels) | 0 |
| E01 [records only] W5_W4_first_update_linkage.csv: the two third-phase target distances versus the fit records | T | W5_W4_first_update_linkage.csv | 540 | 0 | 0 | 0 |
| E02 [records only] W5_W4_first_update_linkage.csv: rows and identical flag (count / label) | T | W5_W4_first_update_linkage.csv | 271 | 0 | 0 | 0 |
| E03 [records only] REPRODUCTION_TRAIN linkage: the two distances versus the fit records | T | REPRODUCTION_TRAIN-V1.0.json | 540 | 0 | 0 | 0 |
| E04 [records only] REPRODUCTION_TRAIN linkage: entries and identical flag (count / label) | T | REPRODUCTION_TRAIN-V1.0.json | 271 | 0 | 0 | 0 |
| E05 [records only] RESULTS reproduction.W5_W4_first_update_linkage and decision-file linkage counts (count) | T | RESULTS-V1.0.json / REPRODUCTION_TRAIN-V1.0.json | 5 | 1 | 0 | 0 |
| E06 [records only] last entry of used_target_dist_by_phase versus last_target_dist in the same fit record | T | fit records | 1404 | 0 | 0 | 0 |
| E07 [records only] third-phase target distance of the 18 campaign W4 sample refits versus archived W4 and versus W5 (label) | T | fit records | 36 | 0 | n/a (labels) | 0 |
| E08 W1_W5_last_target_difference.csv: three measures per participant and seed | P | W1_W5_last_target_difference.csv | 810 | 0 | 0 | 0 |
| E09 W1_W5_last_target_difference.csv: rows (count) | P | W1_W5_last_target_difference.csv | 2 | 0 | 0 | 0 |
| E10 RESULTS W1_W5_last_target_difference: means over the 270 pairs | P | RESULTS-V1.0.json | 3 | 0 | 1.388e-17 | 0 |
| E11 RESULTS W1_W5_last_target_difference: pairs (count) | P | RESULTS-V1.0.json | 1 | 0 | 0 | 0 |
| F01 REPRODUCTION_TRAIN details: equality flags per sample fit versus own byte comparison (label) | D | REPRODUCTION_TRAIN-V1.0.json | 396 | 0 | n/a (labels) | 0 |
| F02 REPRODUCTION_TRAIN details: max_abs_difference_P_train versus own value | D | REPRODUCTION_TRAIN-V1.0.json | 72 | 0 | 0 | 0 |
| F03 REPRODUCTION_TEST details: flag per sample fit versus own byte comparison (label) | D | REPRODUCTION_TEST-V1.0.json | 72 | 0 | n/a (labels) | 0 |
| F04 reproduction counts, mismatch lists and statuses in decision files and RESULTS (count / label) | D | decision files / RESULTS | 16 | 0 | 0 | 0 |
| F05 [informational] sample fits: records of the campaign copy equal the archived records (9 fields, label) | T | campaign and archive records | 648 | 0 | n/a (labels) | 0 |
| F06 [informational] normaliser of every participant (data/preprocessors) versus the normalisation arrays of every archived S0/W0/W1 fit (bytes) | I | archived fits (lee format) | 810 | 0 | n/a (labels) | 0 |
| G01 RESULTS-V1.0.json counts (count) | P | RESULTS-V1.0.json counts | 7 | 0 | 0 | 0 |
| G02 [informational] software versions named in RESULTS versus this run (label) | I | RESULTS-V1.0.json software | 2 | 0 | n/a (labels) | 0 |
| G03 RESULTS-V1.0.json engineering_fixture_only is false (label) | I | RESULTS-V1.0.json | 1 | 0 | n/a (labels) | 0 |

## Every value beyond tolerance

| Group | Key | Recomputed | Compared value | Absolute difference |
|---|---|---|---|---|
| B01 run_metrics.csv: target_displacement | 1/1/S1 | 0.17542738921485523 | 0.1754273921251297 | 2.910e-09 |
| B01 run_metrics.csv: target_displacement | 1/2/S1 | 0.18656551111021424 | 0.18656551837921143 | 7.269e-09 |
| B01 run_metrics.csv: target_displacement | 1/3/S1 | 0.17378457174782233 | 0.1737845540046692 | 1.774e-08 |
| B01 run_metrics.csv: target_displacement | 1/4/S1 | 0.09733275136515517 | 0.09733275324106216 | 1.876e-09 |
| B01 run_metrics.csv: target_displacement | 1/5/S1 | 0.20909505659449645 | 0.2090950459241867 | 1.067e-08 |
| B01 run_metrics.csv: target_displacement | 2/1/S1 | 0.07286740559699076 | 0.07286740094423294 | 4.653e-09 |
| B01 run_metrics.csv: target_displacement | 2/2/S1 | 0.023494111889549557 | 0.023494113236665726 | 1.347e-09 |
| B01 run_metrics.csv: target_displacement | 2/3/S1 | 0.019304839389118245 | 0.01930483803153038 | 1.358e-09 |
| B01 run_metrics.csv: target_displacement | 2/4/S1 | 0.13462512515333136 | 0.1346251368522644 | 1.170e-08 |
| B01 run_metrics.csv: target_displacement | 2/5/S1 | 0.033306265511260084 | 0.03330626338720322 | 2.124e-09 |
| B01 run_metrics.csv: target_displacement | 3/1/S1 | 0.041351405655488775 | 0.041351404041051865 | 1.614e-09 |
| B01 run_metrics.csv: target_displacement | 3/2/S1 | 0.07428223816268113 | 0.07428224384784698 | 5.685e-09 |
| B01 run_metrics.csv: target_displacement | 3/3/S1 | 0.08627607099326404 | 0.08627607673406601 | 5.741e-09 |
| B01 run_metrics.csv: target_displacement | 3/5/S1 | 0.05574572480770572 | 0.05574573203921318 | 7.232e-09 |
| B01 run_metrics.csv: target_displacement | 4/1/S1 | 0.08440056127167615 | 0.08440054953098297 | 1.174e-08 |
| B01 run_metrics.csv: target_displacement | 4/2/S1 | 0.11636241700003115 | 0.11636242270469666 | 5.705e-09 |
| B01 run_metrics.csv: target_displacement | 4/3/S1 | 0.07681920699777783 | 0.07681921124458313 | 4.247e-09 |
| B01 run_metrics.csv: target_displacement | 4/4/S1 | 0.10048770072039458 | 0.10048770904541016 | 8.325e-09 |
| B01 run_metrics.csv: target_displacement | 4/5/S1 | 0.07389961462692762 | 0.07389960438013077 | 1.025e-08 |
| B01 run_metrics.csv: target_displacement | 5/1/S1 | 0.02771295595628526 | 0.027712952345609665 | 3.611e-09 |
| B01 run_metrics.csv: target_displacement | 5/2/S1 | 0.043721676506498476 | 0.04372167959809303 | 3.092e-09 |
| B01 run_metrics.csv: target_displacement | 5/3/S1 | 0.01687676135400935 | 0.016876762732863426 | 1.379e-09 |
| B01 run_metrics.csv: target_displacement | 6/1/S1 | 0.07463493188980824 | 0.07463493943214417 | 7.542e-09 |
| B01 run_metrics.csv: target_displacement | 6/2/S1 | 0.0590594690917686 | 0.059059470891952515 | 1.800e-09 |
| B01 run_metrics.csv: target_displacement | 6/3/S1 | 0.03664953164673913 | 0.03664952889084816 | 2.756e-09 |
| B01 run_metrics.csv: target_displacement | 6/4/S1 | 0.043399789839041344 | 0.04339979216456413 | 2.326e-09 |
| B01 run_metrics.csv: target_displacement | 6/5/S1 | 0.0511401103741201 | 0.05114011466503143 | 4.291e-09 |
| B01 run_metrics.csv: target_displacement | 7/1/S1 | 0.08173238149844832 | 0.0817323848605156 | 3.362e-09 |
| B01 run_metrics.csv: target_displacement | 7/2/S1 | 0.07618327322693656 | 0.0761832743883133 | 1.161e-09 |
| B01 run_metrics.csv: target_displacement | 7/3/S1 | 0.09026444991437423 | 0.0902644619345665 | 1.202e-08 |
| B01 run_metrics.csv: target_displacement | 7/4/S1 | 0.07699519291546487 | 0.07699519395828247 | 1.043e-09 |
| B01 run_metrics.csv: target_displacement | 8/1/S1 | 0.1686343322116822 | 0.1686343252658844 | 6.946e-09 |
| B01 run_metrics.csv: target_displacement | 8/2/S1 | 0.2325915260157427 | 0.23259150981903076 | 1.620e-08 |
| B01 run_metrics.csv: target_displacement | 8/3/S1 | 0.1322359680277242 | 0.13223597407341003 | 6.046e-09 |
| B01 run_metrics.csv: target_displacement | 8/4/S1 | 0.14502303775994826 | 0.14502303302288055 | 4.737e-09 |
| B01 run_metrics.csv: target_displacement | 8/5/S1 | 0.09712160194650676 | 0.09712160378694534 | 1.840e-09 |
| B01 run_metrics.csv: target_displacement | 9/1/S1 | 0.042737038552968246 | 0.04273703694343567 | 1.610e-09 |
| B01 run_metrics.csv: target_displacement | 9/2/S1 | 0.08524895618458446 | 0.08524896949529648 | 1.331e-08 |
| B01 run_metrics.csv: target_displacement | 9/3/S1 | 0.05527322907301942 | 0.05527322739362717 | 1.679e-09 |
| B01 run_metrics.csv: target_displacement | 9/4/S1 | 0.04820044515342908 | 0.048200443387031555 | 1.766e-09 |
| B01 run_metrics.csv: target_displacement | 9/5/S1 | 0.04311295462943255 | 0.04311295598745346 | 1.358e-09 |
| B01 run_metrics.csv: target_displacement | 10/2/S1 | 0.08705341600605672 | 0.08705340325832367 | 1.275e-08 |
| B01 run_metrics.csv: target_displacement | 10/3/S1 | 0.1020724881112041 | 0.10207247734069824 | 1.077e-08 |
| B01 run_metrics.csv: target_displacement | 10/4/S1 | 0.1062975795941812 | 0.1062975823879242 | 2.794e-09 |
| B01 run_metrics.csv: target_displacement | 10/5/S1 | 0.10477891907657691 | 0.10477890819311142 | 1.088e-08 |
| B01 run_metrics.csv: target_displacement | 11/1/S1 | 0.1556475449851721 | 0.15564756095409393 | 1.597e-08 |
| B01 run_metrics.csv: target_displacement | 11/2/S1 | 0.14795617379501708 | 0.14795617759227753 | 3.797e-09 |
| B01 run_metrics.csv: target_displacement | 11/3/S1 | 0.11569257313681018 | 0.11569257080554962 | 2.331e-09 |
| B01 run_metrics.csv: target_displacement | 11/4/S1 | 0.11064878263854754 | 0.11064879596233368 | 1.332e-08 |
| B01 run_metrics.csv: target_displacement | 11/5/S1 | 0.16695391654825417 | 0.166953906416893 | 1.013e-08 |
| B01 run_metrics.csv: target_displacement | 12/1/S1 | 0.1867030234682147 | 0.18670302629470825 | 2.826e-09 |
| B01 run_metrics.csv: target_displacement | 12/2/S1 | 0.2077054153645937 | 0.20770542323589325 | 7.871e-09 |
| B01 run_metrics.csv: target_displacement | 12/3/S1 | 0.10640118977674387 | 0.10640119761228561 | 7.836e-09 |
| B01 run_metrics.csv: target_displacement | 12/4/S1 | 0.12647441235457457 | 0.12647442519664764 | 1.284e-08 |
| B01 run_metrics.csv: target_displacement | 12/5/S1 | 0.0948366479384142 | 0.09483666718006134 | 1.924e-08 |
| B01 run_metrics.csv: target_displacement | 13/1/S1 | 0.19613313012780278 | 0.19613313674926758 | 6.621e-09 |
| B01 run_metrics.csv: target_displacement | 13/2/S1 | 0.18816624655956254 | 0.18816626071929932 | 1.416e-08 |
| B01 run_metrics.csv: target_displacement | 13/3/S1 | 0.15175386409506422 | 0.15175385773181915 | 6.363e-09 |
| B01 run_metrics.csv: target_displacement | 13/4/S1 | 0.18886442342190254 | 0.18886443972587585 | 1.630e-08 |
| B01 run_metrics.csv: target_displacement | 13/5/S1 | 0.1633943790275697 | 0.16339437663555145 | 2.392e-09 |
| B01 run_metrics.csv: target_displacement | 14/1/S1 | 0.1312824814183668 | 0.1312824785709381 | 2.847e-09 |
| B01 run_metrics.csv: target_displacement | 14/2/S1 | 0.09611353575750745 | 0.09611354023218155 | 4.475e-09 |
| B01 run_metrics.csv: target_displacement | 14/4/S1 | 0.07005856593881193 | 0.07005856931209564 | 3.373e-09 |
| B01 run_metrics.csv: target_displacement | 14/5/S1 | 0.08064222625480673 | 0.08064224570989609 | 1.946e-08 |
| B01 run_metrics.csv: target_displacement | 15/1/S1 | 0.013326983625699826 | 0.013326982036232948 | 1.589e-09 |
| B01 run_metrics.csv: target_displacement | 15/3/S1 | 0.013858338412569312 | 0.013858336955308914 | 1.457e-09 |
| B01 run_metrics.csv: target_displacement | 16/1/S1 | 0.17870330581328667 | 0.17870330810546875 | 2.292e-09 |
| B01 run_metrics.csv: target_displacement | 16/3/S1 | 0.10163323805757195 | 0.10163325071334839 | 1.266e-08 |
| B01 run_metrics.csv: target_displacement | 16/4/S1 | 0.11554065973450758 | 0.11554065346717834 | 6.267e-09 |
| B01 run_metrics.csv: target_displacement | 17/1/S1 | 0.0840945209037771 | 0.08409452438354492 | 3.480e-09 |
| B01 run_metrics.csv: target_displacement | 17/2/S1 | 0.1325533600515325 | 0.1325533539056778 | 6.146e-09 |
| B01 run_metrics.csv: target_displacement | 17/4/S1 | 0.040575065932982456 | 0.0405750647187233 | 1.214e-09 |
| B01 run_metrics.csv: target_displacement | 17/5/S1 | 0.05718855761346915 | 0.05718855559825897 | 2.015e-09 |
| B01 run_metrics.csv: target_displacement | 18/1/S1 | 0.0689675584698407 | 0.0689675509929657 | 7.477e-09 |
| B01 run_metrics.csv: target_displacement | 18/2/S1 | 0.053116533863363055 | 0.053116537630558014 | 3.767e-09 |
| B01 run_metrics.csv: target_displacement | 18/3/S1 | 0.028617650331234753 | 0.028617652133107185 | 1.802e-09 |
| B01 run_metrics.csv: target_displacement | 18/5/S1 | 0.060586603479621096 | 0.060586605221033096 | 1.741e-09 |
| B01 run_metrics.csv: target_displacement | 19/1/S1 | 0.07514815329856553 | 0.07514815032482147 | 2.974e-09 |
| B01 run_metrics.csv: target_displacement | 19/2/S1 | 0.07233259585955318 | 0.07233259826898575 | 2.409e-09 |
| B01 run_metrics.csv: target_displacement | 19/5/S1 | 0.12296881012424082 | 0.12296880781650543 | 2.308e-09 |
| B01 run_metrics.csv: target_displacement | 20/2/S1 | 0.08636012351400282 | 0.08636011183261871 | 1.168e-08 |
| B01 run_metrics.csv: target_displacement | 20/3/S1 | 0.10316730556761311 | 0.10316730290651321 | 2.661e-09 |
| B01 run_metrics.csv: target_displacement | 21/2/S1 | 0.018000647165349454 | 0.0180006455630064 | 1.602e-09 |
| B01 run_metrics.csv: target_displacement | 21/3/S1 | 0.01511207964420396 | 0.015112077817320824 | 1.827e-09 |
| B01 run_metrics.csv: target_displacement | 21/4/S1 | 0.013767600246864315 | 0.013767599128186703 | 1.119e-09 |
| B01 run_metrics.csv: target_displacement | 22/2/S1 | 0.0879932721774785 | 0.08799327909946442 | 6.922e-09 |
| B01 run_metrics.csv: target_displacement | 22/3/S1 | 0.08736884466996452 | 0.08736883848905563 | 6.181e-09 |
| B01 run_metrics.csv: target_displacement | 22/4/S1 | 0.13187947513119191 | 0.13187947869300842 | 3.562e-09 |
| B01 run_metrics.csv: target_displacement | 22/5/S1 | 0.10520522828282401 | 0.1052052229642868 | 5.319e-09 |
| B01 run_metrics.csv: target_displacement | 23/1/S1 | 0.11522969763925849 | 0.11522969603538513 | 1.604e-09 |
| B01 run_metrics.csv: target_displacement | 23/2/S1 | 0.05960312355116822 | 0.059603117406368256 | 6.145e-09 |
| B01 run_metrics.csv: target_displacement | 23/3/S1 | 0.07705518716966323 | 0.0770551860332489 | 1.136e-09 |
| B01 run_metrics.csv: target_displacement | 23/4/S1 | 0.09036958695666242 | 0.0903695747256279 | 1.223e-08 |
| B01 run_metrics.csv: target_displacement | 23/5/S1 | 0.11155614767356152 | 0.11155614256858826 | 5.105e-09 |
| B01 run_metrics.csv: target_displacement | 24/1/S1 | 0.060666041796493 | 0.0606660358607769 | 5.936e-09 |
| B01 run_metrics.csv: target_displacement | 24/4/S1 | 0.05836437785289214 | 0.0583643764257431 | 1.427e-09 |
| B01 run_metrics.csv: target_displacement | 24/5/S1 | 0.03862076744503268 | 0.03862076625227928 | 1.193e-09 |
| B01 run_metrics.csv: target_displacement | 25/2/S1 | 0.05352538300168314 | 0.053525377064943314 | 5.937e-09 |
| B01 run_metrics.csv: target_displacement | 25/3/S1 | 0.05102520124009181 | 0.05102520436048508 | 3.120e-09 |
| B01 run_metrics.csv: target_displacement | 25/4/S1 | 0.07083501804056935 | 0.07083501666784286 | 1.373e-09 |
| B01 run_metrics.csv: target_displacement | 25/5/S1 | 0.0885482042041604 | 0.0885482057929039 | 1.589e-09 |
| B01 run_metrics.csv: target_displacement | 26/1/S1 | 0.23086457039619643 | 0.23086458444595337 | 1.405e-08 |
| B01 run_metrics.csv: target_displacement | 26/2/S1 | 0.16286383078103092 | 0.1628638505935669 | 1.981e-08 |
| B01 run_metrics.csv: target_displacement | 26/3/S1 | 0.17654443126344638 | 0.1765444427728653 | 1.151e-08 |
| B01 run_metrics.csv: target_displacement | 26/4/S1 | 0.16424716120525623 | 0.16424717009067535 | 8.885e-09 |
| B01 run_metrics.csv: target_displacement | 26/5/S1 | 0.11199074560991953 | 0.11199074983596802 | 4.226e-09 |
| B01 run_metrics.csv: target_displacement | 27/1/S1 | 0.14525972556918804 | 0.14525972306728363 | 2.502e-09 |
| B01 run_metrics.csv: target_displacement | 27/3/S1 | 0.13172376885784595 | 0.1317237764596939 | 7.602e-09 |
| B01 run_metrics.csv: target_displacement | 27/4/S1 | 0.1366900965618163 | 0.13669009506702423 | 1.495e-09 |
| B01 run_metrics.csv: target_displacement | 27/5/S1 | 0.07309718016238903 | 0.07309718430042267 | 4.138e-09 |
| B01 run_metrics.csv: target_displacement | 28/1/S1 | 0.035858834989138624 | 0.03585883229970932 | 2.689e-09 |
| B01 run_metrics.csv: target_displacement | 28/3/S1 | 0.03290497249630257 | 0.0329049713909626 | 1.105e-09 |
| B01 run_metrics.csv: target_displacement | 28/4/S1 | 0.044759096767554005 | 0.04475909098982811 | 5.778e-09 |
| B01 run_metrics.csv: target_displacement | 28/5/S1 | 0.03010054838665066 | 0.03010055050253868 | 2.116e-09 |
| B01 run_metrics.csv: target_displacement | 29/1/S1 | 0.025230168654682115 | 0.025230171158909798 | 2.504e-09 |
| B01 run_metrics.csv: target_displacement | 29/2/S1 | 0.03167802772250976 | 0.031678032130002975 | 4.407e-09 |
| B01 run_metrics.csv: target_displacement | 29/4/S1 | 0.023741055990961116 | 0.02374105714261532 | 1.152e-09 |
| B01 run_metrics.csv: target_displacement | 29/5/S1 | 0.024444438689001008 | 0.02444443665444851 | 2.035e-09 |
| B01 run_metrics.csv: target_displacement | 30/1/S1 | 0.05924121441252288 | 0.059241220355033875 | 5.943e-09 |
| B01 run_metrics.csv: target_displacement | 30/2/S1 | 0.01905147439900111 | 0.019051475450396538 | 1.051e-09 |
| B01 run_metrics.csv: target_displacement | 30/3/S1 | 0.020214993101100663 | 0.02021499164402485 | 1.457e-09 |
| B01 run_metrics.csv: target_displacement | 30/5/S1 | 0.03418758624368136 | 0.03418758511543274 | 1.128e-09 |
| B01 run_metrics.csv: target_displacement | 31/1/S1 | 0.0920356256320063 | 0.09203562140464783 | 4.227e-09 |
| B01 run_metrics.csv: target_displacement | 31/2/S1 | 0.0896606916733011 | 0.08966068923473358 | 2.439e-09 |
| B01 run_metrics.csv: target_displacement | 31/3/S1 | 0.08171743377453383 | 0.08171743154525757 | 2.229e-09 |
| B01 run_metrics.csv: target_displacement | 31/4/S1 | 0.0801252322948029 | 0.08012522757053375 | 4.724e-09 |
| B01 run_metrics.csv: target_displacement | 31/5/S1 | 0.09934590804064478 | 0.09934590011835098 | 7.922e-09 |
| B01 run_metrics.csv: target_displacement | 33/5/S1 | 0.022271787650402688 | 0.022271789610385895 | 1.960e-09 |
| B01 run_metrics.csv: target_displacement | 34/1/S1 | 0.12628362907514934 | 0.12628363072872162 | 1.654e-09 |
| B01 run_metrics.csv: target_displacement | 34/2/S1 | 0.10146316322386253 | 0.10146317631006241 | 1.309e-08 |
| B01 run_metrics.csv: target_displacement | 34/4/S1 | 0.14111397118419722 | 0.1411139816045761 | 1.042e-08 |
| B01 run_metrics.csv: target_displacement | 34/5/S1 | 0.10429719267416174 | 0.10429719090461731 | 1.770e-09 |
| B01 run_metrics.csv: target_displacement | 36/5/S1 | 0.015115345590448718 | 0.015115346759557724 | 1.169e-09 |
| B01 run_metrics.csv: target_displacement | 37/2/S1 | 0.029343898809654538 | 0.029343895614147186 | 3.196e-09 |
| B01 run_metrics.csv: target_displacement | 37/4/S1 | 0.020069858208193733 | 0.02006985992193222 | 1.714e-09 |
| B01 run_metrics.csv: target_displacement | 37/5/S1 | 0.03031985644046985 | 0.030319854617118835 | 1.823e-09 |
| B01 run_metrics.csv: target_displacement | 38/1/S1 | 0.0719481014575059 | 0.0719481036067009 | 2.149e-09 |
| B01 run_metrics.csv: target_displacement | 38/2/S1 | 0.03672593596441752 | 0.036725934594869614 | 1.370e-09 |
| B01 run_metrics.csv: target_displacement | 38/3/S1 | 0.05153313058748155 | 0.051533136516809464 | 5.929e-09 |
| B01 run_metrics.csv: target_displacement | 38/4/S1 | 0.06361020007579159 | 0.06361020356416702 | 3.488e-09 |
| B01 run_metrics.csv: target_displacement | 39/1/S1 | 0.11982774318950075 | 0.1198277473449707 | 4.155e-09 |
| B01 run_metrics.csv: target_displacement | 39/2/S1 | 0.11919379370875072 | 0.11919379234313965 | 1.366e-09 |
| B01 run_metrics.csv: target_displacement | 39/3/S1 | 0.06800381680351564 | 0.0680038183927536 | 1.589e-09 |
| B01 run_metrics.csv: target_displacement | 39/4/S1 | 0.07780784193215763 | 0.07780784368515015 | 1.753e-09 |
| B01 run_metrics.csv: target_displacement | 39/5/S1 | 0.09683949343763311 | 0.09683949500322342 | 1.566e-09 |
| B01 run_metrics.csv: target_displacement | 40/1/S1 | 0.15460897366783818 | 0.15460897982120514 | 6.153e-09 |
| B01 run_metrics.csv: target_displacement | 40/2/S1 | 0.07451213253728585 | 0.07451213151216507 | 1.025e-09 |
| B01 run_metrics.csv: target_displacement | 40/3/S1 | 0.07521200004801325 | 0.07521199434995651 | 5.698e-09 |
| B01 run_metrics.csv: target_displacement | 40/4/S1 | 0.07213873040991796 | 0.07213873416185379 | 3.752e-09 |
| B01 run_metrics.csv: target_displacement | 40/5/S1 | 0.13604410994112984 | 0.13604411482810974 | 4.887e-09 |
| B01 run_metrics.csv: target_displacement | 41/1/S1 | 0.10901739587140113 | 0.10901740193367004 | 6.062e-09 |
| B01 run_metrics.csv: target_displacement | 41/2/S1 | 0.05203576961298676 | 0.05203577131032944 | 1.697e-09 |
| B01 run_metrics.csv: target_displacement | 41/3/S1 | 0.0785440453539274 | 0.07854404300451279 | 2.349e-09 |
| B01 run_metrics.csv: target_displacement | 41/4/S1 | 0.07663341666968462 | 0.07663342356681824 | 6.897e-09 |
| B01 run_metrics.csv: target_displacement | 41/5/S1 | 0.06695783671804832 | 0.06695783138275146 | 5.335e-09 |
| B01 run_metrics.csv: target_displacement | 42/1/S1 | 0.1446820261549132 | 0.14468201994895935 | 6.206e-09 |
| B01 run_metrics.csv: target_displacement | 42/2/S1 | 0.14213871753179252 | 0.14213873445987701 | 1.693e-08 |
| B01 run_metrics.csv: target_displacement | 42/3/S1 | 0.11820368570332665 | 0.11820369958877563 | 1.389e-08 |
| B01 run_metrics.csv: target_displacement | 42/4/S1 | 0.13924925744442385 | 0.13924925029277802 | 7.152e-09 |
| B01 run_metrics.csv: target_displacement | 42/5/S1 | 0.13138825558084757 | 0.13138824701309204 | 8.568e-09 |
| B01 run_metrics.csv: target_displacement | 43/1/S1 | 0.08703241768551634 | 0.08703242242336273 | 4.738e-09 |
| B01 run_metrics.csv: target_displacement | 43/2/S1 | 0.06555198344129883 | 0.06555198132991791 | 2.111e-09 |
| B01 run_metrics.csv: target_displacement | 43/3/S1 | 0.07468475347199026 | 0.0746847614645958 | 7.993e-09 |
| B01 run_metrics.csv: target_displacement | 43/4/S1 | 0.0857259270354319 | 0.08572591841220856 | 8.623e-09 |
| B01 run_metrics.csv: target_displacement | 43/5/S1 | 0.05431058845111221 | 0.05431059002876282 | 1.578e-09 |
| B01 run_metrics.csv: target_displacement | 44/2/S1 | 0.041289408268970165 | 0.04128940403461456 | 4.234e-09 |
| B01 run_metrics.csv: target_displacement | 44/4/S1 | 0.03188068949292854 | 0.031880687922239304 | 1.571e-09 |
| B01 run_metrics.csv: target_displacement | 45/2/S1 | 0.04104068267619824 | 0.041040681302547455 | 1.374e-09 |
| B01 run_metrics.csv: target_displacement | 45/4/S1 | 0.04140918178875876 | 0.04140918701887131 | 5.230e-09 |
| B01 run_metrics.csv: target_displacement | 45/5/S1 | 0.03775226834370816 | 0.037752266973257065 | 1.370e-09 |
| B01 run_metrics.csv: target_displacement | 46/1/S1 | 0.173720086218019 | 0.1737200915813446 | 5.363e-09 |
| B01 run_metrics.csv: target_displacement | 46/2/S1 | 0.15382834568637407 | 0.15382833778858185 | 7.898e-09 |
| B01 run_metrics.csv: target_displacement | 46/4/S1 | 0.11515476725893407 | 0.11515477299690247 | 5.738e-09 |
| B01 run_metrics.csv: target_displacement | 46/5/S1 | 0.11271784614546766 | 0.11271784454584122 | 1.600e-09 |
| B01 run_metrics.csv: target_displacement | 47/1/S1 | 0.18199663134871538 | 0.18199662864208221 | 2.707e-09 |
| B01 run_metrics.csv: target_displacement | 47/2/S1 | 0.2633511560917789 | 0.2633511424064636 | 1.369e-08 |
| B01 run_metrics.csv: target_displacement | 47/3/S1 | 0.23103734116788488 | 0.23103734850883484 | 7.341e-09 |
| B01 run_metrics.csv: target_displacement | 47/4/S1 | 0.26921777343350817 | 0.2692177891731262 | 1.574e-08 |
| B01 run_metrics.csv: target_displacement | 47/5/S1 | 0.24580189020248444 | 0.2458019107580185 | 2.056e-08 |
| B01 run_metrics.csv: target_displacement | 48/1/S1 | 0.10987362667956127 | 0.10987363755702972 | 1.088e-08 |
| B01 run_metrics.csv: target_displacement | 48/2/S1 | 0.08058917976534609 | 0.0805891826748848 | 2.910e-09 |
| B01 run_metrics.csv: target_displacement | 48/3/S1 | 0.09246544648650284 | 0.09246544539928436 | 1.087e-09 |
| B01 run_metrics.csv: target_displacement | 48/4/S1 | 0.06548823088655603 | 0.06548823416233063 | 3.276e-09 |
| B01 run_metrics.csv: target_displacement | 48/5/S1 | 0.07965267309041274 | 0.07965266704559326 | 6.045e-09 |
| B01 run_metrics.csv: target_displacement | 49/2/S1 | 0.09781150401600351 | 0.0978115051984787 | 1.182e-09 |
| B01 run_metrics.csv: target_displacement | 49/4/S1 | 0.06864525897729051 | 0.06864526122808456 | 2.251e-09 |
| B01 run_metrics.csv: target_displacement | 49/5/S1 | 0.08555447885120664 | 0.08555448800325394 | 9.152e-09 |
| B01 run_metrics.csv: target_displacement | 50/1/S1 | 0.04713797306047747 | 0.04713797569274902 | 2.632e-09 |
| B01 run_metrics.csv: target_displacement | 50/2/S1 | 0.041135830233158935 | 0.04113583266735077 | 2.434e-09 |
| B01 run_metrics.csv: target_displacement | 50/3/S1 | 0.06655136087946417 | 0.06655135750770569 | 3.372e-09 |
| B01 run_metrics.csv: target_displacement | 50/4/S1 | 0.04833137267450023 | 0.048331376165151596 | 3.491e-09 |
| B01 run_metrics.csv: target_displacement | 50/5/S1 | 0.06287726505363783 | 0.06287726759910583 | 2.545e-09 |
| B01 run_metrics.csv: target_displacement | 51/1/S1 | 0.12240095280950455 | 0.12240096926689148 | 1.646e-08 |
| B01 run_metrics.csv: target_displacement | 51/2/S1 | 0.18559385593102637 | 0.1855938583612442 | 2.430e-09 |
| B01 run_metrics.csv: target_displacement | 51/3/S1 | 0.12982977506362553 | 0.1298297792673111 | 4.204e-09 |
| B01 run_metrics.csv: target_displacement | 51/4/S1 | 0.10022695801702491 | 0.10022695362567902 | 4.391e-09 |
| B01 run_metrics.csv: target_displacement | 51/5/S1 | 0.08436921981229809 | 0.08436921238899231 | 7.423e-09 |
| B01 run_metrics.csv: target_displacement | 52/1/S1 | 0.1293722726784649 | 0.1293722689151764 | 3.763e-09 |
| B01 run_metrics.csv: target_displacement | 52/2/S1 | 0.10389011937683318 | 0.10389013588428497 | 1.651e-08 |
| B01 run_metrics.csv: target_displacement | 52/3/S1 | 0.10413458171064108 | 0.10413456708192825 | 1.463e-08 |
| B01 run_metrics.csv: target_displacement | 52/5/S1 | 0.1168875646928615 | 0.11688756197690964 | 2.716e-09 |
| B01 run_metrics.csv: target_displacement | 53/1/S1 | 0.07506422798969313 | 0.07506423443555832 | 6.446e-09 |
| B01 run_metrics.csv: target_displacement | 53/2/S1 | 0.13778647974648212 | 0.13778649270534515 | 1.296e-08 |
| B01 run_metrics.csv: target_displacement | 53/3/S1 | 0.10557179322741007 | 0.10557180643081665 | 1.320e-08 |
| B01 run_metrics.csv: target_displacement | 53/4/S1 | 0.12860243319538275 | 0.12860244512557983 | 1.193e-08 |
| B01 run_metrics.csv: target_displacement | 53/5/S1 | 0.08288900401465589 | 0.08288900554180145 | 1.527e-09 |
| B01 run_metrics.csv: target_displacement | 54/1/S1 | 0.21414468247704768 | 0.21414469182491302 | 9.348e-09 |
| B01 run_metrics.csv: target_displacement | 54/2/S1 | 0.13257169317330872 | 0.13257168233394623 | 1.084e-08 |
| B01 run_metrics.csv: target_displacement | 54/3/S1 | 0.12344880073997927 | 0.12344880402088165 | 3.281e-09 |
| B01 run_metrics.csv: target_displacement | 54/4/S1 | 0.14151388167812207 | 0.1415138840675354 | 2.389e-09 |
| B01 run_metrics.csv: target_displacement | 54/5/S1 | 0.13377980688617336 | 0.13377980887889862 | 1.993e-09 |
| B01 run_metrics.csv: target_displacement | 1/1/W1 | 0.4256515417785684 | 0.42565158009529114 | 3.832e-08 |
| B01 run_metrics.csv: target_displacement | 1/2/W1 | 0.3020839057817399 | 0.30208393931388855 | 3.353e-08 |
| B01 run_metrics.csv: target_displacement | 1/3/W1 | 0.2575834912396548 | 0.25758349895477295 | 7.715e-09 |
| B01 run_metrics.csv: target_displacement | 1/4/W1 | 0.39666078133269667 | 0.39666077494621277 | 6.386e-09 |
| B01 run_metrics.csv: target_displacement | 1/5/W1 | 0.34413372895148425 | 0.34413373470306396 | 5.752e-09 |
| B01 run_metrics.csv: target_displacement | 2/1/W1 | 0.1364253727113959 | 0.13642537593841553 | 3.227e-09 |
| B01 run_metrics.csv: target_displacement | 2/2/W1 | 0.09758501719486042 | 0.097585029900074 | 1.271e-08 |
| B01 run_metrics.csv: target_displacement | 2/3/W1 | 0.3407941235647829 | 0.3407941162586212 | 7.306e-09 |
| B01 run_metrics.csv: target_displacement | 2/4/W1 | 0.09059926749128422 | 0.09059926867485046 | 1.184e-09 |
| B01 run_metrics.csv: target_displacement | 3/1/W1 | 0.17244120503570007 | 0.17244121432304382 | 9.287e-09 |
| B01 run_metrics.csv: target_displacement | 3/2/W1 | 0.16533130579063715 | 0.16533130407333374 | 1.717e-09 |
| B01 run_metrics.csv: target_displacement | 3/3/W1 | 0.10986091802680752 | 0.10986091941595078 | 1.389e-09 |
| B01 run_metrics.csv: target_displacement | 3/4/W1 | 0.15635581562843925 | 0.1563558131456375 | 2.483e-09 |
| B01 run_metrics.csv: target_displacement | 3/5/W1 | 0.14609434219548864 | 0.14609433710575104 | 5.090e-09 |
| B01 run_metrics.csv: target_displacement | 4/1/W1 | 0.23152144085322895 | 0.23152147233486176 | 3.148e-08 |
| B01 run_metrics.csv: target_displacement | 4/2/W1 | 0.2085913516595876 | 0.20859137177467346 | 2.012e-08 |
| B01 run_metrics.csv: target_displacement | 4/5/W1 | 0.217019517958863 | 0.21701951324939728 | 4.709e-09 |
| B01 run_metrics.csv: target_displacement | 5/1/W1 | 0.15269685195116614 | 0.1526968628168106 | 1.087e-08 |
| B01 run_metrics.csv: target_displacement | 5/2/W1 | 0.10381422421507111 | 0.10381422936916351 | 5.154e-09 |
| B01 run_metrics.csv: target_displacement | 5/3/W1 | 0.08840869021383466 | 0.08840867877006531 | 1.144e-08 |
| B01 run_metrics.csv: target_displacement | 5/5/W1 | 0.12471852073080227 | 0.12471853196620941 | 1.124e-08 |
| B01 run_metrics.csv: target_displacement | 6/3/W1 | 0.14113834351573198 | 0.14113834500312805 | 1.487e-09 |
| B01 run_metrics.csv: target_displacement | 6/5/W1 | 0.1345813687174297 | 0.13458137214183807 | 3.424e-09 |
| B01 run_metrics.csv: target_displacement | 7/1/W1 | 0.20771692820171822 | 0.2077169269323349 | 1.269e-09 |
| B01 run_metrics.csv: target_displacement | 7/2/W1 | 0.24884014611851632 | 0.24884015321731567 | 7.099e-09 |
| B01 run_metrics.csv: target_displacement | 7/3/W1 | 0.21967185308663686 | 0.2196718454360962 | 7.651e-09 |
| B01 run_metrics.csv: target_displacement | 7/4/W1 | 0.148614232597593 | 0.14861422777175903 | 4.826e-09 |
| B01 run_metrics.csv: target_displacement | 7/5/W1 | 0.12439780664820273 | 0.12439781427383423 | 7.626e-09 |
| B01 run_metrics.csv: target_displacement | 8/1/W1 | 0.3730651303500892 | 0.37306517362594604 | 4.328e-08 |
| B01 run_metrics.csv: target_displacement | 8/2/W1 | 0.37635744833252155 | 0.37635746598243713 | 1.765e-08 |
| B01 run_metrics.csv: target_displacement | 8/3/W1 | 0.2704638938959206 | 0.27046388387680054 | 1.002e-08 |
| B01 run_metrics.csv: target_displacement | 8/4/W1 | 0.3622472406778659 | 0.3622472286224365 | 1.206e-08 |
| B01 run_metrics.csv: target_displacement | 8/5/W1 | 0.2858915070473483 | 0.28589150309562683 | 3.952e-09 |
| B01 run_metrics.csv: target_displacement | 9/2/W1 | 0.14870941472134777 | 0.14870941638946533 | 1.668e-09 |
| B01 run_metrics.csv: target_displacement | 9/3/W1 | 0.130001087484813 | 0.13000108301639557 | 4.468e-09 |
| B01 run_metrics.csv: target_displacement | 9/4/W1 | 0.15837747902806756 | 0.15837746858596802 | 1.044e-08 |
| B01 run_metrics.csv: target_displacement | 9/5/W1 | 0.1686138063595156 | 0.16861379146575928 | 1.489e-08 |
| B01 run_metrics.csv: target_displacement | 10/1/W1 | 0.21091169810884064 | 0.21091169118881226 | 6.920e-09 |
| B01 run_metrics.csv: target_displacement | 10/2/W1 | 0.2311787823028248 | 0.23117880523204803 | 2.293e-08 |
| B01 run_metrics.csv: target_displacement | 10/3/W1 | 0.20010660941118336 | 0.20010660588741302 | 3.524e-09 |
| B01 run_metrics.csv: target_displacement | 10/4/W1 | 0.259224559975247 | 0.2592245638370514 | 3.862e-09 |
| B01 run_metrics.csv: target_displacement | 10/5/W1 | 0.16720521323571197 | 0.16720519959926605 | 1.364e-08 |
| B01 run_metrics.csv: target_displacement | 11/1/W1 | 0.3036253366229156 | 0.30362531542778015 | 2.120e-08 |
| B01 run_metrics.csv: target_displacement | 11/2/W1 | 0.28067544921214665 | 0.2806754410266876 | 8.185e-09 |
| B01 run_metrics.csv: target_displacement | 11/3/W1 | 0.2815736849852835 | 0.28157365322113037 | 3.176e-08 |
| B01 run_metrics.csv: target_displacement | 11/4/W1 | 0.2312561853538372 | 0.23125620186328888 | 1.651e-08 |
| B01 run_metrics.csv: target_displacement | 11/5/W1 | 0.32439154004224613 | 0.32439151406288147 | 2.598e-08 |
| B01 run_metrics.csv: target_displacement | 12/1/W1 | 0.2661589177395857 | 0.26615890860557556 | 9.134e-09 |
| B01 run_metrics.csv: target_displacement | 12/2/W1 | 0.19688703920366965 | 0.1968870609998703 | 2.180e-08 |
| B01 run_metrics.csv: target_displacement | 12/3/W1 | 0.27632466971623937 | 0.27632462978363037 | 3.993e-08 |
| B01 run_metrics.csv: target_displacement | 12/4/W1 | 0.22866447791527722 | 0.22866447269916534 | 5.216e-09 |
| B01 run_metrics.csv: target_displacement | 12/5/W1 | 0.21609507323827132 | 0.21609506011009216 | 1.313e-08 |
| B01 run_metrics.csv: target_displacement | 13/1/W1 | 0.3977697167304509 | 0.3977696895599365 | 2.717e-08 |
| B01 run_metrics.csv: target_displacement | 13/2/W1 | 0.4413495962270907 | 0.4413495659828186 | 3.024e-08 |
| B01 run_metrics.csv: target_displacement | 13/3/W1 | 0.4305968497684043 | 0.43059685826301575 | 8.495e-09 |
| B01 run_metrics.csv: target_displacement | 13/4/W1 | 0.41127270008548533 | 0.41127270460128784 | 4.516e-09 |
| B01 run_metrics.csv: target_displacement | 13/5/W1 | 0.4211686212789598 | 0.42116859555244446 | 2.573e-08 |
| B01 run_metrics.csv: target_displacement | 14/1/W1 | 0.17183121251428657 | 0.17183120548725128 | 7.027e-09 |
| B01 run_metrics.csv: target_displacement | 14/2/W1 | 0.24062997799923747 | 0.24062997102737427 | 6.972e-09 |
| B01 run_metrics.csv: target_displacement | 14/3/W1 | 0.21649642989638715 | 0.21649642288684845 | 7.010e-09 |
| B01 run_metrics.csv: target_displacement | 14/4/W1 | 0.17172043638949422 | 0.17172043025493622 | 6.135e-09 |
| B01 run_metrics.csv: target_displacement | 14/5/W1 | 0.19821093314997992 | 0.1982109397649765 | 6.615e-09 |
| B01 run_metrics.csv: target_displacement | 15/1/W1 | 0.09571712653156396 | 0.09571713209152222 | 5.560e-09 |
| B01 run_metrics.csv: target_displacement | 15/2/W1 | 0.09668153560470018 | 0.09668152779340744 | 7.811e-09 |
| B01 run_metrics.csv: target_displacement | 15/3/W1 | 0.08437901670785612 | 0.08437902480363846 | 8.096e-09 |
| B01 run_metrics.csv: target_displacement | 15/5/W1 | 0.09425739379204366 | 0.0942573994398117 | 5.648e-09 |
| B01 run_metrics.csv: target_displacement | 16/1/W1 | 0.34247429623395975 | 0.3424742817878723 | 1.445e-08 |
| B01 run_metrics.csv: target_displacement | 16/2/W1 | 0.3005521617348313 | 0.3005521297454834 | 3.199e-08 |
| B01 run_metrics.csv: target_displacement | 16/3/W1 | 0.24587837118279915 | 0.24587835371494293 | 1.747e-08 |
| B01 run_metrics.csv: target_displacement | 16/4/W1 | 0.3649324710876805 | 0.36493244767189026 | 2.342e-08 |
| B01 run_metrics.csv: target_displacement | 16/5/W1 | 0.23650855893097966 | 0.2365085631608963 | 4.230e-09 |
| B01 run_metrics.csv: target_displacement | 17/1/W1 | 0.1779653797915711 | 0.17796538770198822 | 7.910e-09 |
| B01 run_metrics.csv: target_displacement | 17/2/W1 | 0.19659729996875785 | 0.19659730792045593 | 7.952e-09 |
| B01 run_metrics.csv: target_displacement | 17/4/W1 | 0.19477185869581937 | 0.1947718858718872 | 2.718e-08 |
| B01 run_metrics.csv: target_displacement | 17/5/W1 | 0.1735071284018831 | 0.17350713908672333 | 1.068e-08 |
| B01 run_metrics.csv: target_displacement | 18/1/W1 | 0.10629547368499309 | 0.10629548132419586 | 7.639e-09 |
| B01 run_metrics.csv: target_displacement | 18/2/W1 | 0.11095104012081405 | 0.11095103621482849 | 3.906e-09 |
| B01 run_metrics.csv: target_displacement | 18/3/W1 | 0.1023606884454782 | 0.10236069560050964 | 7.155e-09 |
| B01 run_metrics.csv: target_displacement | 18/4/W1 | 0.12879070266961343 | 0.1287907063961029 | 3.726e-09 |
| B01 run_metrics.csv: target_displacement | 18/5/W1 | 0.16005758496140274 | 0.16005758941173553 | 4.450e-09 |
| B01 run_metrics.csv: target_displacement | 19/1/W1 | 0.1575537081522597 | 0.15755370259284973 | 5.559e-09 |
| B01 run_metrics.csv: target_displacement | 19/2/W1 | 0.13997260456485736 | 0.13997259736061096 | 7.204e-09 |
| B01 run_metrics.csv: target_displacement | 19/3/W1 | 0.1464471058021032 | 0.1464471071958542 | 1.394e-09 |
| B01 run_metrics.csv: target_displacement | 19/4/W1 | 0.1800520846373304 | 0.18005208671092987 | 2.074e-09 |
| B01 run_metrics.csv: target_displacement | 19/5/W1 | 0.1380143780558633 | 0.13801436126232147 | 1.679e-08 |
| B01 run_metrics.csv: target_displacement | 20/1/W1 | 0.30235746382759626 | 0.3023574650287628 | 1.201e-09 |
| B01 run_metrics.csv: target_displacement | 20/2/W1 | 0.24203126516776893 | 0.2420312762260437 | 1.106e-08 |
| B01 run_metrics.csv: target_displacement | 20/3/W1 | 0.2918488642979952 | 0.2918488681316376 | 3.834e-09 |
| B01 run_metrics.csv: target_displacement | 20/4/W1 | 0.3244889578714592 | 0.3244889974594116 | 3.959e-08 |
| B01 run_metrics.csv: target_displacement | 20/5/W1 | 0.4049914712806102 | 0.4049915075302124 | 3.625e-08 |
| B01 run_metrics.csv: target_displacement | 21/1/W1 | 0.08985466039890427 | 0.0898546576499939 | 2.749e-09 |
| B01 run_metrics.csv: target_displacement | 21/2/W1 | 0.07895480734829302 | 0.07895480841398239 | 1.066e-09 |
| B01 run_metrics.csv: target_displacement | 21/3/W1 | 0.08408520687594993 | 0.08408520370721817 | 3.169e-09 |
| B01 run_metrics.csv: target_displacement | 21/4/W1 | 0.07947667457022625 | 0.07947668433189392 | 9.762e-09 |
| B01 run_metrics.csv: target_displacement | 21/5/W1 | 0.09669366475919235 | 0.09669365733861923 | 7.421e-09 |
| B01 run_metrics.csv: target_displacement | 22/1/W1 | 0.22818932881376283 | 0.22818933427333832 | 5.460e-09 |
| B01 run_metrics.csv: target_displacement | 22/2/W1 | 0.21042424574992988 | 0.21042422950267792 | 1.625e-08 |
| B01 run_metrics.csv: target_displacement | 22/4/W1 | 0.23251872829207784 | 0.23251871764659882 | 1.065e-08 |
| B01 run_metrics.csv: target_displacement | 23/1/W1 | 0.36100098852106394 | 0.36100101470947266 | 2.619e-08 |
| B01 run_metrics.csv: target_displacement | 23/2/W1 | 0.18650220315170593 | 0.18650218844413757 | 1.471e-08 |
| B01 run_metrics.csv: target_displacement | 23/3/W1 | 0.17178752801016844 | 0.17178753018379211 | 2.174e-09 |
| B01 run_metrics.csv: target_displacement | 23/4/W1 | 0.22720894558188054 | 0.2272089123725891 | 3.321e-08 |
| B01 run_metrics.csv: target_displacement | 23/5/W1 | 0.1780856075858191 | 0.17808561027050018 | 2.685e-09 |
| B01 run_metrics.csv: target_displacement | 24/1/W1 | 0.2043673709505752 | 0.20436736941337585 | 1.537e-09 |
| B01 run_metrics.csv: target_displacement | 24/2/W1 | 0.13992125165015928 | 0.13992126286029816 | 1.121e-08 |
| B01 run_metrics.csv: target_displacement | 24/3/W1 | 0.1261091256456099 | 0.12610910832881927 | 1.732e-08 |
| B01 run_metrics.csv: target_displacement | 24/4/W1 | 0.21530894546791554 | 0.21530893445014954 | 1.102e-08 |
| B01 run_metrics.csv: target_displacement | 25/1/W1 | 0.1770980242180652 | 0.17709802091121674 | 3.307e-09 |
| B01 run_metrics.csv: target_displacement | 25/2/W1 | 0.15763281703201218 | 0.15763281285762787 | 4.174e-09 |
| B01 run_metrics.csv: target_displacement | 25/4/W1 | 0.14552579230878854 | 0.14552578330039978 | 9.008e-09 |
| B01 run_metrics.csv: target_displacement | 25/5/W1 | 0.1928862333438276 | 0.19288621842861176 | 1.492e-08 |
| B01 run_metrics.csv: target_displacement | 26/1/W1 | 0.5044461600845463 | 0.5044462084770203 | 4.839e-08 |
| B01 run_metrics.csv: target_displacement | 26/2/W1 | 0.47517262131099 | 0.47517263889312744 | 1.758e-08 |
| B01 run_metrics.csv: target_displacement | 26/3/W1 | 0.5223991785725692 | 0.5223991870880127 | 8.515e-09 |
| B01 run_metrics.csv: target_displacement | 26/4/W1 | 0.3220620972521099 | 0.32206207513809204 | 2.211e-08 |
| B01 run_metrics.csv: target_displacement | 26/5/W1 | 0.41382529092971554 | 0.41382527351379395 | 1.742e-08 |
| B01 run_metrics.csv: target_displacement | 27/1/W1 | 0.366329885260389 | 0.3663298785686493 | 6.692e-09 |
| B01 run_metrics.csv: target_displacement | 27/2/W1 | 0.14485320817689287 | 0.14485320448875427 | 3.688e-09 |
| B01 run_metrics.csv: target_displacement | 27/3/W1 | 0.1753365284105988 | 0.17533650994300842 | 1.847e-08 |
| B01 run_metrics.csv: target_displacement | 27/4/W1 | 0.3389757981209594 | 0.33897581696510315 | 1.884e-08 |
| B01 run_metrics.csv: target_displacement | 27/5/W1 | 0.3414945322703056 | 0.34149447083473206 | 6.144e-08 |
| B01 run_metrics.csv: target_displacement | 28/1/W1 | 0.1308711260384402 | 0.13087111711502075 | 8.923e-09 |
| B01 run_metrics.csv: target_displacement | 28/2/W1 | 0.13382203748009064 | 0.13382203876972198 | 1.290e-09 |
| B01 run_metrics.csv: target_displacement | 28/3/W1 | 0.08761245466540048 | 0.08761245757341385 | 2.908e-09 |
| B01 run_metrics.csv: target_displacement | 28/4/W1 | 0.13600948859092815 | 0.13600949943065643 | 1.084e-08 |
| B01 run_metrics.csv: target_displacement | 29/1/W1 | 0.11203298271503441 | 0.11203298717737198 | 4.462e-09 |
| B01 run_metrics.csv: target_displacement | 29/3/W1 | 0.08757190495196981 | 0.0875718966126442 | 8.339e-09 |
| B01 run_metrics.csv: target_displacement | 29/4/W1 | 0.10193442316838974 | 0.10193443298339844 | 9.815e-09 |
| B01 run_metrics.csv: target_displacement | 29/5/W1 | 0.10451205791893381 | 0.1045120507478714 | 7.171e-09 |
| B01 run_metrics.csv: target_displacement | 30/1/W1 | 0.11597422980826169 | 0.11597422510385513 | 4.704e-09 |
| B01 run_metrics.csv: target_displacement | 30/2/W1 | 0.09245233454379856 | 0.09245232492685318 | 9.617e-09 |
| B01 run_metrics.csv: target_displacement | 30/3/W1 | 0.09629069550857983 | 0.0962906926870346 | 2.822e-09 |
| B01 run_metrics.csv: target_displacement | 30/4/W1 | 0.11189574503773496 | 0.11189575493335724 | 9.896e-09 |
| B01 run_metrics.csv: target_displacement | 30/5/W1 | 0.12023168551313193 | 0.12023169547319412 | 9.960e-09 |
| B01 run_metrics.csv: target_displacement | 31/1/W1 | 0.27646894818372036 | 0.276468962430954 | 1.425e-08 |
| B01 run_metrics.csv: target_displacement | 31/2/W1 | 0.22207072924837137 | 0.22207075357437134 | 2.433e-08 |
| B01 run_metrics.csv: target_displacement | 31/3/W1 | 0.19688180275098552 | 0.19688181579113007 | 1.304e-08 |
| B01 run_metrics.csv: target_displacement | 31/4/W1 | 0.2070923427807454 | 0.20709234476089478 | 1.980e-09 |
| B01 run_metrics.csv: target_displacement | 31/5/W1 | 0.21489489937982353 | 0.21489490568637848 | 6.307e-09 |
| B01 run_metrics.csv: target_displacement | 32/3/W1 | 0.06166636081337368 | 0.06166635826230049 | 2.551e-09 |
| B01 run_metrics.csv: target_displacement | 32/4/W1 | 0.07245652279294304 | 0.07245651632547379 | 6.467e-09 |
| B01 run_metrics.csv: target_displacement | 33/1/W1 | 0.08766293692647599 | 0.08766292780637741 | 9.120e-09 |
| B01 run_metrics.csv: target_displacement | 33/2/W1 | 0.0819334398160503 | 0.08193343877792358 | 1.038e-09 |
| B01 run_metrics.csv: target_displacement | 33/3/W1 | 0.08184238932872946 | 0.08184239268302917 | 3.354e-09 |
| B01 run_metrics.csv: target_displacement | 33/4/W1 | 0.12388624823692952 | 0.12388624250888824 | 5.728e-09 |
| B01 run_metrics.csv: target_displacement | 33/5/W1 | 0.10263606993892203 | 0.10263607650995255 | 6.571e-09 |
| B01 run_metrics.csv: target_displacement | 34/1/W1 | 0.2809231543724464 | 0.28092312812805176 | 2.624e-08 |
| B01 run_metrics.csv: target_displacement | 34/2/W1 | 0.28903736561029614 | 0.2890373766422272 | 1.103e-08 |
| B01 run_metrics.csv: target_displacement | 34/3/W1 | 0.30145328233851376 | 0.30145329236984253 | 1.003e-08 |
| B01 run_metrics.csv: target_displacement | 34/4/W1 | 0.30784271881698855 | 0.3078427016735077 | 1.714e-08 |
| B01 run_metrics.csv: target_displacement | 34/5/W1 | 0.272113898956696 | 0.2721138894557953 | 9.501e-09 |
| B01 run_metrics.csv: target_displacement | 35/1/W1 | 0.08042842291064929 | 0.08042842149734497 | 1.413e-09 |
| B01 run_metrics.csv: target_displacement | 35/2/W1 | 0.08306968649394979 | 0.08306968957185745 | 3.078e-09 |
| B01 run_metrics.csv: target_displacement | 35/3/W1 | 0.08018907758999533 | 0.0801890641450882 | 1.344e-08 |
| B01 run_metrics.csv: target_displacement | 35/4/W1 | 0.08613628702884726 | 0.08613628149032593 | 5.539e-09 |
| B01 run_metrics.csv: target_displacement | 35/5/W1 | 0.08668927515295778 | 0.08668927103281021 | 4.120e-09 |
| B01 run_metrics.csv: target_displacement | 36/1/W1 | 0.07383223306109024 | 0.07383223623037338 | 3.169e-09 |
| B01 run_metrics.csv: target_displacement | 36/2/W1 | 0.07588880145382589 | 0.07588880509138107 | 3.638e-09 |
| B01 run_metrics.csv: target_displacement | 36/4/W1 | 0.07122752798517604 | 0.0712275356054306 | 7.620e-09 |
| B01 run_metrics.csv: target_displacement | 36/5/W1 | 0.07013539439875835 | 0.07013539224863052 | 2.150e-09 |
| B01 run_metrics.csv: target_displacement | 37/1/W1 | 0.08005489820203937 | 0.08005489408969879 | 4.112e-09 |
| B01 run_metrics.csv: target_displacement | 37/2/W1 | 0.08588615722918141 | 0.0858861654996872 | 8.271e-09 |
| B01 run_metrics.csv: target_displacement | 37/3/W1 | 0.08688577137649943 | 0.08688576519489288 | 6.182e-09 |
| B01 run_metrics.csv: target_displacement | 37/4/W1 | 0.09128500038512075 | 0.09128499776124954 | 2.624e-09 |
| B01 run_metrics.csv: target_displacement | 37/5/W1 | 0.09015592505994043 | 0.0901559367775917 | 1.172e-08 |
| B01 run_metrics.csv: target_displacement | 38/1/W1 | 0.20949026922510355 | 0.20949028432369232 | 1.510e-08 |
| B01 run_metrics.csv: target_displacement | 38/3/W1 | 0.13808288555874798 | 0.13808289170265198 | 6.144e-09 |
| B01 run_metrics.csv: target_displacement | 38/4/W1 | 0.1498957955810258 | 0.1498958021402359 | 6.559e-09 |
| B01 run_metrics.csv: target_displacement | 38/5/W1 | 0.1400614773655691 | 0.14006148278713226 | 5.422e-09 |
| B01 run_metrics.csv: target_displacement | 39/1/W1 | 0.21981308882198305 | 0.21981309354305267 | 4.721e-09 |
| B01 run_metrics.csv: target_displacement | 39/2/W1 | 0.19268024993952904 | 0.1926802694797516 | 1.954e-08 |
| B01 run_metrics.csv: target_displacement | 39/3/W1 | 0.1883129986411495 | 0.18831300735473633 | 8.714e-09 |
| B01 run_metrics.csv: target_displacement | 39/4/W1 | 0.15823110373106034 | 0.15823110938072205 | 5.650e-09 |
| B01 run_metrics.csv: target_displacement | 39/5/W1 | 0.1700006115310925 | 0.17000062763690948 | 1.611e-08 |
| B01 run_metrics.csv: target_displacement | 40/1/W1 | 0.2115390749645724 | 0.21153905987739563 | 1.509e-08 |
| B01 run_metrics.csv: target_displacement | 40/2/W1 | 0.16462297317753688 | 0.164622962474823 | 1.070e-08 |
| B01 run_metrics.csv: target_displacement | 40/4/W1 | 0.15862500340922453 | 0.15862499177455902 | 1.163e-08 |
| B01 run_metrics.csv: target_displacement | 40/5/W1 | 0.1896526661353423 | 0.1896526962518692 | 3.012e-08 |
| B01 run_metrics.csv: target_displacement | 41/1/W1 | 0.19089429959003695 | 0.19089430570602417 | 6.116e-09 |
| B01 run_metrics.csv: target_displacement | 41/2/W1 | 0.18476233379789694 | 0.18476234376430511 | 9.966e-09 |
| B01 run_metrics.csv: target_displacement | 41/3/W1 | 0.17667967437771093 | 0.17667967081069946 | 3.567e-09 |
| B01 run_metrics.csv: target_displacement | 41/4/W1 | 0.12753442447360894 | 0.1275344341993332 | 9.726e-09 |
| B01 run_metrics.csv: target_displacement | 41/5/W1 | 0.19052167415847787 | 0.19052167236804962 | 1.790e-09 |
| B01 run_metrics.csv: target_displacement | 42/1/W1 | 0.2874861825200823 | 0.28748619556427 | 1.304e-08 |
| B01 run_metrics.csv: target_displacement | 42/3/W1 | 0.24101967946265548 | 0.24101966619491577 | 1.327e-08 |
| B01 run_metrics.csv: target_displacement | 42/4/W1 | 0.18284534179414685 | 0.1828453242778778 | 1.752e-08 |
| B01 run_metrics.csv: target_displacement | 42/5/W1 | 0.27101215649993937 | 0.27101218700408936 | 3.050e-08 |
| B01 run_metrics.csv: target_displacement | 43/1/W1 | 0.17158106597371464 | 0.17158107459545135 | 8.622e-09 |
| B01 run_metrics.csv: target_displacement | 43/2/W1 | 0.16208193608901997 | 0.16208194196224213 | 5.873e-09 |
| B01 run_metrics.csv: target_displacement | 43/3/W1 | 0.1456590646043151 | 0.14565905928611755 | 5.318e-09 |
| B01 run_metrics.csv: target_displacement | 43/4/W1 | 0.15569178673424966 | 0.15569180250167847 | 1.577e-08 |
| B01 run_metrics.csv: target_displacement | 44/2/W1 | 0.1539872639911442 | 0.15398725867271423 | 5.318e-09 |
| B01 run_metrics.csv: target_displacement | 44/3/W1 | 0.12318013542395816 | 0.12318014353513718 | 8.111e-09 |
| B01 run_metrics.csv: target_displacement | 44/4/W1 | 0.24200738010629386 | 0.24200737476348877 | 5.343e-09 |
| B01 run_metrics.csv: target_displacement | 44/5/W1 | 0.10926623163075166 | 0.1092662364244461 | 4.794e-09 |
| B01 run_metrics.csv: target_displacement | 45/1/W1 | 0.12026869884488663 | 0.12026870995759964 | 1.111e-08 |
| B01 run_metrics.csv: target_displacement | 45/2/W1 | 0.13112771774575133 | 0.13112770020961761 | 1.754e-08 |
| B01 run_metrics.csv: target_displacement | 45/3/W1 | 0.13055896594227576 | 0.13055895268917084 | 1.325e-08 |
| B01 run_metrics.csv: target_displacement | 45/4/W1 | 0.11618522451500919 | 0.11618523299694061 | 8.482e-09 |
| B01 run_metrics.csv: target_displacement | 45/5/W1 | 0.15143983170060266 | 0.15143983066082 | 1.040e-09 |
| B01 run_metrics.csv: target_displacement | 46/1/W1 | 0.32717738190645457 | 0.32717740535736084 | 2.345e-08 |
| B01 run_metrics.csv: target_displacement | 46/2/W1 | 0.2671709695360927 | 0.2671709656715393 | 3.865e-09 |
| B01 run_metrics.csv: target_displacement | 46/3/W1 | 0.25846126068464864 | 0.25846123695373535 | 2.373e-08 |
| B01 run_metrics.csv: target_displacement | 46/4/W1 | 0.2562647425538116 | 0.25626474618911743 | 3.635e-09 |
| B01 run_metrics.csv: target_displacement | 46/5/W1 | 0.26739438095204243 | 0.26739436388015747 | 1.707e-08 |
| B01 run_metrics.csv: target_displacement | 47/1/W1 | 0.3926794941388575 | 0.39267948269844055 | 1.144e-08 |
| B01 run_metrics.csv: target_displacement | 47/2/W1 | 0.3792075403589222 | 0.3792075216770172 | 1.868e-08 |
| B01 run_metrics.csv: target_displacement | 47/3/W1 | 0.44771351579628493 | 0.4477134644985199 | 5.130e-08 |
| B01 run_metrics.csv: target_displacement | 47/4/W1 | 0.43974618498042195 | 0.4397462010383606 | 1.606e-08 |
| B01 run_metrics.csv: target_displacement | 47/5/W1 | 0.509251561587603 | 0.509251594543457 | 3.296e-08 |
| B01 run_metrics.csv: target_displacement | 48/1/W1 | 0.18934083871945545 | 0.18934084475040436 | 6.031e-09 |
| B01 run_metrics.csv: target_displacement | 48/2/W1 | 0.23313863928136025 | 0.23313863575458527 | 3.527e-09 |
| B01 run_metrics.csv: target_displacement | 48/3/W1 | 0.23769792480468932 | 0.23769792914390564 | 4.339e-09 |
| B01 run_metrics.csv: target_displacement | 48/4/W1 | 0.22897441800032342 | 0.22897440195083618 | 1.605e-08 |
| B01 run_metrics.csv: target_displacement | 48/5/W1 | 0.18890502212110558 | 0.1889050453901291 | 2.327e-08 |
| B01 run_metrics.csv: target_displacement | 49/1/W1 | 0.1817873788183483 | 0.1817874014377594 | 2.262e-08 |
| B01 run_metrics.csv: target_displacement | 49/2/W1 | 0.16189965049053612 | 0.1618996560573578 | 5.567e-09 |
| B01 run_metrics.csv: target_displacement | 49/3/W1 | 0.17169408787845974 | 0.1716940850019455 | 2.877e-09 |
| B01 run_metrics.csv: target_displacement | 49/4/W1 | 0.2496097799364825 | 0.2496097981929779 | 1.826e-08 |
| B01 run_metrics.csv: target_displacement | 50/1/W1 | 0.15116922718105574 | 0.15116924047470093 | 1.329e-08 |
| B01 run_metrics.csv: target_displacement | 50/2/W1 | 0.10692147261362869 | 0.1069214791059494 | 6.492e-09 |
| B01 run_metrics.csv: target_displacement | 50/3/W1 | 0.16285267700281827 | 0.1628526896238327 | 1.262e-08 |
| B01 run_metrics.csv: target_displacement | 50/4/W1 | 0.1418746472430204 | 0.14187464118003845 | 6.063e-09 |
| B01 run_metrics.csv: target_displacement | 50/5/W1 | 0.17684541840371648 | 0.17684540152549744 | 1.688e-08 |
| B01 run_metrics.csv: target_displacement | 51/1/W1 | 0.315547536870554 | 0.31554752588272095 | 1.099e-08 |
| B01 run_metrics.csv: target_displacement | 51/3/W1 | 0.31305153027340876 | 0.3130515217781067 | 8.495e-09 |
| B01 run_metrics.csv: target_displacement | 51/4/W1 | 0.34382295447934774 | 0.3438229262828827 | 2.820e-08 |
| B01 run_metrics.csv: target_displacement | 51/5/W1 | 0.38566173852835683 | 0.38566169142723083 | 4.710e-08 |
| B01 run_metrics.csv: target_displacement | 52/1/W1 | 0.2569415043282768 | 0.2569414973258972 | 7.002e-09 |
| B01 run_metrics.csv: target_displacement | 52/2/W1 | 0.2678765081622738 | 0.2678765058517456 | 2.311e-09 |
| B01 run_metrics.csv: target_displacement | 52/3/W1 | 0.29003298986977666 | 0.2900329828262329 | 7.044e-09 |
| B01 run_metrics.csv: target_displacement | 52/4/W1 | 0.20852834193543157 | 0.2085283398628235 | 2.073e-09 |
| B01 run_metrics.csv: target_displacement | 52/5/W1 | 0.29353580686580405 | 0.2935357987880707 | 8.078e-09 |
| B01 run_metrics.csv: target_displacement | 53/1/W1 | 0.26540633108679346 | 0.2654063105583191 | 2.053e-08 |
| B01 run_metrics.csv: target_displacement | 53/2/W1 | 0.33744629068472515 | 0.3374462425708771 | 4.811e-08 |
| B01 run_metrics.csv: target_displacement | 53/3/W1 | 0.2872547333038134 | 0.2872547209262848 | 1.238e-08 |
| B01 run_metrics.csv: target_displacement | 53/4/W1 | 0.22784200927627005 | 0.22784198820590973 | 2.107e-08 |
| B01 run_metrics.csv: target_displacement | 53/5/W1 | 0.3635277404941333 | 0.36352774500846863 | 4.514e-09 |
| B01 run_metrics.csv: target_displacement | 54/1/W1 | 0.4472498911484431 | 0.4472498595714569 | 3.158e-08 |
| B01 run_metrics.csv: target_displacement | 54/2/W1 | 0.404773675507303 | 0.40477368235588074 | 6.849e-09 |
| B01 run_metrics.csv: target_displacement | 54/3/W1 | 0.32758789107199404 | 0.32758793234825134 | 4.128e-08 |
| B01 run_metrics.csv: target_displacement | 54/4/W1 | 0.3196431647767816 | 0.31964313983917236 | 2.494e-08 |
| B01 run_metrics.csv: target_displacement | 54/5/W1 | 0.44196475151530157 | 0.4419647455215454 | 5.994e-09 |
| B01 run_metrics.csv: target_displacement | 1/1/W4 | 0.06261371462978454 | 0.06261371821165085 | 3.582e-09 |
| B01 run_metrics.csv: target_displacement | 1/2/W4 | 0.04863922781856886 | 0.04863923043012619 | 2.612e-09 |
| B01 run_metrics.csv: target_displacement | 1/3/W4 | 0.04382368769181959 | 0.04382369667291641 | 8.981e-09 |
| B01 run_metrics.csv: target_displacement | 1/4/W4 | 0.048422018699471915 | 0.04842201620340347 | 2.496e-09 |
| B01 run_metrics.csv: target_displacement | 1/5/W4 | 0.05634565170858329 | 0.05634564533829689 | 6.370e-09 |
| B01 run_metrics.csv: target_displacement | 2/2/W4 | 0.01565436538670845 | 0.015654362738132477 | 2.649e-09 |
| B01 run_metrics.csv: target_displacement | 2/4/W4 | 0.013021097315985086 | 0.01302109844982624 | 1.134e-09 |
| B01 run_metrics.csv: target_displacement | 3/5/W4 | 0.022957356193507167 | 0.02295735292136669 | 3.272e-09 |
| B01 run_metrics.csv: target_displacement | 4/1/W4 | 0.029368926842305628 | 0.02936892956495285 | 2.723e-09 |
| B01 run_metrics.csv: target_displacement | 4/2/W4 | 0.027656786453712483 | 0.027656788006424904 | 1.553e-09 |
| B01 run_metrics.csv: target_displacement | 4/4/W4 | 0.029402305061637834 | 0.02940230816602707 | 3.104e-09 |
| B01 run_metrics.csv: target_displacement | 5/1/W4 | 0.01800649931205529 | 0.018006501719355583 | 2.407e-09 |
| B01 run_metrics.csv: target_displacement | 6/1/W4 | 0.021764108721220036 | 0.021764110773801804 | 2.053e-09 |
| B01 run_metrics.csv: target_displacement | 6/2/W4 | 0.01892386866852646 | 0.018923871219158173 | 2.551e-09 |
| B01 run_metrics.csv: target_displacement | 6/5/W4 | 0.01712402312145105 | 0.01712402142584324 | 1.696e-09 |
| B01 run_metrics.csv: target_displacement | 7/1/W4 | 0.028898752788428156 | 0.028898751363158226 | 1.425e-09 |
| B01 run_metrics.csv: target_displacement | 7/3/W4 | 0.03603887394468888 | 0.036038871854543686 | 2.090e-09 |
| B01 run_metrics.csv: target_displacement | 7/4/W4 | 0.019924828676608927 | 0.0199248306453228 | 1.969e-09 |
| B01 run_metrics.csv: target_displacement | 7/5/W4 | 0.014366598637115358 | 0.01436659973114729 | 1.094e-09 |
| B01 run_metrics.csv: target_displacement | 8/1/W4 | 0.060202589963041175 | 0.06020258367061615 | 6.292e-09 |
| B01 run_metrics.csv: target_displacement | 8/2/W4 | 0.05545791068371952 | 0.05545791611075401 | 5.427e-09 |
| B01 run_metrics.csv: target_displacement | 8/3/W4 | 0.04567999729170873 | 0.04567999392747879 | 3.364e-09 |
| B01 run_metrics.csv: target_displacement | 8/5/W4 | 0.048865819058979305 | 0.04886581376194954 | 5.297e-09 |
| B01 run_metrics.csv: target_displacement | 9/1/W4 | 0.02418549689671813 | 0.02418549545109272 | 1.446e-09 |
| B01 run_metrics.csv: target_displacement | 9/2/W4 | 0.023402646393664964 | 0.02340264804661274 | 1.653e-09 |
| B01 run_metrics.csv: target_displacement | 9/4/W4 | 0.02370485591304799 | 0.023704854771494865 | 1.142e-09 |
| B01 run_metrics.csv: target_displacement | 9/5/W4 | 0.026247114172342954 | 0.026247112080454826 | 2.092e-09 |
| B01 run_metrics.csv: target_displacement | 10/1/W4 | 0.03105648075198017 | 0.0310564823448658 | 1.593e-09 |
| B01 run_metrics.csv: target_displacement | 10/2/W4 | 0.04121236639051065 | 0.04121236875653267 | 2.366e-09 |
| B01 run_metrics.csv: target_displacement | 10/3/W4 | 0.03436991995416438 | 0.034369923174381256 | 3.220e-09 |
| B01 run_metrics.csv: target_displacement | 10/4/W4 | 0.03939625667755516 | 0.0393962599337101 | 3.256e-09 |
| B01 run_metrics.csv: target_displacement | 10/5/W4 | 0.024779097002511977 | 0.024779092520475388 | 4.482e-09 |
| B01 run_metrics.csv: target_displacement | 11/1/W4 | 0.046660141087671934 | 0.04666014760732651 | 6.520e-09 |
| B01 run_metrics.csv: target_displacement | 11/2/W4 | 0.04436097804447727 | 0.04436098411679268 | 6.072e-09 |
| B01 run_metrics.csv: target_displacement | 11/3/W4 | 0.0477353605029941 | 0.047735366970300674 | 6.467e-09 |
| B01 run_metrics.csv: target_displacement | 11/4/W4 | 0.031137837737823366 | 0.03113783523440361 | 2.503e-09 |
| B01 run_metrics.csv: target_displacement | 11/5/W4 | 0.046244747345052406 | 0.04624474421143532 | 3.134e-09 |
| B01 run_metrics.csv: target_displacement | 12/1/W4 | 0.03686460285147439 | 0.03686460480093956 | 1.949e-09 |
| B01 run_metrics.csv: target_displacement | 12/2/W4 | 0.028623089963823865 | 0.02862309291958809 | 2.956e-09 |
| B01 run_metrics.csv: target_displacement | 12/3/W4 | 0.0498407543240833 | 0.04984074458479881 | 9.739e-09 |
| B01 run_metrics.csv: target_displacement | 12/4/W4 | 0.03572093760117866 | 0.035720933228731155 | 4.372e-09 |
| B01 run_metrics.csv: target_displacement | 12/5/W4 | 0.03276937603060782 | 0.032769378274679184 | 2.244e-09 |
| B01 run_metrics.csv: target_displacement | 13/1/W4 | 0.09000660338085698 | 0.09000659734010696 | 6.041e-09 |
| B01 run_metrics.csv: target_displacement | 13/2/W4 | 0.10638999342506134 | 0.10638997703790665 | 1.639e-08 |
| B01 run_metrics.csv: target_displacement | 13/3/W4 | 0.10700258709454072 | 0.10700259357690811 | 6.482e-09 |
| B01 run_metrics.csv: target_displacement | 13/4/W4 | 0.082134041804301 | 0.08213403820991516 | 3.594e-09 |
| B01 run_metrics.csv: target_displacement | 13/5/W4 | 0.08860804162263226 | 0.08860804885625839 | 7.234e-09 |
| B01 run_metrics.csv: target_displacement | 14/1/W4 | 0.023966137345595037 | 0.023966139182448387 | 1.837e-09 |
| B01 run_metrics.csv: target_displacement | 14/2/W4 | 0.03804636257245742 | 0.03804636374115944 | 1.169e-09 |
| B01 run_metrics.csv: target_displacement | 15/5/W4 | 0.015471711203675954 | 0.015471712686121464 | 1.482e-09 |
| B01 run_metrics.csv: target_displacement | 16/1/W4 | 0.05654717367599099 | 0.05654717609286308 | 2.417e-09 |
| B01 run_metrics.csv: target_displacement | 16/2/W4 | 0.034736079976415965 | 0.03473607823252678 | 1.744e-09 |
| B01 run_metrics.csv: target_displacement | 16/3/W4 | 0.03087546423918191 | 0.030875463038682938 | 1.200e-09 |
| B01 run_metrics.csv: target_displacement | 16/5/W4 | 0.04419476817755706 | 0.04419476538896561 | 2.789e-09 |
| B01 run_metrics.csv: target_displacement | 17/1/W4 | 0.02137642373140757 | 0.02137642540037632 | 1.669e-09 |
| B01 run_metrics.csv: target_displacement | 17/4/W4 | 0.025154462014011492 | 0.025154460221529007 | 1.792e-09 |
| B01 run_metrics.csv: target_displacement | 18/1/W4 | 0.01690841051461862 | 0.01690840907394886 | 1.441e-09 |
| B01 run_metrics.csv: target_displacement | 18/5/W4 | 0.021934109355713004 | 0.021934110671281815 | 1.316e-09 |
| B01 run_metrics.csv: target_displacement | 19/1/W4 | 0.019945159187944646 | 0.019945157691836357 | 1.496e-09 |
| B01 run_metrics.csv: target_displacement | 19/2/W4 | 0.018473545433611575 | 0.018473543226718903 | 2.207e-09 |
| B01 run_metrics.csv: target_displacement | 19/3/W4 | 0.0216591586787795 | 0.021659160032868385 | 1.354e-09 |
| B01 run_metrics.csv: target_displacement | 20/1/W4 | 0.057591948984404874 | 0.05759195238351822 | 3.399e-09 |
| B01 run_metrics.csv: target_displacement | 20/2/W4 | 0.04941840143653467 | 0.04941840469837189 | 3.262e-09 |
| B01 run_metrics.csv: target_displacement | 20/3/W4 | 0.04803782795424676 | 0.0480378232896328 | 4.665e-09 |
| B01 run_metrics.csv: target_displacement | 20/4/W4 | 0.051680070462663937 | 0.0516800656914711 | 4.771e-09 |
| B01 run_metrics.csv: target_displacement | 20/5/W4 | 0.06678311639562932 | 0.0667831152677536 | 1.128e-09 |
| B01 run_metrics.csv: target_displacement | 21/1/W4 | 0.017290381316127968 | 0.017290379852056503 | 1.464e-09 |
| B01 run_metrics.csv: target_displacement | 22/1/W4 | 0.028583135863016067 | 0.028583133593201637 | 2.270e-09 |
| B01 run_metrics.csv: target_displacement | 22/2/W4 | 0.028704859175029976 | 0.02870485745370388 | 1.721e-09 |
| B01 run_metrics.csv: target_displacement | 22/3/W4 | 0.02449323303209832 | 0.024493234232068062 | 1.200e-09 |
| B01 run_metrics.csv: target_displacement | 23/1/W4 | 0.05284436131076413 | 0.05284435674548149 | 4.565e-09 |
| B01 run_metrics.csv: target_displacement | 23/3/W4 | 0.016812179620699433 | 0.016812177374958992 | 2.246e-09 |
| B01 run_metrics.csv: target_displacement | 23/4/W4 | 0.037539658402363674 | 0.037539657205343246 | 1.197e-09 |
| B01 run_metrics.csv: target_displacement | 24/1/W4 | 0.01674634765899294 | 0.016746345907449722 | 1.752e-09 |
| B01 run_metrics.csv: target_displacement | 24/5/W4 | 0.019172613169941375 | 0.019172614440321922 | 1.270e-09 |
| B01 run_metrics.csv: target_displacement | 26/1/W4 | 0.1194056266323993 | 0.11940563470125198 | 8.069e-09 |
| B01 run_metrics.csv: target_displacement | 26/2/W4 | 0.08384852804561288 | 0.0838485136628151 | 1.438e-08 |
| B01 run_metrics.csv: target_displacement | 26/3/W4 | 0.11529626037738788 | 0.11529625207185745 | 8.306e-09 |
| B01 run_metrics.csv: target_displacement | 26/4/W4 | 0.040046168815112075 | 0.040046170353889465 | 1.539e-09 |
| B01 run_metrics.csv: target_displacement | 26/5/W4 | 0.06486089539083928 | 0.06486088782548904 | 7.565e-09 |
| B01 run_metrics.csv: target_displacement | 27/1/W4 | 0.04976130301767841 | 0.04976130649447441 | 3.477e-09 |
| B01 run_metrics.csv: target_displacement | 27/4/W4 | 0.03946391745517209 | 0.039463918656110764 | 1.201e-09 |
| B01 run_metrics.csv: target_displacement | 27/5/W4 | 0.04486681348878624 | 0.04486681893467903 | 5.446e-09 |
| B01 run_metrics.csv: target_displacement | 28/2/W4 | 0.023737520294743086 | 0.02373751811683178 | 2.178e-09 |
| B01 run_metrics.csv: target_displacement | 29/3/W4 | 0.013575212916480369 | 0.013575213961303234 | 1.045e-09 |
| B01 run_metrics.csv: target_displacement | 29/5/W4 | 0.022298961740668765 | 0.022298960015177727 | 1.725e-09 |
| B01 run_metrics.csv: target_displacement | 30/4/W4 | 0.012341804689591758 | 0.01234180573374033 | 1.044e-09 |
| B01 run_metrics.csv: target_displacement | 31/3/W4 | 0.028336462301541666 | 0.02833646535873413 | 3.057e-09 |
| B01 run_metrics.csv: target_displacement | 31/5/W4 | 0.035420562057998844 | 0.03542055934667587 | 2.711e-09 |
| B01 run_metrics.csv: target_displacement | 32/2/W4 | 0.012209721342049222 | 0.01220971904695034 | 2.295e-09 |
| B01 run_metrics.csv: target_displacement | 33/3/W4 | 0.01593134526157554 | 0.015931343659758568 | 1.602e-09 |
| B01 run_metrics.csv: target_displacement | 34/2/W4 | 0.05053532883166095 | 0.050535332411527634 | 3.580e-09 |
| B01 run_metrics.csv: target_displacement | 34/3/W4 | 0.05595546453906063 | 0.05595546215772629 | 2.381e-09 |
| B01 run_metrics.csv: target_displacement | 34/4/W4 | 0.04679785456087918 | 0.04679785296320915 | 1.598e-09 |
| B01 run_metrics.csv: target_displacement | 34/5/W4 | 0.043723058554060217 | 0.04372306913137436 | 1.058e-08 |
| B01 run_metrics.csv: target_displacement | 36/2/W4 | 0.013123361298796274 | 0.013123362325131893 | 1.026e-09 |
| B01 run_metrics.csv: target_displacement | 36/4/W4 | 0.01083324417661262 | 0.010833242908120155 | 1.268e-09 |
| B01 run_metrics.csv: target_displacement | 37/5/W4 | 0.017061283768628435 | 0.017061281949281693 | 1.819e-09 |
| B01 run_metrics.csv: target_displacement | 38/1/W4 | 0.020926793449510327 | 0.02092679589986801 | 2.450e-09 |
| B01 run_metrics.csv: target_displacement | 39/3/W4 | 0.034983621706385776 | 0.034983620047569275 | 1.659e-09 |
| B01 run_metrics.csv: target_displacement | 39/5/W4 | 0.027255114757375475 | 0.027255112305283546 | 2.452e-09 |
| B01 run_metrics.csv: target_displacement | 40/1/W4 | 0.02814797854172544 | 0.028147980570793152 | 2.029e-09 |
| B01 run_metrics.csv: target_displacement | 40/5/W4 | 0.02313281635883275 | 0.023132817819714546 | 1.461e-09 |
| B01 run_metrics.csv: target_displacement | 41/2/W4 | 0.017341206539427282 | 0.017341207712888718 | 1.173e-09 |
| B01 run_metrics.csv: target_displacement | 41/5/W4 | 0.01637282077443155 | 0.01637282222509384 | 1.451e-09 |
| B01 run_metrics.csv: target_displacement | 42/1/W4 | 0.04199509011559754 | 0.0419950932264328 | 3.111e-09 |
| B01 run_metrics.csv: target_displacement | 42/2/W4 | 0.02840739195069107 | 0.028407389298081398 | 2.653e-09 |
| B01 run_metrics.csv: target_displacement | 42/3/W4 | 0.027036306724745378 | 0.027036303654313087 | 3.070e-09 |
| B01 run_metrics.csv: target_displacement | 42/4/W4 | 0.021438277395318794 | 0.021438276395201683 | 1.000e-09 |
| B01 run_metrics.csv: target_displacement | 43/1/W4 | 0.020330151385623548 | 0.020330149680376053 | 1.705e-09 |
| B01 run_metrics.csv: target_displacement | 43/2/W4 | 0.02127741671086106 | 0.021277418360114098 | 1.649e-09 |
| B01 run_metrics.csv: target_displacement | 43/3/W4 | 0.022234817114396278 | 0.02223481610417366 | 1.010e-09 |
| B01 run_metrics.csv: target_displacement | 43/5/W4 | 0.04603390595948323 | 0.04603390395641327 | 2.003e-09 |
| B01 run_metrics.csv: target_displacement | 44/2/W4 | 0.02222483556498916 | 0.02222483791410923 | 2.349e-09 |
| B01 run_metrics.csv: target_displacement | 44/4/W4 | 0.02659869942526303 | 0.026598701253533363 | 1.828e-09 |
| B01 run_metrics.csv: target_displacement | 45/1/W4 | 0.017676161027329284 | 0.017676159739494324 | 1.288e-09 |
| B01 run_metrics.csv: target_displacement | 45/2/W4 | 0.020565447631838204 | 0.020565444603562355 | 3.028e-09 |
| B01 run_metrics.csv: target_displacement | 45/3/W4 | 0.02061045482191866 | 0.02061045728623867 | 2.464e-09 |
| B01 run_metrics.csv: target_displacement | 45/4/W4 | 0.01890169517080413 | 0.018901696428656578 | 1.258e-09 |
| B01 run_metrics.csv: target_displacement | 45/5/W4 | 0.021195298125924637 | 0.021195299923419952 | 1.797e-09 |
| B01 run_metrics.csv: target_displacement | 46/1/W4 | 0.05033832133904524 | 0.050338324159383774 | 2.820e-09 |
| B01 run_metrics.csv: target_displacement | 46/2/W4 | 0.05014971589412251 | 0.05014971271157265 | 3.183e-09 |
| B01 run_metrics.csv: target_displacement | 46/3/W4 | 0.0398958304624389 | 0.03989582881331444 | 1.649e-09 |
| B01 run_metrics.csv: target_displacement | 46/4/W4 | 0.03554221439720339 | 0.035542212426662445 | 1.971e-09 |
| B01 run_metrics.csv: target_displacement | 46/5/W4 | 0.04722840509832895 | 0.04722840338945389 | 1.709e-09 |
| B01 run_metrics.csv: target_displacement | 47/1/W4 | 0.08952697985373476 | 0.08952698856592178 | 8.712e-09 |
| B01 run_metrics.csv: target_displacement | 47/2/W4 | 0.07171893526592697 | 0.07171893864870071 | 3.383e-09 |
| B01 run_metrics.csv: target_displacement | 47/3/W4 | 0.10210815870099647 | 0.10210816562175751 | 6.921e-09 |
| B01 run_metrics.csv: target_displacement | 47/4/W4 | 0.08942360631620444 | 0.08942361921072006 | 1.289e-08 |
| B01 run_metrics.csv: target_displacement | 48/3/W4 | 0.03455204407695906 | 0.03455204516649246 | 1.090e-09 |
| B01 run_metrics.csv: target_displacement | 48/5/W4 | 0.025502352302851184 | 0.02550235018134117 | 2.122e-09 |
| B01 run_metrics.csv: target_displacement | 49/1/W4 | 0.033251515603458334 | 0.03325151279568672 | 2.808e-09 |
| B01 run_metrics.csv: target_displacement | 49/2/W4 | 0.030059639136345302 | 0.030059637501835823 | 1.635e-09 |
| B01 run_metrics.csv: target_displacement | 49/3/W4 | 0.026314909883533747 | 0.026314912363886833 | 2.480e-09 |
| B01 run_metrics.csv: target_displacement | 49/4/W4 | 0.034096704668617916 | 0.03409670665860176 | 1.990e-09 |
| B01 run_metrics.csv: target_displacement | 50/3/W4 | 0.02515423004722346 | 0.02515423111617565 | 1.069e-09 |
| B01 run_metrics.csv: target_displacement | 50/5/W4 | 0.019854625813789942 | 0.019854627549648285 | 1.736e-09 |
| B01 run_metrics.csv: target_displacement | 51/1/W4 | 0.031784850923345494 | 0.03178485482931137 | 3.906e-09 |
| B01 run_metrics.csv: target_displacement | 51/2/W4 | 0.028019508917913313 | 0.028019510209560394 | 1.292e-09 |
| B01 run_metrics.csv: target_displacement | 51/3/W4 | 0.05323831122638956 | 0.05323830991983414 | 1.307e-09 |
| B01 run_metrics.csv: target_displacement | 51/4/W4 | 0.05235575285139431 | 0.05235575512051582 | 2.269e-09 |
| B01 run_metrics.csv: target_displacement | 52/2/W4 | 0.047803069092011846 | 0.04780306667089462 | 2.421e-09 |
| B01 run_metrics.csv: target_displacement | 52/3/W4 | 0.04543205020880252 | 0.04543204605579376 | 4.153e-09 |
| B01 run_metrics.csv: target_displacement | 52/4/W4 | 0.02830532759726654 | 0.028305325657129288 | 1.940e-09 |
| B01 run_metrics.csv: target_displacement | 53/1/W4 | 0.046058065233881874 | 0.04605806991457939 | 4.681e-09 |
| B01 run_metrics.csv: target_displacement | 53/3/W4 | 0.06071208334346097 | 0.06071208044886589 | 2.895e-09 |
| B01 run_metrics.csv: target_displacement | 53/4/W4 | 0.03457184652372697 | 0.03457184135913849 | 5.165e-09 |
| B01 run_metrics.csv: target_displacement | 53/5/W4 | 0.06840103269112899 | 0.0684010311961174 | 1.495e-09 |
| B01 run_metrics.csv: target_displacement | 54/1/W4 | 0.07495753139402005 | 0.07495752722024918 | 4.174e-09 |
| B01 run_metrics.csv: target_displacement | 54/2/W4 | 0.0711520567533741 | 0.07115205377340317 | 2.980e-09 |
| B01 run_metrics.csv: target_displacement | 54/3/W4 | 0.04946220798062973 | 0.0494622103869915 | 2.406e-09 |
| B01 run_metrics.csv: target_displacement | 54/4/W4 | 0.04759509202714854 | 0.04759509488940239 | 2.862e-09 |
| B01 run_metrics.csv: target_displacement | 54/5/W4 | 0.09169283297710663 | 0.09169283509254456 | 2.115e-09 |
| B01 run_metrics.csv: target_displacement | 1/1/W5 | 0.2816334728642301 | 0.2816334664821625 | 6.382e-09 |
| B01 run_metrics.csv: target_displacement | 1/2/W5 | 0.1957588136829348 | 0.19575881958007812 | 5.897e-09 |
| B01 run_metrics.csv: target_displacement | 1/3/W5 | 0.16725564361511178 | 0.16725565493106842 | 1.132e-08 |
| B01 run_metrics.csv: target_displacement | 1/4/W5 | 0.2292450301383581 | 0.22924503684043884 | 6.702e-09 |
| B01 run_metrics.csv: target_displacement | 1/5/W5 | 0.24034004125577166 | 0.24034003913402557 | 2.122e-09 |
| B01 run_metrics.csv: target_displacement | 2/1/W5 | 0.05466400287309231 | 0.0546640120446682 | 9.172e-09 |
| B01 run_metrics.csv: target_displacement | 2/3/W5 | 0.1942774778984234 | 0.19427748024463654 | 2.346e-09 |
| B01 run_metrics.csv: target_displacement | 2/4/W5 | 0.046808234392352877 | 0.04680823162198067 | 2.770e-09 |
| B01 run_metrics.csv: target_displacement | 3/1/W5 | 0.09140644549665707 | 0.0914064422249794 | 3.272e-09 |
| B01 run_metrics.csv: target_displacement | 3/2/W5 | 0.09892421273837027 | 0.09892420470714569 | 8.031e-09 |
| B01 run_metrics.csv: target_displacement | 3/3/W5 | 0.07174317382317456 | 0.07174317538738251 | 1.564e-09 |
| B01 run_metrics.csv: target_displacement | 3/4/W5 | 0.07388918603798354 | 0.07388919591903687 | 9.881e-09 |
| B01 run_metrics.csv: target_displacement | 3/5/W5 | 0.08850473491737006 | 0.08850473165512085 | 3.262e-09 |
| B01 run_metrics.csv: target_displacement | 4/1/W5 | 0.14265606371125 | 0.14265607297420502 | 9.263e-09 |
| B01 run_metrics.csv: target_displacement | 4/2/W5 | 0.12668037185105596 | 0.12668035924434662 | 1.261e-08 |
| B01 run_metrics.csv: target_displacement | 4/3/W5 | 0.09760681267748775 | 0.09760680794715881 | 4.730e-09 |
| B01 run_metrics.csv: target_displacement | 4/5/W5 | 0.13423663752841886 | 0.1342366337776184 | 3.751e-09 |
| B01 run_metrics.csv: target_displacement | 5/1/W5 | 0.07310023470310081 | 0.07310023158788681 | 3.115e-09 |
| B01 run_metrics.csv: target_displacement | 5/2/W5 | 0.05888734566372239 | 0.05888734385371208 | 1.810e-09 |
| B01 run_metrics.csv: target_displacement | 5/3/W5 | 0.06149971618912295 | 0.061499714851379395 | 1.338e-09 |
| B01 run_metrics.csv: target_displacement | 5/4/W5 | 0.06241930568840292 | 0.062419310212135315 | 4.524e-09 |
| B01 run_metrics.csv: target_displacement | 5/5/W5 | 0.05677761165981545 | 0.05677761510014534 | 3.440e-09 |
| B01 run_metrics.csv: target_displacement | 6/1/W5 | 0.0902530307713099 | 0.09025304019451141 | 9.423e-09 |
| B01 run_metrics.csv: target_displacement | 6/2/W5 | 0.08046876288940684 | 0.08046876639127731 | 3.502e-09 |
| B01 run_metrics.csv: target_displacement | 6/3/W5 | 0.08094420303085212 | 0.08094419538974762 | 7.641e-09 |
| B01 run_metrics.csv: target_displacement | 6/4/W5 | 0.08708396832579682 | 0.08708395808935165 | 1.024e-08 |
| B01 run_metrics.csv: target_displacement | 6/5/W5 | 0.06950049261602377 | 0.06950049102306366 | 1.593e-09 |
| B01 run_metrics.csv: target_displacement | 7/1/W5 | 0.11946966092368629 | 0.11946966499090195 | 4.067e-09 |
| B01 run_metrics.csv: target_displacement | 7/2/W5 | 0.14563897048075472 | 0.14563897252082825 | 2.040e-09 |
| B01 run_metrics.csv: target_displacement | 7/3/W5 | 0.14352425435457744 | 0.14352425932884216 | 4.974e-09 |
| B01 run_metrics.csv: target_displacement | 7/4/W5 | 0.07811559690618357 | 0.07811560481786728 | 7.912e-09 |
| B01 run_metrics.csv: target_displacement | 8/1/W5 | 0.25841374452107546 | 0.25841376185417175 | 1.733e-08 |
| B01 run_metrics.csv: target_displacement | 8/2/W5 | 0.258636659904153 | 0.2586366534233093 | 6.481e-09 |
| B01 run_metrics.csv: target_displacement | 8/3/W5 | 0.19210547222226734 | 0.1921054869890213 | 1.477e-08 |
| B01 run_metrics.csv: target_displacement | 8/4/W5 | 0.2603071559380586 | 0.2603071928024292 | 3.686e-08 |
| B01 run_metrics.csv: target_displacement | 8/5/W5 | 0.19711395679826052 | 0.19711393117904663 | 2.562e-08 |
| B01 run_metrics.csv: target_displacement | 9/1/W5 | 0.09706708376818654 | 0.09706708788871765 | 4.121e-09 |
| B01 run_metrics.csv: target_displacement | 9/2/W5 | 0.09158222773271371 | 0.09158223122358322 | 3.491e-09 |
| B01 run_metrics.csv: target_displacement | 9/3/W5 | 0.0916569369462672 | 0.09165694564580917 | 8.700e-09 |
| B01 run_metrics.csv: target_displacement | 9/4/W5 | 0.09628887137780597 | 0.09628888219594955 | 1.082e-08 |
| B01 run_metrics.csv: target_displacement | 9/5/W5 | 0.10303069021020439 | 0.10303068906068802 | 1.150e-09 |
| B01 run_metrics.csv: target_displacement | 10/1/W5 | 0.12967158278405777 | 0.1296715885400772 | 5.756e-09 |
| B01 run_metrics.csv: target_displacement | 10/2/W5 | 0.16718751431641243 | 0.16718754172325134 | 2.741e-08 |
| B01 run_metrics.csv: target_displacement | 10/3/W5 | 0.13336877041225925 | 0.13336877524852753 | 4.836e-09 |
| B01 run_metrics.csv: target_displacement | 10/4/W5 | 0.17198946441336857 | 0.17198948562145233 | 2.121e-08 |
| B01 run_metrics.csv: target_displacement | 10/5/W5 | 0.09397207790991338 | 0.09397207945585251 | 1.546e-09 |
| B01 run_metrics.csv: target_displacement | 11/1/W5 | 0.20010696527085783 | 0.20010697841644287 | 1.315e-08 |
| B01 run_metrics.csv: target_displacement | 11/2/W5 | 0.18403854378781745 | 0.18403854966163635 | 5.874e-09 |
| B01 run_metrics.csv: target_displacement | 11/3/W5 | 0.19300443202689102 | 0.19300441443920135 | 1.759e-08 |
| B01 run_metrics.csv: target_displacement | 11/4/W5 | 0.1273711161039336 | 0.12737111747264862 | 1.369e-09 |
| B01 run_metrics.csv: target_displacement | 11/5/W5 | 0.2119151208998386 | 0.21191510558128357 | 1.532e-08 |
| B01 run_metrics.csv: target_displacement | 12/1/W5 | 0.17106903925983175 | 0.17106905579566956 | 1.654e-08 |
| B01 run_metrics.csv: target_displacement | 12/2/W5 | 0.11683909610406774 | 0.11683910340070724 | 7.297e-09 |
| B01 run_metrics.csv: target_displacement | 12/3/W5 | 0.20045385864375315 | 0.20045384764671326 | 1.100e-08 |
| B01 run_metrics.csv: target_displacement | 12/4/W5 | 0.15200272147126087 | 0.1520027369260788 | 1.545e-08 |
| B01 run_metrics.csv: target_displacement | 12/5/W5 | 0.1301961795579167 | 0.13019618391990662 | 4.362e-09 |
| B01 run_metrics.csv: target_displacement | 13/1/W5 | 0.3382221270595376 | 0.33822208642959595 | 4.063e-08 |
| B01 run_metrics.csv: target_displacement | 13/2/W5 | 0.3619351879286141 | 0.36193519830703735 | 1.038e-08 |
| B01 run_metrics.csv: target_displacement | 13/3/W5 | 0.37541236416377943 | 0.37541237473487854 | 1.057e-08 |
| B01 run_metrics.csv: target_displacement | 13/4/W5 | 0.32319509500685983 | 0.32319509983062744 | 4.824e-09 |
| B01 run_metrics.csv: target_displacement | 13/5/W5 | 0.3303595987063614 | 0.3303595781326294 | 2.057e-08 |
| B01 run_metrics.csv: target_displacement | 14/1/W5 | 0.0904176933863782 | 0.09041769802570343 | 4.639e-09 |
| B01 run_metrics.csv: target_displacement | 14/2/W5 | 0.15093852935043242 | 0.15093852579593658 | 3.554e-09 |
| B01 run_metrics.csv: target_displacement | 14/3/W5 | 0.12812230351685552 | 0.12812229990959167 | 3.607e-09 |
| B01 run_metrics.csv: target_displacement | 14/4/W5 | 0.09049832242417871 | 0.09049832075834274 | 1.666e-09 |
| B01 run_metrics.csv: target_displacement | 14/5/W5 | 0.10872478503650271 | 0.10872478783130646 | 2.795e-09 |
| B01 run_metrics.csv: target_displacement | 15/2/W5 | 0.0672443752938132 | 0.06724437326192856 | 2.032e-09 |
| B01 run_metrics.csv: target_displacement | 15/3/W5 | 0.058202215228298534 | 0.05820221081376076 | 4.415e-09 |
| B01 run_metrics.csv: target_displacement | 15/5/W5 | 0.0576213543817454 | 0.05762134864926338 | 5.732e-09 |
| B01 run_metrics.csv: target_displacement | 16/1/W5 | 0.26223720552240204 | 0.26223719120025635 | 1.432e-08 |
| B01 run_metrics.csv: target_displacement | 16/2/W5 | 0.17234180653993866 | 0.17234180867671967 | 2.137e-09 |
| B01 run_metrics.csv: target_displacement | 16/3/W5 | 0.13574434933341295 | 0.1357443481683731 | 1.165e-09 |
| B01 run_metrics.csv: target_displacement | 16/4/W5 | 0.25724308798705187 | 0.2572430670261383 | 2.096e-08 |
| B01 run_metrics.csv: target_displacement | 16/5/W5 | 0.1840008686420773 | 0.1840008795261383 | 1.088e-08 |
| B01 run_metrics.csv: target_displacement | 17/1/W5 | 0.08897365625772577 | 0.08897364884614944 | 7.412e-09 |
| B01 run_metrics.csv: target_displacement | 17/2/W5 | 0.09877475281573689 | 0.09877476096153259 | 8.146e-09 |
| B01 run_metrics.csv: target_displacement | 17/3/W5 | 0.08949166103519185 | 0.08949166536331177 | 4.328e-09 |
| B01 run_metrics.csv: target_displacement | 17/4/W5 | 0.09972676506675066 | 0.09972676634788513 | 1.281e-09 |
| B01 run_metrics.csv: target_displacement | 17/5/W5 | 0.08540963163554893 | 0.08540964126586914 | 9.630e-09 |
| B01 run_metrics.csv: target_displacement | 18/2/W5 | 0.07819288840270683 | 0.07819288969039917 | 1.288e-09 |
| B01 run_metrics.csv: target_displacement | 18/3/W5 | 0.06788487086250183 | 0.06788487732410431 | 6.462e-09 |
| B01 run_metrics.csv: target_displacement | 18/4/W5 | 0.07744753821034227 | 0.07744754105806351 | 2.848e-09 |
| B01 run_metrics.csv: target_displacement | 18/5/W5 | 0.0965923222896741 | 0.09659232944250107 | 7.153e-09 |
| B01 run_metrics.csv: target_displacement | 19/1/W5 | 0.08299137190284885 | 0.08299136161804199 | 1.028e-08 |
| B01 run_metrics.csv: target_displacement | 19/2/W5 | 0.07377049450874536 | 0.07377049326896667 | 1.240e-09 |
| B01 run_metrics.csv: target_displacement | 19/3/W5 | 0.09292444282149004 | 0.09292444586753845 | 3.046e-09 |
| B01 run_metrics.csv: target_displacement | 19/4/W5 | 0.09216401775662376 | 0.09216400980949402 | 7.947e-09 |
| B01 run_metrics.csv: target_displacement | 19/5/W5 | 0.07896850440216817 | 0.07896850258111954 | 1.821e-09 |
| B01 run_metrics.csv: target_displacement | 20/1/W5 | 0.23433386615094146 | 0.2343338131904602 | 5.296e-08 |
| B01 run_metrics.csv: target_displacement | 20/2/W5 | 0.18237215457687891 | 0.18237215280532837 | 1.772e-09 |
| B01 run_metrics.csv: target_displacement | 20/3/W5 | 0.19730784832434098 | 0.19730785489082336 | 6.566e-09 |
| B01 run_metrics.csv: target_displacement | 20/4/W5 | 0.2179304195820187 | 0.217930406332016 | 1.325e-08 |
| B01 run_metrics.csv: target_displacement | 20/5/W5 | 0.2877514432925652 | 0.2877514660358429 | 2.274e-08 |
| B01 run_metrics.csv: target_displacement | 21/1/W5 | 0.0601470792279753 | 0.06014707684516907 | 2.383e-09 |
| B01 run_metrics.csv: target_displacement | 21/2/W5 | 0.05551886631548528 | 0.05551886931061745 | 2.995e-09 |
| B01 run_metrics.csv: target_displacement | 21/3/W5 | 0.05656239660279347 | 0.0565623939037323 | 2.699e-09 |
| B01 run_metrics.csv: target_displacement | 21/4/W5 | 0.05105419250486491 | 0.05105419084429741 | 1.661e-09 |
| B01 run_metrics.csv: target_displacement | 21/5/W5 | 0.06463027312922791 | 0.06463027000427246 | 3.125e-09 |
| B01 run_metrics.csv: target_displacement | 22/1/W5 | 0.12779772879315396 | 0.12779773771762848 | 8.924e-09 |
| B01 run_metrics.csv: target_displacement | 22/2/W5 | 0.11964704608896033 | 0.1196470558643341 | 9.775e-09 |
| B01 run_metrics.csv: target_displacement | 22/3/W5 | 0.10686189988088449 | 0.1068618893623352 | 1.052e-08 |
| B01 run_metrics.csv: target_displacement | 22/4/W5 | 0.12158090043172605 | 0.12158090621232986 | 5.781e-09 |
| B01 run_metrics.csv: target_displacement | 22/5/W5 | 0.14301907509147938 | 0.14301908016204834 | 5.071e-09 |
| B01 run_metrics.csv: target_displacement | 23/1/W5 | 0.22272097354712006 | 0.22272098064422607 | 7.097e-09 |
| B01 run_metrics.csv: target_displacement | 23/2/W5 | 0.09357657566141597 | 0.09357656538486481 | 1.028e-08 |
| B01 run_metrics.csv: target_displacement | 23/3/W5 | 0.07573114291643392 | 0.07573113590478897 | 7.012e-09 |
| B01 run_metrics.csv: target_displacement | 23/4/W5 | 0.14837091549065884 | 0.1483709067106247 | 8.780e-09 |
| B01 run_metrics.csv: target_displacement | 23/5/W5 | 0.09570711629493006 | 0.09570711851119995 | 2.216e-09 |
| B01 run_metrics.csv: target_displacement | 24/1/W5 | 0.07223917582328347 | 0.07223918288946152 | 7.066e-09 |
| B01 run_metrics.csv: target_displacement | 24/2/W5 | 0.0655956003640604 | 0.0655955970287323 | 3.335e-09 |
| B01 run_metrics.csv: target_displacement | 24/3/W5 | 0.06284365218303706 | 0.06284365803003311 | 5.847e-09 |
| B01 run_metrics.csv: target_displacement | 24/4/W5 | 0.1076060113949369 | 0.10760602355003357 | 1.216e-08 |
| B01 run_metrics.csv: target_displacement | 24/5/W5 | 0.06676725723970317 | 0.06676725298166275 | 4.258e-09 |
| B01 run_metrics.csv: target_displacement | 25/2/W5 | 0.0721452814944902 | 0.07214528322219849 | 1.728e-09 |
| B01 run_metrics.csv: target_displacement | 25/3/W5 | 0.06678442376425829 | 0.06678442656993866 | 2.806e-09 |
| B01 run_metrics.csv: target_displacement | 25/4/W5 | 0.07167654555850839 | 0.07167655229568481 | 6.737e-09 |
| B01 run_metrics.csv: target_displacement | 25/5/W5 | 0.10821688901184859 | 0.10821687430143356 | 1.471e-08 |
| B01 run_metrics.csv: target_displacement | 26/1/W5 | 0.42584161191404335 | 0.4258415997028351 | 1.221e-08 |
| B01 run_metrics.csv: target_displacement | 26/2/W5 | 0.36672479253870727 | 0.36672481894493103 | 2.641e-08 |
| B01 run_metrics.csv: target_displacement | 26/3/W5 | 0.4527088324187284 | 0.45270881056785583 | 2.185e-08 |
| B01 run_metrics.csv: target_displacement | 26/5/W5 | 0.26765772337641713 | 0.26765772700309753 | 3.627e-09 |
| B01 run_metrics.csv: target_displacement | 27/1/W5 | 0.2152076841943862 | 0.21520769596099854 | 1.177e-08 |
| B01 run_metrics.csv: target_displacement | 27/2/W5 | 0.06535837284824271 | 0.06535837799310684 | 5.145e-09 |
| B01 run_metrics.csv: target_displacement | 27/3/W5 | 0.06984957425571738 | 0.06984958052635193 | 6.271e-09 |
| B01 run_metrics.csv: target_displacement | 27/5/W5 | 0.20456067129058644 | 0.20456068217754364 | 1.089e-08 |
| B01 run_metrics.csv: target_displacement | 28/2/W5 | 0.09078652820468318 | 0.09078653156757355 | 3.363e-09 |
| B01 run_metrics.csv: target_displacement | 28/4/W5 | 0.07557073019967936 | 0.0755707398056984 | 9.606e-09 |
| B01 run_metrics.csv: target_displacement | 29/1/W5 | 0.09084928018729985 | 0.09084928780794144 | 7.621e-09 |
| B01 run_metrics.csv: target_displacement | 29/2/W5 | 0.11020247631546765 | 0.11020248383283615 | 7.517e-09 |
| B01 run_metrics.csv: target_displacement | 29/3/W5 | 0.05496048848775923 | 0.05496048554778099 | 2.940e-09 |
| B01 run_metrics.csv: target_displacement | 29/4/W5 | 0.07542563443263572 | 0.0754256322979927 | 2.135e-09 |
| B01 run_metrics.csv: target_displacement | 29/5/W5 | 0.08326626465520257 | 0.0832662582397461 | 6.415e-09 |
| B01 run_metrics.csv: target_displacement | 30/1/W5 | 0.05310887433878528 | 0.05310886725783348 | 7.081e-09 |
| B01 run_metrics.csv: target_displacement | 30/2/W5 | 0.04739104306928029 | 0.04739103838801384 | 4.681e-09 |
| B01 run_metrics.csv: target_displacement | 30/4/W5 | 0.05185193469128964 | 0.05185193195939064 | 2.732e-09 |
| B01 run_metrics.csv: target_displacement | 30/5/W5 | 0.05970740053062484 | 0.0597073994576931 | 1.073e-09 |
| B01 run_metrics.csv: target_displacement | 31/1/W5 | 0.17610689742374425 | 0.17610691487789154 | 1.745e-08 |
| B01 run_metrics.csv: target_displacement | 31/2/W5 | 0.1410530459186249 | 0.14105305075645447 | 4.838e-09 |
| B01 run_metrics.csv: target_displacement | 31/3/W5 | 0.11864989522480936 | 0.11864989995956421 | 4.735e-09 |
| B01 run_metrics.csv: target_displacement | 31/4/W5 | 0.13505505486121497 | 0.1350550651550293 | 1.029e-08 |
| B01 run_metrics.csv: target_displacement | 31/5/W5 | 0.140722666422783 | 0.14072266221046448 | 4.212e-09 |
| B01 run_metrics.csv: target_displacement | 32/1/W5 | 0.04559974607318511 | 0.04559974744915962 | 1.376e-09 |
| B01 run_metrics.csv: target_displacement | 32/2/W5 | 0.046044224935314675 | 0.04604422673583031 | 1.801e-09 |
| B01 run_metrics.csv: target_displacement | 32/3/W5 | 0.03887941120228742 | 0.038879409432411194 | 1.770e-09 |
| B01 run_metrics.csv: target_displacement | 32/5/W5 | 0.04328286419206506 | 0.04328285530209541 | 8.890e-09 |
| B01 run_metrics.csv: target_displacement | 33/1/W5 | 0.0581158231616625 | 0.058115825057029724 | 1.895e-09 |
| B01 run_metrics.csv: target_displacement | 33/2/W5 | 0.05935909881993096 | 0.059359095990657806 | 2.829e-09 |
| B01 run_metrics.csv: target_displacement | 33/3/W5 | 0.05650237408325103 | 0.05650237575173378 | 1.668e-09 |
| B01 run_metrics.csv: target_displacement | 33/4/W5 | 0.06757671173110538 | 0.06757671386003494 | 2.129e-09 |
| B01 run_metrics.csv: target_displacement | 33/5/W5 | 0.05950681070086242 | 0.05950680747628212 | 3.225e-09 |
| B01 run_metrics.csv: target_displacement | 34/1/W5 | 0.19315998707355345 | 0.19315996766090393 | 1.941e-08 |
| B01 run_metrics.csv: target_displacement | 34/2/W5 | 0.2152170352453893 | 0.21521703898906708 | 3.744e-09 |
| B01 run_metrics.csv: target_displacement | 34/3/W5 | 0.2226127624779077 | 0.22261276841163635 | 5.934e-09 |
| B01 run_metrics.csv: target_displacement | 34/4/W5 | 0.18145498799542392 | 0.18145498633384705 | 1.662e-09 |
| B01 run_metrics.csv: target_displacement | 34/5/W5 | 0.18301725694106558 | 0.18301725387573242 | 3.065e-09 |
| B01 run_metrics.csv: target_displacement | 35/2/W5 | 0.05684800732204305 | 0.05684801563620567 | 8.314e-09 |
| B01 run_metrics.csv: target_displacement | 35/3/W5 | 0.05558529900436073 | 0.05558530241250992 | 3.408e-09 |
| B01 run_metrics.csv: target_displacement | 35/4/W5 | 0.059280046922804024 | 0.059280041605234146 | 5.318e-09 |
| B01 run_metrics.csv: target_displacement | 35/5/W5 | 0.05899581374377693 | 0.058995820581912994 | 6.838e-09 |
| B01 run_metrics.csv: target_displacement | 36/1/W5 | 0.04465027709143736 | 0.044650278985500336 | 1.894e-09 |
| B01 run_metrics.csv: target_displacement | 36/2/W5 | 0.04880878623975418 | 0.048808783292770386 | 2.947e-09 |
| B01 run_metrics.csv: target_displacement | 36/3/W5 | 0.04866219349556457 | 0.04866219684481621 | 3.349e-09 |
| B01 run_metrics.csv: target_displacement | 36/4/W5 | 0.042030274683958924 | 0.042030271142721176 | 3.541e-09 |
| B01 run_metrics.csv: target_displacement | 37/1/W5 | 0.04604662339917629 | 0.046046629548072815 | 6.149e-09 |
| B01 run_metrics.csv: target_displacement | 37/2/W5 | 0.05164325617659988 | 0.0516432523727417 | 3.804e-09 |
| B01 run_metrics.csv: target_displacement | 37/3/W5 | 0.05362184980663599 | 0.05362185090780258 | 1.101e-09 |
| B01 run_metrics.csv: target_displacement | 37/4/W5 | 0.05298763479499049 | 0.05298764258623123 | 7.791e-09 |
| B01 run_metrics.csv: target_displacement | 37/5/W5 | 0.06895459602213422 | 0.06895459443330765 | 1.589e-09 |
| B01 run_metrics.csv: target_displacement | 38/1/W5 | 0.08968791710153327 | 0.08968792110681534 | 4.005e-09 |
| B01 run_metrics.csv: target_displacement | 38/2/W5 | 0.07903349232795721 | 0.07903348654508591 | 5.783e-09 |
| B01 run_metrics.csv: target_displacement | 38/3/W5 | 0.0736956849803606 | 0.07369568198919296 | 2.991e-09 |
| B01 run_metrics.csv: target_displacement | 38/4/W5 | 0.0726652539128718 | 0.0726652517914772 | 2.121e-09 |
| B01 run_metrics.csv: target_displacement | 38/5/W5 | 0.08138805356810627 | 0.08138805627822876 | 2.710e-09 |
| B01 run_metrics.csv: target_displacement | 39/1/W5 | 0.14754218476630762 | 0.14754217863082886 | 6.135e-09 |
| B01 run_metrics.csv: target_displacement | 39/2/W5 | 0.11595857334126128 | 0.11595857888460159 | 5.543e-09 |
| B01 run_metrics.csv: target_displacement | 39/3/W5 | 0.1319422183694204 | 0.13194222748279572 | 9.113e-09 |
| B01 run_metrics.csv: target_displacement | 39/4/W5 | 0.08171204250373909 | 0.0817120373249054 | 5.179e-09 |
| B01 run_metrics.csv: target_displacement | 39/5/W5 | 0.10600309607171711 | 0.10600309073925018 | 5.332e-09 |
| B01 run_metrics.csv: target_displacement | 40/1/W5 | 0.12896209253713395 | 0.12896208465099335 | 7.886e-09 |
| B01 run_metrics.csv: target_displacement | 40/2/W5 | 0.0770462497671912 | 0.07704624533653259 | 4.431e-09 |
| B01 run_metrics.csv: target_displacement | 40/3/W5 | 0.09006017511178278 | 0.09006016701459885 | 8.097e-09 |
| B01 run_metrics.csv: target_displacement | 40/4/W5 | 0.08546450418858456 | 0.08546449989080429 | 4.298e-09 |
| B01 run_metrics.csv: target_displacement | 41/1/W5 | 0.08575810482553146 | 0.08575809746980667 | 7.356e-09 |
| B01 run_metrics.csv: target_displacement | 41/2/W5 | 0.075132188794178 | 0.07513219118118286 | 2.387e-09 |
| B01 run_metrics.csv: target_displacement | 41/3/W5 | 0.09849308041835822 | 0.0984930768609047 | 3.557e-09 |
| B01 run_metrics.csv: target_displacement | 41/4/W5 | 0.06095273670548379 | 0.06095273792743683 | 1.222e-09 |
| B01 run_metrics.csv: target_displacement | 41/5/W5 | 0.07165439894762077 | 0.07165439426898956 | 4.679e-09 |
| B01 run_metrics.csv: target_displacement | 42/1/W5 | 0.18978985187745714 | 0.18978984653949738 | 5.338e-09 |
| B01 run_metrics.csv: target_displacement | 42/2/W5 | 0.1314785142926398 | 0.13147850334644318 | 1.095e-08 |
| B01 run_metrics.csv: target_displacement | 42/3/W5 | 0.12336824429191177 | 0.12336824089288712 | 3.399e-09 |
| B01 run_metrics.csv: target_displacement | 42/4/W5 | 0.09227298580309752 | 0.09227298945188522 | 3.649e-09 |
| B01 run_metrics.csv: target_displacement | 42/5/W5 | 0.16363820718028674 | 0.16363820433616638 | 2.844e-09 |
| B01 run_metrics.csv: target_displacement | 43/1/W5 | 0.08668156981647321 | 0.08668156713247299 | 2.684e-09 |
| B01 run_metrics.csv: target_displacement | 43/2/W5 | 0.08761787670193277 | 0.08761788159608841 | 4.894e-09 |
| B01 run_metrics.csv: target_displacement | 43/3/W5 | 0.08838354491261706 | 0.08838354051113129 | 4.401e-09 |
| B01 run_metrics.csv: target_displacement | 43/4/W5 | 0.06854259040394 | 0.06854259222745895 | 1.824e-09 |
| B01 run_metrics.csv: target_displacement | 43/5/W5 | 0.17757863446806865 | 0.1775786429643631 | 8.496e-09 |
| B01 run_metrics.csv: target_displacement | 44/1/W5 | 0.0723573699419697 | 0.07235736399888992 | 5.943e-09 |
| B01 run_metrics.csv: target_displacement | 44/2/W5 | 0.09149917911586064 | 0.0914991945028305 | 1.539e-08 |
| B01 run_metrics.csv: target_displacement | 44/3/W5 | 0.08020987163772261 | 0.0802098736166954 | 1.979e-09 |
| B01 run_metrics.csv: target_displacement | 44/4/W5 | 0.13424137451353094 | 0.13424138724803925 | 1.273e-08 |
| B01 run_metrics.csv: target_displacement | 44/5/W5 | 0.07505389159747748 | 0.07505389302968979 | 1.432e-09 |
| B01 run_metrics.csv: target_displacement | 45/1/W5 | 0.068379516049991 | 0.06837951391935349 | 2.131e-09 |
| B01 run_metrics.csv: target_displacement | 45/2/W5 | 0.0803337814989365 | 0.08033378422260284 | 2.724e-09 |
| B01 run_metrics.csv: target_displacement | 45/3/W5 | 0.07943892011415477 | 0.07943891733884811 | 2.775e-09 |
| B01 run_metrics.csv: target_displacement | 45/4/W5 | 0.06856649167219994 | 0.06856649369001389 | 2.018e-09 |
| B01 run_metrics.csv: target_displacement | 46/1/W5 | 0.2125182584164872 | 0.21251827478408813 | 1.637e-08 |
| B01 run_metrics.csv: target_displacement | 46/2/W5 | 0.1987132613778515 | 0.1987132430076599 | 1.837e-08 |
| B01 run_metrics.csv: target_displacement | 46/3/W5 | 0.16494691928648259 | 0.16494694352149963 | 2.424e-08 |
| B01 run_metrics.csv: target_displacement | 46/4/W5 | 0.15065946170543387 | 0.1506594717502594 | 1.004e-08 |
| B01 run_metrics.csv: target_displacement | 46/5/W5 | 0.180252212140888 | 0.18025220930576324 | 2.835e-09 |
| B01 run_metrics.csv: target_displacement | 47/1/W5 | 0.3254045832923753 | 0.325404554605484 | 2.869e-08 |
| B01 run_metrics.csv: target_displacement | 47/2/W5 | 0.303988966268582 | 0.3039889633655548 | 2.903e-09 |
| B01 run_metrics.csv: target_displacement | 47/3/W5 | 0.3757117824165804 | 0.37571173906326294 | 4.335e-08 |
| B01 run_metrics.csv: target_displacement | 47/4/W5 | 0.3369083151883141 | 0.33690834045410156 | 2.527e-08 |
| B01 run_metrics.csv: target_displacement | 47/5/W5 | 0.407534292236871 | 0.40753433108329773 | 3.885e-08 |
| B01 run_metrics.csv: target_displacement | 48/1/W5 | 0.10876012312837643 | 0.10876012593507767 | 2.807e-09 |
| B01 run_metrics.csv: target_displacement | 48/2/W5 | 0.17193399552659813 | 0.17193400859832764 | 1.307e-08 |
| B01 run_metrics.csv: target_displacement | 48/3/W5 | 0.1560961643850748 | 0.15609616041183472 | 3.973e-09 |
| B01 run_metrics.csv: target_displacement | 48/5/W5 | 0.10113697658961915 | 0.10113698244094849 | 5.851e-09 |
| B01 run_metrics.csv: target_displacement | 49/1/W5 | 0.1269432591494034 | 0.12694326043128967 | 1.282e-09 |
| B01 run_metrics.csv: target_displacement | 49/4/W5 | 0.13804956450076356 | 0.13804955780506134 | 6.696e-09 |
| B01 run_metrics.csv: target_displacement | 49/5/W5 | 0.097421165706246 | 0.09742116183042526 | 3.876e-09 |
| B01 run_metrics.csv: target_displacement | 50/1/W5 | 0.0784459273790414 | 0.0784459337592125 | 6.380e-09 |
| B01 run_metrics.csv: target_displacement | 50/2/W5 | 0.0520318158995313 | 0.05203182250261307 | 6.603e-09 |
| B01 run_metrics.csv: target_displacement | 50/3/W5 | 0.09847700120720965 | 0.09847699850797653 | 2.699e-09 |
| B01 run_metrics.csv: target_displacement | 50/4/W5 | 0.07264359586754437 | 0.07264359295368195 | 2.914e-09 |
| B01 run_metrics.csv: target_displacement | 50/5/W5 | 0.08573920903312185 | 0.08573920279741287 | 6.236e-09 |
| B01 run_metrics.csv: target_displacement | 51/1/W5 | 0.14833386677812968 | 0.14833387732505798 | 1.055e-08 |
| B01 run_metrics.csv: target_displacement | 51/3/W5 | 0.2125100970527374 | 0.2125100940465927 | 3.006e-09 |
| B01 run_metrics.csv: target_displacement | 51/4/W5 | 0.22974242265316566 | 0.2297423928976059 | 2.976e-08 |
| B01 run_metrics.csv: target_displacement | 51/5/W5 | 0.2510159666837101 | 0.2510160207748413 | 5.409e-08 |
| B01 run_metrics.csv: target_displacement | 52/1/W5 | 0.15220968853007857 | 0.15220968425273895 | 4.277e-09 |
| B01 run_metrics.csv: target_displacement | 52/2/W5 | 0.18779500632242352 | 0.1877950131893158 | 6.867e-09 |
| B01 run_metrics.csv: target_displacement | 52/3/W5 | 0.19430436565466158 | 0.19430434703826904 | 1.862e-08 |
| B01 run_metrics.csv: target_displacement | 52/5/W5 | 0.2026147244788532 | 0.20261473953723907 | 1.506e-08 |
| B01 run_metrics.csv: target_displacement | 53/1/W5 | 0.18318222183463678 | 0.1831822246313095 | 2.797e-09 |
| B01 run_metrics.csv: target_displacement | 53/2/W5 | 0.25265941969916017 | 0.252659410238266 | 9.461e-09 |
| B01 run_metrics.csv: target_displacement | 53/3/W5 | 0.21938021828362142 | 0.2193801999092102 | 1.837e-08 |
| B01 run_metrics.csv: target_displacement | 54/1/W5 | 0.30472141093885374 | 0.3047214150428772 | 4.104e-09 |
| B01 run_metrics.csv: target_displacement | 54/2/W5 | 0.28408382863431836 | 0.2840838134288788 | 1.521e-08 |
| B01 run_metrics.csv: target_displacement | 54/3/W5 | 0.2186648283220541 | 0.21866483986377716 | 1.154e-08 |
| B01 run_metrics.csv: target_displacement | 54/4/W5 | 0.2024045718784406 | 0.20240455865859985 | 1.322e-08 |
| B01 run_metrics.csv: target_displacement | 54/5/W5 | 0.3565596300262088 | 0.3565596640110016 | 3.398e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/1/S1 | 0.17542738921485523 | 0.1754273921251297 | 2.910e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/2/S1 | 0.18656551111021424 | 0.18656551837921143 | 7.269e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/3/S1 | 0.17378457174782233 | 0.1737845540046692 | 1.774e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/4/S1 | 0.09733275136515517 | 0.09733275324106216 | 1.876e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/5/S1 | 0.20909505659449645 | 0.2090950459241867 | 1.067e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/1/S1 | 0.07286740559699076 | 0.07286740094423294 | 4.653e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/2/S1 | 0.023494111889549557 | 0.023494113236665726 | 1.347e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/3/S1 | 0.019304839389118245 | 0.01930483803153038 | 1.358e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/4/S1 | 0.13462512515333136 | 0.1346251368522644 | 1.170e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/5/S1 | 0.033306265511260084 | 0.03330626338720322 | 2.124e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/1/S1 | 0.041351405655488775 | 0.041351404041051865 | 1.614e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/2/S1 | 0.07428223816268113 | 0.07428224384784698 | 5.685e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/3/S1 | 0.08627607099326404 | 0.08627607673406601 | 5.741e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/5/S1 | 0.05574572480770572 | 0.05574573203921318 | 7.232e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/1/S1 | 0.08440056127167615 | 0.08440054953098297 | 1.174e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/2/S1 | 0.11636241700003115 | 0.11636242270469666 | 5.705e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/3/S1 | 0.07681920699777783 | 0.07681921124458313 | 4.247e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/4/S1 | 0.10048770072039458 | 0.10048770904541016 | 8.325e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/5/S1 | 0.07389961462692762 | 0.07389960438013077 | 1.025e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/1/S1 | 0.02771295595628526 | 0.027712952345609665 | 3.611e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/2/S1 | 0.043721676506498476 | 0.04372167959809303 | 3.092e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/3/S1 | 0.01687676135400935 | 0.016876762732863426 | 1.379e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/1/S1 | 0.07463493188980824 | 0.07463493943214417 | 7.542e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/2/S1 | 0.0590594690917686 | 0.059059470891952515 | 1.800e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/3/S1 | 0.03664953164673913 | 0.03664952889084816 | 2.756e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/4/S1 | 0.043399789839041344 | 0.04339979216456413 | 2.326e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/5/S1 | 0.0511401103741201 | 0.05114011466503143 | 4.291e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/1/S1 | 0.08173238149844832 | 0.0817323848605156 | 3.362e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/2/S1 | 0.07618327322693656 | 0.0761832743883133 | 1.161e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/3/S1 | 0.09026444991437423 | 0.0902644619345665 | 1.202e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/4/S1 | 0.07699519291546487 | 0.07699519395828247 | 1.043e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/1/S1 | 0.1686343322116822 | 0.1686343252658844 | 6.946e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/2/S1 | 0.2325915260157427 | 0.23259150981903076 | 1.620e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/3/S1 | 0.1322359680277242 | 0.13223597407341003 | 6.046e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/4/S1 | 0.14502303775994826 | 0.14502303302288055 | 4.737e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/5/S1 | 0.09712160194650676 | 0.09712160378694534 | 1.840e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/1/S1 | 0.042737038552968246 | 0.04273703694343567 | 1.610e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/2/S1 | 0.08524895618458446 | 0.08524896949529648 | 1.331e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/3/S1 | 0.05527322907301942 | 0.05527322739362717 | 1.679e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/4/S1 | 0.04820044515342908 | 0.048200443387031555 | 1.766e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/5/S1 | 0.04311295462943255 | 0.04311295598745346 | 1.358e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/2/S1 | 0.08705341600605672 | 0.08705340325832367 | 1.275e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/3/S1 | 0.1020724881112041 | 0.10207247734069824 | 1.077e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/4/S1 | 0.1062975795941812 | 0.1062975823879242 | 2.794e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/5/S1 | 0.10477891907657691 | 0.10477890819311142 | 1.088e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/1/S1 | 0.1556475449851721 | 0.15564756095409393 | 1.597e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/2/S1 | 0.14795617379501708 | 0.14795617759227753 | 3.797e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/3/S1 | 0.11569257313681018 | 0.11569257080554962 | 2.331e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/4/S1 | 0.11064878263854754 | 0.11064879596233368 | 1.332e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/5/S1 | 0.16695391654825417 | 0.166953906416893 | 1.013e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/1/S1 | 0.1867030234682147 | 0.18670302629470825 | 2.826e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/2/S1 | 0.2077054153645937 | 0.20770542323589325 | 7.871e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/3/S1 | 0.10640118977674387 | 0.10640119761228561 | 7.836e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/4/S1 | 0.12647441235457457 | 0.12647442519664764 | 1.284e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/5/S1 | 0.0948366479384142 | 0.09483666718006134 | 1.924e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/1/S1 | 0.19613313012780278 | 0.19613313674926758 | 6.621e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/2/S1 | 0.18816624655956254 | 0.18816626071929932 | 1.416e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/3/S1 | 0.15175386409506422 | 0.15175385773181915 | 6.363e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/4/S1 | 0.18886442342190254 | 0.18886443972587585 | 1.630e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/5/S1 | 0.1633943790275697 | 0.16339437663555145 | 2.392e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/1/S1 | 0.1312824814183668 | 0.1312824785709381 | 2.847e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/2/S1 | 0.09611353575750745 | 0.09611354023218155 | 4.475e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/4/S1 | 0.07005856593881193 | 0.07005856931209564 | 3.373e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/5/S1 | 0.08064222625480673 | 0.08064224570989609 | 1.946e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/1/S1 | 0.013326983625699826 | 0.013326982036232948 | 1.589e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/3/S1 | 0.013858338412569312 | 0.013858336955308914 | 1.457e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/1/S1 | 0.17870330581328667 | 0.17870330810546875 | 2.292e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/3/S1 | 0.10163323805757195 | 0.10163325071334839 | 1.266e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/4/S1 | 0.11554065973450758 | 0.11554065346717834 | 6.267e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/1/S1 | 0.0840945209037771 | 0.08409452438354492 | 3.480e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/2/S1 | 0.1325533600515325 | 0.1325533539056778 | 6.146e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/4/S1 | 0.040575065932982456 | 0.0405750647187233 | 1.214e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/5/S1 | 0.05718855761346915 | 0.05718855559825897 | 2.015e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/1/S1 | 0.0689675584698407 | 0.0689675509929657 | 7.477e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/2/S1 | 0.053116533863363055 | 0.053116537630558014 | 3.767e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/3/S1 | 0.028617650331234753 | 0.028617652133107185 | 1.802e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/5/S1 | 0.060586603479621096 | 0.060586605221033096 | 1.741e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/1/S1 | 0.07514815329856553 | 0.07514815032482147 | 2.974e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/2/S1 | 0.07233259585955318 | 0.07233259826898575 | 2.409e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/5/S1 | 0.12296881012424082 | 0.12296880781650543 | 2.308e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/2/S1 | 0.08636012351400282 | 0.08636011183261871 | 1.168e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/3/S1 | 0.10316730556761311 | 0.10316730290651321 | 2.661e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/2/S1 | 0.018000647165349454 | 0.0180006455630064 | 1.602e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/3/S1 | 0.01511207964420396 | 0.015112077817320824 | 1.827e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/4/S1 | 0.013767600246864315 | 0.013767599128186703 | 1.119e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/2/S1 | 0.0879932721774785 | 0.08799327909946442 | 6.922e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/3/S1 | 0.08736884466996452 | 0.08736883848905563 | 6.181e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/4/S1 | 0.13187947513119191 | 0.13187947869300842 | 3.562e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/5/S1 | 0.10520522828282401 | 0.1052052229642868 | 5.319e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/1/S1 | 0.11522969763925849 | 0.11522969603538513 | 1.604e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/2/S1 | 0.05960312355116822 | 0.059603117406368256 | 6.145e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/3/S1 | 0.07705518716966323 | 0.0770551860332489 | 1.136e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/4/S1 | 0.09036958695666242 | 0.0903695747256279 | 1.223e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/5/S1 | 0.11155614767356152 | 0.11155614256858826 | 5.105e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/1/S1 | 0.060666041796493 | 0.0606660358607769 | 5.936e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/4/S1 | 0.05836437785289214 | 0.0583643764257431 | 1.427e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/5/S1 | 0.03862076744503268 | 0.03862076625227928 | 1.193e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/2/S1 | 0.05352538300168314 | 0.053525377064943314 | 5.937e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/3/S1 | 0.05102520124009181 | 0.05102520436048508 | 3.120e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/4/S1 | 0.07083501804056935 | 0.07083501666784286 | 1.373e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/5/S1 | 0.0885482042041604 | 0.0885482057929039 | 1.589e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/1/S1 | 0.23086457039619643 | 0.23086458444595337 | 1.405e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/2/S1 | 0.16286383078103092 | 0.1628638505935669 | 1.981e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/3/S1 | 0.17654443126344638 | 0.1765444427728653 | 1.151e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/4/S1 | 0.16424716120525623 | 0.16424717009067535 | 8.885e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/5/S1 | 0.11199074560991953 | 0.11199074983596802 | 4.226e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/1/S1 | 0.14525972556918804 | 0.14525972306728363 | 2.502e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/3/S1 | 0.13172376885784595 | 0.1317237764596939 | 7.602e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/4/S1 | 0.1366900965618163 | 0.13669009506702423 | 1.495e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/5/S1 | 0.07309718016238903 | 0.07309718430042267 | 4.138e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/1/S1 | 0.035858834989138624 | 0.03585883229970932 | 2.689e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/3/S1 | 0.03290497249630257 | 0.0329049713909626 | 1.105e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/4/S1 | 0.044759096767554005 | 0.04475909098982811 | 5.778e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/5/S1 | 0.03010054838665066 | 0.03010055050253868 | 2.116e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/1/S1 | 0.025230168654682115 | 0.025230171158909798 | 2.504e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/2/S1 | 0.03167802772250976 | 0.031678032130002975 | 4.407e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/4/S1 | 0.023741055990961116 | 0.02374105714261532 | 1.152e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/5/S1 | 0.024444438689001008 | 0.02444443665444851 | 2.035e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/1/S1 | 0.05924121441252288 | 0.059241220355033875 | 5.943e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/2/S1 | 0.01905147439900111 | 0.019051475450396538 | 1.051e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/3/S1 | 0.020214993101100663 | 0.02021499164402485 | 1.457e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/5/S1 | 0.03418758624368136 | 0.03418758511543274 | 1.128e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/1/S1 | 0.0920356256320063 | 0.09203562140464783 | 4.227e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/2/S1 | 0.0896606916733011 | 0.08966068923473358 | 2.439e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/3/S1 | 0.08171743377453383 | 0.08171743154525757 | 2.229e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/4/S1 | 0.0801252322948029 | 0.08012522757053375 | 4.724e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/5/S1 | 0.09934590804064478 | 0.09934590011835098 | 7.922e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/5/S1 | 0.022271787650402688 | 0.022271789610385895 | 1.960e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/1/S1 | 0.12628362907514934 | 0.12628363072872162 | 1.654e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/2/S1 | 0.10146316322386253 | 0.10146317631006241 | 1.309e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/4/S1 | 0.14111397118419722 | 0.1411139816045761 | 1.042e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/5/S1 | 0.10429719267416174 | 0.10429719090461731 | 1.770e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/5/S1 | 0.015115345590448718 | 0.015115346759557724 | 1.169e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/2/S1 | 0.029343898809654538 | 0.029343895614147186 | 3.196e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/4/S1 | 0.020069858208193733 | 0.02006985992193222 | 1.714e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/5/S1 | 0.03031985644046985 | 0.030319854617118835 | 1.823e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/1/S1 | 0.0719481014575059 | 0.0719481036067009 | 2.149e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/2/S1 | 0.03672593596441752 | 0.036725934594869614 | 1.370e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/3/S1 | 0.05153313058748155 | 0.051533136516809464 | 5.929e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/4/S1 | 0.06361020007579159 | 0.06361020356416702 | 3.488e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/1/S1 | 0.11982774318950075 | 0.1198277473449707 | 4.155e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/2/S1 | 0.11919379370875072 | 0.11919379234313965 | 1.366e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/3/S1 | 0.06800381680351564 | 0.0680038183927536 | 1.589e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/4/S1 | 0.07780784193215763 | 0.07780784368515015 | 1.753e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/5/S1 | 0.09683949343763311 | 0.09683949500322342 | 1.566e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/1/S1 | 0.15460897366783818 | 0.15460897982120514 | 6.153e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/2/S1 | 0.07451213253728585 | 0.07451213151216507 | 1.025e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/3/S1 | 0.07521200004801325 | 0.07521199434995651 | 5.698e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/4/S1 | 0.07213873040991796 | 0.07213873416185379 | 3.752e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/5/S1 | 0.13604410994112984 | 0.13604411482810974 | 4.887e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/1/S1 | 0.10901739587140113 | 0.10901740193367004 | 6.062e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/2/S1 | 0.05203576961298676 | 0.05203577131032944 | 1.697e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/3/S1 | 0.0785440453539274 | 0.07854404300451279 | 2.349e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/4/S1 | 0.07663341666968462 | 0.07663342356681824 | 6.897e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/5/S1 | 0.06695783671804832 | 0.06695783138275146 | 5.335e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/1/S1 | 0.1446820261549132 | 0.14468201994895935 | 6.206e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/2/S1 | 0.14213871753179252 | 0.14213873445987701 | 1.693e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/3/S1 | 0.11820368570332665 | 0.11820369958877563 | 1.389e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/4/S1 | 0.13924925744442385 | 0.13924925029277802 | 7.152e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/5/S1 | 0.13138825558084757 | 0.13138824701309204 | 8.568e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/1/S1 | 0.08703241768551634 | 0.08703242242336273 | 4.738e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/2/S1 | 0.06555198344129883 | 0.06555198132991791 | 2.111e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/3/S1 | 0.07468475347199026 | 0.0746847614645958 | 7.993e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/4/S1 | 0.0857259270354319 | 0.08572591841220856 | 8.623e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/5/S1 | 0.05431058845111221 | 0.05431059002876282 | 1.578e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/2/S1 | 0.041289408268970165 | 0.04128940403461456 | 4.234e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/4/S1 | 0.03188068949292854 | 0.031880687922239304 | 1.571e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/2/S1 | 0.04104068267619824 | 0.041040681302547455 | 1.374e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/4/S1 | 0.04140918178875876 | 0.04140918701887131 | 5.230e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/5/S1 | 0.03775226834370816 | 0.037752266973257065 | 1.370e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/1/S1 | 0.173720086218019 | 0.1737200915813446 | 5.363e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/2/S1 | 0.15382834568637407 | 0.15382833778858185 | 7.898e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/4/S1 | 0.11515476725893407 | 0.11515477299690247 | 5.738e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/5/S1 | 0.11271784614546766 | 0.11271784454584122 | 1.600e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/1/S1 | 0.18199663134871538 | 0.18199662864208221 | 2.707e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/2/S1 | 0.2633511560917789 | 0.2633511424064636 | 1.369e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/3/S1 | 0.23103734116788488 | 0.23103734850883484 | 7.341e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/4/S1 | 0.26921777343350817 | 0.2692177891731262 | 1.574e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/5/S1 | 0.24580189020248444 | 0.2458019107580185 | 2.056e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/1/S1 | 0.10987362667956127 | 0.10987363755702972 | 1.088e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/2/S1 | 0.08058917976534609 | 0.0805891826748848 | 2.910e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/3/S1 | 0.09246544648650284 | 0.09246544539928436 | 1.087e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/4/S1 | 0.06548823088655603 | 0.06548823416233063 | 3.276e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/5/S1 | 0.07965267309041274 | 0.07965266704559326 | 6.045e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/2/S1 | 0.09781150401600351 | 0.0978115051984787 | 1.182e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/4/S1 | 0.06864525897729051 | 0.06864526122808456 | 2.251e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/5/S1 | 0.08555447885120664 | 0.08555448800325394 | 9.152e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/1/S1 | 0.04713797306047747 | 0.04713797569274902 | 2.632e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/2/S1 | 0.041135830233158935 | 0.04113583266735077 | 2.434e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/3/S1 | 0.06655136087946417 | 0.06655135750770569 | 3.372e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/4/S1 | 0.04833137267450023 | 0.048331376165151596 | 3.491e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/5/S1 | 0.06287726505363783 | 0.06287726759910583 | 2.545e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/1/S1 | 0.12240095280950455 | 0.12240096926689148 | 1.646e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/2/S1 | 0.18559385593102637 | 0.1855938583612442 | 2.430e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/3/S1 | 0.12982977506362553 | 0.1298297792673111 | 4.204e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/4/S1 | 0.10022695801702491 | 0.10022695362567902 | 4.391e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/5/S1 | 0.08436921981229809 | 0.08436921238899231 | 7.423e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/1/S1 | 0.1293722726784649 | 0.1293722689151764 | 3.763e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/2/S1 | 0.10389011937683318 | 0.10389013588428497 | 1.651e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/3/S1 | 0.10413458171064108 | 0.10413456708192825 | 1.463e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/5/S1 | 0.1168875646928615 | 0.11688756197690964 | 2.716e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/1/S1 | 0.07506422798969313 | 0.07506423443555832 | 6.446e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/2/S1 | 0.13778647974648212 | 0.13778649270534515 | 1.296e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/3/S1 | 0.10557179322741007 | 0.10557180643081665 | 1.320e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/4/S1 | 0.12860243319538275 | 0.12860244512557983 | 1.193e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/5/S1 | 0.08288900401465589 | 0.08288900554180145 | 1.527e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/1/S1 | 0.21414468247704768 | 0.21414469182491302 | 9.348e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/2/S1 | 0.13257169317330872 | 0.13257168233394623 | 1.084e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/3/S1 | 0.12344880073997927 | 0.12344880402088165 | 3.281e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/4/S1 | 0.14151388167812207 | 0.1415138840675354 | 2.389e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/5/S1 | 0.13377980688617336 | 0.13377980887889862 | 1.993e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/1/W1 | 0.4256515417785684 | 0.42565158009529114 | 3.832e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/2/W1 | 0.3020839057817399 | 0.30208393931388855 | 3.353e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/3/W1 | 0.2575834912396548 | 0.25758349895477295 | 7.715e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/4/W1 | 0.39666078133269667 | 0.39666077494621277 | 6.386e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/5/W1 | 0.34413372895148425 | 0.34413373470306396 | 5.752e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/1/W1 | 0.1364253727113959 | 0.13642537593841553 | 3.227e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/2/W1 | 0.09758501719486042 | 0.097585029900074 | 1.271e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/3/W1 | 0.3407941235647829 | 0.3407941162586212 | 7.306e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/4/W1 | 0.09059926749128422 | 0.09059926867485046 | 1.184e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/1/W1 | 0.17244120503570007 | 0.17244121432304382 | 9.287e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/2/W1 | 0.16533130579063715 | 0.16533130407333374 | 1.717e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/3/W1 | 0.10986091802680752 | 0.10986091941595078 | 1.389e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/4/W1 | 0.15635581562843925 | 0.1563558131456375 | 2.483e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/5/W1 | 0.14609434219548864 | 0.14609433710575104 | 5.090e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/1/W1 | 0.23152144085322895 | 0.23152147233486176 | 3.148e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/2/W1 | 0.2085913516595876 | 0.20859137177467346 | 2.012e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/5/W1 | 0.217019517958863 | 0.21701951324939728 | 4.709e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/1/W1 | 0.15269685195116614 | 0.1526968628168106 | 1.087e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/2/W1 | 0.10381422421507111 | 0.10381422936916351 | 5.154e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/3/W1 | 0.08840869021383466 | 0.08840867877006531 | 1.144e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/5/W1 | 0.12471852073080227 | 0.12471853196620941 | 1.124e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/3/W1 | 0.14113834351573198 | 0.14113834500312805 | 1.487e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/5/W1 | 0.1345813687174297 | 0.13458137214183807 | 3.424e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/1/W1 | 0.20771692820171822 | 0.2077169269323349 | 1.269e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/2/W1 | 0.24884014611851632 | 0.24884015321731567 | 7.099e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/3/W1 | 0.21967185308663686 | 0.2196718454360962 | 7.651e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/4/W1 | 0.148614232597593 | 0.14861422777175903 | 4.826e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/5/W1 | 0.12439780664820273 | 0.12439781427383423 | 7.626e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/1/W1 | 0.3730651303500892 | 0.37306517362594604 | 4.328e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/2/W1 | 0.37635744833252155 | 0.37635746598243713 | 1.765e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/3/W1 | 0.2704638938959206 | 0.27046388387680054 | 1.002e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/4/W1 | 0.3622472406778659 | 0.3622472286224365 | 1.206e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/5/W1 | 0.2858915070473483 | 0.28589150309562683 | 3.952e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/2/W1 | 0.14870941472134777 | 0.14870941638946533 | 1.668e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/3/W1 | 0.130001087484813 | 0.13000108301639557 | 4.468e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/4/W1 | 0.15837747902806756 | 0.15837746858596802 | 1.044e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/5/W1 | 0.1686138063595156 | 0.16861379146575928 | 1.489e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/1/W1 | 0.21091169810884064 | 0.21091169118881226 | 6.920e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/2/W1 | 0.2311787823028248 | 0.23117880523204803 | 2.293e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/3/W1 | 0.20010660941118336 | 0.20010660588741302 | 3.524e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/4/W1 | 0.259224559975247 | 0.2592245638370514 | 3.862e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/5/W1 | 0.16720521323571197 | 0.16720519959926605 | 1.364e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/1/W1 | 0.3036253366229156 | 0.30362531542778015 | 2.120e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/2/W1 | 0.28067544921214665 | 0.2806754410266876 | 8.185e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/3/W1 | 0.2815736849852835 | 0.28157365322113037 | 3.176e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/4/W1 | 0.2312561853538372 | 0.23125620186328888 | 1.651e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/5/W1 | 0.32439154004224613 | 0.32439151406288147 | 2.598e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/1/W1 | 0.2661589177395857 | 0.26615890860557556 | 9.134e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/2/W1 | 0.19688703920366965 | 0.1968870609998703 | 2.180e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/3/W1 | 0.27632466971623937 | 0.27632462978363037 | 3.993e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/4/W1 | 0.22866447791527722 | 0.22866447269916534 | 5.216e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/5/W1 | 0.21609507323827132 | 0.21609506011009216 | 1.313e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/1/W1 | 0.3977697167304509 | 0.3977696895599365 | 2.717e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/2/W1 | 0.4413495962270907 | 0.4413495659828186 | 3.024e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/3/W1 | 0.4305968497684043 | 0.43059685826301575 | 8.495e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/4/W1 | 0.41127270008548533 | 0.41127270460128784 | 4.516e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/5/W1 | 0.4211686212789598 | 0.42116859555244446 | 2.573e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/1/W1 | 0.17183121251428657 | 0.17183120548725128 | 7.027e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/2/W1 | 0.24062997799923747 | 0.24062997102737427 | 6.972e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/3/W1 | 0.21649642989638715 | 0.21649642288684845 | 7.010e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/4/W1 | 0.17172043638949422 | 0.17172043025493622 | 6.135e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/5/W1 | 0.19821093314997992 | 0.1982109397649765 | 6.615e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/1/W1 | 0.09571712653156396 | 0.09571713209152222 | 5.560e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/2/W1 | 0.09668153560470018 | 0.09668152779340744 | 7.811e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/3/W1 | 0.08437901670785612 | 0.08437902480363846 | 8.096e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/5/W1 | 0.09425739379204366 | 0.0942573994398117 | 5.648e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/1/W1 | 0.34247429623395975 | 0.3424742817878723 | 1.445e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/2/W1 | 0.3005521617348313 | 0.3005521297454834 | 3.199e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/3/W1 | 0.24587837118279915 | 0.24587835371494293 | 1.747e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/4/W1 | 0.3649324710876805 | 0.36493244767189026 | 2.342e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/5/W1 | 0.23650855893097966 | 0.2365085631608963 | 4.230e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/1/W1 | 0.1779653797915711 | 0.17796538770198822 | 7.910e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/2/W1 | 0.19659729996875785 | 0.19659730792045593 | 7.952e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/4/W1 | 0.19477185869581937 | 0.1947718858718872 | 2.718e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/5/W1 | 0.1735071284018831 | 0.17350713908672333 | 1.068e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/1/W1 | 0.10629547368499309 | 0.10629548132419586 | 7.639e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/2/W1 | 0.11095104012081405 | 0.11095103621482849 | 3.906e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/3/W1 | 0.1023606884454782 | 0.10236069560050964 | 7.155e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/4/W1 | 0.12879070266961343 | 0.1287907063961029 | 3.726e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/5/W1 | 0.16005758496140274 | 0.16005758941173553 | 4.450e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/1/W1 | 0.1575537081522597 | 0.15755370259284973 | 5.559e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/2/W1 | 0.13997260456485736 | 0.13997259736061096 | 7.204e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/3/W1 | 0.1464471058021032 | 0.1464471071958542 | 1.394e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/4/W1 | 0.1800520846373304 | 0.18005208671092987 | 2.074e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/5/W1 | 0.1380143780558633 | 0.13801436126232147 | 1.679e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/1/W1 | 0.30235746382759626 | 0.3023574650287628 | 1.201e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/2/W1 | 0.24203126516776893 | 0.2420312762260437 | 1.106e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/3/W1 | 0.2918488642979952 | 0.2918488681316376 | 3.834e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/4/W1 | 0.3244889578714592 | 0.3244889974594116 | 3.959e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/5/W1 | 0.4049914712806102 | 0.4049915075302124 | 3.625e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/1/W1 | 0.08985466039890427 | 0.0898546576499939 | 2.749e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/2/W1 | 0.07895480734829302 | 0.07895480841398239 | 1.066e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/3/W1 | 0.08408520687594993 | 0.08408520370721817 | 3.169e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/4/W1 | 0.07947667457022625 | 0.07947668433189392 | 9.762e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/5/W1 | 0.09669366475919235 | 0.09669365733861923 | 7.421e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/1/W1 | 0.22818932881376283 | 0.22818933427333832 | 5.460e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/2/W1 | 0.21042424574992988 | 0.21042422950267792 | 1.625e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/4/W1 | 0.23251872829207784 | 0.23251871764659882 | 1.065e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/1/W1 | 0.36100098852106394 | 0.36100101470947266 | 2.619e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/2/W1 | 0.18650220315170593 | 0.18650218844413757 | 1.471e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/3/W1 | 0.17178752801016844 | 0.17178753018379211 | 2.174e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/4/W1 | 0.22720894558188054 | 0.2272089123725891 | 3.321e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/5/W1 | 0.1780856075858191 | 0.17808561027050018 | 2.685e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/1/W1 | 0.2043673709505752 | 0.20436736941337585 | 1.537e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/2/W1 | 0.13992125165015928 | 0.13992126286029816 | 1.121e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/3/W1 | 0.1261091256456099 | 0.12610910832881927 | 1.732e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/4/W1 | 0.21530894546791554 | 0.21530893445014954 | 1.102e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/1/W1 | 0.1770980242180652 | 0.17709802091121674 | 3.307e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/2/W1 | 0.15763281703201218 | 0.15763281285762787 | 4.174e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/4/W1 | 0.14552579230878854 | 0.14552578330039978 | 9.008e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/5/W1 | 0.1928862333438276 | 0.19288621842861176 | 1.492e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/1/W1 | 0.5044461600845463 | 0.5044462084770203 | 4.839e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/2/W1 | 0.47517262131099 | 0.47517263889312744 | 1.758e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/3/W1 | 0.5223991785725692 | 0.5223991870880127 | 8.515e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/4/W1 | 0.3220620972521099 | 0.32206207513809204 | 2.211e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/5/W1 | 0.41382529092971554 | 0.41382527351379395 | 1.742e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/1/W1 | 0.366329885260389 | 0.3663298785686493 | 6.692e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/2/W1 | 0.14485320817689287 | 0.14485320448875427 | 3.688e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/3/W1 | 0.1753365284105988 | 0.17533650994300842 | 1.847e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/4/W1 | 0.3389757981209594 | 0.33897581696510315 | 1.884e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/5/W1 | 0.3414945322703056 | 0.34149447083473206 | 6.144e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/1/W1 | 0.1308711260384402 | 0.13087111711502075 | 8.923e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/2/W1 | 0.13382203748009064 | 0.13382203876972198 | 1.290e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/3/W1 | 0.08761245466540048 | 0.08761245757341385 | 2.908e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/4/W1 | 0.13600948859092815 | 0.13600949943065643 | 1.084e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/1/W1 | 0.11203298271503441 | 0.11203298717737198 | 4.462e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/3/W1 | 0.08757190495196981 | 0.0875718966126442 | 8.339e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/4/W1 | 0.10193442316838974 | 0.10193443298339844 | 9.815e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/5/W1 | 0.10451205791893381 | 0.1045120507478714 | 7.171e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/1/W1 | 0.11597422980826169 | 0.11597422510385513 | 4.704e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/2/W1 | 0.09245233454379856 | 0.09245232492685318 | 9.617e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/3/W1 | 0.09629069550857983 | 0.0962906926870346 | 2.822e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/4/W1 | 0.11189574503773496 | 0.11189575493335724 | 9.896e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/5/W1 | 0.12023168551313193 | 0.12023169547319412 | 9.960e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/1/W1 | 0.27646894818372036 | 0.276468962430954 | 1.425e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/2/W1 | 0.22207072924837137 | 0.22207075357437134 | 2.433e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/3/W1 | 0.19688180275098552 | 0.19688181579113007 | 1.304e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/4/W1 | 0.2070923427807454 | 0.20709234476089478 | 1.980e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/5/W1 | 0.21489489937982353 | 0.21489490568637848 | 6.307e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/3/W1 | 0.06166636081337368 | 0.06166635826230049 | 2.551e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/4/W1 | 0.07245652279294304 | 0.07245651632547379 | 6.467e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/1/W1 | 0.08766293692647599 | 0.08766292780637741 | 9.120e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/2/W1 | 0.0819334398160503 | 0.08193343877792358 | 1.038e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/3/W1 | 0.08184238932872946 | 0.08184239268302917 | 3.354e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/4/W1 | 0.12388624823692952 | 0.12388624250888824 | 5.728e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/5/W1 | 0.10263606993892203 | 0.10263607650995255 | 6.571e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/1/W1 | 0.2809231543724464 | 0.28092312812805176 | 2.624e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/2/W1 | 0.28903736561029614 | 0.2890373766422272 | 1.103e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/3/W1 | 0.30145328233851376 | 0.30145329236984253 | 1.003e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/4/W1 | 0.30784271881698855 | 0.3078427016735077 | 1.714e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/5/W1 | 0.272113898956696 | 0.2721138894557953 | 9.501e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/1/W1 | 0.08042842291064929 | 0.08042842149734497 | 1.413e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/2/W1 | 0.08306968649394979 | 0.08306968957185745 | 3.078e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/3/W1 | 0.08018907758999533 | 0.0801890641450882 | 1.344e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/4/W1 | 0.08613628702884726 | 0.08613628149032593 | 5.539e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/5/W1 | 0.08668927515295778 | 0.08668927103281021 | 4.120e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/1/W1 | 0.07383223306109024 | 0.07383223623037338 | 3.169e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/2/W1 | 0.07588880145382589 | 0.07588880509138107 | 3.638e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/4/W1 | 0.07122752798517604 | 0.0712275356054306 | 7.620e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/5/W1 | 0.07013539439875835 | 0.07013539224863052 | 2.150e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/1/W1 | 0.08005489820203937 | 0.08005489408969879 | 4.112e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/2/W1 | 0.08588615722918141 | 0.0858861654996872 | 8.271e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/3/W1 | 0.08688577137649943 | 0.08688576519489288 | 6.182e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/4/W1 | 0.09128500038512075 | 0.09128499776124954 | 2.624e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/5/W1 | 0.09015592505994043 | 0.0901559367775917 | 1.172e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/1/W1 | 0.20949026922510355 | 0.20949028432369232 | 1.510e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/3/W1 | 0.13808288555874798 | 0.13808289170265198 | 6.144e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/4/W1 | 0.1498957955810258 | 0.1498958021402359 | 6.559e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/5/W1 | 0.1400614773655691 | 0.14006148278713226 | 5.422e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/1/W1 | 0.21981308882198305 | 0.21981309354305267 | 4.721e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/2/W1 | 0.19268024993952904 | 0.1926802694797516 | 1.954e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/3/W1 | 0.1883129986411495 | 0.18831300735473633 | 8.714e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/4/W1 | 0.15823110373106034 | 0.15823110938072205 | 5.650e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/5/W1 | 0.1700006115310925 | 0.17000062763690948 | 1.611e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/1/W1 | 0.2115390749645724 | 0.21153905987739563 | 1.509e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/2/W1 | 0.16462297317753688 | 0.164622962474823 | 1.070e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/4/W1 | 0.15862500340922453 | 0.15862499177455902 | 1.163e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/5/W1 | 0.1896526661353423 | 0.1896526962518692 | 3.012e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/1/W1 | 0.19089429959003695 | 0.19089430570602417 | 6.116e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/2/W1 | 0.18476233379789694 | 0.18476234376430511 | 9.966e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/3/W1 | 0.17667967437771093 | 0.17667967081069946 | 3.567e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/4/W1 | 0.12753442447360894 | 0.1275344341993332 | 9.726e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/5/W1 | 0.19052167415847787 | 0.19052167236804962 | 1.790e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/1/W1 | 0.2874861825200823 | 0.28748619556427 | 1.304e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/3/W1 | 0.24101967946265548 | 0.24101966619491577 | 1.327e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/4/W1 | 0.18284534179414685 | 0.1828453242778778 | 1.752e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/5/W1 | 0.27101215649993937 | 0.27101218700408936 | 3.050e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/1/W1 | 0.17158106597371464 | 0.17158107459545135 | 8.622e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/2/W1 | 0.16208193608901997 | 0.16208194196224213 | 5.873e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/3/W1 | 0.1456590646043151 | 0.14565905928611755 | 5.318e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/4/W1 | 0.15569178673424966 | 0.15569180250167847 | 1.577e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/2/W1 | 0.1539872639911442 | 0.15398725867271423 | 5.318e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/3/W1 | 0.12318013542395816 | 0.12318014353513718 | 8.111e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/4/W1 | 0.24200738010629386 | 0.24200737476348877 | 5.343e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/5/W1 | 0.10926623163075166 | 0.1092662364244461 | 4.794e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/1/W1 | 0.12026869884488663 | 0.12026870995759964 | 1.111e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/2/W1 | 0.13112771774575133 | 0.13112770020961761 | 1.754e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/3/W1 | 0.13055896594227576 | 0.13055895268917084 | 1.325e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/4/W1 | 0.11618522451500919 | 0.11618523299694061 | 8.482e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/5/W1 | 0.15143983170060266 | 0.15143983066082 | 1.040e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/1/W1 | 0.32717738190645457 | 0.32717740535736084 | 2.345e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/2/W1 | 0.2671709695360927 | 0.2671709656715393 | 3.865e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/3/W1 | 0.25846126068464864 | 0.25846123695373535 | 2.373e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/4/W1 | 0.2562647425538116 | 0.25626474618911743 | 3.635e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/5/W1 | 0.26739438095204243 | 0.26739436388015747 | 1.707e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/1/W1 | 0.3926794941388575 | 0.39267948269844055 | 1.144e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/2/W1 | 0.3792075403589222 | 0.3792075216770172 | 1.868e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/3/W1 | 0.44771351579628493 | 0.4477134644985199 | 5.130e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/4/W1 | 0.43974618498042195 | 0.4397462010383606 | 1.606e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/5/W1 | 0.509251561587603 | 0.509251594543457 | 3.296e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/1/W1 | 0.18934083871945545 | 0.18934084475040436 | 6.031e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/2/W1 | 0.23313863928136025 | 0.23313863575458527 | 3.527e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/3/W1 | 0.23769792480468932 | 0.23769792914390564 | 4.339e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/4/W1 | 0.22897441800032342 | 0.22897440195083618 | 1.605e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/5/W1 | 0.18890502212110558 | 0.1889050453901291 | 2.327e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/1/W1 | 0.1817873788183483 | 0.1817874014377594 | 2.262e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/2/W1 | 0.16189965049053612 | 0.1618996560573578 | 5.567e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/3/W1 | 0.17169408787845974 | 0.1716940850019455 | 2.877e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/4/W1 | 0.2496097799364825 | 0.2496097981929779 | 1.826e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/1/W1 | 0.15116922718105574 | 0.15116924047470093 | 1.329e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/2/W1 | 0.10692147261362869 | 0.1069214791059494 | 6.492e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/3/W1 | 0.16285267700281827 | 0.1628526896238327 | 1.262e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/4/W1 | 0.1418746472430204 | 0.14187464118003845 | 6.063e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/5/W1 | 0.17684541840371648 | 0.17684540152549744 | 1.688e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/1/W1 | 0.315547536870554 | 0.31554752588272095 | 1.099e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/3/W1 | 0.31305153027340876 | 0.3130515217781067 | 8.495e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/4/W1 | 0.34382295447934774 | 0.3438229262828827 | 2.820e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/5/W1 | 0.38566173852835683 | 0.38566169142723083 | 4.710e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/1/W1 | 0.2569415043282768 | 0.2569414973258972 | 7.002e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/2/W1 | 0.2678765081622738 | 0.2678765058517456 | 2.311e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/3/W1 | 0.29003298986977666 | 0.2900329828262329 | 7.044e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/4/W1 | 0.20852834193543157 | 0.2085283398628235 | 2.073e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/5/W1 | 0.29353580686580405 | 0.2935357987880707 | 8.078e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/1/W1 | 0.26540633108679346 | 0.2654063105583191 | 2.053e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/2/W1 | 0.33744629068472515 | 0.3374462425708771 | 4.811e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/3/W1 | 0.2872547333038134 | 0.2872547209262848 | 1.238e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/4/W1 | 0.22784200927627005 | 0.22784198820590973 | 2.107e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/5/W1 | 0.3635277404941333 | 0.36352774500846863 | 4.514e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/1/W1 | 0.4472498911484431 | 0.4472498595714569 | 3.158e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/2/W1 | 0.404773675507303 | 0.40477368235588074 | 6.849e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/3/W1 | 0.32758789107199404 | 0.32758793234825134 | 4.128e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/4/W1 | 0.3196431647767816 | 0.31964313983917236 | 2.494e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/5/W1 | 0.44196475151530157 | 0.4419647455215454 | 5.994e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/1/W4 | 0.06261371462978454 | 0.06261371821165085 | 3.582e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/2/W4 | 0.04863922781856886 | 0.04863923043012619 | 2.612e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/3/W4 | 0.04382368769181959 | 0.04382369667291641 | 8.981e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/4/W4 | 0.048422018699471915 | 0.04842201620340347 | 2.496e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/5/W4 | 0.05634565170858329 | 0.05634564533829689 | 6.370e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/2/W4 | 0.01565436538670845 | 0.015654362738132477 | 2.649e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/4/W4 | 0.013021097315985086 | 0.01302109844982624 | 1.134e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/5/W4 | 0.022957356193507167 | 0.02295735292136669 | 3.272e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/1/W4 | 0.029368926842305628 | 0.02936892956495285 | 2.723e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/2/W4 | 0.027656786453712483 | 0.027656788006424904 | 1.553e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/4/W4 | 0.029402305061637834 | 0.02940230816602707 | 3.104e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/1/W4 | 0.01800649931205529 | 0.018006501719355583 | 2.407e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/1/W4 | 0.021764108721220036 | 0.021764110773801804 | 2.053e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/2/W4 | 0.01892386866852646 | 0.018923871219158173 | 2.551e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/5/W4 | 0.01712402312145105 | 0.01712402142584324 | 1.696e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/1/W4 | 0.028898752788428156 | 0.028898751363158226 | 1.425e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/3/W4 | 0.03603887394468888 | 0.036038871854543686 | 2.090e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/4/W4 | 0.019924828676608927 | 0.0199248306453228 | 1.969e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/5/W4 | 0.014366598637115358 | 0.01436659973114729 | 1.094e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/1/W4 | 0.060202589963041175 | 0.06020258367061615 | 6.292e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/2/W4 | 0.05545791068371952 | 0.05545791611075401 | 5.427e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/3/W4 | 0.04567999729170873 | 0.04567999392747879 | 3.364e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/5/W4 | 0.048865819058979305 | 0.04886581376194954 | 5.297e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/1/W4 | 0.02418549689671813 | 0.02418549545109272 | 1.446e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/2/W4 | 0.023402646393664964 | 0.02340264804661274 | 1.653e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/4/W4 | 0.02370485591304799 | 0.023704854771494865 | 1.142e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/5/W4 | 0.026247114172342954 | 0.026247112080454826 | 2.092e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/1/W4 | 0.03105648075198017 | 0.0310564823448658 | 1.593e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/2/W4 | 0.04121236639051065 | 0.04121236875653267 | 2.366e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/3/W4 | 0.03436991995416438 | 0.034369923174381256 | 3.220e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/4/W4 | 0.03939625667755516 | 0.0393962599337101 | 3.256e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/5/W4 | 0.024779097002511977 | 0.024779092520475388 | 4.482e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/1/W4 | 0.046660141087671934 | 0.04666014760732651 | 6.520e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/2/W4 | 0.04436097804447727 | 0.04436098411679268 | 6.072e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/3/W4 | 0.0477353605029941 | 0.047735366970300674 | 6.467e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/4/W4 | 0.031137837737823366 | 0.03113783523440361 | 2.503e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/5/W4 | 0.046244747345052406 | 0.04624474421143532 | 3.134e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/1/W4 | 0.03686460285147439 | 0.03686460480093956 | 1.949e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/2/W4 | 0.028623089963823865 | 0.02862309291958809 | 2.956e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/3/W4 | 0.0498407543240833 | 0.04984074458479881 | 9.739e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/4/W4 | 0.03572093760117866 | 0.035720933228731155 | 4.372e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/5/W4 | 0.03276937603060782 | 0.032769378274679184 | 2.244e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/1/W4 | 0.09000660338085698 | 0.09000659734010696 | 6.041e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/2/W4 | 0.10638999342506134 | 0.10638997703790665 | 1.639e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/3/W4 | 0.10700258709454072 | 0.10700259357690811 | 6.482e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/4/W4 | 0.082134041804301 | 0.08213403820991516 | 3.594e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/5/W4 | 0.08860804162263226 | 0.08860804885625839 | 7.234e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/1/W4 | 0.023966137345595037 | 0.023966139182448387 | 1.837e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/2/W4 | 0.03804636257245742 | 0.03804636374115944 | 1.169e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/5/W4 | 0.015471711203675954 | 0.015471712686121464 | 1.482e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/1/W4 | 0.05654717367599099 | 0.05654717609286308 | 2.417e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/2/W4 | 0.034736079976415965 | 0.03473607823252678 | 1.744e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/3/W4 | 0.03087546423918191 | 0.030875463038682938 | 1.200e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/5/W4 | 0.04419476817755706 | 0.04419476538896561 | 2.789e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/1/W4 | 0.02137642373140757 | 0.02137642540037632 | 1.669e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/4/W4 | 0.025154462014011492 | 0.025154460221529007 | 1.792e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/1/W4 | 0.01690841051461862 | 0.01690840907394886 | 1.441e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/5/W4 | 0.021934109355713004 | 0.021934110671281815 | 1.316e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/1/W4 | 0.019945159187944646 | 0.019945157691836357 | 1.496e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/2/W4 | 0.018473545433611575 | 0.018473543226718903 | 2.207e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/3/W4 | 0.0216591586787795 | 0.021659160032868385 | 1.354e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/1/W4 | 0.057591948984404874 | 0.05759195238351822 | 3.399e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/2/W4 | 0.04941840143653467 | 0.04941840469837189 | 3.262e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/3/W4 | 0.04803782795424676 | 0.0480378232896328 | 4.665e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/4/W4 | 0.051680070462663937 | 0.0516800656914711 | 4.771e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/5/W4 | 0.06678311639562932 | 0.0667831152677536 | 1.128e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/1/W4 | 0.017290381316127968 | 0.017290379852056503 | 1.464e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/1/W4 | 0.028583135863016067 | 0.028583133593201637 | 2.270e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/2/W4 | 0.028704859175029976 | 0.02870485745370388 | 1.721e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/3/W4 | 0.02449323303209832 | 0.024493234232068062 | 1.200e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/1/W4 | 0.05284436131076413 | 0.05284435674548149 | 4.565e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/3/W4 | 0.016812179620699433 | 0.016812177374958992 | 2.246e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/4/W4 | 0.037539658402363674 | 0.037539657205343246 | 1.197e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/1/W4 | 0.01674634765899294 | 0.016746345907449722 | 1.752e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/5/W4 | 0.019172613169941375 | 0.019172614440321922 | 1.270e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/1/W4 | 0.1194056266323993 | 0.11940563470125198 | 8.069e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/2/W4 | 0.08384852804561288 | 0.0838485136628151 | 1.438e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/3/W4 | 0.11529626037738788 | 0.11529625207185745 | 8.306e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/4/W4 | 0.040046168815112075 | 0.040046170353889465 | 1.539e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/5/W4 | 0.06486089539083928 | 0.06486088782548904 | 7.565e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/1/W4 | 0.04976130301767841 | 0.04976130649447441 | 3.477e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/4/W4 | 0.03946391745517209 | 0.039463918656110764 | 1.201e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/5/W4 | 0.04486681348878624 | 0.04486681893467903 | 5.446e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/2/W4 | 0.023737520294743086 | 0.02373751811683178 | 2.178e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/3/W4 | 0.013575212916480369 | 0.013575213961303234 | 1.045e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/5/W4 | 0.022298961740668765 | 0.022298960015177727 | 1.725e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/4/W4 | 0.012341804689591758 | 0.01234180573374033 | 1.044e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/3/W4 | 0.028336462301541666 | 0.02833646535873413 | 3.057e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/5/W4 | 0.035420562057998844 | 0.03542055934667587 | 2.711e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/2/W4 | 0.012209721342049222 | 0.01220971904695034 | 2.295e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/3/W4 | 0.01593134526157554 | 0.015931343659758568 | 1.602e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/2/W4 | 0.05053532883166095 | 0.050535332411527634 | 3.580e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/3/W4 | 0.05595546453906063 | 0.05595546215772629 | 2.381e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/4/W4 | 0.04679785456087918 | 0.04679785296320915 | 1.598e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/5/W4 | 0.043723058554060217 | 0.04372306913137436 | 1.058e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/2/W4 | 0.013123361298796274 | 0.013123362325131893 | 1.026e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/4/W4 | 0.01083324417661262 | 0.010833242908120155 | 1.268e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/5/W4 | 0.017061283768628435 | 0.017061281949281693 | 1.819e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/1/W4 | 0.020926793449510327 | 0.02092679589986801 | 2.450e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/3/W4 | 0.034983621706385776 | 0.034983620047569275 | 1.659e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/5/W4 | 0.027255114757375475 | 0.027255112305283546 | 2.452e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/1/W4 | 0.02814797854172544 | 0.028147980570793152 | 2.029e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/5/W4 | 0.02313281635883275 | 0.023132817819714546 | 1.461e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/2/W4 | 0.017341206539427282 | 0.017341207712888718 | 1.173e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/5/W4 | 0.01637282077443155 | 0.01637282222509384 | 1.451e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/1/W4 | 0.04199509011559754 | 0.0419950932264328 | 3.111e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/2/W4 | 0.02840739195069107 | 0.028407389298081398 | 2.653e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/3/W4 | 0.027036306724745378 | 0.027036303654313087 | 3.070e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/4/W4 | 0.021438277395318794 | 0.021438276395201683 | 1.000e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/1/W4 | 0.020330151385623548 | 0.020330149680376053 | 1.705e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/2/W4 | 0.02127741671086106 | 0.021277418360114098 | 1.649e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/3/W4 | 0.022234817114396278 | 0.02223481610417366 | 1.010e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/5/W4 | 0.04603390595948323 | 0.04603390395641327 | 2.003e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/2/W4 | 0.02222483556498916 | 0.02222483791410923 | 2.349e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/4/W4 | 0.02659869942526303 | 0.026598701253533363 | 1.828e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/1/W4 | 0.017676161027329284 | 0.017676159739494324 | 1.288e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/2/W4 | 0.020565447631838204 | 0.020565444603562355 | 3.028e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/3/W4 | 0.02061045482191866 | 0.02061045728623867 | 2.464e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/4/W4 | 0.01890169517080413 | 0.018901696428656578 | 1.258e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/5/W4 | 0.021195298125924637 | 0.021195299923419952 | 1.797e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/1/W4 | 0.05033832133904524 | 0.050338324159383774 | 2.820e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/2/W4 | 0.05014971589412251 | 0.05014971271157265 | 3.183e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/3/W4 | 0.0398958304624389 | 0.03989582881331444 | 1.649e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/4/W4 | 0.03554221439720339 | 0.035542212426662445 | 1.971e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/5/W4 | 0.04722840509832895 | 0.04722840338945389 | 1.709e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/1/W4 | 0.08952697985373476 | 0.08952698856592178 | 8.712e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/2/W4 | 0.07171893526592697 | 0.07171893864870071 | 3.383e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/3/W4 | 0.10210815870099647 | 0.10210816562175751 | 6.921e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/4/W4 | 0.08942360631620444 | 0.08942361921072006 | 1.289e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/3/W4 | 0.03455204407695906 | 0.03455204516649246 | 1.090e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/5/W4 | 0.025502352302851184 | 0.02550235018134117 | 2.122e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/1/W4 | 0.033251515603458334 | 0.03325151279568672 | 2.808e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/2/W4 | 0.030059639136345302 | 0.030059637501835823 | 1.635e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/3/W4 | 0.026314909883533747 | 0.026314912363886833 | 2.480e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/4/W4 | 0.034096704668617916 | 0.03409670665860176 | 1.990e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/3/W4 | 0.02515423004722346 | 0.02515423111617565 | 1.069e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/5/W4 | 0.019854625813789942 | 0.019854627549648285 | 1.736e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/1/W4 | 0.031784850923345494 | 0.03178485482931137 | 3.906e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/2/W4 | 0.028019508917913313 | 0.028019510209560394 | 1.292e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/3/W4 | 0.05323831122638956 | 0.05323830991983414 | 1.307e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/4/W4 | 0.05235575285139431 | 0.05235575512051582 | 2.269e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/2/W4 | 0.047803069092011846 | 0.04780306667089462 | 2.421e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/3/W4 | 0.04543205020880252 | 0.04543204605579376 | 4.153e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/4/W4 | 0.02830532759726654 | 0.028305325657129288 | 1.940e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/1/W4 | 0.046058065233881874 | 0.04605806991457939 | 4.681e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/3/W4 | 0.06071208334346097 | 0.06071208044886589 | 2.895e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/4/W4 | 0.03457184652372697 | 0.03457184135913849 | 5.165e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/5/W4 | 0.06840103269112899 | 0.0684010311961174 | 1.495e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/1/W4 | 0.07495753139402005 | 0.07495752722024918 | 4.174e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/2/W4 | 0.0711520567533741 | 0.07115205377340317 | 2.980e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/3/W4 | 0.04946220798062973 | 0.0494622103869915 | 2.406e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/4/W4 | 0.04759509202714854 | 0.04759509488940239 | 2.862e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/5/W4 | 0.09169283297710663 | 0.09169283509254456 | 2.115e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/1/W5 | 0.2816334728642301 | 0.2816334664821625 | 6.382e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/2/W5 | 0.1957588136829348 | 0.19575881958007812 | 5.897e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/3/W5 | 0.16725564361511178 | 0.16725565493106842 | 1.132e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/4/W5 | 0.2292450301383581 | 0.22924503684043884 | 6.702e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 1/5/W5 | 0.24034004125577166 | 0.24034003913402557 | 2.122e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/1/W5 | 0.05466400287309231 | 0.0546640120446682 | 9.172e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/3/W5 | 0.1942774778984234 | 0.19427748024463654 | 2.346e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 2/4/W5 | 0.046808234392352877 | 0.04680823162198067 | 2.770e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/1/W5 | 0.09140644549665707 | 0.0914064422249794 | 3.272e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/2/W5 | 0.09892421273837027 | 0.09892420470714569 | 8.031e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/3/W5 | 0.07174317382317456 | 0.07174317538738251 | 1.564e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/4/W5 | 0.07388918603798354 | 0.07388919591903687 | 9.881e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 3/5/W5 | 0.08850473491737006 | 0.08850473165512085 | 3.262e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/1/W5 | 0.14265606371125 | 0.14265607297420502 | 9.263e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/2/W5 | 0.12668037185105596 | 0.12668035924434662 | 1.261e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/3/W5 | 0.09760681267748775 | 0.09760680794715881 | 4.730e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 4/5/W5 | 0.13423663752841886 | 0.1342366337776184 | 3.751e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/1/W5 | 0.07310023470310081 | 0.07310023158788681 | 3.115e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/2/W5 | 0.05888734566372239 | 0.05888734385371208 | 1.810e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/3/W5 | 0.06149971618912295 | 0.061499714851379395 | 1.338e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/4/W5 | 0.06241930568840292 | 0.062419310212135315 | 4.524e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 5/5/W5 | 0.05677761165981545 | 0.05677761510014534 | 3.440e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/1/W5 | 0.0902530307713099 | 0.09025304019451141 | 9.423e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/2/W5 | 0.08046876288940684 | 0.08046876639127731 | 3.502e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/3/W5 | 0.08094420303085212 | 0.08094419538974762 | 7.641e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/4/W5 | 0.08708396832579682 | 0.08708395808935165 | 1.024e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 6/5/W5 | 0.06950049261602377 | 0.06950049102306366 | 1.593e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/1/W5 | 0.11946966092368629 | 0.11946966499090195 | 4.067e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/2/W5 | 0.14563897048075472 | 0.14563897252082825 | 2.040e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/3/W5 | 0.14352425435457744 | 0.14352425932884216 | 4.974e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 7/4/W5 | 0.07811559690618357 | 0.07811560481786728 | 7.912e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/1/W5 | 0.25841374452107546 | 0.25841376185417175 | 1.733e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/2/W5 | 0.258636659904153 | 0.2586366534233093 | 6.481e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/3/W5 | 0.19210547222226734 | 0.1921054869890213 | 1.477e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/4/W5 | 0.2603071559380586 | 0.2603071928024292 | 3.686e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 8/5/W5 | 0.19711395679826052 | 0.19711393117904663 | 2.562e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/1/W5 | 0.09706708376818654 | 0.09706708788871765 | 4.121e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/2/W5 | 0.09158222773271371 | 0.09158223122358322 | 3.491e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/3/W5 | 0.0916569369462672 | 0.09165694564580917 | 8.700e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/4/W5 | 0.09628887137780597 | 0.09628888219594955 | 1.082e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 9/5/W5 | 0.10303069021020439 | 0.10303068906068802 | 1.150e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/1/W5 | 0.12967158278405777 | 0.1296715885400772 | 5.756e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/2/W5 | 0.16718751431641243 | 0.16718754172325134 | 2.741e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/3/W5 | 0.13336877041225925 | 0.13336877524852753 | 4.836e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/4/W5 | 0.17198946441336857 | 0.17198948562145233 | 2.121e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 10/5/W5 | 0.09397207790991338 | 0.09397207945585251 | 1.546e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/1/W5 | 0.20010696527085783 | 0.20010697841644287 | 1.315e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/2/W5 | 0.18403854378781745 | 0.18403854966163635 | 5.874e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/3/W5 | 0.19300443202689102 | 0.19300441443920135 | 1.759e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/4/W5 | 0.1273711161039336 | 0.12737111747264862 | 1.369e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 11/5/W5 | 0.2119151208998386 | 0.21191510558128357 | 1.532e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/1/W5 | 0.17106903925983175 | 0.17106905579566956 | 1.654e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/2/W5 | 0.11683909610406774 | 0.11683910340070724 | 7.297e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/3/W5 | 0.20045385864375315 | 0.20045384764671326 | 1.100e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/4/W5 | 0.15200272147126087 | 0.1520027369260788 | 1.545e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 12/5/W5 | 0.1301961795579167 | 0.13019618391990662 | 4.362e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/1/W5 | 0.3382221270595376 | 0.33822208642959595 | 4.063e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/2/W5 | 0.3619351879286141 | 0.36193519830703735 | 1.038e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/3/W5 | 0.37541236416377943 | 0.37541237473487854 | 1.057e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/4/W5 | 0.32319509500685983 | 0.32319509983062744 | 4.824e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 13/5/W5 | 0.3303595987063614 | 0.3303595781326294 | 2.057e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/1/W5 | 0.0904176933863782 | 0.09041769802570343 | 4.639e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/2/W5 | 0.15093852935043242 | 0.15093852579593658 | 3.554e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/3/W5 | 0.12812230351685552 | 0.12812229990959167 | 3.607e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/4/W5 | 0.09049832242417871 | 0.09049832075834274 | 1.666e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 14/5/W5 | 0.10872478503650271 | 0.10872478783130646 | 2.795e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/2/W5 | 0.0672443752938132 | 0.06724437326192856 | 2.032e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/3/W5 | 0.058202215228298534 | 0.05820221081376076 | 4.415e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 15/5/W5 | 0.0576213543817454 | 0.05762134864926338 | 5.732e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/1/W5 | 0.26223720552240204 | 0.26223719120025635 | 1.432e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/2/W5 | 0.17234180653993866 | 0.17234180867671967 | 2.137e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/3/W5 | 0.13574434933341295 | 0.1357443481683731 | 1.165e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/4/W5 | 0.25724308798705187 | 0.2572430670261383 | 2.096e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 16/5/W5 | 0.1840008686420773 | 0.1840008795261383 | 1.088e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/1/W5 | 0.08897365625772577 | 0.08897364884614944 | 7.412e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/2/W5 | 0.09877475281573689 | 0.09877476096153259 | 8.146e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/3/W5 | 0.08949166103519185 | 0.08949166536331177 | 4.328e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/4/W5 | 0.09972676506675066 | 0.09972676634788513 | 1.281e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 17/5/W5 | 0.08540963163554893 | 0.08540964126586914 | 9.630e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/2/W5 | 0.07819288840270683 | 0.07819288969039917 | 1.288e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/3/W5 | 0.06788487086250183 | 0.06788487732410431 | 6.462e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/4/W5 | 0.07744753821034227 | 0.07744754105806351 | 2.848e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 18/5/W5 | 0.0965923222896741 | 0.09659232944250107 | 7.153e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/1/W5 | 0.08299137190284885 | 0.08299136161804199 | 1.028e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/2/W5 | 0.07377049450874536 | 0.07377049326896667 | 1.240e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/3/W5 | 0.09292444282149004 | 0.09292444586753845 | 3.046e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/4/W5 | 0.09216401775662376 | 0.09216400980949402 | 7.947e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 19/5/W5 | 0.07896850440216817 | 0.07896850258111954 | 1.821e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/1/W5 | 0.23433386615094146 | 0.2343338131904602 | 5.296e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/2/W5 | 0.18237215457687891 | 0.18237215280532837 | 1.772e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/3/W5 | 0.19730784832434098 | 0.19730785489082336 | 6.566e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/4/W5 | 0.2179304195820187 | 0.217930406332016 | 1.325e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 20/5/W5 | 0.2877514432925652 | 0.2877514660358429 | 2.274e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/1/W5 | 0.0601470792279753 | 0.06014707684516907 | 2.383e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/2/W5 | 0.05551886631548528 | 0.05551886931061745 | 2.995e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/3/W5 | 0.05656239660279347 | 0.0565623939037323 | 2.699e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/4/W5 | 0.05105419250486491 | 0.05105419084429741 | 1.661e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 21/5/W5 | 0.06463027312922791 | 0.06463027000427246 | 3.125e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/1/W5 | 0.12779772879315396 | 0.12779773771762848 | 8.924e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/2/W5 | 0.11964704608896033 | 0.1196470558643341 | 9.775e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/3/W5 | 0.10686189988088449 | 0.1068618893623352 | 1.052e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/4/W5 | 0.12158090043172605 | 0.12158090621232986 | 5.781e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 22/5/W5 | 0.14301907509147938 | 0.14301908016204834 | 5.071e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/1/W5 | 0.22272097354712006 | 0.22272098064422607 | 7.097e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/2/W5 | 0.09357657566141597 | 0.09357656538486481 | 1.028e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/3/W5 | 0.07573114291643392 | 0.07573113590478897 | 7.012e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/4/W5 | 0.14837091549065884 | 0.1483709067106247 | 8.780e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 23/5/W5 | 0.09570711629493006 | 0.09570711851119995 | 2.216e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/1/W5 | 0.07223917582328347 | 0.07223918288946152 | 7.066e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/2/W5 | 0.0655956003640604 | 0.0655955970287323 | 3.335e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/3/W5 | 0.06284365218303706 | 0.06284365803003311 | 5.847e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/4/W5 | 0.1076060113949369 | 0.10760602355003357 | 1.216e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 24/5/W5 | 0.06676725723970317 | 0.06676725298166275 | 4.258e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/2/W5 | 0.0721452814944902 | 0.07214528322219849 | 1.728e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/3/W5 | 0.06678442376425829 | 0.06678442656993866 | 2.806e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/4/W5 | 0.07167654555850839 | 0.07167655229568481 | 6.737e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 25/5/W5 | 0.10821688901184859 | 0.10821687430143356 | 1.471e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/1/W5 | 0.42584161191404335 | 0.4258415997028351 | 1.221e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/2/W5 | 0.36672479253870727 | 0.36672481894493103 | 2.641e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/3/W5 | 0.4527088324187284 | 0.45270881056785583 | 2.185e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 26/5/W5 | 0.26765772337641713 | 0.26765772700309753 | 3.627e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/1/W5 | 0.2152076841943862 | 0.21520769596099854 | 1.177e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/2/W5 | 0.06535837284824271 | 0.06535837799310684 | 5.145e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/3/W5 | 0.06984957425571738 | 0.06984958052635193 | 6.271e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 27/5/W5 | 0.20456067129058644 | 0.20456068217754364 | 1.089e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/2/W5 | 0.09078652820468318 | 0.09078653156757355 | 3.363e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 28/4/W5 | 0.07557073019967936 | 0.0755707398056984 | 9.606e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/1/W5 | 0.09084928018729985 | 0.09084928780794144 | 7.621e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/2/W5 | 0.11020247631546765 | 0.11020248383283615 | 7.517e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/3/W5 | 0.05496048848775923 | 0.05496048554778099 | 2.940e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/4/W5 | 0.07542563443263572 | 0.0754256322979927 | 2.135e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 29/5/W5 | 0.08326626465520257 | 0.0832662582397461 | 6.415e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/1/W5 | 0.05310887433878528 | 0.05310886725783348 | 7.081e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/2/W5 | 0.04739104306928029 | 0.04739103838801384 | 4.681e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/4/W5 | 0.05185193469128964 | 0.05185193195939064 | 2.732e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 30/5/W5 | 0.05970740053062484 | 0.0597073994576931 | 1.073e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/1/W5 | 0.17610689742374425 | 0.17610691487789154 | 1.745e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/2/W5 | 0.1410530459186249 | 0.14105305075645447 | 4.838e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/3/W5 | 0.11864989522480936 | 0.11864989995956421 | 4.735e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/4/W5 | 0.13505505486121497 | 0.1350550651550293 | 1.029e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 31/5/W5 | 0.140722666422783 | 0.14072266221046448 | 4.212e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/1/W5 | 0.04559974607318511 | 0.04559974744915962 | 1.376e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/2/W5 | 0.046044224935314675 | 0.04604422673583031 | 1.801e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/3/W5 | 0.03887941120228742 | 0.038879409432411194 | 1.770e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 32/5/W5 | 0.04328286419206506 | 0.04328285530209541 | 8.890e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/1/W5 | 0.0581158231616625 | 0.058115825057029724 | 1.895e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/2/W5 | 0.05935909881993096 | 0.059359095990657806 | 2.829e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/3/W5 | 0.05650237408325103 | 0.05650237575173378 | 1.668e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/4/W5 | 0.06757671173110538 | 0.06757671386003494 | 2.129e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 33/5/W5 | 0.05950681070086242 | 0.05950680747628212 | 3.225e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/1/W5 | 0.19315998707355345 | 0.19315996766090393 | 1.941e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/2/W5 | 0.2152170352453893 | 0.21521703898906708 | 3.744e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/3/W5 | 0.2226127624779077 | 0.22261276841163635 | 5.934e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/4/W5 | 0.18145498799542392 | 0.18145498633384705 | 1.662e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 34/5/W5 | 0.18301725694106558 | 0.18301725387573242 | 3.065e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/2/W5 | 0.05684800732204305 | 0.05684801563620567 | 8.314e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/3/W5 | 0.05558529900436073 | 0.05558530241250992 | 3.408e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/4/W5 | 0.059280046922804024 | 0.059280041605234146 | 5.318e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 35/5/W5 | 0.05899581374377693 | 0.058995820581912994 | 6.838e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/1/W5 | 0.04465027709143736 | 0.044650278985500336 | 1.894e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/2/W5 | 0.04880878623975418 | 0.048808783292770386 | 2.947e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/3/W5 | 0.04866219349556457 | 0.04866219684481621 | 3.349e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 36/4/W5 | 0.042030274683958924 | 0.042030271142721176 | 3.541e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/1/W5 | 0.04604662339917629 | 0.046046629548072815 | 6.149e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/2/W5 | 0.05164325617659988 | 0.0516432523727417 | 3.804e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/3/W5 | 0.05362184980663599 | 0.05362185090780258 | 1.101e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/4/W5 | 0.05298763479499049 | 0.05298764258623123 | 7.791e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 37/5/W5 | 0.06895459602213422 | 0.06895459443330765 | 1.589e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/1/W5 | 0.08968791710153327 | 0.08968792110681534 | 4.005e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/2/W5 | 0.07903349232795721 | 0.07903348654508591 | 5.783e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/3/W5 | 0.0736956849803606 | 0.07369568198919296 | 2.991e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/4/W5 | 0.0726652539128718 | 0.0726652517914772 | 2.121e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 38/5/W5 | 0.08138805356810627 | 0.08138805627822876 | 2.710e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/1/W5 | 0.14754218476630762 | 0.14754217863082886 | 6.135e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/2/W5 | 0.11595857334126128 | 0.11595857888460159 | 5.543e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/3/W5 | 0.1319422183694204 | 0.13194222748279572 | 9.113e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/4/W5 | 0.08171204250373909 | 0.0817120373249054 | 5.179e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 39/5/W5 | 0.10600309607171711 | 0.10600309073925018 | 5.332e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/1/W5 | 0.12896209253713395 | 0.12896208465099335 | 7.886e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/2/W5 | 0.0770462497671912 | 0.07704624533653259 | 4.431e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/3/W5 | 0.09006017511178278 | 0.09006016701459885 | 8.097e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 40/4/W5 | 0.08546450418858456 | 0.08546449989080429 | 4.298e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/1/W5 | 0.08575810482553146 | 0.08575809746980667 | 7.356e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/2/W5 | 0.075132188794178 | 0.07513219118118286 | 2.387e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/3/W5 | 0.09849308041835822 | 0.0984930768609047 | 3.557e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/4/W5 | 0.06095273670548379 | 0.06095273792743683 | 1.222e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 41/5/W5 | 0.07165439894762077 | 0.07165439426898956 | 4.679e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/1/W5 | 0.18978985187745714 | 0.18978984653949738 | 5.338e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/2/W5 | 0.1314785142926398 | 0.13147850334644318 | 1.095e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/3/W5 | 0.12336824429191177 | 0.12336824089288712 | 3.399e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/4/W5 | 0.09227298580309752 | 0.09227298945188522 | 3.649e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 42/5/W5 | 0.16363820718028674 | 0.16363820433616638 | 2.844e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/1/W5 | 0.08668156981647321 | 0.08668156713247299 | 2.684e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/2/W5 | 0.08761787670193277 | 0.08761788159608841 | 4.894e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/3/W5 | 0.08838354491261706 | 0.08838354051113129 | 4.401e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/4/W5 | 0.06854259040394 | 0.06854259222745895 | 1.824e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 43/5/W5 | 0.17757863446806865 | 0.1775786429643631 | 8.496e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/1/W5 | 0.0723573699419697 | 0.07235736399888992 | 5.943e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/2/W5 | 0.09149917911586064 | 0.0914991945028305 | 1.539e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/3/W5 | 0.08020987163772261 | 0.0802098736166954 | 1.979e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/4/W5 | 0.13424137451353094 | 0.13424138724803925 | 1.273e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 44/5/W5 | 0.07505389159747748 | 0.07505389302968979 | 1.432e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/1/W5 | 0.068379516049991 | 0.06837951391935349 | 2.131e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/2/W5 | 0.0803337814989365 | 0.08033378422260284 | 2.724e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/3/W5 | 0.07943892011415477 | 0.07943891733884811 | 2.775e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 45/4/W5 | 0.06856649167219994 | 0.06856649369001389 | 2.018e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/1/W5 | 0.2125182584164872 | 0.21251827478408813 | 1.637e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/2/W5 | 0.1987132613778515 | 0.1987132430076599 | 1.837e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/3/W5 | 0.16494691928648259 | 0.16494694352149963 | 2.424e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/4/W5 | 0.15065946170543387 | 0.1506594717502594 | 1.004e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 46/5/W5 | 0.180252212140888 | 0.18025220930576324 | 2.835e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/1/W5 | 0.3254045832923753 | 0.325404554605484 | 2.869e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/2/W5 | 0.303988966268582 | 0.3039889633655548 | 2.903e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/3/W5 | 0.3757117824165804 | 0.37571173906326294 | 4.335e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/4/W5 | 0.3369083151883141 | 0.33690834045410156 | 2.527e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 47/5/W5 | 0.407534292236871 | 0.40753433108329773 | 3.885e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/1/W5 | 0.10876012312837643 | 0.10876012593507767 | 2.807e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/2/W5 | 0.17193399552659813 | 0.17193400859832764 | 1.307e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/3/W5 | 0.1560961643850748 | 0.15609616041183472 | 3.973e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 48/5/W5 | 0.10113697658961915 | 0.10113698244094849 | 5.851e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/1/W5 | 0.1269432591494034 | 0.12694326043128967 | 1.282e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/4/W5 | 0.13804956450076356 | 0.13804955780506134 | 6.696e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 49/5/W5 | 0.097421165706246 | 0.09742116183042526 | 3.876e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/1/W5 | 0.0784459273790414 | 0.0784459337592125 | 6.380e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/2/W5 | 0.0520318158995313 | 0.05203182250261307 | 6.603e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/3/W5 | 0.09847700120720965 | 0.09847699850797653 | 2.699e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/4/W5 | 0.07264359586754437 | 0.07264359295368195 | 2.914e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 50/5/W5 | 0.08573920903312185 | 0.08573920279741287 | 6.236e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/1/W5 | 0.14833386677812968 | 0.14833387732505798 | 1.055e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/3/W5 | 0.2125100970527374 | 0.2125100940465927 | 3.006e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/4/W5 | 0.22974242265316566 | 0.2297423928976059 | 2.976e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 51/5/W5 | 0.2510159666837101 | 0.2510160207748413 | 5.409e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/1/W5 | 0.15220968853007857 | 0.15220968425273895 | 4.277e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/2/W5 | 0.18779500632242352 | 0.1877950131893158 | 6.867e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/3/W5 | 0.19430436565466158 | 0.19430434703826904 | 1.862e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 52/5/W5 | 0.2026147244788532 | 0.20261473953723907 | 1.506e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/1/W5 | 0.18318222183463678 | 0.1831822246313095 | 2.797e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/2/W5 | 0.25265941969916017 | 0.252659410238266 | 9.461e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 53/3/W5 | 0.21938021828362142 | 0.2193801999092102 | 1.837e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/1/W5 | 0.30472141093885374 | 0.3047214150428772 | 4.104e-09 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/2/W5 | 0.28408382863431836 | 0.2840838134288788 | 1.521e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/3/W5 | 0.2186648283220541 | 0.21866483986377716 | 1.154e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/4/W5 | 0.2024045718784406 | 0.20240455865859985 | 1.322e-08 |
| B10 [informational] target displacement versus last_target_dist in the fit record | 54/5/W5 | 0.3565596300262088 | 0.3565596640110016 | 3.398e-08 |
| C02 participant_means.csv: target_displacement | 1/S1 | 0.1684410560065087 | 0.16844105273485183 | 3.272e-09 |
| C02 participant_means.csv: target_displacement | 3/S1 | 0.06535335736478974 | 0.06535336077213287 | 3.407e-09 |
| C02 participant_means.csv: target_displacement | 6/S1 | 0.05297676656829549 | 0.05297676920890808 | 2.641e-09 |
| C02 participant_means.csv: target_displacement | 7/S1 | 0.07528866924678514 | 0.07528867274522781 | 3.498e-09 |
| C02 participant_means.csv: target_displacement | 8/S1 | 0.15512129319232082 | 0.15512128919363022 | 3.999e-09 |
| C02 participant_means.csv: target_displacement | 9/S1 | 0.054914524718686755 | 0.054914526641368866 | 1.923e-09 |
| C02 participant_means.csv: target_displacement | 10/S1 | 0.09597878480888777 | 0.09597877860069275 | 6.208e-09 |
| C02 participant_means.csv: target_displacement | 11/S1 | 0.13937979822076021 | 0.13937980234622954 | 4.125e-09 |
| C02 participant_means.csv: target_displacement | 12/S1 | 0.14442413778050822 | 0.14442414790391922 | 1.012e-08 |
| C02 participant_means.csv: target_displacement | 13/S1 | 0.17766240864638036 | 0.17766241431236268 | 5.666e-09 |
| C02 participant_means.csv: target_displacement | 14/S1 | 0.09242598960655982 | 0.09242599457502365 | 4.968e-09 |
| C02 participant_means.csv: target_displacement | 16/S1 | 0.13551743188628745 | 0.1355174332857132 | 1.399e-09 |
| C02 participant_means.csv: target_displacement | 17/S1 | 0.07601342324172736 | 0.07601342201232911 | 1.229e-09 |
| C02 participant_means.csv: target_displacement | 20/S1 | 0.11682990938026314 | 0.1168299064040184 | 2.976e-09 |
| C02 participant_means.csv: target_displacement | 23/S1 | 0.09076274859806277 | 0.09076274335384368 | 5.244e-09 |
| C02 participant_means.csv: target_displacement | 24/S1 | 0.04890688126086722 | 0.04890687987208366 | 1.389e-09 |
| C02 participant_means.csv: target_displacement | 26/S1 | 0.1693021478511699 | 0.16930215954780578 | 1.170e-08 |
| C02 participant_means.csv: target_displacement | 27/S1 | 0.11165213583227415 | 0.11165213733911514 | 1.507e-09 |
| C02 participant_means.csv: target_displacement | 28/S1 | 0.0353279986426492 | 0.03532799705862999 | 1.584e-09 |
| C02 participant_means.csv: target_displacement | 29/S1 | 0.024254063647077072 | 0.02425406500697136 | 1.360e-09 |
| C02 participant_means.csv: target_displacement | 31/S1 | 0.08857697828305779 | 0.08857697397470474 | 4.308e-09 |
| C02 participant_means.csv: target_displacement | 34/S1 | 0.11570385059491484 | 0.11570385545492172 | 4.860e-09 |
| C02 participant_means.csv: target_displacement | 38/S1 | 0.05192298027386163 | 0.05192298218607903 | 1.912e-09 |
| C02 participant_means.csv: target_displacement | 39/S1 | 0.09633453781431157 | 0.0963345393538475 | 1.540e-09 |
| C02 participant_means.csv: target_displacement | 40/S1 | 0.10250318932083702 | 0.10250319093465805 | 1.614e-09 |
| C02 participant_means.csv: target_displacement | 41/S1 | 0.07663769284520965 | 0.07663769423961639 | 1.394e-09 |
| C02 participant_means.csv: target_displacement | 42/S1 | 0.13513238848306078 | 0.1351323902606964 | 1.778e-09 |
| C02 participant_means.csv: target_displacement | 47/S1 | 0.23828095844887437 | 0.2382809638977051 | 5.449e-09 |
| C02 participant_means.csv: target_displacement | 48/S1 | 0.0856138313816758 | 0.08561383336782455 | 1.986e-09 |
| C02 participant_means.csv: target_displacement | 49/S1 | 0.08154995330350895 | 0.0815499559044838 | 2.601e-09 |
| C02 participant_means.csv: target_displacement | 50/S1 | 0.05320676038024773 | 0.053206761926412584 | 1.546e-09 |
| C02 participant_means.csv: target_displacement | 51/S1 | 0.1244841523266959 | 0.12448415458202362 | 2.255e-09 |
| C02 participant_means.csv: target_displacement | 53/S1 | 0.1059827876347248 | 0.10598279684782028 | 9.213e-09 |
| C02 participant_means.csv: target_displacement | 54/S1 | 0.1490917729909262 | 0.14909177422523498 | 1.234e-09 |
| C02 participant_means.csv: target_displacement | 1/W1 | 0.3452226898168288 | 0.3452227056026459 | 1.579e-08 |
| C02 participant_means.csv: target_displacement | 2/W1 | 0.15190128941471423 | 0.1519012913107872 | 1.896e-09 |
| C02 participant_means.csv: target_displacement | 4/W1 | 0.20725688310342338 | 0.20725689232349395 | 9.220e-09 |
| C02 participant_means.csv: target_displacement | 5/W1 | 0.12186074527399496 | 0.12186074852943421 | 3.255e-09 |
| C02 participant_means.csv: target_displacement | 8/W1 | 0.3336050440607491 | 0.3336050510406494 | 6.980e-09 |
| C02 participant_means.csv: target_displacement | 9/W1 | 0.15331603247089323 | 0.15331602692604065 | 5.545e-09 |
| C02 participant_means.csv: target_displacement | 11/W1 | 0.2843044392432858 | 0.2843044251203537 | 1.412e-08 |
| C02 participant_means.csv: target_displacement | 12/W1 | 0.23682603556260867 | 0.23682602643966674 | 9.123e-09 |
| C02 participant_means.csv: target_displacement | 13/W1 | 0.4204314968180782 | 0.4204314827919006 | 1.403e-08 |
| C02 participant_means.csv: target_displacement | 14/W1 | 0.19977779798987708 | 0.19977779388427735 | 4.106e-09 |
| C02 participant_means.csv: target_displacement | 15/W1 | 0.0910643776883375 | 0.09106438010931014 | 2.421e-09 |
| C02 participant_means.csv: target_displacement | 16/W1 | 0.2980691718340501 | 0.298069155216217 | 1.662e-08 |
| C02 participant_means.csv: target_displacement | 17/W1 | 0.1800066870388868 | 0.1800066977739334 | 1.074e-08 |
| C02 participant_means.csv: target_displacement | 18/W1 | 0.1216910979764603 | 0.12169110178947448 | 3.813e-09 |
| C02 participant_means.csv: target_displacement | 19/W1 | 0.15240797624248278 | 0.15240797102451326 | 5.218e-09 |
| C02 participant_means.csv: target_displacement | 20/W1 | 0.31314360448908596 | 0.31314362287521363 | 1.839e-08 |
| C02 participant_means.csv: target_displacement | 22/W1 | 0.22990064161484733 | 0.22990063726902008 | 4.346e-09 |
| C02 participant_means.csv: target_displacement | 23/W1 | 0.22491705457012762 | 0.22491705119609834 | 3.374e-09 |
| C02 participant_means.csv: target_displacement | 24/W1 | 0.15996533839230248 | 0.1599653348326683 | 3.560e-09 |
| C02 participant_means.csv: target_displacement | 25/W1 | 0.1649709912254464 | 0.1649709850549698 | 6.170e-09 |
| C02 participant_means.csv: target_displacement | 26/W1 | 0.44758106962998623 | 0.4475810766220093 | 6.992e-09 |
| C02 participant_means.csv: target_displacement | 27/W1 | 0.2733979904478291 | 0.27339797616004946 | 1.429e-08 |
| C02 participant_means.csv: target_displacement | 28/W1 | 0.11770380776455072 | 0.11770380884408951 | 1.080e-09 |
| C02 participant_means.csv: target_displacement | 31/W1 | 0.22348174446872923 | 0.22348175644874574 | 1.198e-08 |
| C02 participant_means.csv: target_displacement | 32/W1 | 0.06940479966689722 | 0.06940479800105095 | 1.666e-09 |
| C02 participant_means.csv: target_displacement | 33/W1 | 0.09559221684942146 | 0.09559221565723419 | 1.192e-09 |
| C02 participant_means.csv: target_displacement | 34/W1 | 0.2902740840189882 | 0.2902740776538849 | 6.365e-09 |
| C02 participant_means.csv: target_displacement | 35/W1 | 0.08330254983527989 | 0.08330254554748535 | 4.288e-09 |
| C02 participant_means.csv: target_displacement | 36/W1 | 0.07428267497257009 | 0.07428267747163772 | 2.499e-09 |
| C02 participant_means.csv: target_displacement | 37/W1 | 0.08685355045055627 | 0.08685355186462403 | 1.414e-09 |
| C02 participant_means.csv: target_displacement | 38/W1 | 0.15616070576903784 | 0.15616071224212646 | 6.473e-09 |
| C02 participant_means.csv: target_displacement | 39/W1 | 0.18580761053296288 | 0.18580762147903443 | 1.095e-08 |
| C02 participant_means.csv: target_displacement | 40/W1 | 0.1795319510905499 | 0.17953194975852965 | 1.332e-09 |
| C02 participant_means.csv: target_displacement | 41/W1 | 0.17407848127954634 | 0.17407848536968232 | 4.090e-09 |
| C02 participant_means.csv: target_displacement | 42/W1 | 0.24056266867397333 | 0.24056267142295837 | 2.749e-09 |
| C02 participant_means.csv: target_displacement | 43/W1 | 0.18990333196204284 | 0.18990333676338195 | 4.801e-09 |
| C02 participant_means.csv: target_displacement | 45/W1 | 0.12991608774970512 | 0.12991608530282975 | 2.447e-09 |
| C02 participant_means.csv: target_displacement | 46/W1 | 0.27529374712661003 | 0.27529374361038206 | 3.516e-09 |
| C02 participant_means.csv: target_displacement | 47/W1 | 0.43371965937241785 | 0.43371965289115905 | 6.481e-09 |
| C02 participant_means.csv: target_displacement | 48/W1 | 0.2156113685853868 | 0.2156113713979721 | 2.813e-09 |
| C02 participant_means.csv: target_displacement | 49/W1 | 0.18845385941598897 | 0.18845386803150177 | 8.616e-09 |
| C02 participant_means.csv: target_displacement | 50/W1 | 0.14793268848884794 | 0.1479326903820038 | 1.893e-09 |
| C02 participant_means.csv: target_displacement | 51/W1 | 0.3190059612511811 | 0.3190059423446655 | 1.891e-08 |
| C02 participant_means.csv: target_displacement | 52/W1 | 0.2633830302323126 | 0.263383024930954 | 5.301e-09 |
| C02 participant_means.csv: target_displacement | 53/W1 | 0.29629542096914707 | 0.2962954014539719 | 1.952e-08 |
| C02 participant_means.csv: target_displacement | 54/W1 | 0.38824387480396466 | 0.38824387192726134 | 2.877e-09 |
| C02 participant_means.csv: target_displacement | 1/W4 | 0.051968860109645645 | 0.05196886137127876 | 1.262e-09 |
| C02 participant_means.csv: target_displacement | 4/W4 | 0.028609732450109986 | 0.028609734028577805 | 1.578e-09 |
| C02 participant_means.csv: target_displacement | 8/W4 | 0.0558918213771919 | 0.055891819298267365 | 2.079e-09 |
| C02 participant_means.csv: target_displacement | 10/W4 | 0.03416282415534447 | 0.03416282534599304 | 1.191e-09 |
| C02 participant_means.csv: target_displacement | 11/W4 | 0.04322781294360382 | 0.04322781562805176 | 2.684e-09 |
| C02 participant_means.csv: target_displacement | 12/W4 | 0.03676375215423361 | 0.03676375076174736 | 1.392e-09 |
| C02 participant_means.csv: target_displacement | 13/W4 | 0.09482825346547846 | 0.09482825100421906 | 2.461e-09 |
| C02 participant_means.csv: target_displacement | 23/W4 | 0.030390785542096094 | 0.030390783771872522 | 1.770e-09 |
| C02 participant_means.csv: target_displacement | 26/W4 | 0.08469149585227029 | 0.0846914917230606 | 4.129e-09 |
| C02 participant_means.csv: target_displacement | 27/W4 | 0.03320663581856488 | 0.03320663776248693 | 1.944e-09 |
| C02 participant_means.csv: target_displacement | 34/W4 | 0.04931233230248935 | 0.04931233450770378 | 2.205e-09 |
| C02 participant_means.csv: target_displacement | 46/W4 | 0.044630897438227804 | 0.04463089630007744 | 1.138e-09 |
| C02 participant_means.csv: target_displacement | 47/W4 | 0.09335307143848355 | 0.09335307776927948 | 6.331e-09 |
| C02 participant_means.csv: target_displacement | 51/W4 | 0.046081475550707476 | 0.046081476658582685 | 1.108e-09 |
| C02 participant_means.csv: target_displacement | 52/W4 | 0.04101439099361347 | 0.04101438894867897 | 2.045e-09 |
| C02 participant_means.csv: target_displacement | 1/W5 | 0.22284660031128128 | 0.2228466033935547 | 3.082e-09 |
| C02 participant_means.csv: target_displacement | 2/W5 | 0.08302754400232942 | 0.08302754610776901 | 2.105e-09 |
| C02 participant_means.csv: target_displacement | 4/W5 | 0.1262302125105102 | 0.12623021006584167 | 2.445e-09 |
| C02 participant_means.csv: target_displacement | 6/W5 | 0.08165009152667789 | 0.08165009021759033 | 1.309e-09 |
| C02 participant_means.csv: target_displacement | 7/W5 | 0.10872735145332406 | 0.10872735530138015 | 3.848e-09 |
| C02 participant_means.csv: target_displacement | 8/W5 | 0.23331539787676298 | 0.23331540524959565 | 7.373e-09 |
| C02 participant_means.csv: target_displacement | 9/W5 | 0.09592516200703556 | 0.09592516720294952 | 5.196e-09 |
| C02 participant_means.csv: target_displacement | 10/W5 | 0.13923788196720227 | 0.1392378941178322 | 1.215e-08 |
| C02 participant_means.csv: target_displacement | 11/W5 | 0.1832872356178677 | 0.18328723311424255 | 2.504e-09 |
| C02 participant_means.csv: target_displacement | 12/W5 | 0.15411217900736604 | 0.15411218553781508 | 6.530e-09 |
| C02 participant_means.csv: target_displacement | 13/W5 | 0.34582487457303046 | 0.34582486748695374 | 7.086e-09 |
| C02 participant_means.csv: target_displacement | 15/W5 | 0.058626540014915615 | 0.058626537770032884 | 2.245e-09 |
| C02 participant_means.csv: target_displacement | 16/W5 | 0.20231346360497654 | 0.20231345891952515 | 4.685e-09 |
| C02 participant_means.csv: target_displacement | 17/W5 | 0.09247529336219082 | 0.09247529655694961 | 3.195e-09 |
| C02 participant_means.csv: target_displacement | 18/W5 | 0.0770767728666548 | 0.07707677632570267 | 3.459e-09 |
| C02 participant_means.csv: target_displacement | 19/W5 | 0.08416376627837523 | 0.08416376262903214 | 3.649e-09 |
| C02 participant_means.csv: target_displacement | 20/W5 | 0.22393914638534906 | 0.22393913865089415 | 7.734e-09 |
| C02 participant_means.csv: target_displacement | 21/W5 | 0.057582561556069375 | 0.05758256018161774 | 1.374e-09 |
| C02 participant_means.csv: target_displacement | 22/W5 | 0.12378133005724083 | 0.1237813338637352 | 3.806e-09 |
| C02 participant_means.csv: target_displacement | 23/W5 | 0.12722134478211178 | 0.1272213414311409 | 3.351e-09 |
| C02 participant_means.csv: target_displacement | 24/W5 | 0.0750103394010042 | 0.07501034289598466 | 3.495e-09 |
| C02 participant_means.csv: target_displacement | 27/W5 | 0.14849691739065052 | 0.14849692434072495 | 6.950e-09 |
| C02 participant_means.csv: target_displacement | 28/W5 | 0.07177024521284968 | 0.07177024781703949 | 2.604e-09 |
| C02 participant_means.csv: target_displacement | 30/W5 | 0.050700005932609614 | 0.050700002908706666 | 3.024e-09 |
| C02 participant_means.csv: target_displacement | 31/W5 | 0.1423175119702353 | 0.1423175185918808 | 6.622e-09 |
| C02 participant_means.csv: target_displacement | 32/W5 | 0.04309213021913784 | 0.04309212863445282 | 1.585e-09 |
| C02 participant_means.csv: target_displacement | 34/W5 | 0.199092405946668 | 0.19909240305423737 | 2.892e-09 |
| C02 participant_means.csv: target_displacement | 35/W5 | 0.05741830049042586 | 0.057418303191661836 | 2.701e-09 |
| C02 participant_means.csv: target_displacement | 37/W5 | 0.05465079203990737 | 0.0546507939696312 | 1.930e-09 |
| C02 participant_means.csv: target_displacement | 40/W5 | 0.09650985512636877 | 0.09650985002517701 | 5.101e-09 |
| C02 participant_means.csv: target_displacement | 41/W5 | 0.07839810193823445 | 0.07839809954166413 | 2.397e-09 |
| C02 participant_means.csv: target_displacement | 42/W5 | 0.1401095606890786 | 0.14010955691337584 | 3.776e-09 |
| C02 participant_means.csv: target_displacement | 43/W5 | 0.10176084326060635 | 0.10176084488630295 | 1.626e-09 |
| C02 participant_means.csv: target_displacement | 44/W5 | 0.09067233736131228 | 0.09067234247922898 | 5.118e-09 |
| C02 participant_means.csv: target_displacement | 46/W5 | 0.18141802258542863 | 0.18141802847385408 | 5.888e-09 |
| C02 participant_means.csv: target_displacement | 47/W5 | 0.3499095878805446 | 0.3499095857143402 | 2.166e-09 |
| C02 participant_means.csv: target_displacement | 48/W5 | 0.13854987700553156 | 0.13854988068342208 | 3.678e-09 |
| C02 participant_means.csv: target_displacement | 49/W5 | 0.11529670545639212 | 0.11529670357704162 | 1.879e-09 |
| C02 participant_means.csv: target_displacement | 51/W5 | 0.19313996108149578 | 0.19313996732234956 | 6.241e-09 |
| C02 participant_means.csv: target_displacement | 53/W5 | 0.2124472609714537 | 0.21244725584983826 | 5.122e-09 |
| C02 participant_means.csv: target_displacement | 54/W5 | 0.27328685395997515 | 0.27328685820102694 | 4.241e-09 |
| C07 condition_summary.csv: 17 measures and between-participant SD | S1:target_displacement | 0.08469733657026059 | 0.08469733764693418 | 1.077e-09 |
| C09 RESULTS-V1.0.json summaries: 17 measures and between-participant SD | S1:target_displacement | 0.08469733657026059 | 0.08469733764693418 | 1.077e-09 |
