# Lee2019 — iki yeni kontrol koşulu (S1 ve W5) — V1.0

**Hazırlayan:** Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · **Tarih:** 12.11.2026 · **Günce:** G210, G211 · **Karar kaydı:** KD-20261112-01

Bu klasör, makalenin v1.8 sürümüne girecek iki yeni kontrol koşulunun deneyini içerir. Eski hiçbir sonuç, eski hiçbir dosya değişmez.

## Neden yapılıyor?

Nuri Korhan Hoca'nın v1.7 için iki yerinde tespiti vardı:

1. Müzakere bugüne kadar yalnız Walsh kodlu çıktıyla denendi. "Sıradan sınıf çıktısı + müzakere" hücresi boş. Bu yüzden kodlamanın etkisi ile müzakerenin etkisi birbirinden ayrılamıyor.
2. W1 (birikimli kural) ile W4 (etikete çapalı kural) karşılaştırması iki şeyi birden değiştiriyor: W1 hem eski tahminleri biriktiriyor hem de hedefte tahmine çok daha büyük pay veriyor (son aşamada yaklaşık %69; W4'te en çok %24).

## İki yeni koşul

| Koşul | Tanım | Yanıtladığı soru |
|---|---|---|
| **S1** | Sıradan iki sınıflı çıktı + birikimli müzakere. İlk iki aşamada hedef etiketin kendisi; sonra her aşama sonunda hedef, o anki tahmine doğru 0,03 × aşama sırası kadar kayar (W1 ile aynı takvim). | Müzakerenin etkisi çıktı türüne bağlı mı? |
| **W5** | Walsh çıktı; etikete çapalı, kapısız. Her aşamada hedef = pay × etiket + (1 − pay) × o anki tahmin. Pay, W1'de etiketin hedefte kalan payıyla aynı (son kullanılan aşamada 0,306). Eski tahminler taşınmaz. | W1'in farkı eski tahminleri biriktirmesinden mi, tahmin payının büyüklüğünden mi? |

Diğer her şey önceki Lee2019 deneyleriyle aynı: 54 kişi, birinci gün 100 deneme eğitim, ikinci gün 100 deneme test, EEGNet-8,2, 10 aşama × 30 tur, 5 başlangıç.

## Karşılaştırmalar (tek, yeni, keşif amaçlı aile)

1. S1 − S0
2. (W1 − W0) − (S1 − S0)
3. W1 − W5
4. W5 − W4

Birim: 54 kişinin beş başlangıç ortalaması. İki yönlü eşleştirilmiş t; Holm düzeltmesi bu dört karşılaştırma üzerinden. Wilcoxon yalnız duyarlılık denetimi. Makaledeki eski beş karşılaştırmalı aile ve iki karşılaştırmalı W4 ailesi olduğu gibi kalır. Bu koşullar Lee2019 sonuçları görüldükten sonra eklendiği için makalede "sonradan eklenmiş, keşif amaçlı" diye sunulacaktır.

Bir not: 1. ve 2. karşılaştırmanın toplamı W1 − W0'a, 3. ve 4. karşılaştırmanın toplamı W1 − W4'e eşittir; bu iki fark daha önce raporlandı. Yani bu aile iki yeni bilgi parçası ekler, dört değil.

## Eski dört koşul (S0, W0, W1, W4) nereden gelecek?

Bu dört koşulun 1.080 eğitimi 18 ve 20 Ekim 2026'da bu bilgisayarda yapıldı ve arşivde duruyor. Kural, sonuçlar görülmeden yazıldı ve yalnız birinci gün (eğitim) bilgisine bakar:

- Önce arşivden önceden belirlenmiş bir örnek (9 kişi × 4 koşul × 2 başlangıç = 72 eğitim) aynı kodla yeniden koşulur. Sonra 540 yeni eğitim yapılır.
- **Arşiv kullanılır**, eğer (a) 72 örnek eğitimin eğitim çıktıları arşivdekiyle bit düzeyinde aynıysa **ve** (b) 270 W5 eğitiminin her birinde üçüncü aşamada kullanılan hedefin uzaklığı, arşivdeki aynı kişi ve başlangıcın W4 değeriyle aynıysa (W5'in ilk güncellemesi aritmetik olarak W4'ünkiyle aynıdır). Bu durumda kampanya 612 eğitimle biter (72 + 540).
- **Biri bile tutmazsa** dört eski koşul da bu kampanyada baştan eğitilir (1.008 eğitim daha; toplam 1.620) ve yeni aile yalnız bu kampanyanın eğitimlerinden hesaplanır.
- Modeller dondurulduktan sonra ikinci gün verisi açılır. **Önce 72 örnek eğitim test edilir** ve test çıktıları arşivle karşılaştırılır. Arşiv kuralı altında fark çıkarsa çalışma o noktada durur; S1 ve W5'in hiçbir test çıktısı henüz üretilmemiş olur. Bu durum için yedek kural da önceden yazılıdır: eski koşullar baştan eğitilir (kayıtlı bir protokol eki ile).

## Çalıştırma

`BASLAT-V1.0.cmd` dosyasına **çift tıklayın**. Siyah bir pencere açılır ve sırayla şunlar olur:

1. **Ön kontrol (ilk başlatmada, 15–25 dakika).** Bu bilgisayarın yazılımı eski eğitimlerin yazılımıyla karşılaştırılır. Sonra yapay veriyle üç kontrol bu bilgisayarın ekran kartında koşulur: eğitim çekirdeği, sonuç hesabı ve bütün düzeneğin baştan sona kuru denemesi. Gerçek veri açılmaz. Biri bile geçmezse hiçbir gerçek eğitim başlamaz.
2. **Protokolün dondurulması.** Bilimsel içerik başlatmadan önce yazılmıştır (`records\ONCEDEN_YAZILAN_ICERIK-V1.0.json`) ve kimliği (SHA-256) güncede kayıtlıdır; bu adımda yalnız bu bilgisayara ait bilgiler (yazılım sürümleri, kod ve kaynak dosya özetleri, kontrol makbuzları) eklenir ve `PROTOKOL-V1.0.json` bir kez yazılır.
3. 72 örnek eğitim (yaklaşık 17 dakika), ardından 540 yeni eğitim (yaklaşık 2 saat 10 dakika).
4. Karar: arşiv mi, yeniden eğitim mi. Yeniden eğitim gerekirse 1.008 eğitim daha (yaklaşık 4 saat).
5. Bütün modeller dondurulur; ikinci gün verisi ancak bundan sonra açılır. Önce örnek eğitimler, sonra hepsi birer kez test edilir.
6. Sonuç hesabı yapılır; pencere "TAMAMLANDI" yazar.

Süreler önceki kampanyaların hızına (eğitim başına 13–14 saniye) dayanan tahmindir.

**Bilgisayar prize takılı ve kapağı açık kalmalı.** Pencere açıkken bilgisayar kendiliğinden uykuya geçmez (ekran kararabilir).

**Durdurmak için** pencereyi kapatmanız yeterli. Yeniden çift tıkladığınızda biten eğitimler korunur, yarım kalan eğitim kaldığı aşamadan sürer. Çalışan eğitimin bitmesini bekleyip durdurmak isterseniz `campaign` klasörüne `STOP_AFTER_CURRENT_FIT` adlı boş bir dosya koyun; istek bir kez kullanılır.

Aynı anda ikinci bir pencere açılırsa ikincisi "zaten açık" der ve hiçbir şeye dokunmaz.

### Çalışma sürerken dokunulmaması gerekenler

Her başlatmada ve sonuç hesabından sonra şu dosyaların özetleri denetlenir; biri değişirse çalışma durur:

- `IEEE_ACCESS_GONDERIM-v1.7` klasöründeki altı teslim dosyası (Word dosyalarını açıp **kaydetmeyin**).
- `LEE2019_BAGIMSIZ_DOGRULAMA-V1.0` ve `LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0` klasörleri (taşımayın, yeniden adlandırmayın).
- Bu klasörün adı ve yeri (yol uzunluğu sınıra yakın; daha derine taşımayın).

### Pencere "durdu" derse

- **"ÖN KONTROL GEÇMEDİ":** hiçbir gerçek eğitim başlamamıştır. `logs` klasöründeki `launch-…log` dosyası nedenini yazar. Claude'a haber verin.
- **"ÇALIŞMA DURDU":** pencere kapandıysa ya da elektrik kesildiyse yeniden çift tıklayın. Başka bir hataysa hiçbir dosyayı silmeden Claude'a haber verin; neden `logs\run-…log` ve `ops\CAMPAIGN_FAILURE-…json` dosyalarında yazılıdır.

## Klasörler

| Yol | İçerik |
|---|---|
| `BASLAT-V1.0.cmd` | Başlatıcı (çift tıklanır) |
| `PROTOKOL-V1.0.json` | Dondurulmuş protokol; ilk başlatmada, ilk gerçek eğitimden önce yazılır |
| `PROTOKOL_OZETI-V1.0.md` | Protokolün bir sayfalık sade özeti |
| `code\` | Eğitim çekirdeği (`lee_core.py`: önceki çekirdek + belgelenmiş iki ekleme), koşul tablosu, sarmalayıcı, kampanya mantığı |
| `analysis\` | Sonuç hesabı (kampanya kodundan bağımsız çalışır) |
| `ops\` | Başlatma ve yürütme betikleri; çalışma sırasında ortam kayıtları, ön kontrol makbuzları (`preflight\`), kontrol makbuzları (`qa\`), kenara alınan dosyalar (`orphans\`), tamamlanma ya da hata kayıtları |
| `qa\` | Yapay veriyle kontroller: eğitim çekirdeği, sonuç hesabı, baştan sona kuru deneme, başlatıcı provası |
| `records\` | Önceden yazılan protokol içeriği (`ONCEDEN_YAZILAN_ICERIK-V1.0.json`), kaynak bağlarını ve protokolü yazan betikler, çekirdekte değişen satırlar (`LEE_CORE_DEGISIKLIKLERI-V1.0.diff`), bağımsız inceleme raporu ve yanıtı, paket dosyalarının özet listesi (`PAKET_OZETLERI-V1.0.json`), hazırlık sırasındaki kontrol makbuzları (`prelaunch\`), günce yedekleri (`history\`), dondurma kaydı |
| `data\SOURCE_BINDINGS-V1.0.json` | Girdi dosyalarının ve arşiv eğitimlerinin SHA-256 bağları |
| `data\preprocessors\` | Çalışma sırasında oluşur: her kişinin birinci gün ölçekleme değerleri |
| `campaign\` | Çalışma sırasında oluşur: eğitim kayıtları, model kayıtları, test kayıtları, durum (`STATUS.json`) |
| `final_analysis\` | Çalışma bitince oluşur: sonuç tabloları ve dört karşılaştırma |
| `logs\` | Çalışma günlükleri |
