# Protokol özeti — Lee2019'da iki yeni kontrol koşulu (S1, W5)

Bu sayfa protokolün sade özetidir. Bağlayıcı olan protokolün kendisidir (`PROTOKOL-V1.0.json`).

## Protokol iki katmandır

1. **Önceden yazılan içerik:** tasarım, koşullar, kurallar ve sonuç hesabı. Başlatmadan önce yazıldı (`records\ONCEDEN_YAZILAN_ICERIK-V1.0.json`); kimliği çalışma güncesine (G211) kaydedildi ve başlatıcının içine yazıldı: SHA-256 `9ebd967d29ef2585ac00f515f99cb5659679dab9190297e878649ff3b606b888`. Başlatıcı başka bir içerikle çalışmayı reddeder.
2. **Bilgisayara ait bilgiler:** yazılım sürümleri, kod ve kaynak dosya özetleri, kontrol makbuzları, dondurma zamanı. İlk başlatmada, kontroller bu bilgisayarda geçtikten sonra ve ilk gerçek eğitimden önce eklenir. Bu bilgiler önceden yazılan içeriği değiştiremez.

## Sorular

1. **Müzakerenin etkisi çıktı türüne bağlı mı?** Bugüne kadar müzakere yalnız Walsh kodlu çıktıyla denendi. S1, aynı birikimli müzakereyi sıradan iki sınıflı çıktıya uygular.
2. **W1'in W4'ten farkı nereden geliyor?** W1 hem eski tahminleri biriktiriyor hem de hedefte tahmine büyük pay veriyor. W5, etiketin payını W1 ile eşitler ama eski tahminleri taşımaz; böylece iki etken ayrılır.

## Değişmeyenler

54 kişi; birinci gün 100 deneme eğitim, ikinci gün 100 deneme test; aynı hazırlanmış girdi dosyaları (SHA-256 ile bağlı); EEGNet-8,2; Adam 0,001; 16'lık gruplar; dropout 0,5; 10 aşama × 30 tur; başlangıçlar 1–5; her model için tek son test. Erken durdurma, model seçimi, sıcaklık ayarı, hizalama yok.

## Hedefin aşamalara göre içeriği

| Eğitim aşaması (0'dan) | Önceki güncellemenin oranı | Etiketin hedefteki payı: W1, S1 ve W5 | Tahminin payı: W4 |
|---|---|---|---|
| 0 ve 1 | — / 0 | 1,000 (hedef etiketin kendisi) | 0 |
| 2 | 0,03 | 0,970 | 0,03 |
| 3 | 0,06 | 0,912 | 0,06 |
| 4 | 0,09 | 0,830 | 0,09 |
| 5 | 0,12 | 0,730 | 0,12 |
| 6 | 0,15 | 0,621 | 0,15 |
| 7 | 0,18 | 0,509 | 0,18 |
| 8 | 0,21 | 0,402 | 0,21 |
| 9 (son) | 0,24 | 0,306 | 0,24 |

W1 ve S1'de hedefin etiket dışındaki kısmı önceki aşamaların tahminlerinin birikimidir. W5'te etiket dışındaki kısmın tamamı yalnız son aşamanın tahminidir. Hedefe giren tahminler eğitim verisi üzerinde, değerlendirme kipinde (dropout kapalı) alınır. S1'de hedef tam olarak etiketken (ilk iki aşama) kayıp S0'ınkiyle aynıdır; bu yüzden S1 ile S0 ilk kayan hedefe kadar birebir aynı ilerler.

## Dört karşılaştırma (tek yeni aile)

| # | Karşılaştırma | Ne söyler |
|---|---|---|
| 1 | S1 − S0 | Sıradan çıktıda müzakerenin etkisi |
| 2 | (W1 − W0) − (S1 − S0) | Müzakerenin etkisi iki çıktı türünde farklı mı |
| 3 | W1 − W5 | Eşit etiket payında: birikmiş eski tahminler mi, yalnız son tahmin mi |
| 4 | W5 − W4 | Çapalı kuralda tahmin payını büyütmenin etkisi |

Ölçü: test doğruluğu (puan). Birim: kişi (beş başlangıcın ortalaması), n = 54. İki yönlü eşleştirilmiş t; Holm düzeltmesi yalnız bu dört karşılaştırma üzerinden; %95 aralıklar düzeltmesiz. Wilcoxon yalnız duyarlılık denetimi (sıfır farklar atılır, normal yaklaşım, süreklilik düzeltmesi yok); sonucu değiştiremez.

**Bağımlılık notu:** 1 ile 2'nin toplamı W1 − W0'a, 3 ile 4'ün toplamı W1 − W4'e eşittir ve bu iki fark daha önce raporlandı. Aile bu yüzden iki yeni bilgi parçası ekler. Aynı ikinci gün verisi üzerinde hesaplanan üçüncü ailedir.

**Betimsel ölçüler (anlamlılık testi yok):** NLL, ECE, Brier, ortalama güven, Walsh için bit düzeyinde kayıp, en olası sınıfın doğruluğu ve en yakın kod sözcüğü kararıyla uyuşması, iki Walsh sınıf puanı 8'e bölündükten sonraki olasılık ölçüleri (8 sabittir, veriden ayarlanmaz), eğitim doğruluğu, eğitim–test farkı.

**Hedefin gerçekten ne kadar oynadığı:** son kullanılan hedefin etiketten uzaklığı (çıktı başına ortalama mutlak değişim; Walsh'ta 16 bitin hepsi ve ayrıca iki kod sözcüğünün ayrıştığı 8 bit), Öklid uzaklığı, hedefi öbür sınıfa dönen eğitim denemelerinin payı; her kişi ve başlangıç için W1 ile W5'in son hedefleri arasındaki ortalama mutlak fark. Sıfıra yakın çıkan bir karşılaştırma bu ölçülerle birlikte okunur: hedef hiç oynamadıysa "etki yok" denemez, "koşul fiilen uygulanmadı" denir.

## Önceden yazılan kurallar

- Bu koşullar Lee2019 sonuçları görüldükten sonra eklenmiştir: **keşif amaçlıdır**, doğrulayıcı değildir, bağımsız doğrulama sayılmaz. Makalede böyle yazılacaktır.
- Dört karşılaştırmanın hepsi, sonuç ne olursa olsun, her kişi ve her başlangıçla birlikte raporlanır.
- Sonuçlara bakarak yeni koşul, oran ya da eğitim süresi denenmez.
- Makaledeki eski iki istatistik ailesi yeniden hesaplanmaz, genişletilmez.
- İkinci gün verisi, kampanyanın bütün modelleri dondurulmadan açılmaz.

## Eski dört koşulun kaynağı ve işlerin sırası

1. Önce 72 arşiv eğitimi (kişiler 3, 9, 15, 21, 27, 33, 39, 45, 51; başlangıçlar 1 ve 5; koşullar S0, W0, W1, W4) aynı kodla yeniden koşulur.
2. 540 yeni eğitim yapılır (S1 ve W5).
3. Kaynak kararı bir kez ve yalnız birinci gün bilgisiyle verilir. **Arşiv** kullanılır, eğer (a) 72 örnek eğitimin eğitim tarafı (eğitim çıktıları, eğitim etiketleri, son kullanılan hedef, ölçekleme değerleri) arşivle veri türü, boyut ve bayt düzeyinde aynıysa **ve** (b) 270 W5 eğitiminin her birinde üçüncü aşamada kullanılan hedefin etiketten uzaklığı arşivdeki aynı kişi ve başlangıcın W4 değerine eşitse. W5'in sıfırdan farklı ilk güncellemesinde etiket payı 0,97'dir; bu, aritmetik olarak W4'ün güncellemesidir.
4. Biri bile tutmazsa **yeniden eğitim**: eski dört koşulun 1.080 eğitimi de bu kampanyada yapılır (toplam 1.620) ve yeni aile yalnız bu kampanyanın eğitimlerinden hesaplanır; farklar raporlanır.
5. Bütün modeller dondurulur.
6. İkinci gün verisi açılır. **Önce 72 örnek eğitim test edilir** ve test çıktıları arşivle karşılaştırılır; bu sırada S1 ve W5'in hiçbir test çıktısı yoktur. Arşiv kuralı altında fark çıkarsa çalışma o noktada durur. Yedek kural önceden yazılıdır: kaynak "yeniden eğitim" olur; kalan eski koşul eğitimleri aynı dondurulmuş kodla yapılır ve yeni aile yalnız kampanya eğitimlerinden hesaplanır. Bu, S1 ya da W5'in herhangi bir test çıktısı üretilmeden önce yazılan kayıtlı bir protokol ekiyle yapılır.
7. Kalan bütün modeller birer kez test edilir; sonuç hesabı yapılır.

## Sonuçlardan önce yazılan beklenti

- S1: Lee2019'da eğitim doğruluğu %100'e yakın; sıradan çıktının eğitim verisindeki olasılıkları etikete çok yakınsa hedef az oynar. Farkın sıfıra yakın çıkması olasıdır. Yön öngörmüyorum.
- W5: W1'in farkı tahmin payının büyüklüğünden geliyorsa W5, W1'e benzer; eski tahminlerin birikiminden geliyorsa W4'e benzer. Hangisi olacağını bilmiyorum.
- Genel: beklenen farklar 1 puanın altında. Dört karşılaştırmanın hiçbirinin anlamlı çıkmaması geçerli ve raporlanacak bir sonuçtur.

— Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · 12.11.2026
