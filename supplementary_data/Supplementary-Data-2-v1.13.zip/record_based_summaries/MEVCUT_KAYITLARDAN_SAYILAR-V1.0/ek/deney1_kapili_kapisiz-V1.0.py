# -*- coding: utf-8 -*-
"""Deney 1: kapili (C3) ile kapisiz (C2) capali kuralin test dogrulugu farki - V1.0 (yeni egitim yok; betimsel).

Makalenin v1.8 tartisma bolumundeki tek cumlenin kaynagi: Lee2019'daki W2 - W4 karsilastirmasinin Deney 1'deki
karsiligi. Yalniz Deney 1'in tamamlanmis kosu kayitlarini okur (K1 kodlari, 480 kosu). Birim kisidir: once kisinin
uc baslangici ortalanir, sonra 32 kisi uzerinden ortalama ve noktasal %95 t araligi alinir. Hicbir istatistik
ailesine eklenmez. Denetim icin makalede yayimlanmis dort karsilastirma da ayni yolla yeniden hesaplanir ve
Tablo 4'teki degerlerle karsilastirilir; biri tutmazsa betik hata verir.

Yalniz standart kitaplik kullanir.
"""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]            # .../MEVCUT_KAYITLARDAN_SAYILAR-V1.0 (this file is in its "ek" folder)
PROJECT = ROOT.parent
SOURCE = PROJECT / "ARASTIRMALAR/DENEY_01_MUZAKERE_DUZELTME_v1.0/sonuclar/deney01_kosular.jsonl"
OUT = Path(__file__).resolve().parent / "DENEY1_KAPILI_KAPISIZ-V1.0.json"
T975_31 = 2.039513446396408                           # t quantile 0.975 with 31 degrees of freedom
PUBLISHED = {            # Table 4 of the manuscript (v1.7): difference, CI low, CI high, in percentage points
    ("C1", "C0"): (0.64, 0.02, 1.26),
    ("C3", "C0"): (0.12, -0.18, 0.41),
    ("C3", "C1"): (-0.52, -1.21, 0.16),
    ("C2", "C4"): (0.39, 0.04, 0.73),
}


def main():
    assert not OUT.exists(), "The output exists; it is written once"
    raw = SOURCE.read_bytes()
    rows = [json.loads(line) for line in raw.decode("utf-8").split("\n") if line.strip()]
    k1 = [r for r in rows if r["code"] == "K1"]
    assert len(rows) == 615 and len(k1) == 480, (len(rows), len(k1))
    cells = collections.defaultdict(list)
    for r in k1:
        cells[(r["dataset"], r["subject"], r["condition"])].append(r["acc_test"])
    assert all(len(v) == 3 for v in cells.values()) and len(cells) == 160
    people = sorted({(d, s) for d, s, _ in cells})
    assert len(people) == 32 and collections.Counter(d for d, _ in people) == {"D1": 9, "D3": 14, "D4": 9}

    def contrast(a, b):
        diff = [100.0 * (sum(cells[(d, s, a)]) / 3.0 - sum(cells[(d, s, b)]) / 3.0) for d, s in people]
        n = len(diff)
        mean = sum(diff) / n
        sd = math.sqrt(sum((x - mean) ** 2 for x in diff) / (n - 1))
        half = T975_31 * sd / math.sqrt(n)
        positive, negative = sum(x > 0 for x in diff), sum(x < 0 for x in diff)
        return dict(contrast="%s-%s" % (a, b), n=n, mean_difference_pp=mean, ci95_pp=[mean - half, mean + half], sd_pp=sd,
                    participants_positive=positive, participants_negative=negative, participants_zero=n - positive - negative)

    check = {}
    for (a, b), (m, lo, hi) in PUBLISHED.items():
        c = contrast(a, b)
        assert round(c["mean_difference_pp"], 2) == m and round(c["ci95_pp"][0], 2) == lo and round(c["ci95_pp"][1], 2) == hi, (a, b, c)
        check["%s-%s" % (a, b)] = dict(recomputed=c, published_table_4=dict(mean=m, ci_low=lo, ci_high=hi), equal_at_two_decimals=True)
    result = dict(
        status="COMPLETE_DESCRIPTIVE_NO_NEW_TRAINING",
        created_trt=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat(timespec="seconds"),
        scope="Experiment 1 (CSP-CNN, K1 codes): gated anchored rule C3 minus ungated anchored rule C2, test accuracy",
        unit="participant mean over three seeds; 32 participants (D1 9, D3 14, D4 9); pointwise 95% t interval; no family, no adjustment",
        source=dict(path=str(SOURCE.relative_to(PROJECT)).replace("\\", "/"), sha256=hashlib.sha256(raw).hexdigest(), runs=len(rows), k1_runs=len(k1)),
        C3_minus_C2=contrast("C3", "C2"),
        published_contrasts_recomputed_the_same_way=check)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(json.dumps(result["C3_minus_C2"]))
    print("written", OUT.name, hashlib.sha256(OUT.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
