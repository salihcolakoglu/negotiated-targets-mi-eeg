# -*- coding: utf-8 -*-
"""
Step 2 - Experiment 2 (EEGNet): section C (agreement of the two decision rules)
from the saved outputs of every Walsh fit (W0..W3), plus the check that rule 1
reproduces the recorded acc_test of each fit.
Output: parca_adim2_C_e2.json  (summary + one line per fit)
"""
import os
import sys
import time
import hashlib
import collections
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

t0 = time.time()
rows, _ = bk.read_jsonl(bk.E2_FILE)
WALSH = ["W0", "W1", "W2", "W3"]
per_fit = []
notes = collections.OrderedDict()
shape_problems = []
sha_mismatch = 0
s0_checked = 0
s0_acc_mismatch = 0

for r in rows:
    path = os.path.join(bk.E2_DIR, r["cikti_npz"])
    with open(path, "rb") as fh:
        raw = fh.read()
    if hashlib.sha256(raw).hexdigest() != r["cikti_sha256"]:
        sha_mismatch += 1
    with np.load(path) as z:
        Pt = z["P_test"]
        y = z["y_test"]
    K = 4 if r["dataset"] == "D1" else 2
    N = int(y.shape[0])
    if r["condition"] == "S0":
        # not part of section C; light consistency check only
        s0_checked += 1
        if Pt.shape != (r["n_test"], K):
            shape_problems.append("S0 shape %s %s" % (r["cikti_npz"], Pt.shape))
        acc = float(np.mean(Pt.astype(np.float64).argmax(axis=1) == y))
        if abs(acc - r["acc_test"]) > 1e-12:
            s0_acc_mismatch += 1
        continue
    if Pt.shape != (r["n_test"], 16) or Pt.dtype != np.float32 or y.dtype != np.int64 or y.shape != (r["n_test"],):
        shape_problems.append("%s P %s %s y %s %s n_test %s" % (r["cikti_npz"], Pt.shape, Pt.dtype, y.shape, y.dtype, r["n_test"]))
    if y.min() < 0 or y.max() >= K:
        shape_problems.append("%s labels outside 0..%d" % (r["cikti_npz"], K - 1))

    pred1, d2 = bk.rule1_nearest(Pt, K)
    S = bk.rule2_scores(Pt, K)
    pred2 = S.argmax(axis=1)
    S32 = bk.rule2_scores(Pt, K, clip_in_float32=True)
    pred2_32 = S32.argmax(axis=1)

    d2s = np.sort(d2, axis=1)
    Ss = np.sort(S, axis=1)
    P64 = Pt.astype(np.float64)
    acc1 = float(np.mean(pred1 == y))
    per_fit.append({
        "dataset": r["dataset"], "subject": r["subject"], "condition": r["condition"], "seed": r["seed"],
        "K": K, "trials": N,
        "disagreements": int(np.sum(pred1 != pred2)),
        "disagreements_if_clip_in_float32": int(np.sum(pred1 != pred2_32)),
        "acc_rule1": acc1,
        "acc_rule2": float(np.mean(pred2 == y)),
        "acc_test_recorded": r["acc_test"],
        "acc_rule1_minus_recorded": acc1 - r["acc_test"],
        "correct_rule1": int(np.sum(pred1 == y)),
        "pred_rule1_equals_recorded_pred_test": bool(list(map(int, pred1)) == list(r["pred_test"])),
        "outputs_below_1e-7": int(np.sum(P64 < 1e-7)),
        "outputs_above_1_minus_1e-7": int(np.sum(P64 > 1.0 - 1e-7)),
        "outputs_not_finite_or_outside_0_1": int(np.sum(~np.isfinite(P64) | (P64 < 0) | (P64 > 1))),
        "min_gap_rule1": float(np.min(d2s[:, 1] - d2s[:, 0])),
        "min_gap_rule2": float(np.min(Ss[:, -1] - Ss[:, -2])),
    })

# ------------------------------------------------------------------ summary
C = {}
for ds in ("D1", "D3", "D4"):
    C[ds] = {}
    for c in WALSH:
        fs = [f for f in per_fit if f["dataset"] == ds and f["condition"] == c]
        C[ds][c] = {
            "trials": int(sum(f["trials"] for f in fs)),
            "disagreements": int(sum(f["disagreements"] for f in fs)),
            "fits": len(fs),
            "fits_with_any_disagreement": int(sum(1 for f in fs if f["disagreements"] > 0)),
        }

notes["walsh_fits_processed"] = len(per_fit)
notes["s0_fits_checked"] = s0_checked
notes["s0_fits_argmax_accuracy_differs_from_recorded"] = s0_acc_mismatch
notes["npz_sha256_mismatches_all_800"] = sha_mismatch
notes["shape_or_label_problems"] = shape_problems
notes["rule1_accuracy_vs_recorded_max_abs_diff"] = max(abs(f["acc_rule1_minus_recorded"]) for f in per_fit)
notes["rule1_accuracy_fits_differing_beyond_1e-12"] = sum(1 for f in per_fit if abs(f["acc_rule1_minus_recorded"]) > 1e-12)
notes["rule1_accuracy_fits_bitwise_equal"] = sum(1 for f in per_fit if f["acc_rule1"] == f["acc_test_recorded"])
notes["rule1_predictions_equal_recorded_pred_test_fits"] = sum(1 for f in per_fit if f["pred_rule1_equals_recorded_pred_test"])
notes["outputs_below_1e-7_total"] = sum(f["outputs_below_1e-7"] for f in per_fit)
notes["outputs_above_1_minus_1e-7_total"] = sum(f["outputs_above_1_minus_1e-7"] for f in per_fit)
notes["outputs_not_finite_or_outside_0_1_total"] = sum(f["outputs_not_finite_or_outside_0_1"] for f in per_fit)
notes["disagreements_total"] = sum(f["disagreements"] for f in per_fit)
notes["disagreements_total_if_clip_in_float32"] = sum(f["disagreements_if_clip_in_float32"] for f in per_fit)
notes["smallest_gap_rule1_best_vs_second"] = min(f["min_gap_rule1"] for f in per_fit)
notes["smallest_gap_rule2_best_vs_second"] = min(f["min_gap_rule2"] for f in per_fit)
notes["seconds"] = round(time.time() - t0, 1)

bk.write_json(os.path.join(bk.OUT, "parca_adim2_C_e2.json"),
              {"C_decision_rule_agreement": {"experiment2": C}, "notes": notes, "per_fit": per_fit})

import json
print(json.dumps(notes, indent=1))
for ds in C:
    for c in C[ds]:
        print(ds, c, C[ds][c])
