# -*- coding: utf-8 -*-
"""
Step 9 - writes KARSILASTIRMA.md from the JSON files produced by the earlier steps
(all figures in the report are taken from those files, none is typed by hand).
"""
import os
import sys
import hashlib
import datetime
import platform
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

K = bk.read_json(os.path.join(bk.OUT, "karsilastirma_sonuc.json"))
M = bk.read_json(os.path.join(bk.OUT, "bagimsiz_sonuclar.json"))
G = bk.read_json(os.path.join(bk.OUT, "ek_gozlem.json"))
S2 = bk.read_json(os.path.join(bk.OUT, "ikinci_yol_kontrolu.json"))
MT = bk.read_json(os.path.join(bk.OUT, "karsilastirma_mutasyon_testi.json"))
assert K["mutation_test"] is False and MT["mutation_test"] is True
RR1 = bk.read_json(os.path.join(bk.OUT, "yeniden_kosma_testi_bolum1.json"))
RR2 = bk.read_json(os.path.join(bk.OUT, "yeniden_kosma_testi_bolum2.json"))
assert RR1["all_identical"] is True and RR2["all_identical"] is True

WIN = "C:\\EEG_study_except_for_datasets\\EEG_study_except_for_datasets\\EEG_study_except_for_datasets\\MEVCUT_KAYITLARDAN_SAYILAR-V1.0"
WINO = WIN + "\\bagimsiz_kontrol"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def n(x):
    return "{:,}".format(x)


def sci(x):
    if x is None:
        return "-"
    if x == 0:
        return "0"
    return "%.1e" % x


def sci_tr(x):
    """4.3e-14 -> 4,3 x 10^-14 written with superscript digits"""
    mant, exp = ("%.1e" % x).split("e")
    sup = str(int(exp)).translate(str.maketrans("-0123456789", "\u207b\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\u2079"))
    return "%s \u00d7 10%s" % (mant.replace(".", ","), sup)


def utc_of(path):
    return datetime.datetime.fromtimestamp(os.path.getmtime(path), datetime.timezone.utc)


def both(dt):
    trt = dt.astimezone(datetime.timezone(datetime.timedelta(hours=3)))
    return "%s UTC (%s Turkey time)" % (dt.strftime("%Y-%m-%d %H:%M:%S"), trt.strftime("%Y-%m-%d %H:%M:%S"))


# ------------------------------------------------------------------ integrity of my results file
pre = {}
with open(os.path.join(bk.OUT, "OZETLER_karsilastirma_oncesi.sha256"), encoding="utf-8") as fh:
    lines = fh.read().splitlines()
for line in lines:
    parts = line.split("  ")
    if len(parts) == 2 and len(parts[0]) == 64:
        pre[parts[1]] = parts[0]
pre_stamp = [l for l in lines if "hashes taken" in l][0].split(" ")[0]
mine_path = os.path.join(bk.OUT, "bagimsiz_sonuclar.json")
analyst_path = os.path.join(bk.P, "MEVCUT_KAYITLARDAN_SAYILAR-V1.0", "SAYILAR-V1.0.json")
unchanged = {f: (sha(os.path.join(bk.OUT, f)) == h) for f, h in pre.items()}
assert all(unchanged.values()), unchanged
assert K["independent_file_sha256"] == pre["bagimsiz_sonuclar.json"] == sha(mine_path)
assert K["analyst_file_sha256"] == sha(analyst_path)

T = K["totals"]
BS = K["by_section"]
E = K["all_entries"]
assert T["numbers_beyond_tolerance_total"] == 0 and T["differences_of_any_kind"] == 0 and len(K["differences_beyond_tolerance"]) == 0
assert K["ordered_by_displacement"]["same"] is True
assert MT["mutation_test_passed"] is True
assert S2["total_beyond_1e-9"] == 0

core = ["A_training_fit", "B_gate_open", "C_decision_rule_agreement", "D_E_lee2019_confidence"]
cat = T["numbers_compared_sections_A_to_E_by_category"]
by_cond_max = max(e["abs_diff"] for e in E if e["kind"] == "number" and e["path"].startswith("D_E_lee2019_confidence/by_condition/"))
ints_total = sum(BS[s]["integers_compared_exactly"] for s in BS)
ci_total = sum(BS[s]["ci95_end_points_compared"] for s in BS)
kinds = {}
for e in E:
    kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
texts_compared = kinds.get("text", 0)

rc = M["raw_data_checks"]
r12, r2o, r3, r4 = rc["experiment1_and_2_records"], rc["experiment2_outputs"], rc["lee2019_records"], rc["lee2019_outputs"]
ver = r4["verification_by_condition"]
tqs = M["t_quantiles_0975"]
tqx = M["t_quantiles_0975_crosscheck"]
sens = M["D_sensitivity_clip_in_float32"]
sens_nll8 = max(abs(sens[c]["difference_from_primary"]["nll_div8"]) for c in sens)
sens_nll8_at = max(sens, key=lambda c: abs(sens[c]["difference_from_primary"]["nll_div8"]))
sens_other8 = max(max(abs(sens[c]["difference_from_primary"]["ece15_div8"]), abs(sens[c]["difference_from_primary"]["brier_div8"])) for c in sens)
sens_plain = max(max(abs(sens[c]["difference_from_primary"][k]) for k in ("nll", "ece15", "brier")) for c in sens)
edge_min = min(min(ver[c]["smallest_distance_to_bin_edge"], ver[c].get("smallest_distance_to_bin_edge_div8", 1.0)) for c in ver)
edge_changes = sum(ver[c]["ece_changes_with_other_edge_spelling"] + ver[c].get("ece_div8_changes_with_other_edge_spelling", 0) for c in ver)
gate_alt = max(max(r12["E2_gate_mean_over_fits_vs_participant_first_maxdiff"].values()), r3["gate_mean_over_fits_vs_participant_first_maxdiff"])
gap1_lee = min(ver[c]["smallest_gap_rule1"] for c in ver if c != "S0")
gap2_lee = min(ver[c]["smallest_gap_rule2"] for c in ver if c != "S0")
C = M["C_decision_rule_agreement"]
trials_e2 = sum(C["experiment2"][ds][c]["trials"] for ds in C["experiment2"] for c in C["experiment2"][ds])
trials_lee = sum(C["lee2019"][c]["trials"] for c in C["lee2019"])
dis_total = sum(C["experiment2"][ds][c]["disagreements"] for ds in C["experiment2"] for c in C["experiment2"][ds]) + \
    sum(C["lee2019"][c]["disagreements"] for c in C["lee2019"])
rng_lee = G["within_trial_range_of_outputs_with_equal_code_pattern_lee2019"]
rng_e2 = G["within_trial_range_of_outputs_with_equal_code_pattern_experiment2"]
rng_med = [v["median_range"] for v in list(rng_lee.values()) + list(rng_e2.values())]
rng_max = max(v["max_range"] for v in list(rng_lee.values()) + list(rng_e2.values()))
fl = G["nll_floor_lee2019"]
sat = G["saturated_outputs_lee2019"]
sat2 = G["saturated_outputs_experiment2"]
ltd = G["last_target_dist_over_fits_lee2019"]
w24 = G["lee2019_W2_gate_open_in_phases_2_to_9_versus_W4"]
tg = G["target_used_in_early_phases"]
ceil = G["fits_with_training_accuracy_exactly_1"]

# mean differences that are zero up to rounding (should be printed as 0)
tiny = [e for e in E if e["kind"] == "number" and e["path"].endswith("/mean") and abs(e["mine"]) < 1e-12 and e["category"] == "brief"]

# E2: which D4 participant has 160 training trials
rows2, _ = bk.read_jsonl(bk.E2_FILE)
d4 = sorted(set((r["subject"], r["n_train"]) for r in rows2 if r["dataset"] == "D4"))
d4_160 = [s for s, k in d4 if k == 160]
d4_120 = [s for s, k in d4 if k == 120]

now = datetime.datetime.now(datetime.timezone.utc)
cpu = "unknown"
try:
    with open("/proc/cpuinfo") as fh:
        for line in fh:
            if line.startswith("model name"):
                cpu = line.split(":", 1)[1].strip()
                break
except OSError:
    pass

L = []
A = L.append
A("# KARSILASTIRMA - independent check of the numbers in SAYILAR-V1.0.json")
A("")
A("**Kısa özet (Türkçe).** Analistin `SAYILAR-V1.0.json` dosyasındaki bütün sayılar, ham deney kayıtlarından, "
  "yalnızca yazılı tanımlara bakılarak sıfırdan yazılan ayrı bir kodla yeniden hesaplandı. Karşılaştırılan "
  "%s sayının tamamı tolerans içinde aynı çıktı; en büyük fark %s düzeyinde, yani yalnızca bilgisayarın yuvarlama farkı. "
  "Tolerans dışında kalan tek bir sayı yok: **analistin sayıları doğrulandı.** Analistin betiği hiç açılmadı; analistin "
  "sonuç dosyası ancak bağımsız sonuçlar diske kaydedildikten sonra açıldı. Ham kayıtlarda eksik ya da çift kayıt bulunmadı. "
  "Sayıları okurken bilinmesi yararlı noktalar 6. bölümde, tanımlardaki belirsizlikler ve nasıl çözüldükleri 7. bölümde."
  % (n(T["numbers_compared_total"]).replace(",", "."), sci_tr(T["largest_abs_diff_overall"])))
A("")
A("| | |")
A("|---|---|")
A("| Report written | %s |" % both(now))
A("| Analyst's file | `%s\\SAYILAR-V1.0.json` (SHA-256 `%s`, last changed %s) |" % (WIN, K["analyst_file_sha256"], both(utc_of(analyst_path))))
A("| Independent results | `%s\\bagimsiz_sonuclar.json` (SHA-256 `%s`, written %s) |" % (WINO, K["independent_file_sha256"], both(utc_of(mine_path))))
A("")
A("## 1. Outcome")
A("")
A("Every number in the analyst's file was recomputed from the raw records with separately written code. "
  "All of them agree within the agreed tolerance. **The analyst's numbers are confirmed.**")
A("")
A("- Numbers compared: **%s** (every number that the analyst's file contains)." % n(T["numbers_compared_total"]))
A("- Numbers that differ beyond tolerance: **%d**." % T["numbers_beyond_tolerance_total"])
A("- Largest absolute difference anywhere: **%s** (rounding level; the tolerance is 1e-9). %s of the %s numbers are identical to the last digit."
  % (sci(T["largest_abs_diff_overall"]), n(T["exactly_identical_numbers"]), n(T["numbers_compared_total"])))
A("")
A("| Section | Content | Numbers compared | Largest absolute difference | Beyond tolerance |")
A("|---|---|---:|---:|---:|")
names = {"A_training_fit": ("A", "Training fit (test and training accuracy, their gap, paired differences with 95% intervals)"),
         "B_gate_open": ("B", "Gate (share of training trials with open gate, W2 fits)"),
         "C_decision_rule_agreement": ("C", "Agreement of the two decision rules"),
         "D_E_lee2019_confidence": ("D and E", "Lee2019 confidence measures and target displacement"),
         "algebra": ("extra", "`algebra` block (not defined in my brief, see 3.3)"),
         "source_counts": ("extra", "`source_counts` block (numbers of records and files)")}
for s in ["A_training_fit", "B_gate_open", "C_decision_rule_agreement", "D_E_lee2019_confidence", "algebra", "source_counts"]:
    A("| %s | %s | %s | %s | %d |" % (names[s][0], names[s][1], n(BS[s]["numbers_compared"]), sci(BS[s]["largest_abs_diff"]), BS[s]["numbers_beyond_tolerance"]))
A("| **Total** | | **%s** | **%s** | **%d** |" % (n(T["numbers_compared_total"]), sci(T["largest_abs_diff_overall"]), T["numbers_beyond_tolerance_total"]))
A("")
A("Where the largest differences sit: section A at `%s` (%s percentage points); interval end points in A at most %s; "
  "section D/E at `%s` (%s, a repeated value in percent); %s. Sections B and C agree exactly."
  % (BS["A_training_fit"]["largest_abs_diff_at"], sci(BS["A_training_fit"]["largest_abs_diff"]),
     sci(BS["A_training_fit"]["largest_abs_diff_ci95_end_points"]),
     BS["D_E_lee2019_confidence"]["largest_abs_diff_at"], sci(BS["D_E_lee2019_confidence"]["largest_abs_diff"]),
     "all `by_condition` values of D/E are identical to the last digit" if by_cond_max == 0
     else "the `by_condition` values of D/E differ by at most %s" % sci(by_cond_max)))
A("")
A("## 2. How independence was kept")
A("")
A("1. My code was written only from the written definitions in the task. The analyst's script "
  "(`%s\\kod\\sayilar-V1.0.py`) was never opened, at any time." % WIN)
A("2. The analyst's result file was opened only after my own results were on disk. Before that, only the folder listing "
  "(file names and sizes) had been seen. The key names of the analyst's layout were given to me in the task text, so my file uses a similar layout.")
A("3. Order of events: my results and scripts were hashed at %s UTC (file `OZETLER_karsilastirma_oncesi.sha256`); "
  "the analyst's file was opened after that. The hash of `bagimsiz_sonuclar.json` is still the same "
  "(`%s`), i.e. **no number of mine was changed after seeing the analyst's file**. "
  "The same holds for the other files hashed at that time (six scripts and four partial result files): %d of %d files unchanged."
  % (pre_stamp.replace("T", " ").replace("Z", ""), pre["bagimsiz_sonuclar.json"], sum(unchanged.values()), len(unchanged)))
A("4. The comparison itself is done by a program (`adim6_karsilastir.py`). It walks through every entry of the analyst's file, "
  "so nothing is skipped by hand.")
A("")
A("## 3. What exactly was compared")
A("")
A("### 3.1 Tolerances")
A("")
A("- whole numbers (counts): must be exactly equal - %s numbers;" % n(ints_total))
A("- end points of the 95%% intervals: 1e-6 - %s numbers;" % n(ci_total))
A("- all other numbers (means, standard deviations, shares): 1e-9 - %s numbers."
  % n(T["numbers_compared_total"] - ints_total - ci_total))
A("")
A("### 3.2 Every entry of the analyst's file, by kind")
A("")
A("The analyst's file has %s entries (leaves):" % n(T["analyst_leaves_total"]))
A("")
A("- %s numbers - all compared (table above);" % n(kinds.get("number", 0)))
A("- %d empty values (`null`: S0 has no displacement and no \"div8\" measures) - also empty in my results;" % kinds.get("null", 0))
A("- %d true/false flags (`gate_used` per phase) - all agree with the raw records (entry 0 of the gate list is empty in every W2 fit, entries 1 to 9 are numbers in every W2 fit);" % kinds.get("flag", 0))
A("- %d text entries that could be checked - all agree: the 5 condition names in `ordered_by_displacement` (same order as mine: %s) and the SHA-256 hashes of the two `.jsonl` source files, which I recomputed;"
  % (texts_compared, ", ".join(K["ordered_by_displacement"]["mine"])))
A("- %d text entries that cannot be compared with a number (status, creation time, scope, unit, and five explanatory notes)." % kinds.get("no_counterpart", 0))
A("")
A("No entry of the analyst's file was left without a decision, and there is no number in the analyst's file that I could not recompute.")
A("")
A("### 3.3 Breakdown of the %s numbers in sections A to E" % n(T["numbers_compared_sections_A_to_E"]))
A("")
A("- **%s numbers defined in my brief** (A: %s, B: %s, C: %s, D/E: %s). In B this includes the 36 update rates `rate_of_update`, which are the weights w_p = 0.03 x (p - 1) of the definition."
  % (n(cat["brief"]), n(BS["A_training_fit"]["numbers_by_category"]["brief"]), n(BS["B_gate_open"]["numbers_by_category"]["brief"]),
     n(BS["C_decision_rule_agreement"]["numbers_by_category"]["brief"]), n(BS["D_E_lee2019_confidence"]["numbers_by_category"]["brief"])))
A("- **%s repeated values**: the analyst repeats the descriptive values (n, test, training, gap) inside the two \"versus W0\" tables (%s numbers) and repeats five columns in `ordered_by_displacement` (%s numbers, `accuracy_pct` = 100 x `acc`). They were compared with my values for the same quantity."
  % (n(cat["repeat"]), n(BS["A_training_fit"]["numbers_by_category"]["repeat"]), n(BS["D_E_lee2019_confidence"]["numbers_by_category"]["repeat"])))
A("- **%s phase numbers** (0 to 9) in the gate tables; they only label the rows." % n(cat["index"]))
A("- **%s numbers in two extra fields of section C** that my brief did not list: `disagreement_share` (= disagreements / trials) and `fits_with_different_accuracy` (I read it as: fits whose accuracy under rule 2 differs from the accuracy under rule 1). Both are 0 in every cell, in the analyst's file and in mine."
  % n(cat["extra_derived"]))
A("")
A("Outside sections A to E the analyst's file has two more blocks (%d numbers):" % T["numbers_compared_extras"])
A("")
A("- `algebra` (3 numbers). These are not defined in my brief. From the names I inferred: label share of the last trained target under cumulative updating = product over phases 2 to 9 of (1 - 0.03 x (p - 1)) = %.15f; prediction share = 1 minus that = %.15f; prediction share under anchored updating = rate of the last phase = 0.03 x 8 = 0.24. With these formulas all three agree (difference 0). Because I inferred the definitions, please read this as an arithmetic check only."
  % (K["all_entries"][[e["path"] for e in E].index("algebra/label_share_last_trained_target_cumulative")]["mine"],
     K["all_entries"][[e["path"] for e in E].index("algebra/prediction_share_last_trained_target_cumulative")]["mine"]))
A("- `source_counts` (6 numbers): %s K1 runs, %s Experiment 2 runs, %s Lee2019 records, %s W4 records - same as my counts. The analyst checked the file hashes of %s Lee2019 prediction files and %s Experiment 2 output files (the Walsh fits); I checked the same files and additionally the 160 S0 output files of Experiment 2 (%s in total). All hashes match."
  % (n(r12["E1_rows_K1"]), n(r12["E2_rows_total"]), n(r3["E3_record_files"]), n(r3["W4_fit_record_files"]),
     n(r4["fits_processed"]), n(r2o["walsh_fits_processed"]), n(r2o["walsh_fits_processed"] + r2o["s0_fits_checked"])))
A("")
A("## 4. Numbers that differ beyond tolerance")
A("")
A("**None.** The list produced by the comparison program is empty (`differences_beyond_tolerance` in `karsilastirma_sonuc.json`).")
A("")
A("## 5. Verifications asked for in the definitions")
A("")
A("### 5.1 Student's t quantile (0.975), computed numerically")
A("")
A("Computed by integrating the t density (Gauss-Legendre, 200 nodes) and bisecting. Two further methods (Simpson's rule with 200,000 steps; the incomplete beta function) give the same values.")
A("")
A("| Degrees of freedom | Used for | Quantile | Largest spread between the three methods |")
A("|---:|---|---:|---:|")
use = {"8": "D1 and D4 (9 participants)", "13": "D3 (14 participants)", "31": "pooled (32 participants)", "53": "Lee2019 (54 participants)"}
for df in ("8", "13", "31", "53"):
    v = list(tqx[df].values())
    A("| %s | %s | %.12f | %s |" % (df, use[df], tqs[df], sci(max(v) - min(v))))
A("")
A("### 5.2 Rule 1 (nearest code word) reproduces the recorded test accuracy")
A("")
A("- Experiment 2: %d of %d Walsh fits give exactly the recorded `acc_test` (largest difference %s). The class chosen by rule 1 equals the recorded `pred_test` in every trial of every fit (%d of %d fits)."
  % (r2o["rule1_accuracy_fits_bitwise_equal"], r2o["walsh_fits_processed"], sci(r2o["rule1_accuracy_vs_recorded_max_abs_diff"]),
     r2o["rule1_predictions_equal_recorded_pred_test_fits"], r2o["walsh_fits_processed"]))
A("- Lee2019 (W0 to W3 and W4): %s of %s Walsh fits give exactly the recorded `acc_test` (largest difference %s); predicted classes equal the recorded `pred_test` in %s of %s fits."
  % (n(r4["rule1_accuracy_fits_bitwise_equal"]), n(r4["walsh_fits"]), sci(r4["rule1_accuracy_vs_recorded_max_abs_diff"]),
     n(r4["rule1_predictions_equal_recorded_pred_test_fits"]), n(r4["walsh_fits"])))
A("")
A("### 5.3 NLL and ECE (without division) reproduce the recorded values")
A("")
A("NLL = negative log-likelihood, ECE = expected calibration error (15 bins). For all %s Lee2019 fits (270 per condition, S0, W0 to W4) my values equal the recorded `nll_test` and `ece_test`: largest difference %s for NLL and %s for ECE (required: within 1e-9). Fits outside 1e-9: %d (NLL), %d (ECE)."
  % (n(r4["fits_processed"]), sci(r4["nll_max_abs_diff_all_fits"]), sci(r4["ece_max_abs_diff_all_fits"]),
     r4["nll_fits_beyond_1e-9_all"], r4["ece_fits_beyond_1e-9_all"]))
A("")
A("## 6. Raw data: counts, and things worth knowing")
A("")
A("### 6.1 Counts - all as expected")
A("")
A("| Source | Records | Design | Missing or duplicate combinations |")
A("|---|---:|---|---:|")
A("| E1 (CSP-CNN), code K1 | %s | 32 participants (D1: %d, D3: %d, D4: %d) x 5 conditions x 3 seeds | %d |"
  % (n(r12["E1_rows_K1"]), r12["E1_participants"]["D1"], r12["E1_participants"]["D3"], r12["E1_participants"]["D4"],
     len(r12["E1_design_problems"]) + len(r12["E1_K1_duplicates"])))
A("| E2 (EEGNet) | %s | the same 32 participants x 5 conditions x 5 seeds | %d |"
  % (n(r12["E2_rows_total"]), len(r12["E2_design_problems"]) + len(r12["E2_duplicates"])))
lee_design = len(r3["design_problems"]) + len(r3["duplicates"])
A("| E3 (Lee2019: S0, W0 to W3) | %s | 54 participants x 5 conditions x 5 seeds | %d |"
  % (n(r3["E3_record_files"]), lee_design + len(r3["E3_name_or_path_inconsistencies"])))
A("| W4 (Lee2019, extra condition) | %s fit records, %s test records, %s prediction files | the same 54 participants x 5 seeds | %d |"
  % (n(r3["W4_fit_record_files"]), n(r3["W4_test_record_files"]), n(r3["W4_prediction_files"]), lee_design + len(r3["W4_problems"])))
A("")
A("Lee2019 with W4 together: %d participants, 6 conditions; gaps in the participant x condition x seed design: %d; duplicates: %d. "
  "File names, identifiers and paths inside the Lee2019 and W4 records are consistent with each other. "
  "The E1 file also holds %d rows of code K2 (D1 only); they were not used. No seed is missing anywhere. "
  "All %s output files of Experiment 2 and all %s Lee2019 prediction files have the SHA-256 hash that their run record states."
  % (r3["participants"], len(r3["design_problems"]), len(r3["duplicates"]), r12["E1_rows_by_code"].get("K2", 0),
     n(r2o["walsh_fits_processed"] + r2o["s0_fits_checked"]), n(r4["fits_processed"])))
A("")
A("### 6.2 Nothing inconsistent was found. Points worth knowing when reading the numbers")
A("")
A("1. **One participant with more training trials.** In Experiment 2, D4 participant %s has %d training trials, the other %d D4 participants have 120 (test trials: 160 for all nine)."
  % (", ".join(map(str, d4_160)), 160, len(d4_120)))
A("2. **Gate field.** `used_gate_open_by_phase` is absent for S0, present but empty for W0, W1, W3 (and W4), and holds numbers only for W2. All W2 values lie in [0, 1] and are whole multiples of 1 / (number of training trials).")
A("3. **The target of phases 0 and 1 is the label code in every Walsh fit** (field `used_target_dist_by_phase` is 0 for phases 0 and 1 in all fits; in phase 2 it is above 0 in every W1, W2, W3 and W4 fit). This agrees with the analyst's note that the gate matters from phase 2 on; the phase-1 row of the gate tables has weight 0.")
A("4. **The two decision rules never differ**: %d disagreements in %s Walsh test trials (Experiment 2: %s; Lee2019: %s). This is plausible, not suspicious: the outputs that share the same code pattern are near-copies of each other within a trial (median within-trial range between %.4f and %.4f depending on condition and data set, largest %.3f), and there is no near-tie (smallest margin between the best and second-best class: rule 1 %s, rule 2 %s). On a constructed trial where the rules must differ, my code does give different classes (self-test)."
  % (dis_total, n(trials_e2 + trials_lee), n(trials_e2), n(trials_lee), min(rng_med), max(rng_med), rng_max,
     sci(min(r2o["smallest_gap_rule1_best_vs_second"], gap1_lee)), sci(min(r2o["smallest_gap_rule2_best_vs_second"], gap2_lee))))
A("5. **Saturated outputs exist, so the clip in rule 2 is active.** Lee2019, outputs below 1e-7 / above 1 - 1e-7 (of %s output values per condition): %s. Experiment 2: %d / %s of %s."
  % (n(sat["W0"]["output_values"]),
     "; ".join("%s %d / %s" % (c, sat[c]["below_1e-7"], n(sat[c]["above_1_minus_1e-7"])) for c in ("W0", "W1", "W2", "W3", "W4")),
     sat2["below_1e-7"], n(sat2["above_1_minus_1e-7"]), n(sat2["output_values"])))
A("6. **The undivided NLL of the Walsh conditions depends strongly on the floor 1e-12.** Test trials whose true-class posterior is below 1e-12 (each then counts 27.63): %s, of 27,000 trials per condition. For W0 these trials alone contribute %.2f of the mean NLL of %.2f. After division by 8 no trial reaches the floor. This is a property of the definition, not an error; it matters when the undivided NLL values are interpreted."
  % ("; ".join("%s %s" % (c, n(fl[c]["floored_trials"])) for c in ("S0", "W0", "W1", "W2", "W3", "W4")),
     fl["W0"]["nll_part_from_floored_trials"], fl["W0"]["nll_mean_over_fits"]))
A("7. **Displacement is a constant for two conditions.** `last_target_dist` is 0 in all 270 W0 fits and has the same value %.6f in all 270 W3 fits (%d distinct value). It varies between fits only for W1 (%.3f to %.3f), W2 (%.3f to %.3f) and W4 (%.3f to %.3f)."
  % (ltd["W3"]["min"], ltd["W3"]["distinct_values"], ltd["W1"]["min"], ltd["W1"]["max"], ltd["W2"]["min"], ltd["W2"]["max"], ltd["W4"]["min"], ltd["W4"]["max"]))
A("8. **Training accuracy is at 100%% in most Lee2019 fits** (fits with exactly 100%%: %s). The differences in training accuracy are therefore very small, and the differences in the gap are almost the negative of the differences in test accuracy."
  % "; ".join("%s %s" % (c, ceil["lee2019"][c]) for c in ("S0", "W0", "W1", "W2", "W3", "W4")))
if tiny:
    A("9. **Mean differences that are zero, exactly or up to rounding** (please print them as 0; the sign of a value such as -6e-16 carries no meaning): "
      + "; ".join("`%s` (analyst %s, mine %s)" % (e["path"].replace("A_training_fit/", ""), repr(e["analyst"]), repr(e["mine"])) for e in tiny) + ".")
else:
    A("9. No mean difference is zero up to rounding.")
A("10. **The two Lee2019 campaigns fit together.** For every participant the W4 fit records state the same training-data hash as the E3 records (differences: %d), %s, and the test labels in the S0, W0 and W4 prediction files are identical (participants with different labels: %d). The %d W2 fits whose gate was fully open in phases 2 to 9 have test outputs that are bit-for-bit identical to the W4 fit of the same participant and seed (%d of %d)."
  % (r3["W4_fits_whose_train_data_hash_differs_from_E3_same_subject"],
     "the training settings (learning rate, epochs per phase, number of phases, batch size, dropout) are the same"
     if r3["W4_hyperparameters_equal_E3"] else "THE TRAINING SETTINGS DIFFER",
     w24["subjects_whose_test_labels_differ_between_S0_W0_W4_files"], w24["W2_fits_with_gate_fully_open_in_phases_2_to_9"],
     w24["of_these_test_outputs_bit_identical_to_W4"], w24["W2_fits_with_gate_fully_open_in_phases_2_to_9"]))
A("")
A("## 7. Definitions that were ambiguous, and how I resolved them")
A("")
A("Items 1 to 11 were decided before the analyst's file was opened. Item 12 concerns fields that I saw only in the analyst's file.")
A("")
A("1. **Precision of the clip in rule 2.** The definition says \"clip outputs to [1e-7, 1 - 1e-7]\" but not whether this happens in the stored single precision (float32) or after conversion to double precision (float64). I convert to float64 first (as rule 1 says explicitly) and then clip. As a sensitivity check I also clipped in float32 (there the upper bound rounds to 0.99999988): no agreement count changes; NLL, ECE and Brier without division do not change at all (largest change %s); only the \"div8\" measures move slightly: `nll_div8` by at most %s (%s), `ece15_div8` and `brier_div8` by at most %s. Both readings reproduce the recorded `nll_test` and `ece_test`, so the records cannot decide between them. The analyst's values agree with the float64 reading."
  % (sci(sens_plain), sci(sens_nll8), sens_nll8_at, sci(sens_other8)))
A("2. **Gate: \"mean over fits\".** Taken literally: the plain mean over all W2 fits, not participants first. Because every participant has 5 seeds, both ways give the same number (largest difference %s)." % sci(gate_alt))
A("3. **Standard deviation (`sd`).** Sample standard deviation over participants (denominator n - 1), the one the t interval needs.")
A("4. **95% interval.** mean -/+ t(0.975; n - 1) x sd / sqrt(n), two-sided, separately for each number (pointwise).")
A("5. **Gap and its difference.** Gap of a participant = mean over seeds of (training - test) accuracy, which equals mean training minus mean test. Gap difference = gap of the condition minus gap of the baseline, per participant. Accuracies were turned into percent at participant level.")
A("6. **\"Pooled\".** Plain mean over the 32 participants (D1: 9, D3: 14, D4: 9), each with equal weight; not the mean of the three data-set means.")
A("7. **`acc` in section D.** The recorded `acc_test` as a fraction, participants first. Fit by fit it is identical to the accuracy of rule 1 and to the accuracy of the most probable class.")
A("8. **ECE bin edges.** `numpy.linspace(0, 1, 16)`. Writing the edges as i/15 instead changes the ECE of %d fits; no confidence value lies closer than %s to an edge." % (edge_changes, sci(edge_min)))
A("9. **S0 probabilities.** Used as saved (float32 converted to float64), not re-normalised; the largest deviation of a row sum from 1 is %s. S0 has no \"div8\" measures and no displacement (empty in both files)." % sci(r4["s0_max_abs_rowsum_minus_1"]))
A("10. **Ties.** First index, as defined. No tie occurred (see 6.2, point 4).")
A("11. **Displacement.** Participant-first mean of `last_target_dist`; for W4 the value comes from the fit records.")
A("12. **Fields of the analyst's file that my brief did not define** (`rate_of_update`, `gate_used`, `disagreement_share`, `fits_with_different_accuracy`, `ordered_by_displacement`, the repeated descriptive values, `algebra`, `source_counts`, `source_files_sha256`). I compared each of them with the obvious counterpart from my own results; section 3.3 says how each was read. None of this changed my results file.")
A("")
A("## 8. Checks of my own work")
A("")
A("- **Self-tests** (`adim5_birlestir.py`): the t quantile against the exact formulas for 1 and 2 degrees of freedom; the code matrix (rows 0 to 3, mutual orthogonality); both decision rules on exact code words, on a tie, and on a constructed trial where they must differ; NLL, ECE and Brier against values computed by hand. All passed.")
A("- **Second route** (`adim7_ikinci_yol.py`): sections A, B, E and the aggregation of D were recomputed a second time with pandas pivot tables straight from the raw records, with the t quantile from a different numerical method. %s numbers rechecked, largest difference %s, none beyond 1e-9."
  % (n(S2["total_numbers_rechecked"]), sci(max(v["largest_abs_diff"] for k, v in S2.items() if isinstance(v, dict)))))
A("- **Test of the comparison program** (`BK_MUTATION_TEST=1`): five deliberate changes were made to a copy of my numbers - three beyond tolerance (a mean by 2e-9, an interval end point by 2e-6, a count by 1) and two inside tolerance (a mean by 5e-10, an interval end point by 5e-7). The program reported exactly the three (%s)."
  % ("passed" if MT["mutation_test_passed"] else "FAILED"))
A("- **Re-run test** (`adim10_yeniden_kosma_testi.py`): steps 1 to 5 were executed once more with their output kept in memory (nothing was overwritten). The output is identical to the %d result files on disk, apart from the time stamp and run-time fields. So the scripts in this folder reproduce the results in this folder."
  % (len(RR1["files"]) + len(RR2["files"])))
A("")
A("## 9. What this check does and does not cover")
A("")
A("It confirms that the numbers in `SAYILAR-V1.0.json` follow from the archived records under the written definitions. "
  "It does not examine how the records were produced (training code, data preparation), and it does not judge any conclusion drawn from the numbers.")
A("")
A("## 10. Files")
A("")
A("All files are in `%s\\`. Inside the Linux virtual machine the same folder is `~/mnt/EEG_study_except_for_datasets/EEG_study_except_for_datasets/EEG_study_except_for_datasets/MEVCUT_KAYITLARDAN_SAYILAR-V1.0/bagimsiz_kontrol/`." % WINO)
A("")
A("| File (full path) | Purpose |")
A("|---|---|")
files = [
    ("KARSILASTIRMA.md", "this report"),
    ("bagimsiz_sonuclar.json", "**my independent results** (sections A to E, t quantiles, self-tests, raw-data checks)"),
    ("karsilastirma_sonuc.json", "the comparison: totals, per section, and every one of the %s entries with both values" % n(T["analyst_leaves_total"])),
    ("bk_common.py", "common functions (t quantile, aggregation, code words, decision rules, NLL / ECE / Brier)"),
    ("adim1_e1_e2_kayitlar.py", "step 1: sections A (E1, E2) and B (E2) from the run records"),
    ("adim2_e2_npz.py", "step 2: section C for Experiment 2 from the saved outputs"),
    ("adim3_lee_kayitlar.py", "step 3: sections A, B, E for Lee2019 (with W4) from the run records"),
    ("adim4_lee_npz.py", "step 4: sections C and D for Lee2019 (with W4) from the saved outputs"),
    ("adim5_birlestir.py", "step 5: self-tests and merge into `bagimsiz_sonuclar.json`"),
    ("adim6_karsilastir.py", "step 6: comparison with the analyst's file (the only script that reads it)"),
    ("adim7_ikinci_yol.py", "step 7: second-route check of my own numbers (pandas)"),
    ("adim8_ek_gozlem.py", "step 8: additional observations on the raw data (section 6.2)"),
    ("adim9_rapor.py", "step 9: writes this report from the JSON files"),
    ("adim10_yeniden_kosma_testi.py", "step 10: re-run test (do the scripts on disk reproduce the results on disk?)"),
    ("parca_adim1_A_B_e1_e2.json", "partial results of step 1"),
    ("parca_adim2_C_e2.json", "partial results of step 2, with one line per fit"),
    ("parca_adim3_A_B_E_lee.json", "partial results of step 3"),
    ("parca_adim4_C_D_lee.json", "partial results of step 4, with one line per fit"),
    ("lee_fit_tablosu.json", "table of the 1,620 Lee2019 fits read from the records (input of step 4)"),
    ("ikinci_yol_kontrolu.json", "result of step 7"),
    ("ek_gozlem.json", "result of step 8"),
    ("karsilastirma_mutasyon_testi.json", "result of the test of the comparison program"),
    ("yeniden_kosma_testi_bolum1.json", "result of step 10, part 1 (steps 1 and 2)"),
    ("yeniden_kosma_testi_bolum2.json", "result of step 10, part 2 (steps 3, 4 and 5)"),
    ("OZETLER_karsilastirma_oncesi.sha256", "hashes of my results and scripts, taken before the analyst's file was opened"),
]
for f, purpose in files:
    assert os.path.exists(os.path.join(bk.OUT, f)) or f == "KARSILASTIRMA.md", f
    A("| `%s\\%s` | %s |" % (WINO, f, purpose))
A("")
A("To repeat the check without touching the saved results: run `python3 -X utf8 -B adim10_yeniden_kosma_testi.py 1` and then the same with `2` from that folder in the Linux virtual machine "
  "(this recomputes steps 1 to 5 in memory and compares with the saved results; it only rewrites its own two small result files), then `python3 -X utf8 -B adim6_karsilastir.py` for the comparison (it rewrites `karsilastirma_sonuc.json`). Each command needs less than two minutes. "
  "Running steps 1 to 5 directly also works and gives the same numbers, but step 5 writes the current time into `bagimsiz_sonuclar.json`; its hash then changes and step 9 refuses to write the report, "
  "because step 9 insists on the hash recorded before the analyst's file was opened. "
  "The scripts expect the project under `~/mnt/...` as in the Linux virtual machine; to run them elsewhere, change the path `P` at the top of `bk_common.py`.")
A("")
A("---")
A("")
A("Prepared by Claude (model: Fable 5.2) acting as independent checker, %s. "
  "Environment: Linux virtual machine (kernel %s) on the Windows PC \"the-beast\" (x64); processor as seen there: %s, %d cores assigned; no graphics card used and no training run. "
  "Software: Python %s, numpy %s, pandas %s (pandas only in step 7); no scipy; nothing was downloaded or installed. "
  "Nothing outside the folder `bagimsiz_kontrol` was written, changed, moved or deleted."
  % (both(now), platform.release(), cpu, os.cpu_count() or 0, platform.python_version(), np.__version__, pd.__version__))
A("")

dst = os.path.join(bk.OUT, "KARSILASTIRMA.md")
with open(dst, "w", encoding="utf-8") as fh:
    fh.write("\n".join(L))
print("written", dst, os.path.getsize(dst), "bytes")
