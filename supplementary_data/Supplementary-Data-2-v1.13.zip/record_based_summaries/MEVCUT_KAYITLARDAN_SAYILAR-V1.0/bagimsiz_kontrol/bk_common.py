# -*- coding: utf-8 -*-
"""
Independent check ("bagimsiz kontrol") - common helpers.

Written only from the written definitions of the task. The analyst's script
(kod/sayilar-V1.0.py) was never opened; the analyst's result file is read only
by the final comparison step (adim6_karsilastir.py).

Python 3.10, numpy only (no scipy).
"""
import os
import json
import math
import numpy as np

HOME = os.path.expanduser("~")
P = os.path.join(HOME, "mnt", "EEG_study_except_for_datasets",
                 "EEG_study_except_for_datasets", "EEG_study_except_for_datasets")
OUT = os.path.join(P, "MEVCUT_KAYITLARDAN_SAYILAR-V1.0", "bagimsiz_kontrol")

E1_FILE = os.path.join(P, "ARASTIRMALAR", "DENEY_01_MUZAKERE_DUZELTME_v1.0",
                       "sonuclar", "deney01_kosular.jsonl")
E2_DIR = os.path.join(P, "ARASTIRMALAR", "DENEY_02_03_GPU_v1.0", "sonuclar_bulut_EEGNet")
E2_FILE = os.path.join(E2_DIR, "kosular.jsonl")
E3_DIR = os.path.join(P, "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0", "results", "worker_01")
W4_DIR = os.path.join(P, "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0", "campaign")


# ----------------------------------------------------------------------------
# JSON helpers
# ----------------------------------------------------------------------------
def read_jsonl(path):
    rows = []
    blank = 0
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            s = line.strip()
            if not s:
                blank += 1
                continue
            rows.append(json.loads(s))
    return rows, blank


def _to_builtin(o):
    if isinstance(o, dict):
        return {str(k): _to_builtin(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_to_builtin(v) for v in o]
    if isinstance(o, np.ndarray):
        return [_to_builtin(v) for v in o.tolist()]
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    return o


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(_to_builtin(obj), fh, ensure_ascii=False, indent=1, allow_nan=True)
        fh.write("\n")


def read_json(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


# ----------------------------------------------------------------------------
# Student's t: 0.975 quantile computed numerically (three independent routes)
# ----------------------------------------------------------------------------
def _t_logc(nu):
    return math.lgamma((nu + 1.0) / 2.0) - math.lgamma(nu / 2.0) - 0.5 * math.log(nu * math.pi)


_GLX, _GLW = np.polynomial.legendre.leggauss(200)


def t_cdf_gl(t, nu):
    """CDF by Gauss-Legendre integration of the t density on [0, t] (t >= 0)."""
    xs = 0.5 * t * (_GLX + 1.0)
    f = np.exp(_t_logc(nu) - 0.5 * (nu + 1.0) * np.log1p(xs * xs / nu))
    return 0.5 + 0.5 * t * float(np.dot(_GLW, f))


def t_cdf_simpson(t, nu, m=200000):
    """CDF by composite Simpson integration of the t density on [0, t] (t >= 0)."""
    xs = np.linspace(0.0, t, m + 1)
    f = np.exp(_t_logc(nu) - 0.5 * (nu + 1.0) * np.log1p(xs * xs / nu))
    h = t / m
    s = f[0] + f[-1] + 4.0 * f[1:-1:2].sum() + 2.0 * f[2:-1:2].sum()
    return 0.5 + s * h / 3.0


def _betacf(a, b, x):
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    h = d
    for m in range(1, 10000):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < 1e-16:
            break
    return h


def _betai(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log1p(-x)
    bt = math.exp(lbt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def t_cdf_beta(t, nu):
    """CDF through the regularised incomplete beta function (t >= 0)."""
    x = nu / (nu + t * t)
    return 1.0 - 0.5 * _betai(nu / 2.0, 0.5, x)


def t_quantile(p, nu, cdf=t_cdf_gl):
    lo, hi = 0.0, 100.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if cdf(mid, nu) < p:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-15:
            break
    return 0.5 * (lo + hi)


_TQ_CACHE = {}


def tq975(df):
    """0.975 quantile of Student's t with df degrees of freedom (primary: Gauss-Legendre)."""
    if df not in _TQ_CACHE:
        _TQ_CACHE[df] = t_quantile(0.975, float(df), t_cdf_gl)
    return _TQ_CACHE[df]


# ----------------------------------------------------------------------------
# Summaries
# ----------------------------------------------------------------------------
def paired_summary(diffs):
    """mean, sample sd (n-1), n and two-sided pointwise 95% t interval."""
    d = np.asarray(diffs, dtype=np.float64)
    n = int(d.size)
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    half = tq975(n - 1) * sd / math.sqrt(n)
    return {"mean": m, "sd": sd, "n": n, "ci95": [m - half, m + half]}


def aggregate_participants(fits, fields):
    """
    fits: list of dicts having 'dataset', 'subject', 'condition', 'seed' and the fields.
    Returns (pm, seeds):
      pm[(dataset, subject)][condition][field] = mean over that participant's seeds
      seeds[(dataset, subject)][condition]     = sorted list of seeds
    Fields whose value is None for every seed of a participant give None.
    """
    tmp = {}
    for r in fits:
        key = (r["dataset"], r["subject"])
        tmp.setdefault(key, {}).setdefault(r["condition"], []).append(r)
    pm, seeds = {}, {}
    for key, bycond in tmp.items():
        pm[key], seeds[key] = {}, {}
        for c, rs in bycond.items():
            seeds[key][c] = sorted(r["seed"] for r in rs)
            pm[key][c] = {}
            for f in fields:
                vals = [r.get(f) for r in rs]
                if all(v is None for v in vals):
                    pm[key][c][f] = None
                elif any(v is None for v in vals):
                    raise ValueError("partly missing field %s for %s %s" % (f, key, c))
                else:
                    pm[key][c][f] = float(np.mean(np.asarray(vals, dtype=np.float64)))
    return pm, seeds


def check_design(seeds, participants, conditions, expected_seeds):
    """Return a list of problems in the participant x condition x seed design."""
    problems = []
    for p in participants:
        for c in conditions:
            s = seeds.get(p, {}).get(c)
            if s is None:
                problems.append("missing: %s %s" % (p, c))
            elif s != list(expected_seeds):
                problems.append("seeds %s for %s %s" % (s, p, c))
    return problems


def training_fit_block(pm, participants, conditions, baseline):
    """Section A for one scope. Accuracies in percent, differences in percentage points."""
    out = {}

    def col(c, f):
        return np.array([100.0 * pm[p][c][f] for p in participants], dtype=np.float64)

    for c in conditions:
        test = col(c, "acc_test")
        train = col(c, "acc_train")
        gap = train - test
        d = {
            "n_participants": len(participants),
            "test_accuracy_pct": float(test.mean()),
            "train_accuracy_pct": float(train.mean()),
            "train_minus_test_pp": float(gap.mean()),
        }
        if baseline is not None and c != baseline:
            bt = col(baseline, "acc_test")
            btr = col(baseline, "acc_train")
            bgap = btr - bt
            d["versus_" + baseline] = {
                "train_accuracy_difference_pp": paired_summary(train - btr),
                "test_accuracy_difference_pp": paired_summary(test - bt),
                "gap_difference_pp": paired_summary(gap - bgap),
            }
        out[c] = d
    return out


def versus_only_block(pm, participants, conditions, baseline):
    """Only the paired differences against `baseline` (used for the 'versus W0' tables)."""
    full = training_fit_block(pm, participants, [baseline] + list(conditions), baseline)
    return {c: {"n_participants": full[c]["n_participants"],
                "versus_" + baseline: full[c]["versus_" + baseline]} for c in conditions}


# ----------------------------------------------------------------------------
# Section B: gate
# ----------------------------------------------------------------------------
def gate_summary(lists):
    """lists: one list (phases 0..9) per W2 fit; entry 0 is None."""
    problems = []
    for i, l in enumerate(lists):
        if len(l) != 10:
            problems.append("fit %d: length %d" % (i, len(l)))
        if l[0] is not None:
            problems.append("fit %d: entry 0 is not null (%r)" % (i, l[0]))
        if any(v is None for v in l[1:]):
            problems.append("fit %d: null among phases 1..9" % i)
    arr = np.array([[np.nan if v is None else float(v) for v in l] for l in lists], dtype=np.float64)
    by_phase = []
    for p in range(1, 10):
        colv = arr[:, p]
        by_phase.append({
            "phase": p,
            "open_fraction_mean": float(colv.mean()),
            "open_fraction_min": float(colv.min()),
            "fits_with_all_open": int((colv == 1.0).sum()),
            "fits": int(colv.size),
        })
    num, den = 0.0, 0.0
    for p in range(2, 10):
        w = 0.03 * (p - 1)
        num += w * (1.0 - by_phase[p - 1]["open_fraction_mean"])
        den += w
    return {"by_phase": by_phase, "rate_weighted_closed_share": num / den,
            "n_fits": int(arr.shape[0]), "problems": problems}


# ----------------------------------------------------------------------------
# Sections C and D: code words, decision rules, confidence measures
# ----------------------------------------------------------------------------
def walsh_matrix(n=16):
    """M1 = [1]; M_{2n} = [[M_n, M_n], [M_n, 1 - M_n]]."""
    M = np.array([[1]], dtype=np.int64)
    while M.shape[0] < n:
        M = np.block([[M, M], [M, 1 - M]])
    if M.shape[0] != n:
        raise ValueError("n must be a power of two")
    return M


CODE16 = walsh_matrix(16)


def rule1_nearest(P, K):
    """Rule 1: float64 cast, smallest squared Euclidean distance to rows 0..K-1, first index on ties."""
    P64 = np.asarray(P).astype(np.float64)
    C = CODE16[:K].astype(np.float64)
    d2 = ((P64[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
    return d2.argmin(axis=1), d2


def rule2_scores(P, K, clip_in_float32=False):
    """
    Rule 2 class scores: clip outputs to [1e-7, 1 - 1e-7];
    score_k = sum_j [ c_kj*log(p_j) + (1 - c_kj)*log(1 - p_j) ].
    Primary reading: cast to float64 first, then clip (clip_in_float32=False).
    Diagnostic alternative: clip in float32 with float32 bounds, then cast to float64.
    """
    if clip_in_float32:
        P32 = np.asarray(P).astype(np.float32)
        Pc = np.clip(P32, np.float32(1e-7), np.float32(1.0) - np.float32(1e-7)).astype(np.float64)
    else:
        P64 = np.asarray(P).astype(np.float64)
        Pc = np.clip(P64, 1e-7, 1.0 - 1e-7)
    C = CODE16[:K].astype(np.float64)
    lp = np.log(Pc)
    l1p = np.log(1.0 - Pc)
    return lp @ C.T + l1p @ (1.0 - C).T


def softmax_rows(S):
    m = S.max(axis=1, keepdims=True)
    e = np.exp(S - m)
    return e / e.sum(axis=1, keepdims=True)


BIN_EDGES_15 = np.linspace(0.0, 1.0, 16)


def nll_of(post, y):
    pt = post[np.arange(post.shape[0]), y]
    return float(-np.mean(np.log(np.maximum(pt, 1e-12))))


def ece15_of(post, y, edges=BIN_EDGES_15):
    conf = post.max(axis=1)
    pred = post.argmax(axis=1)
    corr = (pred == y).astype(np.float64)
    n = conf.shape[0]
    total = 0.0
    counted = 0
    for b in range(15):
        lo, hi = edges[b], edges[b + 1]
        if b == 0:
            m = (conf >= lo) & (conf <= hi)
        else:
            m = (conf > lo) & (conf <= hi)
        nb = int(m.sum())
        counted += nb
        if nb > 0:
            total += (nb / n) * abs(float(corr[m].mean()) - float(conf[m].mean()))
    if counted != n:
        raise ValueError("ECE binning lost trials: %d of %d" % (counted, n))
    return float(total)


def brier_of(post, y):
    onehot = np.zeros_like(post)
    onehot[np.arange(post.shape[0]), y] = 1.0
    return float(np.mean(((post - onehot) ** 2).sum(axis=1)))


def edge_proximity(post, edges=BIN_EDGES_15):
    """Smallest distance of any confidence value to an interior bin edge."""
    conf = post.max(axis=1)
    return float(np.min(np.abs(conf[:, None] - edges[None, 1:-1])))
