# -*- coding: utf-8 -*-
"""
Step 5 - self-tests of the helper functions and merge of the partial results
into bagimsiz_sonuclar.json (the independent results).
The analyst's files are NOT read here.
"""
import os
import sys
import math
import time
import platform
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

# ------------------------------------------------------------------ self-tests
tests = {}

# (a) Student t: closed forms for 1 and 2 degrees of freedom
tests["t_quantile_df1_error"] = abs(bk.t_quantile(0.975, 1.0, bk.t_cdf_beta) - math.tan(math.pi * 0.475))
u = 0.95
tests["t_quantile_df2_error"] = abs(bk.t_quantile(0.975, 2.0, bk.t_cdf_gl) - math.sqrt(2 * u * u / (1 - u * u)))
spread = {}
for df in (8, 13, 31, 53):
    v = [bk.t_quantile(0.975, float(df), f) for f in (bk.t_cdf_gl, bk.t_cdf_simpson, bk.t_cdf_beta)]
    spread[str(df)] = max(v) - min(v)
    # the quantile must put 0.975 of the mass below it
    assert abs(bk.t_cdf_beta(bk.tq975(df), float(df)) - 0.975) < 1e-13
tests["t_quantile_spread_between_three_methods"] = spread
assert tests["t_quantile_df1_error"] < 1e-9 and tests["t_quantile_df2_error"] < 1e-11
assert max(spread.values()) < 1e-11

# (b) code words
M = bk.CODE16
assert M.shape == (16, 16) and set(np.unique(M)) == {0, 1}
assert (M[0] == 1).all() and (M[1] == np.tile([1, 0], 8)).all()
assert (M[2] == np.tile([1, 1, 0, 0], 4)).all() and (M[3] == np.tile([1, 0, 0, 1], 4)).all()
# +-1 version is a Hadamard matrix: rows mutually orthogonal
H = 2 * M - 1
assert (H @ H.T == 16 * np.eye(16, dtype=int)).all()
tests["code_matrix_rows_0_to_3"] = M[:4].tolist()

# (c) decision rules: exact code words give their own class under both rules (K = 4 and K = 2)
for K in (2, 4):
    Pcw = M[:K].astype(np.float32)
    p1, _ = bk.rule1_nearest(Pcw, K)
    p2 = bk.rule2_scores(Pcw, K).argmax(axis=1)
    assert list(p1) == list(range(K)) and list(p2) == list(range(K))
# a constructed trial on which the two rules must differ (K = 2):
# discriminating outputs (odd positions) = one very confident "class 0" value and seven weak "class 1" values
x = np.full(16, 0.99, dtype=np.float32)
x[1::2] = [0.99999, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4]
p1, _ = bk.rule1_nearest(x[None, :], 2)
p2 = bk.rule2_scores(x[None, :], 2).argmax(axis=1)
tests["constructed_trial_rule1_class"] = int(p1[0])
tests["constructed_trial_rule2_class"] = int(p2[0])
assert p1[0] == 1 and p2[0] == 0
# ties -> first index
tie = np.full((1, 16), 0.5, dtype=np.float32)
assert bk.rule1_nearest(tie, 4)[0][0] == 0 and bk.rule2_scores(tie, 4).argmax(axis=1)[0] == 0

# (d) NLL / ECE / Brier against hand-computed values
post = np.array([[0.9, 0.1], [0.62, 0.38], [0.3, 0.7], [0.55, 0.45]])
y = np.array([0, 1, 1, 0])
tests["nll_hand_example_error"] = abs(bk.nll_of(post, y) - (-(math.log(0.9) + math.log(0.38) + math.log(0.7) + math.log(0.55)) / 4))
tests["ece_hand_example_error"] = abs(bk.ece15_of(post, y) - 0.25 * (0.1 + 0.62 + 0.3 + 0.45))
tests["brier_hand_example_error"] = abs(bk.brier_of(post, y) - (0.02 + 0.7688 + 0.18 + 0.405) / 4)
post5 = np.vstack([post, [0.57, 0.43]])
y5 = np.array([0, 1, 1, 0, 1])
tests["ece_two_trials_in_one_bin_error"] = abs(bk.ece15_of(post5, y5) - ((0.1 + 0.62 + 0.3) / 5 + (2 / 5) * abs(0.5 - 0.56)))
# floor of the true-class posterior
assert abs(bk.nll_of(np.array([[1.0, 0.0]]), np.array([1])) - (-math.log(1e-12))) < 1e-12
for k in ("nll_hand_example_error", "ece_hand_example_error", "brier_hand_example_error", "ece_two_trials_in_one_bin_error"):
    assert tests[k] < 1e-12, k
# bins: first bin closed on both sides, others open on the left / closed on the right
e = bk.BIN_EDGES_15
assert bk.ece15_of(np.array([[e[8], 1 - e[8]]]), np.array([0])) == abs(1.0 - e[8])
tests["all_self_tests_passed"] = True

# ------------------------------------------------------------------ merge
p1 = bk.read_json(os.path.join(bk.OUT, "parca_adim1_A_B_e1_e2.json"))
p2 = bk.read_json(os.path.join(bk.OUT, "parca_adim2_C_e2.json"))
p3 = bk.read_json(os.path.join(bk.OUT, "parca_adim3_A_B_E_lee.json"))
p4 = bk.read_json(os.path.join(bk.OUT, "parca_adim4_C_D_lee.json"))

# section E from the records (step 3) must equal the displacement recomputed in step 4
for c, v in p3["E_displacement_by_condition"].items():
    w = p4["D_E_lee2019_confidence"]["by_condition"][c]["displacement"]
    assert (v is None and w is None) or abs(v - w) < 1e-15, c
for c, v in p3["recorded_metrics_by_condition"].items():
    assert abs(v["acc_recorded"] - p4["D_E_lee2019_confidence"]["by_condition"][c]["acc"]) < 1e-15, c

A = {}
A.update(p1["A_training_fit"])
A.update(p3["A_training_fit"])
B = {"experiment2": {ds: {k: v for k, v in blk.items() if k in ("by_phase", "rate_weighted_closed_share", "n_fits")}
                     for ds, blk in p1["B_gate_open"]["experiment2"].items()},
     "lee2019": {k: v for k, v in p3["B_gate_open"]["lee2019"].items() if k in ("by_phase", "rate_weighted_closed_share", "n_fits")}}
C = {"experiment2": p2["C_decision_rule_agreement"]["experiment2"],
     "lee2019": p4["C_decision_rule_agreement"]["lee2019"]}
D = p4["D_E_lee2019_confidence"]

out = {
    "meta": {
        "what": "Independent recomputation (bagimsiz kontrol) of the descriptive numbers, from the raw records only.",
        "independence": "Own code written from the written definitions; the analyst's script was never opened; "
                        "the analyst's result file was not opened before this file was saved.",
        "created_local_time": time.strftime("%Y-%m-%d %H:%M:%S %z"),
        "python": platform.python_version(), "numpy": np.__version__, "platform": platform.platform(),
        "scripts": ["bk_common.py", "adim1_e1_e2_kayitlar.py", "adim2_e2_npz.py", "adim3_lee_kayitlar.py",
                    "adim4_lee_npz.py", "adim5_birlestir.py"],
        "conventions": {
            "unit": "participant = (dataset, subject); seeds averaged first, then participants",
            "accuracy": "percent in section A; fraction in section D ('acc')",
            "paired_difference": "condition minus baseline, per participant, in percentage points",
            "sd": "sample standard deviation over participants (denominator n-1)",
            "ci95": "mean -/+ t(0.975, n-1) * sd / sqrt(n); t quantile computed numerically (see t_quantiles_0975)",
            "gate_mean": "plain mean over W2 fits (equals the participant-first mean; balanced design)",
            "rule2_precision": "outputs cast to float64, then clipped to [1e-7, 1-1e-7] (primary reading)",
            "ece_bin_edges": "numpy.linspace(0, 1, 16)",
            "section_D_acc": "recorded acc_test (identical to rule-1 and to most-probable-class accuracy in every fit)",
        },
    },
    "t_quantiles_0975": p1["t_quantiles_0975"],
    "t_quantiles_0975_crosscheck": p1["t_quantiles_0975_crosscheck"],
    "A_training_fit": A,
    "B_gate_open": B,
    "C_decision_rule_agreement": C,
    "D_E_lee2019_confidence": D,
    "D_sensitivity_clip_in_float32": p4["D_sensitivity_clip_in_float32"],
    "self_tests": tests,
    "raw_data_checks": {
        "experiment1_and_2_records": p1["notes"],
        "experiment2_outputs": p2["notes"],
        "lee2019_records": {k: v for k, v in p3["notes"].items() if k != "subject_ids"},
        "lee2019_outputs": p4["notes"],
    },
}
dst = os.path.join(bk.OUT, "bagimsiz_sonuclar.json")
bk.write_json(dst, out)
print("self-tests:", tests)
print("written:", dst, os.path.getsize(dst), "bytes")


def count_numbers(o):
    if isinstance(o, dict):
        return sum(count_numbers(v) for v in o.values())
    if isinstance(o, list):
        return sum(count_numbers(v) for v in o)
    return 1 if isinstance(o, (int, float)) and not isinstance(o, bool) else 0


for k in ("A_training_fit", "B_gate_open", "C_decision_rule_agreement", "D_E_lee2019_confidence"):
    print(k, "numbers:", count_numbers(out[k]))
