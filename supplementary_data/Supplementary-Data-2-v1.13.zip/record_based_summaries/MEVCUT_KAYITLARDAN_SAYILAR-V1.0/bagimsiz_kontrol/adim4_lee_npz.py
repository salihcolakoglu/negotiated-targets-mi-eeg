# -*- coding: utf-8 -*-
"""
Step 4 - Lee2019 (S0, W0..W3 from E3, plus W4): sections C and D from the saved
test outputs of every fit. Uses lee_fit_tablosu.json written by step 3.
Output: parca_adim4_C_D_lee.json  (summary + one line per fit)
"""
import os
import sys
import time
import hashlib
import collections
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

t0 = time.time()
fits = bk.read_json(os.path.join(bk.OUT, "lee_fit_tablosu.json"))
CONDS = ["S0", "W0", "W1", "W2", "W3", "W4"]
WALSH = ["W0", "W1", "W2", "W3", "W4"]
K = 2
per_fit = []
problems = []
sha_mismatch = collections.Counter()
edges_alt = np.arange(16, dtype=np.float64) / 15.0   # i/15 written the other way (sensitivity only)

for f in fits:
    path = f["prediction_path"]
    with open(path, "rb") as fh:
        raw = fh.read()
    if hashlib.sha256(raw).hexdigest() != f["prediction_sha256"]:
        sha_mismatch[f["source"]] += 1
    with np.load(path) as z:
        Pt = z[f["key_P"]]
        y = z[f["key_y"]]
    N = int(y.shape[0])
    row = {"source": f["source"], "dataset": "Lee2019", "subject": f["subject"],
           "condition": f["condition"], "seed": f["seed"], "trials": N,
           "acc_test_recorded": f["acc_test"], "nll_test_recorded": f["nll_test"],
           "ece_test_recorded": f["ece_test"], "last_target_dist": f["last_target_dist"]}
    if y.dtype != np.int64 or y.shape != (f["n_test"],) or y.min() < 0 or y.max() >= K or Pt.dtype != np.float32:
        problems.append("labels/dtype: %s" % os.path.basename(path))

    if f["condition"] == "S0":
        if Pt.shape != (f["n_test"], 2):
            problems.append("S0 shape %s %s" % (os.path.basename(path), Pt.shape))
        post = Pt.astype(np.float64)
        row["s0_max_abs_rowsum_minus_1"] = float(np.max(np.abs(post.sum(axis=1) - 1.0)))
        pred = post.argmax(axis=1)
        row.update({
            "acc_posterior_argmax": float(np.mean(pred == y)),
            "pred_equals_recorded_pred_test": bool(list(map(int, pred)) == list(f["pred_test"])),
            "nll": bk.nll_of(post, y), "ece15": bk.ece15_of(post, y), "brier": bk.brier_of(post, y),
            "nll_div8": None, "ece15_div8": None, "brier_div8": None,
            "ece15_alt_edges": bk.ece15_of(post, y, edges_alt),
            "edge_distance": bk.edge_proximity(post),
            "true_class_posterior_below_1e-12": int(np.sum(post[np.arange(N), y] < 1e-12)),
        })
    else:
        if Pt.shape != (f["n_test"], 16):
            problems.append("Walsh shape %s %s" % (os.path.basename(path), Pt.shape))
        pred1, d2 = bk.rule1_nearest(Pt, K)
        S = bk.rule2_scores(Pt, K)
        pred2 = S.argmax(axis=1)
        post = bk.softmax_rows(S)
        post8 = bk.softmax_rows(S / 8.0)
        S32 = bk.rule2_scores(Pt, K, clip_in_float32=True)
        post32 = bk.softmax_rows(S32)
        post32_8 = bk.softmax_rows(S32 / 8.0)
        P64 = Pt.astype(np.float64)
        acc1 = float(np.mean(pred1 == y))
        row.update({
            "disagreements": int(np.sum(pred1 != pred2)),
            "disagreements_if_clip_in_float32": int(np.sum(pred1 != S32.argmax(axis=1))),
            "acc_rule1": acc1,
            "acc_rule1_minus_recorded": acc1 - f["acc_test"],
            "acc_posterior_argmax": float(np.mean(post.argmax(axis=1) == y)),
            "pred_equals_recorded_pred_test": bool(list(map(int, pred1)) == list(f["pred_test"])),
            "nll": bk.nll_of(post, y), "ece15": bk.ece15_of(post, y), "brier": bk.brier_of(post, y),
            "nll_div8": bk.nll_of(post8, y), "ece15_div8": bk.ece15_of(post8, y), "brier_div8": bk.brier_of(post8, y),
            "nll_if_clip_in_float32": bk.nll_of(post32, y),
            "ece15_if_clip_in_float32": bk.ece15_of(post32, y),
            "brier_if_clip_in_float32": bk.brier_of(post32, y),
            "nll_div8_if_clip_in_float32": bk.nll_of(post32_8, y),
            "ece15_div8_if_clip_in_float32": bk.ece15_of(post32_8, y),
            "brier_div8_if_clip_in_float32": bk.brier_of(post32_8, y),
            "ece15_alt_edges": bk.ece15_of(post, y, edges_alt),
            "ece15_div8_alt_edges": bk.ece15_of(post8, y, edges_alt),
            "edge_distance": bk.edge_proximity(post),
            "edge_distance_div8": bk.edge_proximity(post8),
            "true_class_posterior_below_1e-12": int(np.sum(post[np.arange(N), y] < 1e-12)),
            "true_class_posterior_below_1e-12_div8": int(np.sum(post8[np.arange(N), y] < 1e-12)),
            "outputs_below_1e-7": int(np.sum(P64 < 1e-7)),
            "outputs_above_1_minus_1e-7": int(np.sum(P64 > 1.0 - 1e-7)),
            "outputs_not_finite_or_outside_0_1": int(np.sum(~np.isfinite(P64) | (P64 < 0) | (P64 > 1))),
            "min_gap_rule1": float(np.min(np.abs(d2[:, 0] - d2[:, 1]))),
            "min_gap_rule2": float(np.min(np.abs(S[:, 0] - S[:, 1]))),
            "argmax_changes_after_div8": int(np.sum(post.argmax(axis=1) != post8.argmax(axis=1))),
        })
    row["nll_minus_recorded"] = row["nll"] - f["nll_test"]
    row["ece_minus_recorded"] = row["ece15"] - f["ece_test"]
    per_fit.append(row)

# ------------------------------------------------------------------ section C
C = {}
for c in WALSH:
    fs = [r for r in per_fit if r["condition"] == c]
    C[c] = {"trials": int(sum(r["trials"] for r in fs)),
            "disagreements": int(sum(r["disagreements"] for r in fs)),
            "fits": len(fs),
            "fits_with_any_disagreement": int(sum(1 for r in fs if r["disagreements"] > 0))}

# ------------------------------------------------------------------ section D (participant first)
fields = ["acc_test_recorded", "acc_posterior_argmax", "nll", "ece15", "brier",
          "nll_div8", "ece15_div8", "brier_div8", "last_target_dist",
          "nll_test_recorded", "ece_test_recorded"]
alt_fields = ["nll_if_clip_in_float32", "ece15_if_clip_in_float32", "brier_if_clip_in_float32",
              "nll_div8_if_clip_in_float32", "ece15_div8_if_clip_in_float32", "brier_div8_if_clip_in_float32"]
pm, seeds = bk.aggregate_participants(per_fit, fields + alt_fields)
parts = sorted(pm.keys())
design = bk.check_design(seeds, parts, CONDS, [1, 2, 3, 4, 5])


def pmean(c, f):
    vals = [pm[p][c][f] for p in parts]
    if all(v is None for v in vals):
        return None
    return float(np.mean(np.asarray(vals, dtype=np.float64)))


D = {}
for c in CONDS:
    D[c] = {
        "acc": pmean(c, "acc_test_recorded"),
        "acc_posterior_argmax": pmean(c, "acc_posterior_argmax"),
        "nll": pmean(c, "nll"), "ece15": pmean(c, "ece15"), "brier": pmean(c, "brier"),
        "displacement": pmean(c, "last_target_dist"),
        "nll_div8": pmean(c, "nll_div8"), "ece15_div8": pmean(c, "ece15_div8"), "brier_div8": pmean(c, "brier_div8"),
        "nll_recorded_mean": pmean(c, "nll_test_recorded"), "ece_recorded_mean": pmean(c, "ece_test_recorded"),
        "n_participants": len(parts), "fits": sum(1 for r in per_fit if r["condition"] == c),
    }

# sensitivity: same measures if the clip is done in float32 (bounds rounded to float32) - NOT the primary reading
D_alt = {}
for c in WALSH:
    D_alt[c] = {"nll": pmean(c, "nll_if_clip_in_float32"), "ece15": pmean(c, "ece15_if_clip_in_float32"),
                "brier": pmean(c, "brier_if_clip_in_float32"),
                "nll_div8": pmean(c, "nll_div8_if_clip_in_float32"),
                "ece15_div8": pmean(c, "ece15_div8_if_clip_in_float32"),
                "brier_div8": pmean(c, "brier_div8_if_clip_in_float32")}
    D_alt[c]["difference_from_primary"] = {k: D_alt[c][k] - D[c][k] for k in ("nll", "ece15", "brier", "nll_div8", "ece15_div8", "brier_div8")}

# ------------------------------------------------------------------ verification notes
notes = collections.OrderedDict()
walsh_rows = [r for r in per_fit if r["condition"] != "S0"]
s0_rows = [r for r in per_fit if r["condition"] == "S0"]
notes["fits_processed"] = len(per_fit)
notes["participants"] = len(parts)
notes["design_problems"] = design
notes["file_problems"] = problems
notes["prediction_sha256_mismatches"] = dict(sha_mismatch)
notes["rule1_accuracy_vs_recorded_max_abs_diff"] = max(abs(r["acc_rule1_minus_recorded"]) for r in walsh_rows)
notes["rule1_accuracy_fits_differing_beyond_1e-12"] = sum(1 for r in walsh_rows if abs(r["acc_rule1_minus_recorded"]) > 1e-12)
notes["rule1_accuracy_fits_bitwise_equal"] = sum(1 for r in walsh_rows if r["acc_rule1"] == r["acc_test_recorded"])
notes["walsh_fits"] = len(walsh_rows)
notes["rule1_predictions_equal_recorded_pred_test_fits"] = sum(1 for r in walsh_rows if r["pred_equals_recorded_pred_test"])
notes["s0_fits"] = len(s0_rows)
notes["s0_argmax_accuracy_differs_from_recorded"] = sum(1 for r in s0_rows if abs(r["acc_posterior_argmax"] - r["acc_test_recorded"]) > 1e-12)
notes["s0_predictions_equal_recorded_pred_test_fits"] = sum(1 for r in s0_rows if r["pred_equals_recorded_pred_test"])
notes["s0_max_abs_rowsum_minus_1"] = max(r["s0_max_abs_rowsum_minus_1"] for r in s0_rows)
ver = {}
for c in CONDS:
    fs = [r for r in per_fit if r["condition"] == c]
    ver[c] = {
        "fits": len(fs),
        "nll_max_abs_diff": max(abs(r["nll_minus_recorded"]) for r in fs),
        "nll_fits_beyond_1e-9": sum(1 for r in fs if abs(r["nll_minus_recorded"]) > 1e-9),
        "ece_max_abs_diff": max(abs(r["ece_minus_recorded"]) for r in fs),
        "ece_fits_beyond_1e-9": sum(1 for r in fs if abs(r["ece_minus_recorded"]) > 1e-9),
    }
    if c != "S0":
        ver[c]["nll_max_abs_diff_if_clip_in_float32"] = max(abs(r["nll_if_clip_in_float32"] - r["nll_test_recorded"]) for r in fs)
        ver[c]["nll_fits_beyond_1e-9_if_clip_in_float32"] = sum(1 for r in fs if abs(r["nll_if_clip_in_float32"] - r["nll_test_recorded"]) > 1e-9)
        ver[c]["ece_max_abs_diff_if_clip_in_float32"] = max(abs(r["ece15_if_clip_in_float32"] - r["ece_test_recorded"]) for r in fs)
        ver[c]["outputs_below_1e-7"] = sum(r["outputs_below_1e-7"] for r in fs)
        ver[c]["outputs_above_1_minus_1e-7"] = sum(r["outputs_above_1_minus_1e-7"] for r in fs)
        ver[c]["trials_true_class_posterior_floored_at_1e-12"] = sum(r["true_class_posterior_below_1e-12"] for r in fs)
        ver[c]["trials_true_class_posterior_floored_at_1e-12_div8"] = sum(r["true_class_posterior_below_1e-12_div8"] for r in fs)
        ver[c]["disagreements_if_clip_in_float32"] = sum(r["disagreements_if_clip_in_float32"] for r in fs)
        ver[c]["smallest_gap_rule1"] = min(r["min_gap_rule1"] for r in fs)
        ver[c]["smallest_gap_rule2"] = min(r["min_gap_rule2"] for r in fs)
        ver[c]["argmax_changes_after_div8"] = sum(r["argmax_changes_after_div8"] for r in fs)
        ver[c]["ece_div8_changes_with_other_edge_spelling"] = sum(1 for r in fs if r["ece15_div8"] != r["ece15_div8_alt_edges"])
        ver[c]["smallest_distance_to_bin_edge_div8"] = min(r["edge_distance_div8"] for r in fs)
    else:
        ver[c]["trials_true_class_posterior_floored_at_1e-12"] = sum(r["true_class_posterior_below_1e-12"] for r in fs)
    ver[c]["ece_changes_with_other_edge_spelling"] = sum(1 for r in fs if r["ece15"] != r["ece15_alt_edges"])
    ver[c]["smallest_distance_to_bin_edge"] = min(r["edge_distance"] for r in fs)
notes["verification_by_condition"] = ver
notes["nll_max_abs_diff_all_fits"] = max(abs(r["nll_minus_recorded"]) for r in per_fit)
notes["ece_max_abs_diff_all_fits"] = max(abs(r["ece_minus_recorded"]) for r in per_fit)
notes["nll_fits_beyond_1e-9_all"] = sum(1 for r in per_fit if abs(r["nll_minus_recorded"]) > 1e-9)
notes["ece_fits_beyond_1e-9_all"] = sum(1 for r in per_fit if abs(r["ece_minus_recorded"]) > 1e-9)
notes["seconds"] = round(time.time() - t0, 1)

bk.write_json(os.path.join(bk.OUT, "parca_adim4_C_D_lee.json"), {
    "C_decision_rule_agreement": {"lee2019": C},
    "D_E_lee2019_confidence": {"by_condition": D},
    "D_sensitivity_clip_in_float32": D_alt,
    "notes": notes,
    "per_fit": per_fit,
})

import json
print(json.dumps(notes, indent=1))
for c in C:
    print("C", c, C[c])
for c in D:
    print("D", c, json.dumps(D[c]))
for c in D_alt:
    print("D_alt(float32 clip) minus primary", c, json.dumps(D_alt[c]["difference_from_primary"]))
