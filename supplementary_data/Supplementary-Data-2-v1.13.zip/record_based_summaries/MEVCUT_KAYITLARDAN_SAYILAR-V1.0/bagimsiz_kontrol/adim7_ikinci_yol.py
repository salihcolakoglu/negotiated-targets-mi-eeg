# -*- coding: utf-8 -*-
"""
Step 7 - second-route check of MY OWN numbers (double check, not a comparison with the analyst):
sections A, B, E and the aggregation of D are recomputed with pandas pivot tables, straight
from the raw records, with the t quantile from a different numerical method (incomplete beta
instead of Gauss-Legendre integration). Result is compared with bagimsiz_sonuclar.json.
Output: ikinci_yol_kontrolu.json
"""
import os
import sys
import glob
import json
import math
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

mine = bk.read_json(os.path.join(bk.OUT, "bagimsiz_sonuclar.json"))
diffs = {}


def tq(df):
    return bk.t_quantile(0.975, float(df), bk.t_cdf_beta)


def check(section, path, mine_value, value):
    d = abs(mine_value - value)
    diffs.setdefault(section, []).append(d)
    if d > 1e-9:
        print("DIFFERENCE", section, path, mine_value, value)


def section_a(df, name, scope_name, conds, baseline, mine_block, mine_vs_block=None, vs_base=None, vs_conds=()):
    # df: columns subject, condition, seed, acc_test, acc_train  (one dataset or the pool with 'pid')
    g = df.groupby(["pid", "condition"])[["acc_test", "acc_train"]].mean() * 100.0
    test = g["acc_test"].unstack("condition")
    train = g["acc_train"].unstack("condition")
    gap = train - test
    n = test.shape[0]
    for c in conds:
        mb = mine_block[scope_name][c]
        check(name, (scope_name, c, "n"), mb["n_participants"], n)
        check(name, (scope_name, c, "test"), mb["test_accuracy_pct"], test[c].mean())
        check(name, (scope_name, c, "train"), mb["train_accuracy_pct"], train[c].mean())
        check(name, (scope_name, c, "gap"), mb["train_minus_test_pp"], gap[c].mean())
    pairs = [(c, baseline, mine_block) for c in conds if c != baseline]
    if mine_vs_block is not None:
        pairs += [(c, vs_base, mine_vs_block) for c in vs_conds]
    for c, b, blk in pairs:
        for key, tab in (("train_accuracy_difference_pp", train), ("test_accuracy_difference_pp", test), ("gap_difference_pp", gap)):
            d = tab[c] - tab[b]
            m_, sd_ = d.mean(), d.std()            # pandas std: denominator n-1
            half = tq(n - 1) * sd_ / math.sqrt(n)
            mv = blk[scope_name][c]["versus_" + b][key]
            check(name, (scope_name, c, b, key, "mean"), mv["mean"], m_)
            check(name, (scope_name, c, b, key, "sd"), mv["sd"], sd_)
            check(name, (scope_name, c, b, key, "n"), mv["n"], n)
            check(name, (scope_name, c, b, key, "lo"), mv["ci95"][0], m_ - half)
            check(name, (scope_name, c, b, key, "hi"), mv["ci95"][1], m_ + half)


# ------------------------------------------------------------------ E1
e1 = pd.read_json(bk.E1_FILE, lines=True)
e1 = e1[e1["code"] == "K1"].copy()
e1["pid"] = e1["dataset"] + "_" + e1["subject"].astype(str)
A = mine["A_training_fit"]
for ds in ("D1", "D3", "D4"):
    section_a(e1[e1["dataset"] == ds], "A_E1", ds, ["C0", "C1", "C2", "C3", "C4"], "C0", A["experiment1_CSP_CNN_K1"])
section_a(e1, "A_E1", "pooled_participants", ["C0", "C1", "C2", "C3", "C4"], "C0", A["experiment1_CSP_CNN_K1"])

# ------------------------------------------------------------------ E2
rows = []
with open(bk.E2_FILE, encoding="utf-8") as fh:
    for line in fh:
        if line.strip():
            r = json.loads(line)
            rows.append({k: r.get(k) for k in ("dataset", "subject", "condition", "seed", "acc_test", "acc_train", "used_gate_open_by_phase")})
e2 = pd.DataFrame(rows)
e2["pid"] = e2["dataset"] + "_" + e2["subject"].astype(str)
W = ["S0", "W0", "W1", "W2", "W3"]
for ds in ("D1", "D3", "D4"):
    section_a(e2[e2["dataset"] == ds], "A_E2", ds, W, "S0", A["experiment2_EEGNet"],
              A["experiment2_EEGNet_walsh_versus_W0"], "W0", ["W1", "W2", "W3"])
section_a(e2, "A_E2", "pooled_participants", W, "S0", A["experiment2_EEGNet"],
          A["experiment2_EEGNet_walsh_versus_W0"], "W0", ["W1", "W2", "W3"])


def section_b(lists, mine_blk, name):
    g = pd.DataFrame(lists, columns=["p%d" % i for i in range(10)]).astype(float)
    num = den = 0.0
    for p in range(1, 10):
        col = g["p%d" % p]
        mb = mine_blk["by_phase"][p - 1]
        assert mb["phase"] == p
        check(name, (p, "mean"), mb["open_fraction_mean"], col.sum() / len(col))
        check(name, (p, "min"), mb["open_fraction_min"], col.min())
        check(name, (p, "all_open"), mb["fits_with_all_open"], int((col >= 1.0).sum()))
        check(name, (p, "fits"), mb["fits"], len(col))
        if p >= 2:
            num += 0.03 * (p - 1) * (1.0 - col.sum() / len(col))
            den += 0.03 * (p - 1)
    check(name, ("closed_share",), mine_blk["rate_weighted_closed_share"], num / den)


for ds in ("D1", "D3", "D4"):
    sub = e2[(e2["dataset"] == ds) & (e2["condition"] == "W2")]
    section_b(list(sub["used_gate_open_by_phase"]), mine["B_gate_open"]["experiment2"][ds], "B_E2")

# ------------------------------------------------------------------ Lee2019 (E3 + W4), raw records again
rows = []
for f in sorted(glob.glob(os.path.join(bk.E3_DIR, "records", "*.json"))):
    r = bk.read_json(f)
    rows.append({"subject": r["identity"]["subject"], "condition": r["identity"]["condition"], "seed": r["identity"]["seed"],
                 "acc_test": r["acc_test"], "acc_train": r["acc_train"], "last_target_dist": r.get("last_target_dist"),
                 "gate": r.get("used_gate_open_by_phase")})
for f in sorted(glob.glob(os.path.join(bk.W4_DIR, "fit_records", "*.json"))):
    r = bk.read_json(f)
    t = bk.read_json(os.path.join(bk.W4_DIR, "test_records", os.path.basename(f)[:-5] + "_day2.json"))
    rows.append({"subject": r["subject"], "condition": "W4", "seed": r["seed"], "acc_test": t["acc_test"],
                 "acc_train": r["acc_train"], "last_target_dist": r.get("last_target_dist"), "gate": None})
lee = pd.DataFrame(rows)
lee["pid"] = lee["subject"]
WL = ["S0", "W0", "W1", "W2", "W3", "W4"]
section_a(lee, "A_Lee", "Lee2019", WL, "S0", A["lee2019_EEGNet"], A["lee2019_EEGNet_walsh_versus_W0"], "W0", ["W1", "W2", "W3", "W4"])
section_b(list(lee[lee["condition"] == "W2"]["gate"]), mine["B_gate_open"]["lee2019"], "B_Lee")
disp = lee[lee["condition"] != "S0"].groupby(["condition", "pid"])["last_target_dist"].mean().groupby("condition").mean()
D = mine["D_E_lee2019_confidence"]["by_condition"]
for c in WL[1:]:
    check("E_displacement", (c,), D[c]["displacement"], disp[c])

# ------------------------------------------------------------------ D: aggregation of my per-fit measures with pandas
pf = pd.DataFrame(bk.read_json(os.path.join(bk.OUT, "parca_adim4_C_D_lee.json"))["per_fit"])
for key, col in (("acc", "acc_test_recorded"), ("nll", "nll"), ("ece15", "ece15"), ("brier", "brier"),
                 ("nll_div8", "nll_div8"), ("ece15_div8", "ece15_div8"), ("brier_div8", "brier_div8")):
    agg = pf.groupby(["condition", "subject"])[col].mean().groupby("condition").mean()
    for c in WL:
        if D[c][key] is None:
            assert pf[pf["condition"] == c][col].isna().all()
            continue
        check("D_aggregation", (c, key), D[c][key], agg[c])

summary = {k: {"numbers_rechecked": len(v), "largest_abs_diff": float(max(v)), "beyond_1e-9": int(sum(1 for x in v if x > 1e-9))}
           for k, v in diffs.items()}
summary["total_numbers_rechecked"] = int(sum(len(v) for v in diffs.values()))
summary["total_beyond_1e-9"] = int(sum(1 for v in diffs.values() for x in v if x > 1e-9))
bk.write_json(os.path.join(bk.OUT, "ikinci_yol_kontrolu.json"), summary)
print(json.dumps(summary, indent=1))
