# KARSILASTIRMA - independent check of the numbers in SAYILAR-V1.0.json

**Kısa özet (Türkçe).** Analistin `SAYILAR-V1.0.json` dosyasındaki bütün sayılar, ham deney kayıtlarından, yalnızca yazılı tanımlara bakılarak sıfırdan yazılan ayrı bir kodla yeniden hesaplandı. Karşılaştırılan 1.473 sayının tamamı tolerans içinde aynı çıktı; en büyük fark 4,3 × 10⁻¹⁴ düzeyinde, yani yalnızca bilgisayarın yuvarlama farkı. Tolerans dışında kalan tek bir sayı yok: **analistin sayıları doğrulandı.** Analistin betiği hiç açılmadı; analistin sonuç dosyası ancak bağımsız sonuçlar diske kaydedildikten sonra açıldı. Ham kayıtlarda eksik ya da çift kayıt bulunmadı. Sayıları okurken bilinmesi yararlı noktalar 6. bölümde, tanımlardaki belirsizlikler ve nasıl çözüldükleri 7. bölümde.

| | |
|---|---|
| Report written | 2026-11-11 23:24:16 UTC (2026-11-12 02:24:16 Turkey time) |
| Analyst's file | `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\SAYILAR-V1.0.json` (SHA-256 `5298c454bdf5da52d7b696cdc02b347110ea63bdaea3ca8fc0d2ca723c194015`, last changed 2026-11-11 22:28:56 UTC (2026-11-12 01:28:56 Turkey time)) |
| Independent results | `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\bagimsiz_sonuclar.json` (SHA-256 `1fd0a114291dc28fe5a72033ca981d86ca9469de362f4c74e3bc38869dc35913`, written 2026-11-11 22:59:29 UTC (2026-11-12 01:59:29 Turkey time)) |

## 1. Outcome

Every number in the analyst's file was recomputed from the raw records with separately written code. All of them agree within the agreed tolerance. **The analyst's numbers are confirmed.**

- Numbers compared: **1,473** (every number that the analyst's file contains).
- Numbers that differ beyond tolerance: **0**.
- Largest absolute difference anywhere: **4.3e-14** (rounding level; the tolerance is 1e-9). 765 of the 1,473 numbers are identical to the last digit.

| Section | Content | Numbers compared | Largest absolute difference | Beyond tolerance |
|---|---|---:|---:|---:|
| A | Training fit (test and training accuracy, their gap, paired differences with 95% intervals) | 1,063 | 4.3e-14 | 0 |
| B | Gate (share of training trials with open gate, W2 fits) | 224 | 0 | 0 |
| C | Agreement of the two decision rules | 102 | 0 | 0 |
| D and E | Lee2019 confidence measures and target displacement | 75 | 2.8e-14 | 0 |
| extra | `algebra` block (not defined in my brief, see 3.3) | 3 | 0 | 0 |
| extra | `source_counts` block (numbers of records and files) | 6 | 0 | 0 |
| **Total** | | **1,473** | **4.3e-14** | **0** |

Where the largest differences sit: section A at `A_training_fit/lee2019_EEGNet/Lee2019/W1/train_accuracy_pct` (4.3e-14 percentage points); interval end points in A at most 3.8e-14; section D/E at `D_E_lee2019_confidence/ordered_by_displacement/4/accuracy_pct` (2.8e-14, a repeated value in percent); all `by_condition` values of D/E are identical to the last digit. Sections B and C agree exactly.

## 2. How independence was kept

1. My code was written only from the written definitions in the task. The analyst's script (`C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\kod\sayilar-V1.0.py`) was never opened, at any time.
2. The analyst's result file was opened only after my own results were on disk. Before that, only the folder listing (file names and sizes) had been seen. The key names of the analyst's layout were given to me in the task text, so my file uses a similar layout.
3. Order of events: my results and scripts were hashed at 2026-11-11 22:59:55 UTC (file `OZETLER_karsilastirma_oncesi.sha256`); the analyst's file was opened after that. The hash of `bagimsiz_sonuclar.json` is still the same (`1fd0a114291dc28fe5a72033ca981d86ca9469de362f4c74e3bc38869dc35913`), i.e. **no number of mine was changed after seeing the analyst's file**. The same holds for the other files hashed at that time (six scripts and four partial result files): 11 of 11 files unchanged.
4. The comparison itself is done by a program (`adim6_karsilastir.py`). It walks through every entry of the analyst's file, so nothing is skipped by hand.

## 3. What exactly was compared

### 3.1 Tolerances

- whole numbers (counts): must be exactly equal - 435 numbers;
- end points of the 95% intervals: 1e-6 - 318 numbers;
- all other numbers (means, standard deviations, shares): 1e-9 - 720 numbers.

### 3.2 Every entry of the analyst's file, by kind

The analyst's file has 1,533 entries (leaves):

- 1,473 numbers - all compared (table above);
- 4 empty values (`null`: S0 has no displacement and no "div8" measures) - also empty in my results;
- 40 true/false flags (`gate_used` per phase) - all agree with the raw records (entry 0 of the gate list is empty in every W2 fit, entries 1 to 9 are numbers in every W2 fit);
- 7 text entries that could be checked - all agree: the 5 condition names in `ordered_by_displacement` (same order as mine: W0, W2, W4, W1, W3) and the SHA-256 hashes of the two `.jsonl` source files, which I recomputed;
- 9 text entries that cannot be compared with a number (status, creation time, scope, unit, and five explanatory notes).

No entry of the analyst's file was left without a decision, and there is no number in the analyst's file that I could not recompute.

### 3.3 Breakdown of the 1,464 numbers in sections A to E

- **1,281 numbers defined in my brief** (A: 979, B: 184, C: 68, D/E: 50). In B this includes the 36 update rates `rate_of_update`, which are the weights w_p = 0.03 x (p - 1) of the definition.
- **109 repeated values**: the analyst repeats the descriptive values (n, test, training, gap) inside the two "versus W0" tables (84 numbers) and repeats five columns in `ordered_by_displacement` (25 numbers, `accuracy_pct` = 100 x `acc`). They were compared with my values for the same quantity.
- **40 phase numbers** (0 to 9) in the gate tables; they only label the rows.
- **34 numbers in two extra fields of section C** that my brief did not list: `disagreement_share` (= disagreements / trials) and `fits_with_different_accuracy` (I read it as: fits whose accuracy under rule 2 differs from the accuracy under rule 1). Both are 0 in every cell, in the analyst's file and in mine.

Outside sections A to E the analyst's file has two more blocks (9 numbers):

- `algebra` (3 numbers). These are not defined in my brief. From the names I inferred: label share of the last trained target under cumulative updating = product over phases 2 to 9 of (1 - 0.03 x (p - 1)) = 0.305560431047872; prediction share = 1 minus that = 0.694439568952128; prediction share under anchored updating = rate of the last phase = 0.03 x 8 = 0.24. With these formulas all three agree (difference 0). Because I inferred the definitions, please read this as an arithmetic check only.
- `source_counts` (6 numbers): 480 K1 runs, 800 Experiment 2 runs, 1,350 Lee2019 records, 270 W4 records - same as my counts. The analyst checked the file hashes of 1,620 Lee2019 prediction files and 640 Experiment 2 output files (the Walsh fits); I checked the same files and additionally the 160 S0 output files of Experiment 2 (800 in total). All hashes match.

## 4. Numbers that differ beyond tolerance

**None.** The list produced by the comparison program is empty (`differences_beyond_tolerance` in `karsilastirma_sonuc.json`).

## 5. Verifications asked for in the definitions

### 5.1 Student's t quantile (0.975), computed numerically

Computed by integrating the t density (Gauss-Legendre, 200 nodes) and bisecting. Two further methods (Simpson's rule with 200,000 steps; the incomplete beta function) give the same values.

| Degrees of freedom | Used for | Quantile | Largest spread between the three methods |
|---:|---|---:|---:|
| 8 | D1 and D4 (9 participants) | 2.306004135204 | 5.3e-15 |
| 13 | D3 (14 participants) | 2.160368656463 | 4.0e-14 |
| 31 | pooled (32 participants) | 2.039513446396 | 2.4e-14 |
| 53 | Lee2019 (54 participants) | 2.005745995318 | 2.9e-14 |

### 5.2 Rule 1 (nearest code word) reproduces the recorded test accuracy

- Experiment 2: 640 of 640 Walsh fits give exactly the recorded `acc_test` (largest difference 0). The class chosen by rule 1 equals the recorded `pred_test` in every trial of every fit (640 of 640 fits).
- Lee2019 (W0 to W3 and W4): 1,350 of 1,350 Walsh fits give exactly the recorded `acc_test` (largest difference 0); predicted classes equal the recorded `pred_test` in 1,350 of 1,350 fits.

### 5.3 NLL and ECE (without division) reproduce the recorded values

NLL = negative log-likelihood, ECE = expected calibration error (15 bins). For all 1,620 Lee2019 fits (270 per condition, S0, W0 to W4) my values equal the recorded `nll_test` and `ece_test`: largest difference 0 for NLL and 5.6e-17 for ECE (required: within 1e-9). Fits outside 1e-9: 0 (NLL), 0 (ECE).

## 6. Raw data: counts, and things worth knowing

### 6.1 Counts - all as expected

| Source | Records | Design | Missing or duplicate combinations |
|---|---:|---|---:|
| E1 (CSP-CNN), code K1 | 480 | 32 participants (D1: 9, D3: 14, D4: 9) x 5 conditions x 3 seeds | 0 |
| E2 (EEGNet) | 800 | the same 32 participants x 5 conditions x 5 seeds | 0 |
| E3 (Lee2019: S0, W0 to W3) | 1,350 | 54 participants x 5 conditions x 5 seeds | 0 |
| W4 (Lee2019, extra condition) | 270 fit records, 270 test records, 270 prediction files | the same 54 participants x 5 seeds | 0 |

Lee2019 with W4 together: 54 participants, 6 conditions; gaps in the participant x condition x seed design: 0; duplicates: 0. File names, identifiers and paths inside the Lee2019 and W4 records are consistent with each other. The E1 file also holds 135 rows of code K2 (D1 only); they were not used. No seed is missing anywhere. All 800 output files of Experiment 2 and all 1,620 Lee2019 prediction files have the SHA-256 hash that their run record states.

### 6.2 Nothing inconsistent was found. Points worth knowing when reading the numbers

1. **One participant with more training trials.** In Experiment 2, D4 participant 8 has 160 training trials, the other 8 D4 participants have 120 (test trials: 160 for all nine).
2. **Gate field.** `used_gate_open_by_phase` is absent for S0, present but empty for W0, W1, W3 (and W4), and holds numbers only for W2. All W2 values lie in [0, 1] and are whole multiples of 1 / (number of training trials).
3. **The target of phases 0 and 1 is the label code in every Walsh fit** (field `used_target_dist_by_phase` is 0 for phases 0 and 1 in all fits; in phase 2 it is above 0 in every W1, W2, W3 and W4 fit). This agrees with the analyst's note that the gate matters from phase 2 on; the phase-1 row of the gate tables has weight 0.
4. **The two decision rules never differ**: 0 disagreements in 238,040 Walsh test trials (Experiment 2: 103,040; Lee2019: 135,000). This is plausible, not suspicious: the outputs that share the same code pattern are near-copies of each other within a trial (median within-trial range between 0.0005 and 0.0022 depending on condition and data set, largest 0.056), and there is no near-tie (smallest margin between the best and second-best class: rule 1 5.8e-05, rule 2 1.5e-04). On a constructed trial where the rules must differ, my code does give different classes (self-test).
5. **Saturated outputs exist, so the clip in rule 2 is active.** Lee2019, outputs below 1e-7 / above 1 - 1e-7 (of 432,000 output values per condition): W0 317 / 1,160; W1 164 / 569; W2 271 / 1,115; W3 61 / 528; W4 258 / 1,190. Experiment 2: 27 / 1,309 of 1,648,640.
6. **The undivided NLL of the Walsh conditions depends strongly on the floor 1e-12.** Test trials whose true-class posterior is below 1e-12 (each then counts 27.63): S0 7; W0 1,582; W1 703; W2 1,432; W3 231; W4 1,439, of 27,000 trials per condition. For W0 these trials alone contribute 1.62 of the mean NLL of 5.04. After division by 8 no trial reaches the floor. This is a property of the definition, not an error; it matters when the undivided NLL values are interpreted.
7. **Displacement is a constant for two conditions.** `last_target_dist` is 0 in all 270 W0 fits and has the same value 0.339411 in all 270 W3 fits (1 distinct value). It varies between fits only for W1 (0.062 to 0.522), W2 (0.010 to 0.119) and W4 (0.010 to 0.119).
8. **Training accuracy is at 100% in most Lee2019 fits** (fits with exactly 100%: S0 262/270; W0 264/270; W1 239/270; W2 264/270; W3 268/270; W4 263/270). The differences in training accuracy are therefore very small, and the differences in the gap are almost the negative of the differences in test accuracy.
9. **Mean differences that are zero, exactly or up to rounding** (please print them as 0; the sign of a value such as -6e-16 carries no meaning): `experiment1_CSP_CNN_K1/D1/C4/versus_C0/test_accuracy_difference_pp/mean` (analyst -6.167905692361981e-16, mine -7.894919286223335e-16); `experiment2_EEGNet_walsh_versus_W0/D3/W2/versus_W0/train_accuracy_difference_pp/mean` (analyst 0.0, mine 0.0); `lee2019_EEGNet_walsh_versus_W0/Lee2019/W2/versus_W0/train_accuracy_difference_pp/mean` (analyst -2.0559685641206603e-16, mine -2.631639762074445e-16).
10. **The two Lee2019 campaigns fit together.** For every participant the W4 fit records state the same training-data hash as the E3 records (differences: 0), the training settings (learning rate, epochs per phase, number of phases, batch size, dropout) are the same, and the test labels in the S0, W0 and W4 prediction files are identical (participants with different labels: 0). The 20 W2 fits whose gate was fully open in phases 2 to 9 have test outputs that are bit-for-bit identical to the W4 fit of the same participant and seed (20 of 20).

## 7. Definitions that were ambiguous, and how I resolved them

Items 1 to 11 were decided before the analyst's file was opened. Item 12 concerns fields that I saw only in the analyst's file.

1. **Precision of the clip in rule 2.** The definition says "clip outputs to [1e-7, 1 - 1e-7]" but not whether this happens in the stored single precision (float32) or after conversion to double precision (float64). I convert to float64 first (as rule 1 says explicitly) and then clip. As a sensitivity check I also clipped in float32 (there the upper bound rounds to 0.99999988): no agreement count changes; NLL, ECE and Brier without division do not change at all (largest change 0); only the "div8" measures move slightly: `nll_div8` by at most 6.3e-05 (W4), `ece15_div8` and `brier_div8` by at most 2.8e-11. Both readings reproduce the recorded `nll_test` and `ece_test`, so the records cannot decide between them. The analyst's values agree with the float64 reading.
2. **Gate: "mean over fits".** Taken literally: the plain mean over all W2 fits, not participants first. Because every participant has 5 seeds, both ways give the same number (largest difference 3.3e-16).
3. **Standard deviation (`sd`).** Sample standard deviation over participants (denominator n - 1), the one the t interval needs.
4. **95% interval.** mean -/+ t(0.975; n - 1) x sd / sqrt(n), two-sided, separately for each number (pointwise).
5. **Gap and its difference.** Gap of a participant = mean over seeds of (training - test) accuracy, which equals mean training minus mean test. Gap difference = gap of the condition minus gap of the baseline, per participant. Accuracies were turned into percent at participant level.
6. **"Pooled".** Plain mean over the 32 participants (D1: 9, D3: 14, D4: 9), each with equal weight; not the mean of the three data-set means.
7. **`acc` in section D.** The recorded `acc_test` as a fraction, participants first. Fit by fit it is identical to the accuracy of rule 1 and to the accuracy of the most probable class.
8. **ECE bin edges.** `numpy.linspace(0, 1, 16)`. Writing the edges as i/15 instead changes the ECE of 0 fits; no confidence value lies closer than 6.6e-07 to an edge.
9. **S0 probabilities.** Used as saved (float32 converted to float64), not re-normalised; the largest deviation of a row sum from 1 is 8.9e-08. S0 has no "div8" measures and no displacement (empty in both files).
10. **Ties.** First index, as defined. No tie occurred (see 6.2, point 4).
11. **Displacement.** Participant-first mean of `last_target_dist`; for W4 the value comes from the fit records.
12. **Fields of the analyst's file that my brief did not define** (`rate_of_update`, `gate_used`, `disagreement_share`, `fits_with_different_accuracy`, `ordered_by_displacement`, the repeated descriptive values, `algebra`, `source_counts`, `source_files_sha256`). I compared each of them with the obvious counterpart from my own results; section 3.3 says how each was read. None of this changed my results file.

## 8. Checks of my own work

- **Self-tests** (`adim5_birlestir.py`): the t quantile against the exact formulas for 1 and 2 degrees of freedom; the code matrix (rows 0 to 3, mutual orthogonality); both decision rules on exact code words, on a tie, and on a constructed trial where they must differ; NLL, ECE and Brier against values computed by hand. All passed.
- **Second route** (`adim7_ikinci_yol.py`): sections A, B, E and the aggregation of D were recomputed a second time with pandas pivot tables straight from the raw records, with the t quantile from a different numerical method. 1,171 numbers rechecked, largest difference 5.7e-14, none beyond 1e-9.
- **Test of the comparison program** (`BK_MUTATION_TEST=1`): five deliberate changes were made to a copy of my numbers - three beyond tolerance (a mean by 2e-9, an interval end point by 2e-6, a count by 1) and two inside tolerance (a mean by 5e-10, an interval end point by 5e-7). The program reported exactly the three (passed).
- **Re-run test** (`adim10_yeniden_kosma_testi.py`): steps 1 to 5 were executed once more with their output kept in memory (nothing was overwritten). The output is identical to the 6 result files on disk, apart from the time stamp and run-time fields. So the scripts in this folder reproduce the results in this folder.

## 9. What this check does and does not cover

It confirms that the numbers in `SAYILAR-V1.0.json` follow from the archived records under the written definitions. It does not examine how the records were produced (training code, data preparation), and it does not judge any conclusion drawn from the numbers.

## 10. Files

All files are in `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\`. Inside the Linux virtual machine the same folder is `~/mnt/EEG_study_except_for_datasets/EEG_study_except_for_datasets/EEG_study_except_for_datasets/MEVCUT_KAYITLARDAN_SAYILAR-V1.0/bagimsiz_kontrol/`.

| File (full path) | Purpose |
|---|---|
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\KARSILASTIRMA.md` | this report |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\bagimsiz_sonuclar.json` | **my independent results** (sections A to E, t quantiles, self-tests, raw-data checks) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\karsilastirma_sonuc.json` | the comparison: totals, per section, and every one of the 1,533 entries with both values |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\bk_common.py` | common functions (t quantile, aggregation, code words, decision rules, NLL / ECE / Brier) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim1_e1_e2_kayitlar.py` | step 1: sections A (E1, E2) and B (E2) from the run records |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim2_e2_npz.py` | step 2: section C for Experiment 2 from the saved outputs |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim3_lee_kayitlar.py` | step 3: sections A, B, E for Lee2019 (with W4) from the run records |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim4_lee_npz.py` | step 4: sections C and D for Lee2019 (with W4) from the saved outputs |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim5_birlestir.py` | step 5: self-tests and merge into `bagimsiz_sonuclar.json` |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim6_karsilastir.py` | step 6: comparison with the analyst's file (the only script that reads it) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim7_ikinci_yol.py` | step 7: second-route check of my own numbers (pandas) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim8_ek_gozlem.py` | step 8: additional observations on the raw data (section 6.2) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim9_rapor.py` | step 9: writes this report from the JSON files |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\adim10_yeniden_kosma_testi.py` | step 10: re-run test (do the scripts on disk reproduce the results on disk?) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\parca_adim1_A_B_e1_e2.json` | partial results of step 1 |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\parca_adim2_C_e2.json` | partial results of step 2, with one line per fit |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\parca_adim3_A_B_E_lee.json` | partial results of step 3 |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\parca_adim4_C_D_lee.json` | partial results of step 4, with one line per fit |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\lee_fit_tablosu.json` | table of the 1,620 Lee2019 fits read from the records (input of step 4) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\ikinci_yol_kontrolu.json` | result of step 7 |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\ek_gozlem.json` | result of step 8 |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\karsilastirma_mutasyon_testi.json` | result of the test of the comparison program |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\yeniden_kosma_testi_bolum1.json` | result of step 10, part 1 (steps 1 and 2) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\yeniden_kosma_testi_bolum2.json` | result of step 10, part 2 (steps 3, 4 and 5) |
| `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\OZETLER_karsilastirma_oncesi.sha256` | hashes of my results and scripts, taken before the analyst's file was opened |

To repeat the check without touching the saved results: run `python3 -X utf8 -B adim10_yeniden_kosma_testi.py 1` and then the same with `2` from that folder in the Linux virtual machine (this recomputes steps 1 to 5 in memory and compares with the saved results; it only rewrites its own two small result files), then `python3 -X utf8 -B adim6_karsilastir.py` for the comparison (it rewrites `karsilastirma_sonuc.json`). Each command needs less than two minutes. Running steps 1 to 5 directly also works and gives the same numbers, but step 5 writes the current time into `bagimsiz_sonuclar.json`; its hash then changes and step 9 refuses to write the report, because step 9 insists on the hash recorded before the analyst's file was opened. The scripts expect the project under `~/mnt/...` as in the Linux virtual machine; to run them elsewhere, change the path `P` at the top of `bk_common.py`.

---

Prepared by Claude (model: Fable 5.2) acting as independent checker, 2026-11-11 23:24:16 UTC (2026-11-12 02:24:16 Turkey time). Environment: Linux virtual machine (kernel 6.8.0-138-generic) on the Windows PC "the-beast" (x64); processor as seen there: 13th Gen Intel(R) Core(TM) i9-13950HX, 2 cores assigned; no graphics card used and no training run. Software: Python 3.10.12, numpy 2.2.6, pandas 2.3.3 (pandas only in step 7); no scipy; nothing was downloaded or installed. Nothing outside the folder `bagimsiz_kontrol` was written, changed, moved or deleted.
