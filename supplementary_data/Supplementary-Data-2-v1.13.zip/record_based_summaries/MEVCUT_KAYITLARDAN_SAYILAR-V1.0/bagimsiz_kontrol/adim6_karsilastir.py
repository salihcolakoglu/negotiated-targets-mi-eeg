# -*- coding: utf-8 -*-
"""
Step 6 - comparison of the analyst's SAYILAR-V1.0.json with the independent
results (bagimsiz_sonuclar.json). This is the only script that reads the
analyst's result file. It does not change bagimsiz_sonuclar.json.

Method: the independent results are re-arranged into the analyst's layout
("my view"), then both trees are walked in parallel and EVERY leaf of the
analyst's file is classified and compared.
Tolerances: integers exact; interval end points (ci95) 1e-6; all other numbers 1e-9.
Output: karsilastirma_sonuc.json
"""
import os
import sys
import hashlib
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

ANALYST = os.path.join(bk.P, "MEVCUT_KAYITLARDAN_SAYILAR-V1.0", "SAYILAR-V1.0.json")
MINE = os.path.join(bk.OUT, "bagimsiz_sonuclar.json")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


a = bk.read_json(ANALYST)
m = bk.read_json(MINE)
p2 = bk.read_json(os.path.join(bk.OUT, "parca_adim2_C_e2.json"))
p4 = bk.read_json(os.path.join(bk.OUT, "parca_adim4_C_D_lee.json"))
p1 = bk.read_json(os.path.join(bk.OUT, "parca_adim1_A_B_e1_e2.json"))
p3 = bk.read_json(os.path.join(bk.OUT, "parca_adim3_A_B_E_lee.json"))

# ----------------------------------------------------------------------------
# "my view": the independent results arranged in the analyst's layout
# ----------------------------------------------------------------------------
view = {}
mA = m["A_training_fit"]
DESC = ("n_participants", "test_accuracy_pct", "train_accuracy_pct", "train_minus_test_pp")


def versus_block(main, vs, baseline, conds):
    """analyst repeats the descriptive values in the 'versus W0' tables; take them from my main table"""
    out = {}
    for scope in main:
        out[scope] = {}
        for c in [baseline] + conds:
            d = {k: main[scope][c][k] for k in DESC}
            if c != baseline:
                d["versus_" + baseline] = vs[scope][c]["versus_" + baseline]
            out[scope][c] = d
    return out


view["A_training_fit"] = {
    "experiment1_CSP_CNN_K1": mA["experiment1_CSP_CNN_K1"],
    "experiment2_EEGNet": mA["experiment2_EEGNet"],
    "experiment2_EEGNet_walsh_versus_W0": versus_block(
        mA["experiment2_EEGNet"], mA["experiment2_EEGNet_walsh_versus_W0"], "W0", ["W1", "W2", "W3"]),
    "lee2019_EEGNet": mA["lee2019_EEGNet"],
    "lee2019_EEGNet_walsh_versus_W0": versus_block(
        mA["lee2019_EEGNet"], mA["lee2019_EEGNet_walsh_versus_W0"], "W0", ["W1", "W2", "W3", "W4"]),
}


def gate_view(blk, problems):
    # problems == [] certifies: entry 0 is null in every W2 fit, entries 1..9 are numbers in every W2 fit
    assert problems == [], problems
    rows = [{"phase": 0, "gate_used": False}]
    for bp in blk["by_phase"]:
        p = bp["phase"]
        rows.append({"phase": p, "gate_used": True, "rate_of_update": 0.03 * (p - 1),
                     "open_fraction_mean": bp["open_fraction_mean"], "open_fraction_min": bp["open_fraction_min"],
                     "fits_with_all_open": bp["fits_with_all_open"], "fits": bp["fits"]})
    return {"by_phase": rows, "rate_weighted_closed_share": blk["rate_weighted_closed_share"]}


view["B_gate_open"] = {
    "experiment2": {ds: gate_view(m["B_gate_open"]["experiment2"][ds], p1["B_gate_open"]["experiment2"][ds]["problems"])
                    for ds in ("D1", "D3", "D4")},
    "lee2019": gate_view(m["B_gate_open"]["lee2019"], p3["B_gate_open"]["lee2019"]["problems"]),
}

# C: the two extra fields of the analyst are derived from my per-fit tables
#    disagreement_share = disagreements / trials
#    fits_with_different_accuracy = fits whose rule-2 accuracy differs from their rule-1 accuracy (my reading)
C_view = {"experiment2": {}, "lee2019": {}}
for ds in ("D1", "D3", "D4"):
    C_view["experiment2"][ds] = {}
    for c in ("W0", "W1", "W2", "W3"):
        d = dict(m["C_decision_rule_agreement"]["experiment2"][ds][c])
        fs = [f for f in p2["per_fit"] if f["dataset"] == ds and f["condition"] == c]
        assert len(fs) == d["fits"]
        d["fits_with_different_accuracy"] = sum(1 for f in fs if f["acc_rule2"] != f["acc_rule1"])
        d["disagreement_share"] = d["disagreements"] / d["trials"]
        C_view["experiment2"][ds][c] = d
for c in ("W0", "W1", "W2", "W3", "W4"):
    d = dict(m["C_decision_rule_agreement"]["lee2019"][c])
    fs = [f for f in p4["per_fit"] if f["condition"] == c]
    assert len(fs) == d["fits"]
    d["fits_with_different_accuracy"] = sum(1 for f in fs if f["acc_posterior_argmax"] != f["acc_rule1"])
    d["disagreement_share"] = d["disagreements"] / d["trials"]
    C_view["lee2019"][c] = d
view["C_decision_rule_agreement"] = C_view

mD = m["D_E_lee2019_confidence"]["by_condition"]
DKEYS = ("n_participants", "acc", "nll", "ece15", "brier", "displacement", "nll_div8", "ece15_div8", "brier_div8")
D_view = {"by_condition": {c: {k: mD[c][k] for k in DKEYS} for c in mD}}
walsh_sorted = sorted([c for c in mD if mD[c]["displacement"] is not None], key=lambda c: mD[c]["displacement"])
D_view["ordered_by_displacement"] = [
    {"condition": c, "displacement": mD[c]["displacement"], "nll": mD[c]["nll"], "nll_div8": mD[c]["nll_div8"],
     "ece15": mD[c]["ece15"], "accuracy_pct": mA["lee2019_EEGNet"]["Lee2019"][c]["test_accuracy_pct"]}
    for c in walsh_sorted]
view["D_E_lee2019_confidence"] = D_view

# extras outside the written brief --------------------------------------------------
label_share = 1.0
for p in range(2, 10):
    label_share *= (1.0 - 0.03 * (p - 1))
view["algebra"] = {
    # formulas inferred from the field names (not defined in the brief):
    "label_share_last_trained_target_cumulative": label_share,           # prod_{p=2..9} (1 - 0.03 (p-1))
    "prediction_share_last_trained_target_cumulative": 1.0 - label_share,
    "prediction_share_last_trained_target_anchored": 0.03 * 8,           # rate of the last phase
}
rc = m["raw_data_checks"]
view["source_counts"] = {
    "experiment1_K1_runs": rc["experiment1_and_2_records"]["E1_rows_K1"],
    "experiment2_runs": rc["experiment1_and_2_records"]["E2_rows_total"],
    "lee_records": rc["lee2019_records"]["E3_record_files"],
    "w4_records": rc["lee2019_records"]["W4_fit_record_files"],
    "lee_prediction_files_hash_checked": rc["lee2019_outputs"]["fits_processed"],
    "experiment2_output_files_hash_checked": rc["experiment2_outputs"]["walsh_fits_processed"],
}
view["source_files_sha256"] = {}
for rel in a.get("source_files_sha256", {}):
    path = os.path.join(bk.P, *rel.split("/"))
    view["source_files_sha256"][rel] = sha256_file(path) if os.path.exists(path) else None

# ----------------------------------------------------------------------------
# optional mutation test of the comparison itself (BK_MUTATION_TEST=1):
# five deliberate changes are made to a COPY of my view; exactly three of them
# are beyond tolerance and must be reported, two are inside tolerance and must not.
# ----------------------------------------------------------------------------
MUTATION_TEST = os.environ.get("BK_MUTATION_TEST") == "1"
OUT_NAME = "karsilastirma_sonuc.json"
if MUTATION_TEST:
    import copy
    view = copy.deepcopy(view)
    OUT_NAME = "karsilastirma_mutasyon_testi.json"
    v = view["A_training_fit"]["experiment1_CSP_CNN_K1"]["D1"]
    v["C1"]["test_accuracy_pct"] += 2e-9                                              # must be reported
    v["C2"]["test_accuracy_pct"] += 5e-10                                             # must NOT be reported
    v["C1"]["versus_C0"]["gap_difference_pp"]["ci95"][0] += 2e-6                      # must be reported
    v["C1"]["versus_C0"]["gap_difference_pp"]["ci95"][1] += 5e-7                      # must NOT be reported
    view["C_decision_rule_agreement"]["lee2019"]["W4"]["disagreements"] += 1          # must be reported

# ----------------------------------------------------------------------------
# parallel walk
# ----------------------------------------------------------------------------
entries = []          # every leaf of the analyst's file
mine_only = []        # leaves of my view that the analyst's file does not have
TOP_TEXT = []


def is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def category(path):
    sec = path[0]
    last = path[-1]
    if sec in ("algebra",):
        return "extra_inferred_definition"
    if sec in ("source_counts",):
        return "extra_source_counts"
    if sec == "B_gate_open" and last == "phase":
        return "index"
    if sec == "C_decision_rule_agreement" and last in ("fits_with_different_accuracy", "disagreement_share"):
        return "extra_derived"
    if sec == "D_E_lee2019_confidence" and len(path) > 1 and path[1] == "ordered_by_displacement":
        return "repeat"
    if sec == "A_training_fit" and path[1].endswith("walsh_versus_W0") and last in DESC:
        return "repeat"
    return "brief"


def tol_for(path, av, mv):
    if "ci95" in path:
        return 1e-6
    if isinstance(av, int) and isinstance(mv, int):
        return 0.0
    return 1e-9


def walk(av, mv, path, has_mine=True):
    if isinstance(av, dict):
        keys = list(av.keys())
        for k in keys:
            if has_mine and isinstance(mv, dict) and k in mv:
                walk(av[k], mv[k], path + (k,), True)
            else:
                walk(av[k], None, path + (k,), False)
        if has_mine and isinstance(mv, dict):
            for k in mv:
                if k not in av:
                    collect_mine_only(mv[k], path + (k,))
        return
    if isinstance(av, list):
        if has_mine and isinstance(mv, list) and len(mv) != len(av):
            entries.append({"path": path, "kind": "list_length", "analyst": len(av), "mine": len(mv),
                            "ok": False, "category": category(path)})
        for i, x in enumerate(av):
            if has_mine and isinstance(mv, list) and i < len(mv):
                walk(x, mv[i], path + (i,), True)
            else:
                walk(x, None, path + (i,), False)
        return
    # leaf of the analyst's file
    e = {"path": path, "analyst": av, "category": category(path)}
    if not has_mine:
        e.update({"kind": "no_counterpart", "mine": None, "ok": None})
    elif isinstance(av, bool) or isinstance(mv, bool):
        e.update({"kind": "flag", "mine": mv, "ok": (isinstance(av, bool) and isinstance(mv, bool) and av == mv)})
    elif is_num(av) and is_num(mv):
        tol = tol_for(path, av, mv)
        diff = abs(float(av) - float(mv))
        e.update({"kind": "number", "mine": mv, "abs_diff": diff, "tolerance": tol,
                  "type_note": None if type(av) == type(mv) else "%s vs %s" % (type(av).__name__, type(mv).__name__),
                  "ok": diff <= tol})
    elif av is None and mv is None:
        e.update({"kind": "null", "mine": None, "ok": True})
    elif isinstance(av, str) and isinstance(mv, str):
        e.update({"kind": "text", "mine": mv, "ok": av == mv})
    else:
        e.update({"kind": "type_mismatch", "mine": mv, "ok": False})
    entries.append(e)


def collect_mine_only(mv, path):
    if isinstance(mv, dict):
        for k, v in mv.items():
            collect_mine_only(v, path + (k,))
    elif isinstance(mv, list):
        for i, v in enumerate(mv):
            collect_mine_only(v, path + (i,))
    else:
        mine_only.append({"path": path, "mine": mv})


for key in a:
    if key in view:
        walk(a[key], view[key], (key,), True)
    else:
        walk(a[key], None, (key,), False)
for key in view:
    if key not in a:
        collect_mine_only(view[key], (key,))

# ----------------------------------------------------------------------------
# summaries
# ----------------------------------------------------------------------------
SECTIONS = ["A_training_fit", "B_gate_open", "C_decision_rule_agreement", "D_E_lee2019_confidence",
            "algebra", "source_counts", "source_files_sha256"]
summary = collections.OrderedDict()
for sec in SECTIONS:
    es = [e for e in entries if e["path"][0] == sec]
    nums = [e for e in es if e["kind"] == "number"]
    bycat = collections.Counter(e["category"] for e in nums)
    summary[sec] = {
        "analyst_leaves": len(es),
        "numbers_compared": len(nums),
        "numbers_by_category": dict(bycat),
        "numbers_beyond_tolerance": sum(1 for e in nums if not e["ok"]),
        "largest_abs_diff": max([e["abs_diff"] for e in nums], default=None),
        "largest_abs_diff_ci95_end_points": max([e["abs_diff"] for e in nums if "ci95" in e["path"]], default=None),
        "largest_abs_diff_other_numbers": max([e["abs_diff"] for e in nums if "ci95" not in e["path"]], default=None),
        "integers_compared_exactly": sum(1 for e in nums if e["tolerance"] == 0.0),
        "ci95_end_points_compared": sum(1 for e in nums if "ci95" in e["path"]),
        "nulls_matching": sum(1 for e in es if e["kind"] == "null"),
        "flags_compared": sum(1 for e in es if e["kind"] == "flag"),
        "flags_differing": sum(1 for e in es if e["kind"] == "flag" and not e["ok"]),
        "texts_compared": sum(1 for e in es if e["kind"] == "text"),
        "texts_differing": sum(1 for e in es if e["kind"] == "text" and not e["ok"]),
        "no_counterpart": sum(1 for e in es if e["kind"] == "no_counterpart"),
        "type_mismatch_or_list_length": sum(1 for e in es if e["kind"] in ("type_mismatch", "list_length")),
        "type_notes": sum(1 for e in nums if e.get("type_note")),
    }
    w = [e for e in nums if e["abs_diff"] == summary[sec]["largest_abs_diff"]]
    summary[sec]["largest_abs_diff_at"] = "/".join(map(str, w[0]["path"])) if w else None

core = ["A_training_fit", "B_gate_open", "C_decision_rule_agreement", "D_E_lee2019_confidence"]
all_nums = [e for e in entries if e["kind"] == "number"]
totals = {
    "analyst_leaves_total": len(entries),
    "numbers_compared_total": len(all_nums),
    "numbers_compared_sections_A_to_E": sum(summary[s]["numbers_compared"] for s in core),
    "numbers_compared_sections_A_to_E_by_category": dict(collections.Counter(
        e["category"] for e in all_nums if e["path"][0] in core)),
    "numbers_compared_extras": sum(summary[s]["numbers_compared"] for s in ("algebra", "source_counts")),
    "numbers_beyond_tolerance_total": sum(1 for e in all_nums if not e["ok"]),
    "differences_of_any_kind": sum(1 for e in entries if e["ok"] is False),
    "analyst_leaves_without_counterpart": sum(1 for e in entries if e["kind"] == "no_counterpart"),
    "analyst_numbers_without_counterpart": sum(1 for e in entries if e["kind"] == "no_counterpart" and is_num(e["analyst"])),
    "largest_abs_diff_overall": max(e["abs_diff"] for e in all_nums),
    "exactly_identical_numbers": sum(1 for e in all_nums if e["abs_diff"] == 0.0),
}
top_not_compared = [{"path": "/".join(map(str, e["path"])), "analyst": e["analyst"]}
                    for e in entries if e["kind"] == "no_counterpart"]
differences = [dict(e, path="/".join(map(str, e["path"]))) for e in entries if e["ok"] is False]

# order check of 'ordered_by_displacement'
order_analyst = [x["condition"] for x in a["D_E_lee2019_confidence"]["ordered_by_displacement"]]
order_mine = walsh_sorted

out = {
    "analyst_file": ANALYST, "analyst_file_sha256": sha256_file(ANALYST),
    "independent_file": MINE, "independent_file_sha256": sha256_file(MINE),
    "tolerances": {"integers": "exact", "ci95_end_points": 1e-6, "other_numbers": 1e-9},
    "totals": totals,
    "by_section": summary,
    "ordered_by_displacement": {"analyst": order_analyst, "mine": order_mine, "same": order_analyst == order_mine},
    "differences_beyond_tolerance": differences,
    "analyst_leaves_without_counterpart": top_not_compared,
    "independent_leaves_not_in_analyst_layout": [{"path": "/".join(map(str, e["path"])), "mine": e["mine"]} for e in mine_only],
    "all_entries": [dict(e, path="/".join(map(str, e["path"]))) for e in entries],
}
out["mutation_test"] = MUTATION_TEST
if MUTATION_TEST:
    found = sorted(d["path"] for d in differences)
    expected = sorted([
        "A_training_fit/experiment1_CSP_CNN_K1/D1/C1/test_accuracy_pct",
        "A_training_fit/experiment1_CSP_CNN_K1/D1/C1/versus_C0/gap_difference_pp/ci95/0",
        "C_decision_rule_agreement/lee2019/W4/disagreements",
    ])
    out["mutation_test_expected"] = expected
    out["mutation_test_found"] = found
    out["mutation_test_passed"] = (found == expected)
    print("MUTATION TEST passed:", found == expected, found)
bk.write_json(os.path.join(bk.OUT, OUT_NAME), out)

import json
print(json.dumps(totals, indent=1))
print(json.dumps(summary, indent=1))
print("order:", out["ordered_by_displacement"])
print("differences:", json.dumps(differences, indent=1))
print("analyst leaves without counterpart:")
for x in top_not_compared:
    print("   ", x["path"], "=", json.dumps(x["analyst"], ensure_ascii=False)[:160])
print("mine only:", out["independent_leaves_not_in_analyst_layout"])
