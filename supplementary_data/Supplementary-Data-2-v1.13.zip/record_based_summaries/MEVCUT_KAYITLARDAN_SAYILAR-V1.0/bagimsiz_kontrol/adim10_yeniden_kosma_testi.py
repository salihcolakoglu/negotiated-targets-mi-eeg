# -*- coding: utf-8 -*-
"""
Step 10 - re-run test: do the scripts on disk reproduce the results on disk?
Steps 1 to 5 are executed again, but their output is kept in memory (bk.write_json is
replaced, so NOTHING is overwritten). The output is then compared with the files on disk.
Only the time stamp and the run-time fields ("seconds", "created_local_time") may differ.

Usage (two parts because of the time limit per command):
    python3 -X utf8 -B adim10_yeniden_kosma_testi.py 1     # steps 1 and 2
    python3 -X utf8 -B adim10_yeniden_kosma_testi.py 2     # steps 3, 4 and 5
Output: yeniden_kosma_testi_bolum1.json / yeniden_kosma_testi_bolum2.json
"""
import os
import io
import sys
import json
import runpy
import contextlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bk_common as bk

part = sys.argv[1] if len(sys.argv) > 1 else "1"
captured = {}
real_write, real_read = bk.write_json, bk.read_json


def fake_write(path, obj):
    # round trip through JSON text so that the comparison sees exactly what a file would hold
    captured[os.path.basename(path)] = json.loads(json.dumps(bk._to_builtin(obj), ensure_ascii=False, allow_nan=True))


def fake_read(path):
    name = os.path.basename(path)
    if os.path.dirname(os.path.abspath(path)) == os.path.abspath(bk.OUT) and name in captured:
        return captured[name]
    return real_read(path)


VOLATILE = {"seconds", "created_local_time"}


def differences(a, b, path=""):
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k in VOLATILE:
                continue
            if k not in a or k not in b:
                out.append(path + "/" + k + " (missing on one side)")
            else:
                out += differences(a[k], b[k], path + "/" + k)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(path + " (list length)")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                out += differences(x, y, path + "/" + str(i))
    else:
        same = (a == b) or (isinstance(a, float) and isinstance(b, float) and a != a and b != b)
        if not same or type(a) != type(b):
            out.append("%s: %r vs %r" % (path, a, b))
    return out


def run(script):
    bk.write_json, bk.read_json = fake_write, fake_read
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            runpy.run_path(os.path.join(HERE, script), run_name="__main__")
    finally:
        bk.write_json, bk.read_json = real_write, real_read


if part == "1":
    scripts = ["adim1_e1_e2_kayitlar.py", "adim2_e2_npz.py"]
    targets = ["parca_adim1_A_B_e1_e2.json", "parca_adim2_C_e2.json"]
else:
    scripts = ["adim3_lee_kayitlar.py", "adim4_lee_npz.py", "adim5_birlestir.py"]
    targets = ["parca_adim3_A_B_E_lee.json", "lee_fit_tablosu.json", "parca_adim4_C_D_lee.json", "bagimsiz_sonuclar.json"]

for s in scripts:
    run(s)

result = {"part": part, "scripts_run_in_memory": scripts, "files": {}}
for t in targets:
    d = differences(captured[t], real_read(os.path.join(bk.OUT, t)))
    result["files"][t] = {"identical_apart_from_time_fields": len(d) == 0, "differences": d[:20], "number_of_differences": len(d)}
result["all_identical"] = all(v["identical_apart_from_time_fields"] for v in result["files"].values())
real_write(os.path.join(bk.OUT, "yeniden_kosma_testi_bolum%s.json" % part), result)
print(json.dumps(result, indent=1))
