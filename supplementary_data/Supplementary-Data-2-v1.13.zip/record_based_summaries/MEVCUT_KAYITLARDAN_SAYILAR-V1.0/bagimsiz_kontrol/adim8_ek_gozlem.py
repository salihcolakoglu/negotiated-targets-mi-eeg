# -*- coding: utf-8 -*-
"""
Step 8 - additional observations on the raw data (not part of the compared numbers):
 (1) how similar the outputs are that share the same code-word pattern (explains why the two
     decision rules never differ);
 (2) spread of last_target_dist over fits, per condition;
 (3) how much of the plain NLL comes from trials whose true-class posterior is at the 1e-12 floor;
 (4) consistency of the two Lee2019 campaigns: W2 fits whose gate never closed versus the W4 fit
     of the same subject and seed; test labels of S0 / W0 / W4 files;
 (5) saturated outputs (outside [1e-7, 1 - 1e-7]) per condition;
 (6) distance of the target used in phases 0, 1 and 2 from the label code (field
     used_target_dist_by_phase), to check the statement that phases 0 and 1 are trained on the labels;
 (7) how many fits have a training accuracy of exactly 100 %.
Output: ek_gozlem.json
"""
import os
import sys
import json
import collections
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

out = collections.OrderedDict()


def group_ranges(Pt, K):
    """within-trial range (max-min) of the outputs whose columns have the same pattern in rows 0..K-1"""
    P64 = Pt.astype(np.float64)
    pats = {}
    for j in range(16):
        pats.setdefault(tuple(bk.CODE16[:K, j]), []).append(j)
    r = []
    for cols in pats.values():
        sub = P64[:, cols]
        r.append(sub.max(axis=1) - sub.min(axis=1))
    return np.concatenate(r), len(pats)


# (1) Lee2019 + W4
fits = bk.read_json(os.path.join(bk.OUT, "lee_fit_tablosu.json"))
res = {}
for c in ("W0", "W1", "W2", "W3", "W4"):
    allr = []
    for f in fits:
        if f["condition"] != c:
            continue
        with np.load(f["prediction_path"]) as z:
            Pt = z[f["key_P"]]
        r, ng = group_ranges(Pt, 2)
        allr.append(r)
    allr = np.concatenate(allr)
    res[c] = {"groups_of_equal_pattern": ng, "values": int(allr.size), "median_range": float(np.median(allr)),
              "p99_range": float(np.quantile(allr, 0.99)), "max_range": float(allr.max())}
out["within_trial_range_of_outputs_with_equal_code_pattern_lee2019"] = res

rows, _ = bk.read_jsonl(bk.E2_FILE)
res = {}
for ds in ("D1", "D3", "D4"):
    K = 4 if ds == "D1" else 2
    allr = []
    for r_ in rows:
        if r_["dataset"] != ds or r_["condition"] == "S0":
            continue
        with np.load(os.path.join(bk.E2_DIR, r_["cikti_npz"])) as z:
            Pt = z["P_test"]
        r, ng = group_ranges(Pt, K)
        allr.append(r)
    allr = np.concatenate(allr)
    res[ds] = {"K": K, "groups_of_equal_pattern": ng, "values": int(allr.size), "median_range": float(np.median(allr)),
               "p99_range": float(np.quantile(allr, 0.99)), "max_range": float(allr.max())}
out["within_trial_range_of_outputs_with_equal_code_pattern_experiment2"] = res

# (2) last_target_dist spread over fits
res = {}
for c in ("W0", "W1", "W2", "W3", "W4"):
    v = np.array([f["last_target_dist"] for f in fits if f["condition"] == c], dtype=np.float64)
    res[c] = {"fits": int(v.size), "min": float(v.min()), "max": float(v.max()), "distinct_values": int(np.unique(v).size)}
out["last_target_dist_over_fits_lee2019"] = res

# (3) share of the plain NLL that comes from floored trials (true-class posterior < 1e-12 -> -log = 27.631)
pf = bk.read_json(os.path.join(bk.OUT, "parca_adim4_C_D_lee.json"))["per_fit"]
res = {}
for c in ("S0", "W0", "W1", "W2", "W3", "W4"):
    fs = [r for r in pf if r["condition"] == c]
    trials = sum(r["trials"] for r in fs)
    floored = sum(r["true_class_posterior_below_1e-12"] for r in fs)
    mean_nll = float(np.mean([r["nll"] for r in fs]))      # balanced design: equals the participant-first mean
    res[c] = {"trials": trials, "floored_trials": floored, "floored_share": floored / trials,
              "nll_mean_over_fits": mean_nll, "nll_part_from_floored_trials": floored * (-np.log(1e-12)) / trials,
              "fits_with_floored_trials": sum(1 for r in fs if r["true_class_posterior_below_1e-12"] > 0)}
out["nll_floor_lee2019"] = res

# (4) W2 with gate open in every phase that has a non-zero rate (2..9) versus W4, same subject and seed
idx = {(f["subject"], f["condition"], f["seed"]): f for f in fits}
n_open = same_P = same_acc = same_dist = 0
for (sub, c, seed), f in idx.items():
    if c != "W2" or not all(v == 1.0 for v in f["used_gate_open_by_phase"][2:]):
        continue
    w4 = idx[(sub, "W4", seed)]
    n_open += 1
    with np.load(f["prediction_path"]) as z:
        P2 = z["P_test"]
    with np.load(w4["prediction_path"]) as z:
        P4 = z["P_test_float32"]
    same_P += int(np.array_equal(P2, P4))
    same_acc += int(f["acc_test"] == w4["acc_test"])
    same_dist += int(f["last_target_dist"] == w4["last_target_dist"])
labels_differ = 0
for sub in sorted(set(f["subject"] for f in fits)):
    with np.load(idx[(sub, "S0", 1)]["prediction_path"]) as z:
        ys = z["y_test"]
    with np.load(idx[(sub, "W0", 1)]["prediction_path"]) as z:
        y0 = z["y_test"]
    with np.load(idx[(sub, "W4", 1)]["prediction_path"]) as z:
        y4 = z["y_test_int64"]
    if not (np.array_equal(ys, y0) and np.array_equal(y0, y4)):
        labels_differ += 1
out["lee2019_W2_gate_open_in_phases_2_to_9_versus_W4"] = {
    "W2_fits_with_gate_fully_open_in_phases_2_to_9": n_open,
    "of_these_test_outputs_bit_identical_to_W4": same_P,
    "of_these_same_acc_test_as_W4": same_acc,
    "of_these_same_last_target_dist_as_W4": same_dist,
    "subjects_whose_test_labels_differ_between_S0_W0_W4_files": labels_differ,
}

# (5) saturated outputs
sat = {}
for c in ("W0", "W1", "W2", "W3", "W4"):
    fs = [r for r in pf if r["condition"] == c]
    sat[c] = {"output_values": sum(r["trials"] for r in fs) * 16,
              "below_1e-7": sum(r["outputs_below_1e-7"] for r in fs),
              "above_1_minus_1e-7": sum(r["outputs_above_1_minus_1e-7"] for r in fs)}
out["saturated_outputs_lee2019"] = sat
pf2 = bk.read_json(os.path.join(bk.OUT, "parca_adim2_C_e2.json"))["per_fit"]
out["saturated_outputs_experiment2"] = {
    "output_values": sum(r["trials"] for r in pf2) * 16,
    "below_1e-7": sum(r["outputs_below_1e-7"] for r in pf2),
    "above_1_minus_1e-7": sum(r["outputs_above_1_minus_1e-7"] for r in pf2)}

# (6) target used in phases 0, 1, 2
import glob
tgt = {}


def add_tgt(key, d, last):
    t = tgt.setdefault(key, {"fits": 0, "phase0_is_label": 0, "phase1_is_label": 0, "phase2_is_label": 0,
                             "last_entry_equals_last_target_dist": 0})
    t["fits"] += 1
    t["phase0_is_label"] += int(d[0] == 0.0)
    t["phase1_is_label"] += int(d[1] == 0.0)
    t["phase2_is_label"] += int(d[2] == 0.0)
    t["last_entry_equals_last_target_dist"] += int(d[-1] == last)


for fpath in sorted(glob.glob(os.path.join(bk.E3_DIR, "records", "*.json"))):
    r = bk.read_json(fpath)
    if r["identity"]["condition"] != "S0":
        add_tgt("lee2019 " + r["identity"]["condition"], r["used_target_dist_by_phase"], r["last_target_dist"])
for fpath in sorted(glob.glob(os.path.join(bk.W4_DIR, "fit_records", "*.json"))):
    r = bk.read_json(fpath)
    add_tgt("lee2019 W4", r["used_target_dist_by_phase"], r["last_target_dist"])
for r in rows:
    if r["condition"] != "S0":
        add_tgt("experiment2 " + r["condition"], r["used_target_dist_by_phase"], r["last_target_dist"])
out["target_used_in_early_phases"] = {k: tgt[k] for k in sorted(tgt)}

# (7) training accuracy at 100 %
out["fits_with_training_accuracy_exactly_1"] = {
    "lee2019": {c: "%d/%d" % (sum(1 for f in fits if f["condition"] == c and f["acc_train"] == 1.0),
                              sum(1 for f in fits if f["condition"] == c)) for c in ("S0", "W0", "W1", "W2", "W3", "W4")},
    "experiment2": {ds: {c: "%d/%d" % (sum(1 for r in rows if r["dataset"] == ds and r["condition"] == c and r["acc_train"] == 1.0),
                                       sum(1 for r in rows if r["dataset"] == ds and r["condition"] == c))
                         for c in ("S0", "W0", "W1", "W2", "W3")} for ds in ("D1", "D3", "D4")},
}

bk.write_json(os.path.join(bk.OUT, "ek_gozlem.json"), out)
print(json.dumps(out, indent=1))
