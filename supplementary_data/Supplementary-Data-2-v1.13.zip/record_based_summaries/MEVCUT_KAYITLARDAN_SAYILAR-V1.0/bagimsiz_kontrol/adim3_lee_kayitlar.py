# -*- coding: utf-8 -*-
"""
Step 3 - Lee2019 (E3: S0, W0..W3; extra condition W4) from the run records.
Produces section A (Lee2019), section B (gate, W2) and section E (target displacement).
Also writes a compact per-fit table (lee_fit_tablosu.json) used by step 4.
Output: parca_adim3_A_B_E_lee.json, lee_fit_tablosu.json
"""
import os
import sys
import glob
import time
import collections
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

t0 = time.time()
notes = collections.OrderedDict()
fits = []

# ------------------------------------------------------------------ E3 records
files = sorted(glob.glob(os.path.join(bk.E3_DIR, "records", "*.json")))
notes["E3_record_files"] = len(files)
name_problems = []
e3_train_sha = {}
e3_params = collections.Counter()
e3_code = collections.Counter()
for f in files:
    r = bk.read_json(f)
    idn = r["identity"]
    base = os.path.basename(f)[:-5]
    exp = "subject_%02d_train__%s__seed%d" % (idn["subject"], idn["condition"], idn["seed"])
    if base != exp or r.get("job") != base or r.get("prediction_file") != "predictions/" + base + ".npz":
        name_problems.append(base)
    e3_train_sha.setdefault(idn["subject"], set()).add(idn["data_sha256"]["train"])
    e3_params[tuple(sorted(idn["parameters"].items()))] += 1
    e3_code[tuple(sorted(idn["code_sha256"].items()))] += 1
    fits.append({
        "source": "E3",
        "dataset": "Lee2019", "dataset_in_record": idn["dataset"],
        "subject": idn["subject"], "condition": idn["condition"], "seed": idn["seed"],
        "acc_train": r["acc_train"], "acc_test": r["acc_test"],
        "nll_test": r["nll_test"], "ece_test": r["ece_test"],
        "last_target_dist": r.get("last_target_dist"),
        "used_gate_open_by_phase": r.get("used_gate_open_by_phase"),
        "n_train": r["n_train"], "n_test": r["n_test"],
        "prediction_path": os.path.join(bk.E3_DIR, r["prediction_file"]),
        "prediction_sha256": r.get("prediction_sha256"),
        "pred_test": r.get("pred_test"),
        "key_P": "P_test", "key_y": "y_test",
    })
notes["E3_name_or_path_inconsistencies"] = name_problems
notes["E3_dataset_names"] = dict(collections.Counter(f["dataset_in_record"] for f in fits))
notes["E3_distinct_hyperparameter_sets"] = len(e3_params)
notes["E3_distinct_code_hash_sets"] = len(e3_code)
notes["E3_subjects_with_more_than_one_train_data_hash"] = sum(1 for s in e3_train_sha.values() if len(s) != 1)

# ------------------------------------------------------------------ W4 records
fit_files = sorted(glob.glob(os.path.join(bk.W4_DIR, "fit_records", "*.json")))
test_files = sorted(glob.glob(os.path.join(bk.W4_DIR, "test_records", "*.json")))
pred_files = sorted(glob.glob(os.path.join(bk.W4_DIR, "predictions", "*.npz")))
notes["W4_fit_record_files"] = len(fit_files)
notes["W4_test_record_files"] = len(test_files)
notes["W4_prediction_files"] = len(pred_files)
w4_problems = []
w4_params = collections.Counter()
w4_train_sha_differs = []
for f in fit_files:
    fit = os.path.basename(f)[:-5]
    r = bk.read_json(f)
    tpath = os.path.join(bk.W4_DIR, "test_records", fit + "_day2.json")
    ppath = os.path.join(bk.W4_DIR, "predictions", fit + "_day2.npz")
    if not os.path.exists(tpath) or not os.path.exists(ppath):
        w4_problems.append("missing test record or prediction for " + fit)
        continue
    t = bk.read_json(tpath)
    exp = "subject_%02d_train__W4__seed%d" % (r["subject"], r["seed"])
    if fit != exp or r.get("fit_id") != fit or t.get("fit_id") != fit or r.get("condition") != "W4" \
            or t.get("condition") != "W4" or t.get("subject") != r["subject"] or t.get("seed") != r["seed"] \
            or t.get("predictions_path") != "campaign/predictions/" + fit + "_day2.npz":
        w4_problems.append("identity mismatch for " + fit)
    w4_params[tuple(sorted(r["identity"]["parameters"].items()))] += 1
    if e3_train_sha.get(r["subject"]) != {r.get("train_source_sha256")}:
        w4_train_sha_differs.append(fit)
    fits.append({
        "source": "W4",
        "dataset": "Lee2019", "dataset_in_record": None,
        "subject": r["subject"], "condition": "W4", "seed": r["seed"],
        "acc_train": r["acc_train"], "acc_test": t["acc_test"],
        "nll_test": t["nll_test"], "ece_test": t["ece_test"],
        "last_target_dist": r.get("last_target_dist"),
        "used_gate_open_by_phase": r.get("used_gate_open_by_phase"),
        "n_train": r.get("n_train"), "n_test": t.get("n_test"),
        "prediction_path": ppath,
        "prediction_sha256": t.get("prediction_sha256"),
        "pred_test": t.get("pred_test"),
        "key_P": "P_test_float32", "key_y": "y_test_int64",
    })
notes["W4_problems"] = w4_problems
notes["W4_distinct_hyperparameter_sets"] = len(w4_params)
notes["W4_hyperparameters_equal_E3"] = (set(w4_params) == set(e3_params))
notes["W4_fits_whose_train_data_hash_differs_from_E3_same_subject"] = len(w4_train_sha_differs)
notes["W4_campaign_eligible_false"] = sum(1 for f in fit_files if bk.read_json(f).get("campaign_eligible") is not True)

# ------------------------------------------------------------------ design checks
CONDS = ["S0", "W0", "W1", "W2", "W3", "W4"]
notes["fits_by_condition"] = dict(collections.Counter(f["condition"] for f in fits))
notes["duplicates"] = [k for k, v in collections.Counter(
    (f["subject"], f["condition"], f["seed"]) for f in fits).items() if v > 1]
notes["n_train_n_test"] = {"%s/%s" % k: v for k, v in collections.Counter((f["n_train"], f["n_test"]) for f in fits).items()}
pm, seeds = bk.aggregate_participants(fits, ["acc_test", "acc_train", "nll_test", "ece_test", "last_target_dist"])
parts = sorted(pm.keys())
notes["participants"] = len(parts)
notes["subject_ids"] = [p[1] for p in parts]
notes["design_problems"] = bk.check_design(seeds, parts, CONDS, [1, 2, 3, 4, 5])
notes["acc_out_of_range"] = sum(1 for f in fits if not (0.0 <= f["acc_test"] <= 1.0 and 0.0 <= f["acc_train"] <= 1.0))
notes["acc_test_not_multiple_of_1_over_n_test"] = sum(
    1 for f in fits if abs(f["acc_test"] * f["n_test"] - round(f["acc_test"] * f["n_test"])) > 1e-9)
notes["last_target_dist_missing_by_condition"] = {c: sum(1 for f in fits if f["condition"] == c and f["last_target_dist"] is None) for c in CONDS}
notes["gate_numbers_by_condition"] = {
    c: sum(1 for f in fits if f["condition"] == c and f["used_gate_open_by_phase"] is not None
           and any(v is not None for v in f["used_gate_open_by_phase"])) for c in CONDS}

# ------------------------------------------------------------------ section A
A = {"Lee2019": bk.training_fit_block(pm, parts, CONDS, "S0")}
Aw = {"Lee2019": bk.versus_only_block(pm, parts, ["W1", "W2", "W3", "W4"], "W0")}

# ------------------------------------------------------------------ section B (W2 fits)
w2 = [f for f in fits if f["condition"] == "W2"]
B = bk.gate_summary([f["used_gate_open_by_phase"] for f in w2])
g = [dict(dataset="Lee2019", subject=f["subject"], condition="W2", seed=f["seed"],
          **{"g%d" % p: f["used_gate_open_by_phase"][p] for p in range(1, 10)}) for f in w2]
pmg, _ = bk.aggregate_participants(g, ["g%d" % p for p in range(1, 10)])
alt = [float(np.mean([pmg[k]["W2"]["g%d" % p] for k in sorted(pmg)])) for p in range(1, 10)]
notes["gate_mean_over_fits_vs_participant_first_maxdiff"] = max(
    abs(a - b["open_fraction_mean"]) for a, b in zip(alt, B["by_phase"]))

# ------------------------------------------------------------------ section E (displacement)
E = {}
for c in CONDS:
    vals = [pm[p][c]["last_target_dist"] for p in parts]
    E[c] = None if all(v is None for v in vals) else float(np.mean(np.asarray(vals, dtype=np.float64)))
# recorded acc / nll / ece aggregated by participant (for reference in section D)
REC = {c: {"acc_recorded": float(np.mean([pm[p][c]["acc_test"] for p in parts])),
           "nll_recorded": float(np.mean([pm[p][c]["nll_test"] for p in parts])),
           "ece_recorded": float(np.mean([pm[p][c]["ece_test"] for p in parts]))} for c in CONDS}

notes["seconds"] = round(time.time() - t0, 1)
bk.write_json(os.path.join(bk.OUT, "parca_adim3_A_B_E_lee.json"), {
    "A_training_fit": {"lee2019_EEGNet": A, "lee2019_EEGNet_walsh_versus_W0": Aw},
    "B_gate_open": {"lee2019": B},
    "E_displacement_by_condition": E,
    "recorded_metrics_by_condition": REC,
    "notes": notes,
})
bk.write_json(os.path.join(bk.OUT, "lee_fit_tablosu.json"), fits)

import json
print(json.dumps({k: v for k, v in notes.items() if k != "subject_ids"}, indent=1))
print("subject ids:", notes["subject_ids"])
for c in CONDS:
    d = A["Lee2019"][c]
    line = "Lee %s n=%d test=%8.4f train=%8.4f gap=%8.4f" % (c, d["n_participants"], d["test_accuracy_pct"], d["train_accuracy_pct"], d["train_minus_test_pp"])
    if "versus_S0" in d:
        for k in ("train_accuracy_difference_pp", "test_accuracy_difference_pp", "gap_difference_pp"):
            v = d["versus_S0"][k]
            line += " | %s %+.4f [%+.4f,%+.4f]" % (k[:5], v["mean"], v["ci95"][0], v["ci95"][1])
    print(line)
for c in Aw["Lee2019"]:
    line = "Lee %s vs W0" % c
    for k in ("train_accuracy_difference_pp", "test_accuracy_difference_pp", "gap_difference_pp"):
        v = Aw["Lee2019"][c]["versus_W0"][k]
        line += " | %s %+.4f [%+.4f,%+.4f] sd %.4f n %d" % (k[:5], v["mean"], v["ci95"][0], v["ci95"][1], v["sd"], v["n"])
    print(line)
print("B Lee: fits", B["n_fits"], "closed share %.8f" % B["rate_weighted_closed_share"], B["problems"])
for bp in B["by_phase"]:
    print("    ", bp)
print("E:", E)
print("REC:", REC)
