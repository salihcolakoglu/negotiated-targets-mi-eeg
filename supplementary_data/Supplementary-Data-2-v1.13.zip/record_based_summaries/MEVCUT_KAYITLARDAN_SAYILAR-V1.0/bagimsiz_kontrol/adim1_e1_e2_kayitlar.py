# -*- coding: utf-8 -*-
"""
Step 1 - Experiment 1 (CSP-CNN, code K1) and Experiment 2 (EEGNet) from the run records.
Produces section A for E1 and E2 and section B (gate) for E2.
Output: parca_adim1_A_B_e1_e2.json
"""
import os
import sys
import collections
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bk_common as bk

notes = {}

# ------------------------------------------------------------------ E1
rows1_all, blank1 = bk.read_jsonl(bk.E1_FILE)
rows1 = [r for r in rows1_all if r["code"] == "K1"]
notes["E1_rows_total"] = len(rows1_all)
notes["E1_blank_lines"] = blank1
notes["E1_rows_K1"] = len(rows1)
notes["E1_rows_by_code"] = dict(collections.Counter(r["code"] for r in rows1_all))
notes["E1_K1_seeds"] = sorted(set(r["seed"] for r in rows1))
notes["E1_K1_duplicates"] = [k for k, v in collections.Counter(
    (r["dataset"], r["subject"], r["condition"], r["seed"]) for r in rows1).items() if v > 1]

E1_CONDS = ["C0", "C1", "C2", "C3", "C4"]
pm1, seeds1 = bk.aggregate_participants(rows1, ["acc_test", "acc_train"])
parts1 = sorted(pm1.keys())
notes["E1_participants"] = {ds: sum(1 for p in parts1 if p[0] == ds) for ds in ("D1", "D3", "D4")}
notes["E1_design_problems"] = bk.check_design(seeds1, parts1, E1_CONDS, [1, 2, 3])
notes["E1_conditions_found"] = sorted(set(r["condition"] for r in rows1))
notes["E1_acc_out_of_range"] = sum(1 for r in rows1 if not (0.0 <= r["acc_test"] <= 1.0 and 0.0 <= r["acc_train"] <= 1.0))

A1 = {}
for ds in ("D1", "D3", "D4"):
    A1[ds] = bk.training_fit_block(pm1, [p for p in parts1 if p[0] == ds], E1_CONDS, "C0")
A1["pooled_participants"] = bk.training_fit_block(pm1, parts1, E1_CONDS, "C0")

# ------------------------------------------------------------------ E2
rows2, blank2 = bk.read_jsonl(bk.E2_FILE)
notes["E2_rows_total"] = len(rows2)
notes["E2_blank_lines"] = blank2
notes["E2_seeds"] = sorted(set(r["seed"] for r in rows2))
notes["E2_duplicates"] = [k for k, v in collections.Counter(
    (r["dataset"], r["subject"], r["condition"], r["seed"]) for r in rows2).items() if v > 1]
E2_CONDS = ["S0", "W0", "W1", "W2", "W3"]
pm2, seeds2 = bk.aggregate_participants(rows2, ["acc_test", "acc_train"])
parts2 = sorted(pm2.keys())
notes["E2_participants"] = {ds: sum(1 for p in parts2 if p[0] == ds) for ds in ("D1", "D3", "D4")}
notes["E2_design_problems"] = bk.check_design(seeds2, parts2, E2_CONDS, [1, 2, 3, 4, 5])
notes["E2_conditions_found"] = sorted(set(r["condition"] for r in rows2))
notes["E2_acc_out_of_range"] = sum(1 for r in rows2 if not (0.0 <= r["acc_test"] <= 1.0 and 0.0 <= r["acc_train"] <= 1.0))
notes["E2_same_participants_as_E1"] = (parts1 == parts2)
notes["E2_n_test_by_dataset"] = {ds: dict(collections.Counter(r["n_test"] for r in rows2 if r["dataset"] == ds)) for ds in ("D1", "D3", "D4")}
notes["E2_n_train_by_dataset"] = {ds: dict(collections.Counter(r["n_train"] for r in rows2 if r["dataset"] == ds)) for ds in ("D1", "D3", "D4")}
# acc_test should be a multiple of 1/n_test
bad = 0
for r in rows2:
    k = r["acc_test"] * r["n_test"]
    if abs(k - round(k)) > 1e-9:
        bad += 1
notes["E2_acc_test_not_multiple_of_1_over_n_test"] = bad

A2, A2w = {}, {}
for ds in ("D1", "D3", "D4"):
    pp = [p for p in parts2 if p[0] == ds]
    A2[ds] = bk.training_fit_block(pm2, pp, E2_CONDS, "S0")
    A2w[ds] = bk.versus_only_block(pm2, pp, ["W1", "W2", "W3"], "W0")
A2["pooled_participants"] = bk.training_fit_block(pm2, parts2, E2_CONDS, "S0")
A2w["pooled_participants"] = bk.versus_only_block(pm2, parts2, ["W1", "W2", "W3"], "W0")

# ------------------------------------------------------------------ B (E2 gate, W2 fits)
B2 = {}
gate_presence = {}
for c in E2_CONDS:
    rs = [r for r in rows2 if r["condition"] == c]
    has = sum(1 for r in rs if "used_gate_open_by_phase" in r)
    numeric = sum(1 for r in rs if any(v is not None for v in r.get("used_gate_open_by_phase", [])))
    gate_presence[c] = {"fits": len(rs), "field_present": has, "with_numbers": numeric}
notes["E2_gate_field_by_condition"] = gate_presence
for ds in ("D1", "D3", "D4"):
    rs = [r for r in rows2 if r["condition"] == "W2" and r["dataset"] == ds]
    B2[ds] = bk.gate_summary([r["used_gate_open_by_phase"] for r in rs])
# mean over fits versus participant-first aggregation (should be identical up to rounding)
gate_alt = {}
for ds in ("D1", "D3", "D4"):
    rs = [dict(dataset=r["dataset"], subject=r["subject"], condition="W2", seed=r["seed"],
               **{"g%d" % p: r["used_gate_open_by_phase"][p] for p in range(1, 10)})
          for r in rows2 if r["condition"] == "W2" and r["dataset"] == ds]
    pmg, _ = bk.aggregate_participants(rs, ["g%d" % p for p in range(1, 10)])
    alt = [float(np.mean([pmg[k]["W2"]["g%d" % p] for k in sorted(pmg)])) for p in range(1, 10)]
    gate_alt[ds] = max(abs(a - b["open_fraction_mean"]) for a, b in zip(alt, B2[ds]["by_phase"]))
notes["E2_gate_mean_over_fits_vs_participant_first_maxdiff"] = gate_alt

out = {
    "t_quantiles_0975": {str(df): bk.tq975(df) for df in (8, 13, 31, 53)},
    "t_quantiles_0975_crosscheck": {
        str(df): {"gauss_legendre": bk.t_quantile(0.975, float(df), bk.t_cdf_gl),
                  "simpson": bk.t_quantile(0.975, float(df), bk.t_cdf_simpson),
                  "incomplete_beta": bk.t_quantile(0.975, float(df), bk.t_cdf_beta)}
        for df in (8, 13, 31, 53)},
    "A_training_fit": {
        "experiment1_CSP_CNN_K1": A1,
        "experiment2_EEGNet": A2,
        "experiment2_EEGNet_walsh_versus_W0": A2w,
    },
    "B_gate_open": {"experiment2": B2},
    "notes": notes,
}
bk.write_json(os.path.join(bk.OUT, "parca_adim1_A_B_e1_e2.json"), out)

# ------------------------------------------------------------------ console summary
import json
print(json.dumps(notes, indent=1, default=str))
for name, blk in (("E1", A1), ("E2", A2)):
    for scope in blk:
        for c in blk[scope]:
            d = blk[scope][c]
            line = "%s %-20s %s n=%2d test=%8.4f train=%8.4f gap=%8.4f" % (
                name, scope, c, d["n_participants"], d["test_accuracy_pct"], d["train_accuracy_pct"], d["train_minus_test_pp"])
            v = [k for k in d if k.startswith("versus_")]
            if v:
                g = d[v[0]]["gap_difference_pp"]
                t = d[v[0]]["test_accuracy_difference_pp"]
                line += " | %s test %+.4f [%+.4f,%+.4f] gap %+.4f [%+.4f,%+.4f]" % (
                    v[0], t["mean"], t["ci95"][0], t["ci95"][1], g["mean"], g["ci95"][0], g["ci95"][1])
            print(line)
for ds in B2:
    print("B E2", ds, "fits", B2[ds]["n_fits"], "closed share %.6f" % B2[ds]["rate_weighted_closed_share"], B2[ds]["problems"])
    for bp in B2[ds]["by_phase"]:
        print("    ", bp)
