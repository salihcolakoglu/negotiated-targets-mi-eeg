"""Write RAPOR-V1.0.md from SAYILAR-V1.0.json. No number is typed by hand, except the results of the
independent recomputation in section 6, which are copied from bagimsiz_kontrol/KARSILASTIRMA.md."""
import json
import sys
from pathlib import Path

source, target = Path(sys.argv[1]), Path(sys.argv[2])
r = json.loads(source.read_text(encoding="utf8"))
A, B, C, D = r["A_training_fit"], r["B_gate_open"], r["C_decision_rule_agreement"], r["D_E_lee2019_confidence"]
BASE = "C:\\EEG_study_except_for_datasets\\EEG_study_except_for_datasets\\EEG_study_except_for_datasets\\MEVCUT_KAYITLARDAN_SAYILAR-V1.0"
out = []


def tr(value, digits=2, sign=False):
    """Turkish decimal comma; a value that rounds to zero is printed without a sign."""
    text = ("%+.*f" if sign else "%.*f") % (digits, value)
    if float(text) == 0:
        text = "%.*f" % (digits, 0)
    return text.replace(".", ",").replace("-", "−")


def whole(value):
    return "{:,}".format(value).replace(",", ".")


def ci(block, digits=2):
    return "%s [%s; %s]" % (tr(block["mean"], digits, True), tr(block["ci95"][0], digits, True), tr(block["ci95"][1], digits, True))


def add(text, **values):
    out.append(text.format(**values) if values else text)


def level_table(rows, title):
    add("**" + title + "**\n")
    add("| Koşul | Kişi sayısı | Eğitim doğruluğu (%) | Test doğruluğu (%) | Fark: eğitim − test (puan) |")
    add("|---|---|---|---|---|")
    for name, row in rows.items():
        add("| %s | %d | %s | %s | %s |" % (name, row["n_participants"], tr(row["train_accuracy_pct"]),
                                          tr(row["test_accuracy_pct"]), tr(row["train_minus_test_pp"])))
    add("")


def difference_table(rows, key, title):
    base = key.split("_")[1]
    add("**" + title + "**\n")
    add("| Karşılaştırma | Eğitim doğruluğu farkı | Test doğruluğu farkı | Eğitim–test farkındaki değişim |")
    add("|---|---|---|---|")
    for name, row in rows.items():
        if key in row:
            v = row[key]
            add("| %s − %s | %s | %s | %s |" % (name, base, ci(v["train_accuracy_difference_pp"]),
                                               ci(v["test_accuracy_difference_pp"]), ci(v["gap_difference_pp"])))
    add("")


counts = r["source_counts"]
add("""# Eldeki kayıtlardan çıkarılan sayılar — rapor V1.0

**Hazırlayan:** Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · **Tarih:** 12.11.2026 · **Günce:** G211

## Bu rapor nedir?

Nuri Korhan Hoca'nın v1.7 için önerilerinden dördü, **yeni eğitim yapmadan**, eldeki kayıtlardan çıkarılabilecek sayılar istiyordu. Bu rapor o sayıları verir. Hiçbir model yeniden eğitilmedi, hiçbir eski dosya değişmedi, yeni bir anlamlılık testi ailesi açılmadı. Bütün sayılar betimseldir.

- Sayıların tamamı: `{base}\\SAYILAR-V1.0.json`
- Hesabı yapan betik: `{base}\\kod\\sayilar-V1.0.py`
- Bağımsız yeniden hesap: `{base}\\bagimsiz_kontrol\\KARSILASTIRMA.md`

**Nasıl okunur:** Her sayı önce kişi içinde (başlangıçlar üzerinden), sonra kişiler üzerinden ortalamadır. Köşeli parantez, kişiler arası %95 güven aralığıdır (tek tek; çoklu karşılaştırma düzeltmesi yok). "Puan" yüzde puanıdır. Bu rapordaki aralıklar yeni bir test değildir; makaledeki istatistik aileleri olduğu gibi durur.

**Veri kümeleri:** D1: BCI Competition IV-2a (9 kişi). D3: BNCI2014-002 (14 kişi). D4: BCI Competition IV-2b (9 kişi). Bu üçü Deney 1 ve Deney 2'nin 32 kişisidir. Lee2019: 54 kişi, birinci gün eğitim, ikinci gün test.

**Kaynak sayıları:** Deney 1: {e1} koşu. Deney 2: {e2} koşu. Lee2019: {lee} eğitim kaydı. W4 çalışması: {w4} eğitim kaydı. Okunmadan önce SHA-256 özeti denetlenen çıktı dosyası: {h1} (Lee2019 ve W4) ve {h2} (Deney 2).
""", base=BASE, e1=whole(counts["experiment1_K1_runs"]), e2=whole(counts["experiment2_runs"]), lee=whole(counts["lee_records"]),
    w4=whole(counts["w4_records"]), h1=whole(counts["lee_prediction_files_hash_checked"]),
    h2=whole(counts["experiment2_output_files_hash_checked"]))

add("""## 1. Eğitim doğruluğu, test doğruluğu ve aradaki fark

**Neden:** Makale "müzakere aşırı öğrenmeyi sınırlamak için önerilmişti" diyor, ama v1.7'de eğitim doğruluğu hiç raporlanmıyordu. Aşırı öğrenmenin en yalın göstergesi eğitim ile test doğruluğu arasındaki farktır.
""")
e1 = A["experiment1_CSP_CNN_K1"]["pooled_participants"]
e2_all = A["experiment2_EEGNet"]["pooled_participants"]
e2 = A["experiment2_EEGNet_walsh_versus_W0"]["pooled_participants"]
lee_all = A["lee2019_EEGNet"]["Lee2019"]
lee = A["lee2019_EEGNet_walsh_versus_W0"]["Lee2019"]
level_table(e1, "Deney 1 (CSP + küçük evrişimli ağ), üç veri kümesi birlikte, 32 kişi")
difference_table(e1, "versus_C0", "Deney 1: C0'a göre farklar (puan; köşeli parantez %95 aralık)")
level_table(e2_all, "Deney 2 (EEGNet), üç veri kümesi birlikte, 32 kişi")
difference_table(e2, "versus_W0", "Deney 2: W0'a göre farklar (puan)")
level_table(lee_all, "Lee2019 (EEGNet), 54 kişi")
difference_table(lee, "versus_W0", "Lee2019: W0'a göre farklar (puan)")

lee_w1 = lee["W1"]["versus_W0"]
add("""**Ne görülüyor:**

- **Deney 1'de** birikimli müzakere (C1, C0'a göre): eğitim doğruluğu {a1}, test doğruluğu {a2}, eğitim–test farkı {a3} puan. Eğitime uyum ölçülebilir biçimde azalıyor.
- **Deney 2'de** aynı kural (W1, W0'a göre): eğitim doğruluğu {b1}, test doğruluğu {b2}, eğitim–test farkı {b3} puan.
- **Lee2019'da** eğitim doğruluğu bütün koşullarda %{t1} ile %{t2} arasında. W1'in W0'a göre eğitim doğruluğu farkı {c1}, test doğruluğu farkı {c2}, eğitim–test farkındaki değişim {c3} puan. Eğitim–test farkındaki daralmanın büyük kısmı test tarafından geliyor; eğitim tarafındaki değişim yalnız {c0} puan. Bu veri kümesinde "müzakere eğitime uymayı azaltıyor" denemez; ağ eğitim verisini her koşulda neredeyse tamamen öğreniyor.
- Eğitim–test farkı her koşulda büyük: Deney 1'de {g1}–{g2}, Deney 2'de {g3}–{g4}, Lee2019'da {g5}–{g6} puan.

**Makaleye etkisi:** v1.8'e "eğitime uyum" başlıklı kısa bir alt bölüm ve bir tablo giriyor. Metin yansız yazılıyor: aşırı öğrenme çerçevesi ilk iki deneyde ölçümle uyumlu, Lee2019'da değil.
""", a1=ci(e1["C1"]["versus_C0"]["train_accuracy_difference_pp"]), a2=ci(e1["C1"]["versus_C0"]["test_accuracy_difference_pp"]),
    a3=ci(e1["C1"]["versus_C0"]["gap_difference_pp"]), b1=ci(e2["W1"]["versus_W0"]["train_accuracy_difference_pp"]),
    b2=ci(e2["W1"]["versus_W0"]["test_accuracy_difference_pp"]), b3=ci(e2["W1"]["versus_W0"]["gap_difference_pp"]),
    t1=tr(min(v["train_accuracy_pct"] for v in lee_all.values())), t2=tr(max(v["train_accuracy_pct"] for v in lee_all.values())),
    c0=tr(abs(lee_w1["train_accuracy_difference_pp"]["mean"])), c1=ci(lee_w1["train_accuracy_difference_pp"]), c2=ci(lee_w1["test_accuracy_difference_pp"]), c3=ci(lee_w1["gap_difference_pp"]),
    g1=tr(min(v["train_minus_test_pp"] for v in e1.values()), 1), g2=tr(max(v["train_minus_test_pp"] for v in e1.values()), 1),
    g3=tr(min(v["train_minus_test_pp"] for v in e2_all.values()), 1), g4=tr(max(v["train_minus_test_pp"] for v in e2_all.values()), 1),
    g5=tr(min(v["train_minus_test_pp"] for v in lee_all.values()), 1), g6=tr(max(v["train_minus_test_pp"] for v in lee_all.values()), 1))

add("""## 2. "Kapı" ne kadar açık kalıyor? (W2 koşulu)

**Neden:** W2'de hedef yalnız ağın o an doğru bildiği eğitim denemelerinde güncellenir ("kapı açık"). Kapı neredeyse hep açıksa W2 ile kapısız W4 fiilen aynı koşuldur; makale bunu sayıyla söylemeliydi.

**Lee2019, 270 eğitim (W2):**

| Eğitim aşaması (0'dan) | Bu aşamada kullanılan hedefin güncelleme oranı | Kapının açık olduğu denemelerin payı (ortalama) | En düşük (tek eğitim) | Kapısı hep açık eğitim sayısı |
|---|---|---|---|---|""")
for row in B["lee2019"]["by_phase"]:
    if row.get("gate_used"):
        add("| %d | %s | %%%s | %%%s | %d / %d |" % (row["phase"], tr(row["rate_of_update"]), tr(100 * row["open_fraction_mean"], 1),
                                                    tr(100 * row["open_fraction_min"], 0), row["fits_with_all_open"], row["fits"]))
add("""
Aşama 0 ve 1 etiketin kendisiyle eğitilir (aşama 1'in oranı sıfırdır); kapı aşama 2'den itibaren işe yarar. Güncelleme oranıyla tartıldığında kapının geri çevirdiği pay yalnız %{closed}. **Sonuç:** Lee2019'da W2 ile W4 neredeyse aynı işlemi yapıyor; ikisinin sonuçlarının yakın çıkması beklenen bir şeydir ve makalede böyle yazılacak.

**Deney 2, W2 — kapının açık olduğu pay (aşama 2 → son aşama):**
""", closed=tr(100 * B["lee2019"]["rate_weighted_closed_share"], 1))
for key, block in B["experiment2"].items():
    used = [row for row in block["by_phase"] if row.get("gate_used")]
    second = [row for row in used if row["phase"] == 2][0]
    add("- %s: %%%s → %%%s" % (key, tr(100 * second["open_fraction_mean"], 1), tr(100 * used[-1]["open_fraction_mean"], 1)))
add("\nİlk veri kümelerinde kapı Lee2019'dakinden daha sık kapalı; orada W2'nin kapısı gerçekten bir şey yapıyor.\n")

lee_c = C["lee2019"]
lee_trials = sum(v["trials"] for v in lee_c.values())
e2_trials = sum(v["trials"] for block in C["experiment2"].values() for v in block.values())
wrong = sum(v["disagreements"] for v in lee_c.values()) + sum(v["disagreements"] for block in C["experiment2"].values() for v in block.values())
add("""## 3. İki karar kuralı aynı kararı veriyor mu?

**Neden:** Walsh çıktılı ağda sınıf iki yoldan seçilebilir: çıktıya en yakın kod sözcüğü, ya da iki sınıfa verilen olasılıklardan büyük olanı. Makale doğruluğu birinciyle, olasılık ölçülerini ikinciyle hesaplıyor; ikisi farklı karar veriyorsa bu söylenmeliydi.

**Sonuç:** Kayıtlı {total} Walsh test denemesinin {wrong} tanesinde iki kural farklı karar verdi (Lee2019: {lee} deneme, beş koşul; Deney 2: {e2} deneme, dört koşul, üç veri kümesi). İki kural bu verilerde birebir aynı kararı veriyor; makaleye bir cümle olarak giriyor.
""", total=whole(lee_trials + e2_trials), wrong=whole(wrong), lee=whole(lee_trials), e2=whole(e2_trials))

by = D["by_condition"]
add("""## 4. Lee2019'da olasılık ölçüleri: ham ve 8'e bölünmüş

**Neden:** Walsh çıktısında iki sınıfın puanı 16 bitten gelir; iki kod sözcüğünün ayrıştığı 8 bit yüzünden olasılıklar aşırı keskinleşir ve "olasılık hatası" ölçüsü (NLL: doğru sınıfa verilen olasılığın eksi logaritması; küçük olması iyi) büyür. Makale ilk veri kümelerinde puanları sabit 8'e bölerek de rapor veriyordu; Lee2019 için bu denetim eksikti. Buradaki 8 sabittir, veriden ayarlanmamıştır. ECE, ağın güveni ile gerçek doğruluğu arasındaki uyumsuzluktur (küçük olması iyi).

| Koşul | Test doğruluğu (%) | NLL (ham) | NLL (8'e bölünmüş) | ECE (ham) | ECE (8'e bölünmüş) | Son kullanılan hedefin etiketten uzaklığı |
|---|---|---|---|---|---|---|""")
for name, row in by.items():
    add("| %s | %s | %s | %s | %s | %s | %s |" % (
        name, tr(100 * row["acc"]), tr(row["nll"], 3), tr(row["nll_div8"], 3) if row.get("nll_div8") is not None else "—",
        tr(row["ece15"], 3), tr(row["ece15_div8"], 3) if row.get("ece15_div8") is not None else "—",
        tr(row["displacement"], 4) if row.get("displacement") is not None else "—"))
add("""
S0 sıradan çıktılıdır; 8'e bölme ona uygulanmaz.

**Ne görülüyor:**

- 8'e bölününce Walsh koşullarının NLL değeri {low}–{high} aralığına iniyor ve S0'ın ham değerinin ({s0}) altında kalıyor. Ham NLL'deki büyük farkın kaynağı keskinliktir, yanlış karar değil.
- Koşullar hedefin etiketten uzaklığına göre sıralandığında NLL aynı sırayla düşüyor:""",
    low=tr(min(row["nll_div8"] for row in D["ordered_by_displacement"]), 2),
    high=tr(max(row["nll_div8"] for row in D["ordered_by_displacement"]), 2), s0=tr(by["S0"]["nll"], 3))
for row in D["ordered_by_displacement"]:
    add("  - %s: uzaklık %s → NLL %s (8'e bölünmüş %s), test doğruluğu %%%s" % (
        row["condition"], tr(row["displacement"], 4), tr(row["nll"], 2), tr(row["nll_div8"], 3), tr(row["accuracy_pct"])))
add("""- Bu sıra doğruluk sırasıyla aynı değil. NLL'deki düşüş, hedefin etiketten uzaklaşmasıyla (ağın daha az keskin çıktı vermeye itilmesiyle) birlikte geliyor; "müzakere olasılıkları daha doğru yapıyor" demek için tek başına yeterli değil. Makalede "daha iyi kalibre" ifadesi bu sınırla birlikte yazılacak.

## 5. Hedefte etiketin ve tahminin payı (cebir)

Birikimli kuralda (W1) son kullanılan hedefte etiketin payı {label}, tahminlerin toplam payı {prediction}. Çapalı kuralda (W2, W4) tahminin payı en çok {anchored}. Yani W1 ile W4 arasındaki fark yalnız "eskiyi biriktirme" değil, aynı zamanda tahmine verilen payın büyüklüğüdür. Yeni W5 koşulu bu ikisini ayırmak için eklendi.

## 6. Bağımsız doğrulama

Bu sayıları, hesabı yazan oturumun kodunu kullanmayan ayrı bir yardımcı oturum, kayıt dosyalarından kendi yazdığı kodla yeniden hesapladı. `SAYILAR-V1.0.json` içindeki 1.473 sayının hepsi doğrulandı; en büyük mutlak fark 4,3 × 10⁻¹⁴ (yuvarlama düzeyi). Ayrıntı: `{base}\\bagimsiz_kontrol\\KARSILASTIRMA.md`.

Bağımsız kontrolün eklediği üç bilgi:

1. NLL hesabında olasılığa konan alt sınır (10⁻¹²), 27.000 Lee2019 test denemesinin şu kadarında devreye giriyor: S0 7, W0 1.582, W1 703, W2 1.432, W3 231, W4 1.439. 8'e bölünmüş hesapta hiç devreye girmiyor. Ham NLL ortalamaları bu yüzden alt sınır seçimine duyarlıdır; makalenin ek bilgi dosyasına not olarak girecek.
2. Lee2019'da eğitim doğruluğu, koşul başına 270 eğitimin 239–268'inde tam %100. Bu, 1. bölümdeki "eğitim–test farkındaki değişim test tarafından geliyor" tespitini destekler.
3. Üç ortalama fark tam sıfırdır; tablolarda işaretsiz yazılır.

## 7. Sınırlar

- Bu sayılar daha önce incelenmiş verilerden, sonradan çıkarılmıştır; keşif amaçlı ve betimseldir.
- Aralıklar tek tek %95 aralıklardır; birlikte okunduklarında yanlış alarm olasılığı %5'ten büyüktür.
- Deney 1 ve Deney 2'de ilk iki veri kümesi yöntem geliştirilirken kullanılmıştı; buradaki sayılar o deneylerin doğrulayıcı kanıtı değildir.

— Claude (Anthropic) · model kimliği `claude-fable-5-2` (oturum yapılandırması; hizmet veren model değişebilir) · 12.11.2026
""", label=tr(r["algebra"]["label_share_last_trained_target_cumulative"], 3),
    prediction=tr(r["algebra"]["prediction_share_last_trained_target_cumulative"], 3),
    anchored=tr(r["algebra"]["prediction_share_last_trained_target_anchored"], 2), base=BASE)

target.parent.mkdir(parents=True, exist_ok=True)
target.write_text("\n".join(out) + "\n", encoding="utf8")
print(len("\n".join(out)), "characters")
