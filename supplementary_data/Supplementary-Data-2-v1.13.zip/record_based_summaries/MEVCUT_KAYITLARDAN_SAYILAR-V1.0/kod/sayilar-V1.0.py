# -*- coding: utf-8 -*-
"""Mevcut kayitlardan yeni sayilar - V1.0 (yeni egitim yok; betimsel).

Yalniz daha once tamamlanmis deneylerin kayit ve cikti dosyalarini okur:
  Deney 1  CSP-CNN (C0-C4, K1 kodlari)   ARASTIRMALAR/DENEY_01_MUZAKERE_DUZELTME_v1.0
  Deney 2  EEGNet  (S0, W0-W3)            ARASTIRMALAR/DENEY_02_03_GPU_v1.0
  Deney 3  Lee2019 (S0, W0-W3)            LEE2019_BAGIMSIZ_DOGRULAMA-V1.0
  W4 kontrolu (Lee2019)                    LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0

Cikardiklari:
  A  egitim dogrulugu, test dogrulugu ve aralarindaki fark (kosul ve veri kumesi bazinda)
  B  dogruluk kapisinin acik kalma orani (W2; Deney 2 ve Lee2019)
  C  iki karar kuralinin (en yakin kod sozcugu / en olasi sinif) deneme duzeyinde uyusmasi
  D  Lee2019 Walsh kosullarinda sinif puanlarini 8'e bolunce NLL, ECE ve Brier
  E  Lee2019'da hedef kaymasi ile NLL'nin yan yana tablosu

Birim her yerde kisidir: once kisinin baslangiclari ortalanir, sonra kisiler ortalanir.
Hicbir istatistik ailesi eklenmez; araliklar noktasal %95 t araligidir, duzeltme yoktur.
Yalniz numpy ve standart kitaplik kullanir.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
E1 = PROJECT / "ARASTIRMALAR/DENEY_01_MUZAKERE_DUZELTME_v1.0/sonuclar/deney01_kosular.jsonl"
E2_DIR = PROJECT / "ARASTIRMALAR/DENEY_02_03_GPU_v1.0/sonuclar_bulut_EEGNet"
E2 = E2_DIR / "kosular.jsonl"
LEE = PROJECT / "LEE2019_BAGIMSIZ_DOGRULAMA-V1.0/results/worker_01"
W4 = PROJECT / "LEE2019_ANKRAJ_KAPI_AYRISTIRMA-V1.0/campaign"
T975 = {8: 2.306004135204166, 13: 2.1603686564627913, 31: 2.039513446396408, 53: 2.0057459953178687}
R_RATE = 0.03


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def jsonl(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def create_walsh(size=16):
    """Released construction, including row order."""
    n = int(math.log(size, 2) + 1)
    j, old = 1, 1
    for i in range(n):
        j_new = 2 ** i
        new = np.zeros([j_new, j_new], dtype=np.float32)
        new[:j, :j] = old
        new[j:, :j] = old
        new[:j, j:] = old
        new[j:, j:] = abs(1 - old)
        old, j = new, j_new
    return new


def person_means(rows, value, keys=("dataset", "condition")):
    """{group key: {subject: mean over seeds}}"""
    bucket = {}
    for r in rows:
        group = tuple(r[k] for k in keys)
        bucket.setdefault(group, {}).setdefault(r["subject"], []).append(value(r))
    return {group: {s: float(np.mean(v)) for s, v in people.items()} for group, people in bucket.items()}


def mean_ci(values):
    d = np.asarray(values, dtype=np.float64)
    n = d.size
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else 0.0
    half = T975[n - 1] * sd / math.sqrt(n) if n - 1 in T975 else None
    return dict(mean=mean, sd=sd, n=int(n), ci95=None if half is None else [mean - half, mean + half])


def fit_table(rows, datasets, conditions, baseline, seeds_expected):
    """Train, test and gap per dataset and pooled; paired differences from the hard-target baseline."""
    out = {}
    scopes = [(d, [r for r in rows if r["dataset"] == d]) for d in datasets]
    if len(datasets) > 1:
        scopes.append(("pooled_participants", rows))
    for scope, subset in scopes:
        keyed = [dict(r, person=(r["dataset"], r["subject"])) for r in subset]
        table = {}
        per = {}
        for c in conditions:
            group = [r for r in keyed if r["condition"] == c]
            people = {}
            for r in group:
                people.setdefault(r["person"], []).append(r)
            assert all(len(v) == seeds_expected for v in people.values()), (scope, c)
            train = {p: float(np.mean([r["acc_train"] for r in v])) for p, v in people.items()}
            test = {p: float(np.mean([r["acc_test"] for r in v])) for p, v in people.items()}
            per[c] = (train, test)
            order = sorted(people)
            table[c] = dict(n_participants=len(order),
                            test_accuracy_pct=100 * float(np.mean([test[p] for p in order])),
                            train_accuracy_pct=100 * float(np.mean([train[p] for p in order])),
                            train_minus_test_pp=100 * float(np.mean([train[p] - test[p] for p in order])))
        for c in conditions:
            if c == baseline:
                continue
            order = sorted(per[c][0])
            assert order == sorted(per[baseline][0])
            d_train = [100 * (per[c][0][p] - per[baseline][0][p]) for p in order]
            d_test = [100 * (per[c][1][p] - per[baseline][1][p]) for p in order]
            d_gap = [a - b for a, b in zip(d_train, d_test)]
            table[c]["versus_" + baseline] = dict(train_accuracy_difference_pp=mean_ci(d_train),
                                                  test_accuracy_difference_pp=mean_ci(d_test),
                                                  gap_difference_pp=mean_ci(d_gap))
        out[scope] = table
    return out


def walsh_trial_metrics(P, y, C):
    """Per-trial decisions and class scores exactly as in the training code's walsh_metrics."""
    p = P.astype(np.float64)
    C64 = C.astype(np.float64)
    nearest = ((p[:, None, :] - C64[None, :, :]) ** 2).sum(-1).argmin(1)
    pc = np.clip(p, 1e-7, 1 - 1e-7)
    scores = np.log(pc) @ C64.T + np.log(1 - pc) @ (1 - C64.T)
    return nearest, scores


def posterior_from_scores(scores, divisor=1.0):
    scaled = scores / divisor
    scaled = scaled - scaled.max(1, keepdims=True)
    post = np.exp(scaled)
    return post / post.sum(1, keepdims=True)


def ece15(post, y):
    conf = post.max(1)
    pred = post.argmax(1)
    edges = np.linspace(0.0, 1.0, 16)
    total = 0.0
    for i in range(15):
        mask = (conf >= edges[i]) & (conf <= edges[i + 1]) if i == 0 else (conf > edges[i]) & (conf <= edges[i + 1])
        if mask.any():
            total += mask.mean() * abs((pred[mask] == y[mask]).mean() - conf[mask].mean())
    return float(total)


def probability_metrics(post, y):
    n = len(y)
    return dict(nll=float(-np.log(np.clip(post[np.arange(n), y], 1e-12, 1.0)).mean()), ece15=ece15(post, y),
                brier=float(np.mean(np.sum((post - np.eye(post.shape[1])[y]) ** 2, axis=1))))


def gate_summary(records):
    """records: list of used_gate_open_by_phase lists (phase 0 has no gate)."""
    phases = len(records[0])
    table = []
    for p in range(phases):
        values = [r[p] for r in records if r[p] is not None]
        if not values:
            table.append(dict(phase=p, gate_used=False))
            continue
        assert len(values) == len(records)
        table.append(dict(phase=p, gate_used=True, rate_of_update=R_RATE * (p - 1),
                          open_fraction_mean=float(np.mean(values)), open_fraction_min=float(np.min(values)),
                          fits_with_all_open=int(sum(1 for v in values if v == 1.0)), fits=len(values)))
    weights = [(R_RATE * (p - 1), 1 - row["open_fraction_mean"]) for p, row in enumerate(table)
               if row.get("gate_used") and p >= 2]
    excluded = sum(w * x for w, x in weights) / sum(w for w, _ in weights)
    return dict(by_phase=table, rate_weighted_closed_share=float(excluded),
                note="Phase p uses the gate computed after phase p-1. Phases 0 and 1 are trained on the labels; the gate "
                     "matters from phase 2 on. Closed share is weighted by the update rate 0.03 x (p-1), phases 2..9.")


def main():
    stamp = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat()
    sources = {}

    def bind(path):
        sources[str(Path(path).relative_to(PROJECT)).replace("\\", "/")] = sha(path)

    # ------------------------------------------------------------------ A: Experiment 1 and 2
    e1 = [r for r in jsonl(E1) if r["code"] == "K1"]
    bind(E1)
    assert len(e1) == 480 and sorted(set(r["seed"] for r in e1)) == [1, 2, 3]
    exp1 = fit_table(e1, ("D1", "D3", "D4"), ("C0", "C1", "C2", "C3", "C4"), "C0", 3)
    e2 = jsonl(E2)
    bind(E2)
    assert len(e2) == 800 and sorted(set(r["seed"] for r in e2)) == [1, 2, 3, 4, 5]
    exp2 = fit_table(e2, ("D1", "D3", "D4"), ("S0", "W0", "W1", "W2", "W3"), "S0", 5)
    exp2_walsh = fit_table([r for r in e2 if r["condition"] != "S0"], ("D1", "D3", "D4"), ("W0", "W1", "W2", "W3"), "W0", 5)

    # ------------------------------------------------------------------ Lee2019 records
    lee_rows, lee_predictions = [], {}
    for path in sorted((LEE / "records").glob("subject_*.json")):
        r = json.loads(path.read_text(encoding="utf-8"))
        subject, condition, seed = r["identity"]["subject"], r["identity"]["condition"], r["identity"]["seed"]
        prediction = LEE / r["prediction_file"]
        assert sha(prediction) == r["prediction_sha256"], path.name
        lee_rows.append(dict(dataset="Lee2019", subject=subject, condition=condition, seed=seed,
                             acc_train=r["acc_train"], acc_test=r["acc_test"], acc_test_post=r["acc_test_post"],
                             nll_test=r["nll_test"], ece_test=r["ece_test"],
                             last_target_dist=r.get("last_target_dist"),
                             used_gate=r.get("used_gate_open_by_phase"), prediction=prediction))
    assert len(lee_rows) == 1350
    w4_rows = []
    for path in sorted((W4 / "fit_records").glob("subject_*.json")):
        f = json.loads(path.read_text(encoding="utf-8"))
        t = json.loads((W4 / "test_records" / (path.stem + "_day2.json")).read_text(encoding="utf-8"))
        prediction = W4 / "predictions" / (path.stem + "_day2.npz")
        assert sha(prediction) == t["prediction_sha256"], path.name
        w4_rows.append(dict(dataset="Lee2019", subject=f["subject"], condition="W4", seed=f["seed"],
                            acc_train=f["acc_train"], acc_test=t["acc_test"], acc_test_post=t["acc_test_post"],
                            nll_test=t["nll_test"], ece_test=t["ece_test"], last_target_dist=f["last_target_dist"],
                            used_gate=f.get("used_gate_open_by_phase"), prediction=prediction))
    assert len(w4_rows) == 270
    lee_all = lee_rows + w4_rows
    lee_conditions = ("S0", "W0", "W1", "W2", "W3", "W4")
    lee = fit_table(lee_all, ("Lee2019",), lee_conditions, "S0", 5)
    lee_walsh = fit_table([r for r in lee_all if r["condition"] != "S0"], ("Lee2019",), lee_conditions[1:], "W0", 5)

    # ------------------------------------------------------------------ B: gate
    gate = dict(
        experiment2={d: gate_summary([r["used_gate_open_by_phase"] for r in e2
                                      if r["condition"] == "W2" and r["dataset"] == d]) for d in ("D1", "D3", "D4")},
        lee2019=gate_summary([r["used_gate"] for r in lee_rows if r["condition"] == "W2"]))

    # ------------------------------------------------------------------ C, D, E: trial-level outputs
    walsh16 = create_walsh(16)
    agreement = {"experiment2": {}, "lee2019": {}}
    for r in e2:
        if r["condition"] == "S0":
            continue
        path = E2_DIR / r["cikti_npz"]
        assert sha(path) == r["cikti_sha256"], r["cikti_npz"]
        with np.load(path, allow_pickle=False) as z:
            P, y = z["P_test"], z["y_test"]
        K = int(y.max()) + 1
        nearest, scores = walsh_trial_metrics(P, y, walsh16[:K])
        assert abs(float((nearest == y).mean()) - r["acc_test"]) < 1e-12, r["cikti_npz"]
        most_probable = scores.argmax(1)
        cell = agreement["experiment2"].setdefault(r["dataset"], {}).setdefault(
            r["condition"], dict(trials=0, disagreements=0, fits=0, fits_with_any_disagreement=0,
                                 fits_with_different_accuracy=0))
        differ = int((nearest != most_probable).sum())
        cell["trials"] += len(y)
        cell["disagreements"] += differ
        cell["fits"] += 1
        cell["fits_with_any_disagreement"] += int(differ > 0)
        cell["fits_with_different_accuracy"] += int(r["acc_test"] != r["acc_test_post"])
    C2 = walsh16[:2]
    per_fit = []
    for r in lee_all:
        if r["condition"] == "S0":
            with np.load(r["prediction"], allow_pickle=False) as z:
                P, y = z["P_test"], z["y_test"]
            raw = probability_metrics(P.astype(np.float64), y)
            assert abs(raw["nll"] - r["nll_test"]) < 1e-11 and abs(raw["ece15"] - r["ece_test"]) < 1e-11
            per_fit.append(dict(subject=r["subject"], condition="S0", seed=r["seed"], acc=r["acc_test"],
                                nll=raw["nll"], ece15=raw["ece15"], brier=raw["brier"], displacement=None,
                                nll_div8=None, ece15_div8=None, brier_div8=None))
            continue
        with np.load(r["prediction"], allow_pickle=False) as z:
            if r["condition"] == "W4":
                P, y = z["P_test_float32"], z["y_test_int64"]
            else:
                P, y = z["P_test"], z["y_test"]
        nearest, scores = walsh_trial_metrics(P, y, C2)
        assert abs(float((nearest == y).mean()) - r["acc_test"]) < 1e-12
        raw = probability_metrics(posterior_from_scores(scores), y)
        assert abs(raw["nll"] - r["nll_test"]) < 1e-11 and abs(raw["ece15"] - r["ece_test"]) < 1e-11, r["prediction"].name
        div8 = probability_metrics(posterior_from_scores(scores, 8.0), y)
        most_probable = scores.argmax(1)
        cell = agreement["lee2019"].setdefault(r["condition"], dict(trials=0, disagreements=0, fits=0,
                                                                    fits_with_any_disagreement=0,
                                                                    fits_with_different_accuracy=0))
        differ = int((nearest != most_probable).sum())
        cell["trials"] += len(y)
        cell["disagreements"] += differ
        cell["fits"] += 1
        cell["fits_with_any_disagreement"] += int(differ > 0)
        cell["fits_with_different_accuracy"] += int(r["acc_test"] != r["acc_test_post"])
        per_fit.append(dict(subject=r["subject"], condition=r["condition"], seed=r["seed"], acc=r["acc_test"],
                            nll=raw["nll"], ece15=raw["ece15"], brier=raw["brier"], displacement=r["last_target_dist"],
                            nll_div8=div8["nll"], ece15_div8=div8["ece15"], brier_div8=div8["brier"]))
    for scope in agreement.values():
        cells = [c for c in scope.values() if "trials" in c] or [c for d in scope.values() for c in d.values()]
        for cell in cells:
            cell["disagreement_share"] = cell["disagreements"] / cell["trials"]
    confidence = {}
    for c in lee_conditions:
        group = [f for f in per_fit if f["condition"] == c]
        row = dict(n_participants=54)
        for name in ("acc", "nll", "ece15", "brier", "displacement", "nll_div8", "ece15_div8", "brier_div8"):
            if group[0][name] is None:
                row[name] = None
                continue
            people = {}
            for f in group:
                people.setdefault(f["subject"], []).append(f[name])
            assert len(people) == 54 and all(len(v) == 5 for v in people.values())
            row[name] = float(np.mean([np.mean(v) for v in people.values()]))
        confidence[c] = row

    result = dict(
        status="COMPLETE_DESCRIPTIVE_NUMBERS_FROM_EXISTING_RECORDS", created_trt=stamp,
        scope="No new training. Descriptive only; no new significance family. Intervals are pointwise 95% t intervals.",
        unit="participant mean over seeds, then mean over participants",
        A_training_fit=dict(experiment1_CSP_CNN_K1=exp1, experiment2_EEGNet=exp2,
                            experiment2_EEGNet_walsh_versus_W0=exp2_walsh, lee2019_EEGNet=lee,
                            lee2019_EEGNet_walsh_versus_W0=lee_walsh),
        B_gate_open=gate, C_decision_rule_agreement=agreement,
        D_E_lee2019_confidence=dict(
            note="div8: the two class log scores divided by 8 before normalisation (same definition as the SHU T8 "
                 "column). displacement: mean Euclidean distance between the last trained target and the label code.",
            by_condition=confidence,
            ordered_by_displacement=sorted(
                [dict(condition=c, displacement=confidence[c]["displacement"], nll=confidence[c]["nll"],
                      nll_div8=confidence[c]["nll_div8"], ece15=confidence[c]["ece15"], accuracy_pct=100 * confidence[c]["acc"])
                 for c in lee_conditions if confidence[c]["displacement"] is not None],
                key=lambda row: row["displacement"])),
        algebra=dict(label_share_last_trained_target_cumulative=float(np.prod([1 - R_RATE * k for k in range(1, 9)])),
                     prediction_share_last_trained_target_cumulative=1 - float(np.prod([1 - R_RATE * k for k in range(1, 9)])),
                     prediction_share_last_trained_target_anchored=R_RATE * 8),
        source_files_sha256=sources,
        source_counts=dict(experiment1_K1_runs=len(e1), experiment2_runs=len(e2), lee_records=len(lee_rows),
                           w4_records=len(w4_rows), lee_prediction_files_hash_checked=len(lee_rows) + len(w4_rows),
                           experiment2_output_files_hash_checked=sum(1 for r in e2 if r["condition"] != "S0")))
    out = ROOT / "SAYILAR-V1.0.json"
    assert not out.exists(), "written once"
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(status=result["status"], sha256=sha(out), counts=result["source_counts"])))


if __name__ == "__main__":
    main()
