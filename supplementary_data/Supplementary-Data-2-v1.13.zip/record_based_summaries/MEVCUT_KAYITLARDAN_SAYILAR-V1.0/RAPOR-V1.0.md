# Eldeki kayıtlardan çıkarılan sayılar — rapor V1.0

**Hazırlayan:** Claude (Anthropic), model kimliği `claude-fable-5-2` (oturum yapılandırması) · **Tarih:** 12.11.2026 · **Günce:** G211

## Bu rapor nedir?

Nuri Korhan Hoca'nın v1.7 için önerilerinden dördü, **yeni eğitim yapmadan**, eldeki kayıtlardan çıkarılabilecek sayılar istiyordu. Bu rapor o sayıları verir. Hiçbir model yeniden eğitilmedi, hiçbir eski dosya değişmedi, yeni bir anlamlılık testi ailesi açılmadı. Bütün sayılar betimseldir.

- Sayıların tamamı: `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\SAYILAR-V1.0.json`
- Hesabı yapan betik: `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\kod\sayilar-V1.0.py`
- Bağımsız yeniden hesap: `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\KARSILASTIRMA.md`

**Nasıl okunur:** Her sayı önce kişi içinde (başlangıçlar üzerinden), sonra kişiler üzerinden ortalamadır. Köşeli parantez, kişiler arası %95 güven aralığıdır (tek tek; çoklu karşılaştırma düzeltmesi yok). "Puan" yüzde puanıdır. Bu rapordaki aralıklar yeni bir test değildir; makaledeki istatistik aileleri olduğu gibi durur.

**Veri kümeleri:** D1: BCI Competition IV-2a (9 kişi). D3: BNCI2014-002 (14 kişi). D4: BCI Competition IV-2b (9 kişi). Bu üçü Deney 1 ve Deney 2'nin 32 kişisidir. Lee2019: 54 kişi, birinci gün eğitim, ikinci gün test.

**Kaynak sayıları:** Deney 1: 480 koşu. Deney 2: 800 koşu. Lee2019: 1.350 eğitim kaydı. W4 çalışması: 270 eğitim kaydı. Okunmadan önce SHA-256 özeti denetlenen çıktı dosyası: 1.620 (Lee2019 ve W4) ve 640 (Deney 2).

## 1. Eğitim doğruluğu, test doğruluğu ve aradaki fark

**Neden:** Makale "müzakere aşırı öğrenmeyi sınırlamak için önerilmişti" diyor, ama v1.7'de eğitim doğruluğu hiç raporlanmıyordu. Aşırı öğrenmenin en yalın göstergesi eğitim ile test doğruluğu arasındaki farktır.

**Deney 1 (CSP + küçük evrişimli ağ), üç veri kümesi birlikte, 32 kişi**

| Koşul | Kişi sayısı | Eğitim doğruluğu (%) | Test doğruluğu (%) | Fark: eğitim − test (puan) |
|---|---|---|---|---|
| C0 | 32 | 85,92 | 67,69 | 18,24 |
| C1 | 32 | 83,16 | 68,33 | 14,83 |
| C2 | 32 | 85,09 | 67,99 | 17,11 |
| C3 | 32 | 85,77 | 67,80 | 17,97 |
| C4 | 32 | 85,67 | 67,60 | 18,07 |

**Deney 1: C0'a göre farklar (puan; köşeli parantez %95 aralık)**

| Karşılaştırma | Eğitim doğruluğu farkı | Test doğruluğu farkı | Eğitim–test farkındaki değişim |
|---|---|---|---|
| C1 − C0 | −2,76 [−3,49; −2,03] | +0,64 [+0,02; +1,26] | −3,40 [−4,37; −2,44] |
| C2 − C0 | −0,83 [−1,12; −0,54] | +0,30 [+0,06; +0,54] | −1,13 [−1,48; −0,78] |
| C3 − C0 | −0,15 [−0,39; +0,08] | +0,12 [−0,18; +0,41] | −0,27 [−0,58; +0,04] |
| C4 − C0 | −0,25 [−0,54; +0,04] | −0,08 [−0,43; +0,26] | −0,17 [−0,58; +0,25] |

**Deney 2 (EEGNet), üç veri kümesi birlikte, 32 kişi**

| Koşul | Kişi sayısı | Eğitim doğruluğu (%) | Test doğruluğu (%) | Fark: eğitim − test (puan) |
|---|---|---|---|---|
| S0 | 32 | 98,41 | 72,51 | 25,90 |
| W0 | 32 | 97,72 | 73,37 | 24,35 |
| W1 | 32 | 95,59 | 73,74 | 21,85 |
| W2 | 32 | 97,88 | 73,26 | 24,62 |
| W3 | 32 | 98,35 | 72,67 | 25,67 |

**Deney 2: W0'a göre farklar (puan)**

| Karşılaştırma | Eğitim doğruluğu farkı | Test doğruluğu farkı | Eğitim–test farkındaki değişim |
|---|---|---|---|
| W1 − W0 | −2,13 [−2,82; −1,44] | +0,37 [−0,22; +0,97] | −2,50 [−3,25; −1,75] |
| W2 − W0 | +0,16 [+0,02; +0,31] | −0,11 [−0,40; +0,19] | +0,27 [−0,06; +0,60] |
| W3 − W0 | +0,63 [+0,33; +0,92] | −0,70 [−1,35; −0,05] | +1,32 [+0,63; +2,01] |

**Lee2019 (EEGNet), 54 kişi**

| Koşul | Kişi sayısı | Eğitim doğruluğu (%) | Test doğruluğu (%) | Fark: eğitim − test (puan) |
|---|---|---|---|---|
| S0 | 54 | 99,96 | 63,56 | 36,40 |
| W0 | 54 | 99,97 | 63,26 | 36,71 |
| W1 | 54 | 99,81 | 63,79 | 36,03 |
| W2 | 54 | 99,97 | 63,30 | 36,66 |
| W3 | 54 | 99,99 | 62,99 | 37,00 |
| W4 | 54 | 99,96 | 63,43 | 36,53 |

**Lee2019: W0'a göre farklar (puan)**

| Karşılaştırma | Eğitim doğruluğu farkı | Test doğruluğu farkı | Eğitim–test farkındaki değişim |
|---|---|---|---|
| W1 − W0 | −0,15 [−0,24; −0,06] | +0,53 [+0,08; +0,98] | −0,68 [−1,13; −0,24] |
| W2 − W0 | 0,00 [−0,01; +0,01] | +0,05 [−0,13; +0,22] | −0,05 [−0,22; +0,13] |
| W3 − W0 | +0,02 [−0,01; +0,05] | −0,27 [−0,76; +0,22] | +0,29 [−0,20; +0,78] |
| W4 − W0 | −0,01 [−0,02; 0,00] | +0,17 [0,00; +0,35] | −0,18 [−0,36; −0,01] |

**Ne görülüyor:**

- **Deney 1'de** birikimli müzakere (C1, C0'a göre): eğitim doğruluğu −2,76 [−3,49; −2,03], test doğruluğu +0,64 [+0,02; +1,26], eğitim–test farkı −3,40 [−4,37; −2,44] puan. Eğitime uyum ölçülebilir biçimde azalıyor.
- **Deney 2'de** aynı kural (W1, W0'a göre): eğitim doğruluğu −2,13 [−2,82; −1,44], test doğruluğu +0,37 [−0,22; +0,97], eğitim–test farkı −2,50 [−3,25; −1,75] puan.
- **Lee2019'da** eğitim doğruluğu bütün koşullarda %99,81 ile %99,99 arasında. W1'in W0'a göre eğitim doğruluğu farkı −0,15 [−0,24; −0,06], test doğruluğu farkı +0,53 [+0,08; +0,98], eğitim–test farkındaki değişim −0,68 [−1,13; −0,24] puan. Eğitim–test farkındaki daralmanın büyük kısmı test tarafından geliyor; eğitim tarafındaki değişim yalnız 0,15 puan. Bu veri kümesinde "müzakere eğitime uymayı azaltıyor" denemez; ağ eğitim verisini her koşulda neredeyse tamamen öğreniyor.
- Eğitim–test farkı her koşulda büyük: Deney 1'de 14,8–18,2, Deney 2'de 21,8–25,9, Lee2019'da 36,0–37,0 puan.

**Makaleye etkisi:** v1.8'e "eğitime uyum" başlıklı kısa bir alt bölüm ve bir tablo giriyor. Metin yansız yazılıyor: aşırı öğrenme çerçevesi ilk iki deneyde ölçümle uyumlu, Lee2019'da değil.

## 2. "Kapı" ne kadar açık kalıyor? (W2 koşulu)

**Neden:** W2'de hedef yalnız ağın o an doğru bildiği eğitim denemelerinde güncellenir ("kapı açık"). Kapı neredeyse hep açıksa W2 ile kapısız W4 fiilen aynı koşuldur; makale bunu sayıyla söylemeliydi.

**Lee2019, 270 eğitim (W2):**

| Eğitim aşaması (0'dan) | Bu aşamada kullanılan hedefin güncelleme oranı | Kapının açık olduğu denemelerin payı (ortalama) | En düşük (tek eğitim) | Kapısı hep açık eğitim sayısı |
|---|---|---|---|---|
| 1 | 0,00 | %82,2 | %63 | 3 / 270 |
| 2 | 0,03 | %89,0 | %73 | 20 / 270 |
| 3 | 0,06 | %95,4 | %83 | 55 / 270 |
| 4 | 0,09 | %98,2 | %88 | 122 / 270 |
| 5 | 0,12 | %99,3 | %90 | 195 / 270 |
| 6 | 0,15 | %99,7 | %91 | 234 / 270 |
| 7 | 0,18 | %99,9 | %94 | 249 / 270 |
| 8 | 0,21 | %100,0 | %97 | 259 / 270 |
| 9 | 0,24 | %100,0 | %97 | 264 / 270 |

Aşama 0 ve 1 etiketin kendisiyle eğitilir (aşama 1'in oranı sıfırdır); kapı aşama 2'den itibaren işe yarar. Güncelleme oranıyla tartıldığında kapının geri çevirdiği pay yalnız %0,9. **Sonuç:** Lee2019'da W2 ile W4 neredeyse aynı işlemi yapıyor; ikisinin sonuçlarının yakın çıkması beklenen bir şeydir ve makalede böyle yazılacak.

**Deney 2, W2 — kapının açık olduğu pay (aşama 2 → son aşama):**

- D1: %77,6 → %94,5
- D3: %90,8 → %99,7
- D4: %85,8 → %96,4

İlk veri kümelerinde kapı Lee2019'dakinden daha sık kapalı; orada W2'nin kapısı gerçekten bir şey yapıyor.

## 3. İki karar kuralı aynı kararı veriyor mu?

**Neden:** Walsh çıktılı ağda sınıf iki yoldan seçilebilir: çıktıya en yakın kod sözcüğü, ya da iki sınıfa verilen olasılıklardan büyük olanı. Makale doğruluğu birinciyle, olasılık ölçülerini ikinciyle hesaplıyor; ikisi farklı karar veriyorsa bu söylenmeliydi.

**Sonuç:** Kayıtlı 238.040 Walsh test denemesinin 0 tanesinde iki kural farklı karar verdi (Lee2019: 135.000 deneme, beş koşul; Deney 2: 103.040 deneme, dört koşul, üç veri kümesi). İki kural bu verilerde birebir aynı kararı veriyor; makaleye bir cümle olarak giriyor.

## 4. Lee2019'da olasılık ölçüleri: ham ve 8'e bölünmüş

**Neden:** Walsh çıktısında iki sınıfın puanı 16 bitten gelir; iki kod sözcüğünün ayrıştığı 8 bit yüzünden olasılıklar aşırı keskinleşir ve "olasılık hatası" ölçüsü (NLL: doğru sınıfa verilen olasılığın eksi logaritması; küçük olması iyi) büyür. Makale ilk veri kümelerinde puanları sabit 8'e bölerek de rapor veriyordu; Lee2019 için bu denetim eksikti. Buradaki 8 sabittir, veriden ayarlanmamıştır. ECE, ağın güveni ile gerçek doğruluğu arasındaki uyumsuzluktur (küçük olması iyi).

| Koşul | Test doğruluğu (%) | NLL (ham) | NLL (8'e bölünmüş) | ECE (ham) | ECE (8'e bölünmüş) | Son kullanılan hedefin etiketten uzaklığı |
|---|---|---|---|---|---|---|
| S0 | 63,56 | 1,132 | — | 0,246 | — | — |
| W0 | 63,26 | 5,044 | 0,951 | 0,356 | 0,233 | 0,0000 |
| W1 | 63,79 | 3,886 | 0,783 | 0,343 | 0,198 | 0,2053 |
| W2 | 63,30 | 4,859 | 0,921 | 0,353 | 0,229 | 0,0318 |
| W3 | 62,99 | 2,948 | 0,713 | 0,338 | 0,179 | 0,3394 |
| W4 | 63,43 | 4,867 | 0,923 | 0,353 | 0,229 | 0,0320 |

S0 sıradan çıktılıdır; 8'e bölme ona uygulanmaz.

**Ne görülüyor:**

- 8'e bölününce Walsh koşullarının NLL değeri 0,71–0,95 aralığına iniyor ve S0'ın ham değerinin (1,132) altında kalıyor. Ham NLL'deki büyük farkın kaynağı keskinliktir, yanlış karar değil.
- Koşullar hedefin etiketten uzaklığına göre sıralandığında NLL aynı sırayla düşüyor:
  - W0: uzaklık 0,0000 → NLL 5,04 (8'e bölünmüş 0,951), test doğruluğu %63,26
  - W2: uzaklık 0,0318 → NLL 4,86 (8'e bölünmüş 0,921), test doğruluğu %63,30
  - W4: uzaklık 0,0320 → NLL 4,87 (8'e bölünmüş 0,923), test doğruluğu %63,43
  - W1: uzaklık 0,2053 → NLL 3,89 (8'e bölünmüş 0,783), test doğruluğu %63,79
  - W3: uzaklık 0,3394 → NLL 2,95 (8'e bölünmüş 0,713), test doğruluğu %62,99
- Bu sıra doğruluk sırasıyla aynı değil. NLL'deki düşüş, hedefin etiketten uzaklaşmasıyla (ağın daha az keskin çıktı vermeye itilmesiyle) birlikte geliyor; "müzakere olasılıkları daha doğru yapıyor" demek için tek başına yeterli değil. Makalede "daha iyi kalibre" ifadesi bu sınırla birlikte yazılacak.

## 5. Hedefte etiketin ve tahminin payı (cebir)

Birikimli kuralda (W1) son kullanılan hedefte etiketin payı 0,306, tahminlerin toplam payı 0,694. Çapalı kuralda (W2, W4) tahminin payı en çok 0,24. Yani W1 ile W4 arasındaki fark yalnız "eskiyi biriktirme" değil, aynı zamanda tahmine verilen payın büyüklüğüdür. Yeni W5 koşulu bu ikisini ayırmak için eklendi.

## 6. Bağımsız doğrulama

Bu sayıları, hesabı yazan oturumun kodunu kullanmayan ayrı bir yardımcı oturum, kayıt dosyalarından kendi yazdığı kodla yeniden hesapladı. `SAYILAR-V1.0.json` içindeki 1.473 sayının hepsi doğrulandı; en büyük mutlak fark 4,3 × 10⁻¹⁴ (yuvarlama düzeyi). Ayrıntı: `C:\EEG_study_except_for_datasets\EEG_study_except_for_datasets\EEG_study_except_for_datasets\MEVCUT_KAYITLARDAN_SAYILAR-V1.0\bagimsiz_kontrol\KARSILASTIRMA.md`.

Bağımsız kontrolün eklediği üç bilgi:

1. NLL hesabında olasılığa konan alt sınır (10⁻¹²), 27.000 Lee2019 test denemesinin şu kadarında devreye giriyor: S0 7, W0 1.582, W1 703, W2 1.432, W3 231, W4 1.439. 8'e bölünmüş hesapta hiç devreye girmiyor. Ham NLL ortalamaları bu yüzden alt sınır seçimine duyarlıdır; makalenin ek bilgi dosyasına not olarak girecek.
2. Lee2019'da eğitim doğruluğu, koşul başına 270 eğitimin 239–268'inde tam %100. Bu, 1. bölümdeki "eğitim–test farkındaki değişim test tarafından geliyor" tespitini destekler.
3. Üç ortalama fark tam sıfırdır; tablolarda işaretsiz yazılır.

## 7. Sınırlar

- Bu sayılar daha önce incelenmiş verilerden, sonradan çıkarılmıştır; keşif amaçlı ve betimseldir.
- Aralıklar tek tek %95 aralıklardır; birlikte okunduklarında yanlış alarm olasılığı %5'ten büyüktür.
- Deney 1 ve Deney 2'de ilk iki veri kümesi yöntem geliştirilirken kullanılmıştı; buradaki sayılar o deneylerin doğrulayıcı kanıtı değildir.

— Claude (Anthropic) · model kimliği `claude-fable-5-2` (oturum yapılandırması; hizmet veren model değişebilir) · 12.11.2026

