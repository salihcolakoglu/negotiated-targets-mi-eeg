# Supplementary analysis data for JNM manuscript V4.4

This package supports numerical checking of the completed CSP–CNN and EEGNet follow-up experiments in *Walsh-coded and negotiated targets for motor imagery EEG decoding: a controlled evaluation of accuracy and confidence*. It contains analysis data and a new independent verification script. It contains no original model-training implementation, model weights, or raw EEG recordings. It does not run any training or download data.

## Contents

- `e1_e2_all_1415_runs_verified_v4.csv`: one row per completed training run; accuracy and available scalar metrics.
- `e1_e2_subject_seed_means_verified_v4.csv`: 365 participant/condition/code rows, with seed means and seed variability.
- `e1_e2_paired_participant_differences_verified_v4.csv`: 288 paired participant rows, covering eight main contrasts and the descriptive EEGNet W0–S0 contrast.
- `verified_e1_e2_tables_v4.json`: unchanged copy of the independent analysis summary used when preparing the manuscript. Some fields document checks of the original project rather than checks reproducible from this reduced package.
- `e1_records_sanitized_v4.json`: 615 records projected onto experiment identifiers and scalar analysis metrics.
- `e2_records_sanitized_v4.json`: 800 records projected onto identifiers, scalar metrics, sample counts, prediction-file basenames and SHA-256 hashes. Machine paths, runtime/device fields, elapsed times, original code/plan identity fields, and duplicated prediction lists are excluded.
- `eegnet_predictions/`: 800 unchanged NumPy `.npz` files containing saved train/test model outputs, class labels, and the final used targets where applicable.
- `verify_supplement_v4.py`: standalone consistency checker using NumPy and the Python standard library only.
- `MANIFEST_SHA256.txt`: SHA-256 hashes of every package file other than the manifest itself.

The three CSV files and analysis-summary JSON are byte-identical copies of the manuscript preparation outputs. Their `source_file`, `source_line`, and `input_hashes` fields are provenance labels. They do not require access to the original project folders. The checker uses only files in this package.

## Experiment and data identifiers

| Identifier | Public source dataset | Participants | Training/test trials per participant |
|---|---|---:|---:|
|D1|BNCI2014-001 / BCI Competition IV dataset 2a|9|288/288|
|D3|BNCI2014-002|14|80/80|
|D4|BNCI2014-004 / BCI Competition IV dataset 2b|9|120/160, except participant B08: 160/160|

The independent biological sample comprises 32 participants. Repeated runs and seeds do not increase that sample size.

E1 contains five CSP–CNN conditions and three seeds: 480 runs use code set K1 across all 32 participants; 135 additional runs compare code set K2 in D1. C0 uses fixed targets; C1 cumulative negotiation; C2 label-anchored negotiation; C3 correctness-gated label anchoring; C4 bit-level smoothing towards 0.5. The four main comparisons are C1–C0, C3–C0, C3–C1, and C2–C4, using K1.

E2 contains five EEGNet conditions and five seeds: 800 runs across the same 32 participants. S0 uses conventional class outputs; W0 fixed Walsh targets; W1 cumulative negotiation; W2 correctness-gated label anchoring; W3 class-level smoothing in code space. The four main comparisons are W1–W0, W2–W0, W2–W1, and W2–W3. W3 differs from E1 C4: its target is mixed with the mean of the class codewords, rather than moving every coordinate to 0.5.

Accuracy fields are proportions between 0 and 1; differences with suffix `_pp` are percentage points. Each paired estimate first averages seeds within a participant. Two-sided paired t tests and pointwise 95% t confidence intervals are then calculated across 32 participants. Holm correction is applied separately to each experiment's four-comparison family. The confidence intervals are not simultaneous/multiplicity-adjusted intervals. The follow-ups reused benchmark test sets from earlier development and are exploratory; non-significance does not imply equivalence.

## Run the verification

Requirements: Python 3.10 or newer and NumPy. No SciPy, pandas, TensorFlow, PyTorch, or other training library is required. Install NumPy through your usual approved environment-management process if necessary.

From any working directory:

```text
python /path/to/Analysis_Data_v4.0/verify_supplement_v4.py
```

On Windows, quote paths containing spaces. To save the JSON result, use a new report path outside the package:

```text
python verify_supplement_v4.py --report ../verification_result.json
```

The checker never overwrites an existing report. It reads package-relative inputs, performs no network access, and leaves the package unchanged. Success prints a JSON object with `"status": "PASS"` and exits 0. A failed check prints a reason and exits 1.

The checker verifies the manifest, record completeness/uniqueness, all three CSV levels, the eight primary paired t/CI/effect-size/Holm calculations against the supplied summary, all 800 prediction hashes, and train/test accuracy from the saved EEGNet outputs. It additionally recomputes available EEGNet NLL, ECE, test binary cross-entropy, posterior-based accuracy, target distance, and target assignment checks. NumPy files are read with `allow_pickle=False`.

The Walsh classification rule is Euclidean nearest-codeword assignment. Its NLL/ECE use a class posterior constructed from independent Bernoulli bit probabilities and restricted to the class codewords; that probability mapping differs from the classification rule. Softmax probabilities are used directly for S0. These implementation choices are explicit in the checker and manuscript.

This package cannot independently recreate EEG preprocessing, regenerate the training runs, verify E1 logits that were not retained, or establish the authors' scientific approval. E1 calculations are checked from retained scalar records. The supplied summary's Wilcoxon/Shapiro/bootstrap or classical-reference fields, where present, are not recomputed by this reduced checker.

## Rights and release status

Code for data preparation, training and analysis of the two matched-budget experiments and the CSP–LDA reference is publicly available under the MIT license at https://github.com/salihcolakoglu/negotiated-targets-mi-eeg (code package v2.0, commit 63286819027270c790a626d36f29b6ae121570ae). The original EEG recordings remain subject to their providers’ terms and are not redistributed in this supplementary archive. This archive contains derived analysis records and retained predictions; its standalone checker does not run training. The original internal data-folder name is retained to preserve existing relative paths.

The new verification script was prepared with GPT-based Codex assistance; its numerical routines were adapted from the independent v4 audit, with no original experiment-training code included. The authors remain responsible for reviewing the package and its use. The data files retain participant numbers from publicly distributed research datasets; no direct personal identifiers or private computer paths were added.
