SUPPLEMENTARY DATA 1, VERSION 1.13 (file Supplementary-Data-1-v1.13.zip)
Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding:
A Controlled Evaluation of Accuracy and Confidence
S. Colakoglu, M. Onat, N. Korhan

This file accompanies manuscript version 1.13 and its Supplementary Information. It holds
the numerical records of Experiments 1, 2 and 3. The second supplementary data file of the
submission, Supplementary-Data-2-v1.13.zip, holds the S1/W5 control, the record-based
summaries, the classical-pipeline and resource files and the equivalence and sensitivity
analysis. The third, Supplementary-Data-3-v1.13.zip, holds the three additional sensitivity
analyses of Supplementary Section S19.


WHAT CHANGED IN VERSIONS 1.9 TO 1.13

Version 1.9 (15 November 2026) changed only this README and SHA256_MANIFEST.json (its entry
for this README, its version field and one added note). Every other file is byte-identical
to the earlier file
Supplementary_Data-V1.2.zip (35,969,231 bytes, SHA-256
6724b9a7cac8d6eae5e5cc1c612c331da9bfc19af125ecd21a0c3c67e408b226). The earlier README had
an outdated header (V1.1, 18 October 2026) and outdated statements about the public
software release; both were corrected.

Versions 1.10 (16 November 2026), 1.11, 1.12 (both 17 November 2026) and 1.13 (18 November
2026) changed only this
README (the version and the names of the three data files) and, in SHA256_MANIFEST.json, the
entry for this README, the version field and the note. This file was named
Supplementary-Data-1-v1.9.zip on 15 November 2026 (SHA-256
55c073c3b03ffd7ca8ae91af1001a438a089a4cb690d46d31a4d8a0776b77f3c),
Supplementary-Data-1-v1.10.zip on 16 November 2026 (SHA-256
0dc853afbe97c6ce5a36e8d7c61065491ff2fbefe476ec952d5ce99f8423f9af) and
Supplementary-Data-1-v1.11.zip earlier on 17 November 2026 (SHA-256
36d58e451e17fe323fc613849da44bbf8fae0d9d96be77f05aa944a9753d4554) and
Supplementary-Data-1-v1.12.zip later that day (SHA-256
ad634fddad905c70c1073c87367e7e2f7f8bfc0d5e024f5b6a55e5249a54e587); records written on
15 November use the first name, for example in the folder new_computations/ of the third
data file. All other files are byte-identical in the five versions. From version 1.13 the
three data files are also published in folder supplementary_data/ of software release
v2.3.0 of the repository https://github.com/salihcolakoglu/negotiated-targets-mi-eeg.


CONTENTS

legacy/
    All 809 files of the numerical supplement of Experiments 1 and 2 (named
    Supplementary_Data-V4.4.zip in the manifest), unmodified: the 1,415 controlled fits
    (615 CSP-CNN fits of Experiment 1 and 800 EEGNet fits of Experiment 2), the 800 EEGNet
    prediction files, summaries and checks. Experiment 1 stored scalar metrics for each fit
    and no trial-level predictions, so its results can be checked from the run records but
    not from predictions.

lee2019/
    Experiment 3: the pre-specified cross-day evaluation on Lee2019, with 54 participants
    who were not part of Experiments 1 and 2.
    results/worker_01/records/      1,350 EEGNet fit records (54 participants x 5 conditions
                                    x 5 seeds)
    results/worker_01/predictions/  1,350 NPZ files: output arrays, targets and labels
    all_1350_fit_metrics.csv        the scalar results of all fits, full precision
    classical_results/              54 six-feature two-ended CSP-LDA references (one fit per
                                    participant)
    final_analysis/                 participant means, descriptive results, the five planned
                                    paired contrasts with Holm correction, completion
                                    accounting
    protocol/                       the protocol (DENEY_PROTOKOLU-V1.0.json), its SHA-256
                                    value and the record of the excluded training-only
                                    timing pilot
    code/, prepare/, ops/           the scripts, adapter checks and package requirements
    preparation_metadata/           54 records of the paired days, covering 108 source
                                    recordings (no EEG signals)
    execution_environment/          run identity, packages, GPU and deterministic-mode
                                    records

provenance/
    Licence, citation and attribution files of the earlier public release v2.1.0.

Raw EEG, prepared signal arrays and model or optimizer checkpoints are not included.
Source EEG of Experiment 3: DOI 10.5524/100542 (CC0 1.0); data paper DOI
10.1093/gigascience/giz002. The provider's file 100542.md5 is kept under lee2019/prepare/.
The source data of Experiments 1 and 2 are the BNCI Horizon 2020 data sets 001-2014,
002-2014 and 004-2014; the manuscript gives their sources.


THE PROTOCOL OF EXPERIMENT 3 AND ITS DATING

The protocol file carries the time stamp 2026-10-18T09:09:39+03:00 and has the SHA-256 value
493378c9982feff6182216eb7406f68799e1435284cd80d39d91b258130fcab8. The 1,350 fit records were
completed between 09:11 and 14:03 (UTC+3) on the same day; each names the SHA-256 values of
the three training-code files that the protocol lists. The 54 classical-reference records
name the SHA-256 value of the protocol file. The protocol was not registered with an
external service. Its first public record is software release v2.2.0 of 20 October 2026,
two days after the fits. The time stamps of 18 October were written by the authors'
computer and cannot be checked by a third party.


RELATION TO THE PUBLIC SOFTWARE RELEASE

Software release v2.2.0 (https://doi.org/10.5281/zenodo.23504655, repository
https://github.com/salihcolakoglu/negotiated-targets-mi-eeg) holds the code and records of
Experiments 1 to 3 and of the calibration, SHU and W4 controls. This file is the
supplementary copy of the records of Experiments 1 to 3 for the journal. The older DOI
10.5281/zenodo.23290274 identifies release v2.1.0, which covers Experiments 1 and 2 only.


HOW THE RESULTS WERE ANALYZED

Seeds are averaged within each participant and condition (n = 32 in Experiments 1 and 2,
n = 54 in Experiment 3). Experiment 3: primary contrast W2-W0; one Holm family of exactly
five contrasts, W2-W0, W1-W0, W2-W1, W2-W3 and W0-S0. The 95% confidence intervals concern
one contrast at a time and are not adjusted for multiplicity. NLL and ECE are descriptive.
The 32 participants of Experiments 1 and 2 and the 54 participants of Experiment 3 are not
pooled. The six-filter CSP-LDA reference of Experiment 3 differs from the three-filter
binary reference of Experiments 1 and 2.


NAMES AND WORDING INSIDE THE RECORDS

The records were written during the work and are kept unchanged. Some carry Turkish names:
the study identifier LEE2019_BAGIMSIZ_DOGRULAMA ("Lee2019 independent validation") is the
working name of Experiment 3, and DENEY_PROTOKOLU means "experiment protocol". Where the
records use the word "independent", they refer to participants and data that were not used
in Experiments 1 and 2, or to a check made by a separate script or AI session within the
authors' work. They do not mean a verification by an independent party. Some records
contain file paths of the authors' computer; the paths carry no scientific content.


HOW TO CHECK THE FILES

Unzip the file and run

    python verify_package.py

(Python standard library only). It compares all 3,770 files with SHA256_MANIFEST.json (the
manifest itself excepted) and counts the Experiment 3 records.

The Experiment 3 analysis can be recomputed from the extracted folder (NumPy and SciPy
required; see lee2019/ops/requirements-lock.txt; one command line):

    python lee2019/code/analysis/final_analysis.py --results lee2019/results --out recheck
        --csp-csv lee2019/classical_results/classical_summary.csv

It verifies completeness before the tests. The verification script of Experiments 1 and 2
is legacy/Analysis_Data_v4.0/verify_supplement_v4.py (see the README.md in that folder).
None of these checks repeats EEG preprocessing or model training.


LICENSES

Code: MIT (see provenance/earlier_release_LICENSE). Explanatory material and result tables
created by the authors: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. External
data and the unchanged legacy files keep their recorded terms.


USE OF AI TOOLS

AI-assisted preparation used Claude (Anthropic) and Codex (OpenAI); the Acknowledgment of
the manuscript states the scope.
