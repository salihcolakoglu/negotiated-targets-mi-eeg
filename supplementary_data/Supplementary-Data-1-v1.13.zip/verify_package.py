"""Check every packaged file and complete Lee result/prediction counts."""
from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
manifest = json.loads((root / "SHA256_MANIFEST.json").read_text(encoding="utf-8"))
for name, entry in manifest["files"].items():
    data = (root / name).read_bytes()
    assert len(data) == entry["bytes"], name
    assert hashlib.sha256(data).hexdigest() == entry["sha256"], name
assert len(list((root / "lee2019/results/worker_01/records").glob("*.json"))) == 1350
assert len(list((root / "lee2019/results/worker_01/predictions").glob("*.npz"))) == 1350
assert len(list((root / "lee2019/classical_results").glob("subject_*_classical.json"))) == 54
assert len(list((root / "lee2019/classical_results").glob("subject_*_classical_predictions.npz"))) == 54
print("PASS:", len(manifest["files"]), "SHA-256 payload checks; 1350 Lee fits/predictions; 54 CSP-LDA records/predictions")
