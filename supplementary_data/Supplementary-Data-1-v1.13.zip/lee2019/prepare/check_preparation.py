"""Focused checks for day separation, class mapping and signal shape.

No participant data or training is involved. MNE/SciPy checks run only when
those dependencies are available; the report lists any skipped checks.
"""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import prepare_lee2019 as prep


def synthetic_fields():
    # Two classes, four events, known 10 Hz activity, 62 EEG channels.
    samples = np.arange(20000, dtype=np.float64)
    signal = np.tile((20.0 * np.sin(2 * np.pi * 10 * samples / 1000.0))[:, None], (1, 62))
    return {
        "signal_uV": signal, "sampling_hz": 1000.0,
        "channel_names": [f"EEG{i:02d}" for i in range(62)],
        "event_samples": np.array([0, 5000, 10000, 15000]),
        "source_codes": np.array([2, 1, 2, 1]),
        "source_class_mapping": {"left": 2, "right": 1},
    }


class FormatChecks(unittest.TestCase):
    def test_01_official_checksum_lookup(self):
        self.assertEqual(prep.checksum_entry(Path(__file__).with_name("100542.md5"), 1, 1),
                         "5f4efd43bd9d4164a777362062a7e6a5")

    def test_02_source_classes_and_events(self):
        fields = prep.validate_fields(synthetic_fields(), expected_trials=4)
        self.assertEqual(fields["event_samples"].tolist(), [0, 5000, 10000, 15000])
        fields["source_class_mapping"] = {"left": 1, "right": 2}
        with self.assertRaisesRegex(ValueError, "class mapping"):
            prep.validate_fields(fields, expected_trials=4)

    def test_03_duplicate_events_fail(self):
        fields = synthetic_fields()
        fields["event_samples"][1] = 0
        with self.assertRaisesRegex(ValueError, "increasing"):
            prep.validate_fields(fields, expected_trials=4)

    def test_04_incomplete_epoch_fails(self):
        fields = synthetic_fields()
        fields["event_samples"][-1] = 19999
        with self.assertRaisesRegex(ValueError, "outside"):
            prep.validate_fields(fields, expected_trials=4)

    def test_05_emg_channel_fails(self):
        fields = synthetic_fields()
        fields["channel_names"][-1] = "EMG1"
        with self.assertRaisesRegex(ValueError, "without EMG"):
            prep.validate_fields(fields, expected_trials=4)

    @unittest.skipUnless(importlib.util.find_spec("scipy"), "SciPy unavailable")
    def test_06_mat_offline_variable_only(self):
        from scipy.io import savemat
        fields = synthetic_fields()
        mapping = np.empty((2, 2), dtype=object)
        mapping[:] = [[np.array([[2]]), np.array(["left"])],
                      [np.array([[1]]), np.array(["right"])]]
        offline = {"x": fields["signal_uV"], "fs": 1000,
                   "chan": np.array(fields["channel_names"], dtype=object),
                   "t": fields["event_samples"], "y_dec": fields["source_codes"], "class": mapping}
        with tempfile.TemporaryDirectory() as directory:
            mat_path = Path(directory) / "synthetic.mat"
            savemat(mat_path, {"EEG_MI_train": offline, "EEG_MI_test": np.array(["MUST_NOT_BE_LOADED"])})
            loaded = prep.validate_fields(prep.read_offline_fields(mat_path), expected_trials=4)
            self.assertEqual(loaded["source_class_mapping"], {"left": 2, "right": 1})
            np.testing.assert_array_equal(loaded["signal_uV"], fields["signal_uV"])

    @unittest.skipUnless(importlib.util.find_spec("mne"), "MNE unavailable")
    def test_07_epoch_resample_mapping_units(self):
        fields = prep.validate_fields(synthetic_fields(), expected_trials=4)
        X, y, details = prep.preprocess(fields)
        self.assertEqual(X.shape, (4, 62, 512))
        self.assertEqual(details["source_epoch_samples_inclusive"], 4001)
        self.assertEqual(details["output_epoch_samples"], 512)
        np.testing.assert_array_equal(y, [0, 1, 0, 1])
        self.assertEqual(X.dtype, np.float32)
        self.assertEqual(y.dtype, np.int64)
        self.assertGreater(float(np.std(X[1, 0])), 10.0)  # microvolts, not volts
        self.assertLess(float(np.std(X[1, 0])), 20.0)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(FormatChecks)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(json.dumps({"tests_run": result.testsRun, "failures": len(result.failures),
                      "errors": len(result.errors), "skipped": [reason for _, reason in result.skipped],
                      "successful": result.wasSuccessful()}, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
