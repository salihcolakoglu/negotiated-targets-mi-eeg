"""Synthetic checks for the new, explicitly six-feature contextual reference."""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import classical_reference as reference


class ReferenceChecks(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(20261018)
        self.X = rng.standard_normal((24, 10, 256))
        self.y = np.tile([0, 1], 12)
        self.X[self.y == 0, :3] *= 4.0
        self.X[self.y == 1, -3:] *= 4.0

    def test_01_six_unique_endpoint_filters(self):
        W, indices = reference.fit_csp(self.X, self.y)
        np.testing.assert_array_equal(indices, [0, 1, 2, 7, 8, 9])
        self.assertEqual(W.shape, (6, 10))
        self.assertEqual(len(np.unique(indices)), 6)
        features = reference.csp_transform(self.X, W)
        self.assertEqual(features.shape, (24, 6))

    def test_02_heldout_transform_cannot_refit_spatial_filters(self):
        W, _ = reference.fit_csp(self.X, self.y)
        frozen = W.copy()
        heldout = np.random.default_rng(7).standard_normal((7, 10, 256)) * 999.0
        reference.csp_transform(heldout, W)
        np.testing.assert_array_equal(W, frozen)
        np.testing.assert_array_equal(reference.fit_csp(self.X, self.y)[0], frozen)

    def test_03_metric_definitions(self):
        result = reference.class_metrics(np.array([[0.8, 0.2], [0.2, 0.8]]), np.array([0, 1]))
        self.assertEqual(result["acc"], 1.0)
        self.assertAlmostEqual(result["nll"], -np.log(0.8), places=14)
        self.assertAlmostEqual(result["ece"], 0.2, places=14)

    @unittest.skipUnless(importlib.util.find_spec("sklearn") and importlib.util.find_spec("scipy"), "SciPy/scikit-learn unavailable")
    def test_04_lda_defaults_and_probability_order(self):
        from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
        W, _ = reference.fit_csp(self.X, self.y)
        lda = LinearDiscriminantAnalysis().fit(reference.csp_transform(self.X, W), self.y)
        self.assertEqual(lda.solver, "svd")
        self.assertIsNone(lda.shrinkage)
        np.testing.assert_array_equal(lda.classes_, [0, 1])
        prob = lda.predict_proba(reference.csp_transform(self.X[:3], W))
        self.assertEqual(prob.shape, (3, 2))
        np.testing.assert_allclose(prob.sum(1), 1.0)

    def _completed_fixture(self, directory):
        data, out = Path(directory) / "data", Path(directory) / "out"
        data.mkdir()
        out.mkdir()
        paths = {"metadata": data / "subject_01_meta.json", "train": data / "subject_01_train.npz", "test": data / "subject_01_test.npz"}
        paths["metadata"].write_text('{"synthetic_resume_fixture": true}', encoding="utf-8")
        for split in ("train", "test"):
            np.savez(paths[split], **{f"X_{split}": np.zeros((2, 1, 1), dtype=np.float32), f"y_{split}": np.array([0, 1], dtype=np.int64)})
        pred = out / "subject_01_classical_predictions.npz"
        np.savez(pred, synthetic_fixture=np.array([1, 2]))
        protocol = {"filename": "synthetic_protocol.json", "sha256": "synthetic_protocol_hash"}
        row = {"reference_id": reference.REFERENCE_ID, "dataset": "Lee2019_MI", "subject": 1,
               "protocol": protocol, "script_sha256": "synthetic_script_hash", "n_train": 100, "n_test": 100,
               "n_features": 6, "lda": {"classes": [0, 1]},
               "input_provenance": {name: {"filename": path.name, **reference.file_hashes(path)} for name, path in paths.items()},
               "predictions": {"filename": pred.name, **reference.file_hashes(pred)}}
        for split in ("train", "test"):
            row.update({f"acc_{split}": 0.5, f"nll_{split}": float(np.log(2.0)), f"ece_{split}": 0.0})
        reference.atomic_json(out / "subject_01_classical.json", row)
        return data, out, protocol, paths, pred

    def test_05_complete_resume_identity_and_hashes(self):
        with tempfile.TemporaryDirectory() as directory:
            data, out, protocol, _, _ = self._completed_fixture(directory)
            self.assertTrue(reference.validate_completed_result(data, out, 1, protocol, "synthetic_script_hash"))
            with self.assertRaisesRegex(RuntimeError, "protocol or code changed"):
                reference.validate_completed_result(data, out, 1, protocol, "different_script_hash")

    def test_06_resume_rejects_changed_input_or_predictions(self):
        with tempfile.TemporaryDirectory() as directory:
            data, out, protocol, paths, pred = self._completed_fixture(directory)
            paths["metadata"].write_text('{"changed": true}', encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "input bytes changed"):
                reference.validate_completed_result(data, out, 1, protocol, "synthetic_script_hash")
        with tempfile.TemporaryDirectory() as directory:
            data, out, protocol, paths, pred = self._completed_fixture(directory)
            pred.write_bytes(b"changed prediction bytes")
            with self.assertRaisesRegex(RuntimeError, "prediction checksum changed"):
                reference.validate_completed_result(data, out, 1, protocol, "synthetic_script_hash")

    def test_07_orphan_preserved_before_recomputation(self):
        with tempfile.TemporaryDirectory() as directory:
            data, out, protocol, _, pred = self._completed_fixture(directory)
            (out / "subject_01_classical.json").unlink()
            original = pred.read_bytes()
            self.assertFalse(reference.validate_completed_result(data, out, 1, protocol, "synthetic_script_hash"))
            preserved = reference.preserve_orphan_prediction(out, 1)
            self.assertEqual(preserved.read_bytes(), original)
            self.assertFalse(pred.exists())
            self.assertTrue(preserved.with_suffix(preserved.suffix + ".json").is_file())


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReferenceChecks))
    print(json.dumps({"tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
                      "skipped": [reason for _, reason in result.skipped], "successful": result.wasSuccessful()}, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
