[DOI] 10.5524/100542

[Title] Supporting data for "EEG Dataset and OpenBMI Toolbox for Three BCI
Paradigms: An Investigation into BCI Illiteracy"

[Release Date] 2019-01-24

[Citation] Lee, M; Kwon, O; Kim, Y; Kim, H; Lee, Y; Williamson, J; Fazli, S;
Lee, S (2019): Supporting data for "EEG Dataset and OpenBMI Toolbox for Three
BCI Paradigms: An Investigation into BCI Illiteracy" GigaScience Database.
https://dx.doi.org/10.5524/100542

[Data Type] Software,Neuroscience

[Data Summary] Electroencephalography (EEG)-based brain-computer interface (BCI)
systems are mainly divided into three major paradigms: motor-imagery (MI),
event-related potential (ERP), and steady-state visually evoked potential
(SSVEP). In this paper, we present a BCI dataset that includes the three major
BCI paradigms with a large number of subjects over multiple sessions. In
addition, information about the psychological and physiological conditions of
BCI users was obtained using a questionnaire, and task-unrelated parameters such
as resting state, artifacts, and electromyography of both arms were also
recorded. We evaluated the decoding accuracies for the individual paradigms and
determined performance variations across both, subjects and sessions.
Furthermore, we looked for more general, severe cases of BCI illiteracy than
have been previously reported in the literature.<br>
Average decoding accuracies across all subjects and sessions were 71.1%
(±0.15), 96.7% (±0.05), and 95.1% (±0.09), and rates of BCI illiteracy were
53.7%, 11.1%, and 10.2% for MI, ERP, and SSVEP, respectively. Compared to the
ERP and SSVEP paradigms, the MI paradigm exhibited large performance variations
between both, subjects and sessions. Furthermore, we found that 27.8% (15 out of
54) of users were universally BCI literate, i.e. they were able to pro ciently
perform all three paradigms. Interestingly, we found no universally illiterate
BCI user, i.e. all participants were able able to control at least one type of
BCI system. <br>Our EEG dataset can be utilized for a wide range of BCI-related
research questions. All methods for the data analysis in this study are
supported with fully open-source scripts that can aid in every step of BCI
technology. Furthermore, our results support previous but disjointed  ndings on
the phenomenon of BCI illiteracy.

[File Location] https://s3.ap-northeast-1.wasabisys.com/gigadb-datasets/live/pub/10.5524/100001_101000/100542/

[File name] - [File Description]
sess01_subj21_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj35_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj36_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj07_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj25_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj30_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj26_EEG_MI.mat6  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj18_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj02_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj12_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj09_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj18_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj39_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj52_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj42_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj39_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj25_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj45_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj38_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj45_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj26_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj14_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj45_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj22_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj26_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj29_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj34_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj37_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj50_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj39_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj17_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj30_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj10_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj11_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj2_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj23_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj17_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj47_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj21_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj46_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj2_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj20_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj19_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj33_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj04_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj25_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj44_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj21_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj09_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj35_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj41_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj42_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj1_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj24_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj30_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj53_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj29_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj16_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj3_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
readme.txt  -  
sess02_subj28_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj6_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj14_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj51_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj54_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj12_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj51_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj38_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj39_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj45_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj24_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj31_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj1_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj16_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj52_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj53_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj45_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj9_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj20_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj53_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj26_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj34_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj14_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj29_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
random_cell_order.mat  -  the index of flashing characters for the 6x6 matrix speller in the ERP paradigm
sess01_subj02_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj38_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj32_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj37_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj10_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj02_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj9_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj16_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj3_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj47_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj27_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj32_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj50_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj27_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj37_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj43_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj46_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj13_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj16_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj18_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj33_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj50_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj20_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj04_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj22_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj13_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj15_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj42_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj23_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj34_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj54_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj30_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj40_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj42_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj40_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj13_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj50_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj21_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj03_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj31_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj34_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj40_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj52_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj6_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj44_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj21_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj28_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj4_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj47_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj44_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj43_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj47_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj19_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj29_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj26_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj30_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj45_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj21_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj48_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj13_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj48_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj34_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj35_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj4_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj5_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj6_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj7_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj19_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj16_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj06_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj18_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj20_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj32_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj27_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj48_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj24_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj8_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj49_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj36_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj17_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj41_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj18_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj13_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj35_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj22_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj44_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj28_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj35_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj48_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj18_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj36_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj54_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj13_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj27_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj17_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj11_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj18_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj11_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj22_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj43_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj51_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj47_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj34_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj38_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj2_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj39_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj41_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj1_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj49_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj54_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj29_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj33_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj36_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj32_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj48_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj53_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj05_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj26_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj21_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj24_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj44_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj40_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj35_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj43_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj41_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj31_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj9_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj44_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj01_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj14_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj17_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj7_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj53_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj49_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj5_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj54_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj6_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj15_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj24_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj3_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj28_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj33_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj32_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj41_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj51_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj37_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj22_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj11_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj07_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj07_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj12_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj44_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj4_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj9_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj46_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj41_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj07_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj09_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj10_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj16_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj22_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj37_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj23_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj11_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj11_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj14_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj15_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj17_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj32_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj25_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj13_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj24_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj11_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj17_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj23_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj23_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj45_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj28_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj15_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj19_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj28_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj33_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj10_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj01_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj40_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj37_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj06_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj49_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj10_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj8_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj01_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj24_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj38_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj36_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj52_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj10_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj20_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj22_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj25_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj30_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj43_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj48_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj50_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj47_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj49_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj52_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj20_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj27_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj51_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj15_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj30_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj16_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj52_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj10_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj54_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj19_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj05_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj12_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj34_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj46_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj54_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj12_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj42_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj1_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj42_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj7_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj40_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj36_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj5_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj09_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj09_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj05_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj46_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj47_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj2_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj46_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj20_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj46_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj04_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj51_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj36_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj08_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj53_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj8_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj38_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj25_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj40_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj08_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj25_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj27_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj28_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj33_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj37_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj53_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj23_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj16_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj02_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj28_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj40_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj53_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj32_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj41_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj46_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj12_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj43_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj24_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj27_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj21_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj31_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj26_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj38_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj26_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj14_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj50_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj50_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj51_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj8_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj7_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj52_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj5_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj15_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj29_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj44_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj25_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj50_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj3_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj23_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj19_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj31_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj42_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj33_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj33_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj39_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj38_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj49_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj11_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj41_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj13_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj30_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj4_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj48_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj49_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj43_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj32_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj35_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj42_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj51_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj31_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj43_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj45_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj06_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj52_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj22_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj29_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj31_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj35_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess02_subj36_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj06_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj20_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj47_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj54_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj15_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
Questionnaire_results.csv  -  Questionnaire collecting nformation about the psychological and physiological conditions of BCI users
sess01_subj03_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj18_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj14_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess02_subj48_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj39_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj27_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj31_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj05_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj34_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess01_subj29_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj37_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj12_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj14_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj17_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj08_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj03_EEG_ERP.mat  -  mat formatted file : Electroencephalography - event-related potential
sess01_subj08_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj03_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj49_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj19_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj19_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess02_subj12_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential
sess01_subj15_EEG_Artifact.mat  -  mat formatted file : Electroencephalography - artifact
sess02_subj39_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
OpenBMI-master.zip  -  An open software package dedicated for the development of Brain-Computer Interfaces with various advanced pattern recognition algorithms. Archival copy of the github repository https://github.com/PatternRecognition/OpenBMI, downloaded 23-Nov-2018. Please refer to the GitHub repo for most recent updates.
sess02_subj23_EEG_MI.mat  -  mat formatted file : Electroencephalography - motor-imagery
sess01_subj04_EEG_SSVEP.mat  -  mat formatted file : Electroencephalography - steady-state visually evoked potential

[License]
All files and data are distributed under the CC0 1.0 Universal (CC0 1.0) Public
Domain Dedication (https://creativecommons.org/publicdomain/zero/1.0/), unless
specifically stated otherwise, see http://gigadb.org/site/term for more details.

[Comments]

[End]
