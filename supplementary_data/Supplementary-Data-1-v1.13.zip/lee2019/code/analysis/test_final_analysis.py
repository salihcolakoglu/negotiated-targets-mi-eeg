"""Synthetic verification of the prespecified final statistics and completion gate."""
import json
from pathlib import Path
import tempfile

import numpy as np
from scipy import stats

import final_analysis as analysis


def main():
    p = [0.01, 0.04, 0.03, 0.002, 0.7]
    np.testing.assert_allclose(analysis.holm_adjust(p), [0.04, 0.09, 0.09, 0.01, 0.7], rtol=0, atol=1e-15)
    rng = np.random.default_rng(1018)
    baseline = rng.uniform(0.55, 0.85, size=54)
    alternative = baseline + rng.normal(0.01, 0.02, size=54)
    got = analysis.paired_summary(alternative, baseline)
    expected = stats.ttest_rel(alternative, baseline)
    np.testing.assert_allclose(got["t_statistic"], expected.statistic, rtol=1e-13)
    np.testing.assert_allclose(got["p_two_sided"], expected.pvalue, rtol=1e-13)
    ci = expected.confidence_interval(0.95)
    np.testing.assert_allclose([got["ci95_low_percentage_points"], got["ci95_high_percentage_points"]],
                               [100 * ci.low, 100 * ci.high], rtol=1e-13)
    zero = analysis.paired_summary(baseline, baseline)
    assert zero["p_two_sided"] == 1.0 and zero["t_statistic"] == 0.0
    assert zero["ci95_low_percentage_points"] == zero["ci95_high_percentage_points"] == 0.0

    # 1350 fits must become 54 paired observations, never 270 or 1350 samples.
    fixture = {}
    offsets = {"S0": -0.01, "W0": 0.0, "W1": 0.003, "W2": 0.006, "W3": 0.002}
    for subject in analysis.SUBJECTS:
        for condition in analysis.CONDITIONS:
            for seed in analysis.SEEDS:
                # Subject-varying differences with the same declared average.
                factor = 1 + 0.2 * ((subject - 27.5) / 27.5)
                value = baseline[subject - 1] + offsets[condition] * factor + (seed - 3) * 0.001
                fixture[(subject, condition, seed)] = (dict(acc_test=float(value), nll_test=0.5, ece_test=0.1), None)
    participants, conditions, contrasts = analysis.compute_final(fixture)
    assert len(participants) == 270 and len(conditions) == 5 and len(contrasts) == 5
    assert [r["contrast"] for r in contrasts] == ["W2-W0", "W1-W0", "W2-W1", "W2-W3", "W0-S0"]
    assert all(r["n_participants"] == 54 and r["degrees_of_freedom"] == 53 and r["holm_family_size"] == 5 for r in contrasts)
    assert sum(r["primary"] for r in contrasts) == 1
    np.testing.assert_allclose([r["mean_difference_percentage_points"] for r in contrasts],
                               [0.6, 0.3, 0.3, 0.4, 1.0], rtol=0, atol=1e-12)
    with tempfile.TemporaryDirectory() as temporary:
        accounting, found, identity = analysis.audit_complete(Path(temporary))
        assert not accounting["analysis_permitted"] and not accounting["test_statistics_computed"]
        assert accounting["missing_fits"] == 1350 and not found and identity is None
        # Worker folders are scanned recursively, with hashes relative to each
        # worker. A duplicate job across workers is invalid, never averaged twice.
        folder = Path(temporary)
        for worker, seed in (("worker_01", 1), ("worker_02", 2)):
            run_root = folder / worker
            (run_root / "records").mkdir(parents=True)
            (run_root / "predictions").mkdir()
            prediction = run_root / "predictions" / "fixture.npz"
            np.savez(prediction, fixture=np.array([1], dtype=np.int64))
            record = dict(identity=dict(subject=1, condition="W0", seed=seed,
                                        command="run", dataset="Lee2019_MI", parameters=analysis.PARAMS,
                                        code_sha256={"fixture": "synthetic"}, data_sha256={"train": "same"}),
                          epochs_completed=300, phase_test_metrics_computed=False,
                          final_test_evaluations=1, n_train=100, n_test=100,
                          prediction_file="predictions/fixture.npz", prediction_sha256=analysis.sha(prediction))
            analysis.atomic_json(run_root / "records" / "fixture.json", record)
        accounting, found, _ = analysis.audit_complete(folder)
        assert accounting["valid_completed_fits"] == 2 and accounting["missing_fits"] == 1348
        assert not accounting["analysis_permitted"] and not accounting["test_statistics_computed"]
        duplicate = json.loads((folder / "worker_02/records/fixture.json").read_text())
        duplicate["identity"]["seed"] = 1
        analysis.atomic_json(folder / "worker_02/records/fixture.json", duplicate)
        accounting, _, _ = analysis.audit_complete(folder)
        assert len(accounting["invalid_records"]) == 1 and not accounting["analysis_permitted"]
    report = dict(status="PASS", holm_known_values="verified", paired_t_and_ci="match scipy ttest_rel",
                  zero_difference_case="verified", independent_unit="54 participant seed means",
                  five_contrasts_and_one_primary="verified", incomplete_results_gate="no test statistics",
                  worker_folders="recursive scan with duplicate rejection",
                  real_lee_test_data_opened=False)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
