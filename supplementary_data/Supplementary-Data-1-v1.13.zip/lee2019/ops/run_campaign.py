"""Resumable local Lee2019 campaign with checksummed downloads and fixed protocol.

This supervisor reports completion counts only. Statistical comparisons run
once, after all 1,350 fits and the 54 contextual references are complete.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4*1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def atomic(path, value):
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temp.replace(path)

def command(args, log, *, env):
    verify_frozen_sources()
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('a', encoding='utf-8') as output:
        output.write(f'\n{now()} COMMAND {json.dumps(args, ensure_ascii=False)}\n')
        output.flush()
        result = subprocess.run(args, stdout=output, stderr=subprocess.STDOUT, cwd=ROOT, env=env)
    if result.returncode:
        raise RuntimeError(f'Exit {result.returncode}; inspect {log}')

FROZEN_SOURCES = {}
FROZEN_PROTOCOL = None
FROZEN_PROTOCOL_SHA = None

def verify_frozen_sources():
    if FROZEN_PROTOCOL is not None and sha(FROZEN_PROTOCOL) != FROZEN_PROTOCOL_SHA:
        raise RuntimeError('Frozen protocol changed during execution')
    for rel, expected in FROZEN_SOURCES.items():
        if sha(ROOT / rel) != expected:
            raise RuntimeError(f'Frozen source changed: {rel}')

def verify_prepared(subject, day):
    split = 'train' if day == 1 else 'test'
    data = ROOT / 'data' / 'prepared' / f'subject_{subject:02d}_{split}.npz'
    meta = ROOT / 'data' / 'prepared' / f'subject_{subject:02d}_meta.json'
    if not data.exists() or not meta.exists():
        return False
    metadata = json.loads(meta.read_text(encoding='utf-8'))
    if split not in metadata.get('days', {}):
        return False  # Recover NPZ written before its atomic metadata commit.
    record = metadata['days'][split]
    from download_lee import checksums
    expected_md5 = checksums(ROOT/'prepare'/'100542.md5')[f'sess{day:02d}_subj{subject:02d}_EEG_MI.mat']
    valid = (metadata.get('subject') == subject
             and metadata.get('schema') == 'lee2019-separated-days-v1'
             and metadata.get('data_units') == 'uV'
             and metadata.get('sampling_hz') == 128.0
             and metadata.get('label_mapping') == {'left_hand':0, 'right_hand':1}
             and len(metadata.get('channel_names', [])) == 62
             and len(set(metadata['channel_names'])) == 62
             and metadata.get('normalization') == 'none'
             and record.get('shape') == [100,62,512]
             and record.get('class_counts') == {'left_hand':50,'right_hand':50}
             and record.get('source_session') == day
             and record.get('source_run') == 'EEG_MI_train'
             and record.get('source_event_codes_to_labels') == {'2':0,'1':1}
             and record.get('preparation_script_sha256') == FROZEN_SOURCES.get('prepare/prepare_lee2019.py')
             and record['source']['published_md5_verified']
             and record['source']['published_md5'] == expected_md5
             and record['source']['md5'] == expected_md5
             and record['source']['filename'] == f'sess{day:02d}_subj{subject:02d}_EEG_MI.mat'
             and record['processing']['filter']['l_freq'] == 4.0
             and record['processing']['filter']['h_freq'] == 38.0
             and record['processing']['resample_hz'] == 128.0
             and record['processing']['epoch_tmin_requested_s'] == 0.0
             and record['processing']['epoch_tmax_requested_s'] == 4.0
             and sha(data) == record['prepared_npz']['sha256'])
    if not valid:
        raise RuntimeError(f'Prepared data verification failed: subject {subject}, day {day}')
    return True

def main():
    global FROZEN_SOURCES, FROZEN_PROTOCOL, FROZEN_PROTOCOL_SHA
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--protocol-sha256', required=True)
    parser.add_argument('--workers', type=int, choices=range(1,5), default=1)
    parser.add_argument('--download-workers', type=int, choices=range(1,5), default=2)
    args = parser.parse_args()
    args.python = args.python.resolve()
    args.protocol = args.protocol.resolve()
    if sha(args.protocol) != args.protocol_sha256:
        raise RuntimeError('Frozen protocol SHA256 mismatch')
    protocol = json.loads(args.protocol.read_text(encoding='utf-8'))
    if protocol['status'] != 'frozen_before_day2_performance':
        raise RuntimeError('Protocol is not frozen')
    for rel, expected in protocol['code_sha256'].items():
        if sha(ROOT / rel) != expected:
            raise RuntimeError(f'Frozen source changed: {rel}')
    if protocol['execution']['parallel_gpu_workers'] != args.workers:
        raise RuntimeError('GPU concurrency must match the frozen execution plan')
    FROZEN_SOURCES = protocol['code_sha256']
    FROZEN_PROTOCOL, FROZEN_PROTOCOL_SHA = args.protocol, args.protocol_sha256
    from lee_train import output_lock
    # Lock before downloading so a second supervisor cannot race .part files.
    with output_lock(ROOT, recover=True):
        execute_campaign(args)

def execute_campaign(args):
    logs = ROOT / 'logs' / 'campaign'
    logs.mkdir(parents=True, exist_ok=True)
    status_path = ROOT / 'CAMPAIGN_STATUS.json'
    started = now()
    env = os.environ.copy()
    env.update(OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
               CUBLAS_WORKSPACE_CONFIG=':4096:8', PYTHONUNBUFFERED='1',
               MPLCONFIGDIR=str(ROOT/'cache'/'matplotlib'), MNE_DATA=str(ROOT/'data'/'raw'))
    states = {}
    mutex = threading.Lock()
    stop = threading.Event()
    download_log = (logs / 'download_all.log').open('a', encoding='utf-8')
    dl_args = [str(args.python), str(ROOT/'ops'/'download_lee.py'), '--root', str(ROOT),
               '--subjects', *map(str, range(1,55)), '--sessions', '1', '2',
               '--workers', str(args.download_workers)]
    downloader = subprocess.Popen(dl_args, stdout=download_log, stderr=subprocess.STDOUT, cwd=ROOT, env=env)

    def update(worker, stage, subject=None):
        with mutex:
            states[str(worker)] = dict(stage=stage, subject=subject, updated_utc=now())

    def worker_task(worker):
        subjects = list(range(worker, 55, args.workers))
        output = ROOT / 'results' / f'worker_{worker:02d}'
        for subject in subjects:
            if stop.is_set() or (ROOT/'STOP_AFTER_CURRENT_SUBJECT').exists():
                update(worker, 'stopped_at_subject_boundary', subject)
                return
            update(worker, 'waiting_for_verified_source', subject)
            for day in (1,2):
                name = f'sess{day:02d}_subj{subject:02d}_EEG_MI.mat'
                raw = ROOT/'data'/'raw'/f'session{day}'/f's{subject}'/name
                verified = ROOT/'logs'/'downloads'/(name+'.json')
                while not (raw.exists() and verified.exists()):
                    if stop.is_set():
                        return
                    if downloader.poll() is not None:
                        raise RuntimeError(f'Download ended before subject {subject} day {day}; inspect download_all.log')
                    time.sleep(5)
                record = json.loads(verified.read_text(encoding='utf-8'))
                if record['status'] != 'verified' or raw.stat().st_size != record['bytes']:
                    raise RuntimeError(f'Source verification record invalid: {name}')
                if not verify_prepared(subject, day):
                    update(worker, f'preparing_day_{day}', subject)
                    prep_command = [str(args.python), str(ROOT/'prepare'/'prepare_lee2019.py'),
                             '--mat', str(raw), '--subject', str(subject), '--day', str(day),
                             '--out-dir', str(ROOT/'data'/'prepared')]
                    if (ROOT/'data'/'prepared'/f'subject_{subject:02d}_{"train" if day == 1 else "test"}.npz').exists():
                        prep_command.append('--overwrite')
                    command(prep_command,
                            logs/f'prepare_subject_{subject:02d}_day{day}.log', env=env)
                    if not verify_prepared(subject, day):
                        raise RuntimeError('Preparation did not produce verified files')
            update(worker, 'training_fixed_25_fits', subject)
            # Each invocation owns a distinct output folder; completed fits are
            # hash checked and skipped. Interrupted phases resume their own RNG.
            command([str(args.python), str(ROOT/'code'/'lee_train.py'), 'run',
                     '--data-dir', str(ROOT/'data'/'prepared'), '--out', str(output),
                     '--device', 'cuda', '--threads', '2', '--subjects', str(subject),
                     '--recover-stale-lock'], logs/f'gpu_worker_{worker:02d}.log', env=env)
        update(worker, 'complete')

    errors = []
    def counts():
        return dict(verified_source_files=sum(1 for p in (ROOT/'logs'/'downloads').glob('sess*_EEG_MI.mat.json')),
                    expected_source_files=108,
                    prepared_npz_files=sum(1 for p in (ROOT/'data'/'prepared').glob('subject_*.npz')),
                    expected_prepared_npz_files=108,
                    completed_fits=sum(1 for p in (ROOT/'results').glob('worker_*/records/*.json')),
                    expected_fits=1350)
    def report(status):
        with mutex:
            snap = dict(states)
        value = dict(status=status, supervisor_pid=os.getpid(), started_utc=started, updated_utc=now(),
                     protocol_sha256=args.protocol_sha256, workers=snap, errors=errors, **counts())
        atomic(status_path, value)
        print(json.dumps(value, ensure_ascii=False), flush=True)

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(worker_task, worker) for worker in range(1,args.workers+1)]
            while not all(f.done() for f in futures):
                report('running')
                for f in futures:
                    if f.done() and f.exception() is not None:
                        stop.set()
                time.sleep(15)
            for f in futures:
                try:
                    f.result()
                except Exception as exc:
                    errors.append(str(exc))
        if errors:
            raise RuntimeError('Campaign worker failed: ' + '; '.join(errors))
        if (ROOT/'STOP_AFTER_CURRENT_SUBJECT').exists():
            report('stopped_at_user_control_file')
            return
        if counts()['completed_fits'] != 1350:
            raise RuntimeError('Full training count is not 1350')
        if downloader.wait() != 0:
            raise RuntimeError('Source download batch failed')
        update('classical', 'running_all_54')
        report('classical_reference')
        command([str(args.python), str(ROOT/'prepare'/'classical_reference.py'),
                 '--data-dir', str(ROOT/'data'/'prepared'), '--out-dir', str(ROOT/'classical_results'),
                 '--protocol', str(args.protocol), '--protocol-sha256', args.protocol_sha256],
                logs/'classical_reference.log', env=env)
        update('analysis', 'final_analysis_all_1350')
        report('final_analysis')
        command([str(args.python), str(ROOT/'code'/'analysis'/'final_analysis.py'),
                 '--results', str(ROOT/'results'), '--out', str(ROOT/'final_analysis'),
                 '--csp-csv', str(ROOT/'classical_results'/'classical_summary.csv')],
                logs/'final_analysis.log', env=env)
        final = json.loads((ROOT/'final_analysis'/'final_analysis.json').read_text(encoding='utf-8'))
        if final['status'] != 'COMPLETE_FINAL_ANALYSIS':
            raise RuntimeError('Final analysis did not verify completion')
        report('complete')
    except BaseException as exc:
        stop.set()
        errors.append(repr(exc))
        report('failed_resumable')
        traceback.print_exc()
        raise
    finally:
        if downloader.poll() is None:
            downloader.terminate()
            try:
                downloader.wait(timeout=8)
            except subprocess.TimeoutExpired:
                downloader.kill()
                downloader.wait(timeout=5)
        download_log.close()

if __name__ == '__main__':
    sys.path.insert(0, str(ROOT/'code'))
    main()
