"""Record the measured pilot, environment, and study plan before Day-2 outcomes."""
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import winreg

import psutil
import torch

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(4*1024*1024),b''): h.update(part)
    return h.hexdigest()

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists(): raise FileExistsError(f'Frozen receipt already exists: {path}')
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def registry(key,names):
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,key) as k:
        result={}
        for n in names:
            try: result[n]=winreg.QueryValueEx(k,n)[0]
            except FileNotFoundError: result[n]=None
        return result

def main():
    stamp=datetime.now(ZoneInfo('Europe/Istanbul')).isoformat(timespec='seconds')
    records=[json.loads(p.read_text(encoding='utf-8')) for p in (ROOT/'pilot'/'02_full_300_epochs'/'records').glob('*.json')]
    if len(records)!=3 or {r['identity']['condition'] for r in records}!={'W0','W1','W2'} or any(r['final_test_evaluations']!=0 or r['epochs_completed']!=300 for r in records):
        raise RuntimeError('All three full-budget training-only pilots must be complete')
    parallel=json.loads((ROOT/'pilot'/'03_parallel_3'/'throughput.json').read_text(encoding='utf-8'))
    mean=statistics.mean(r['wall_seconds'] for r in records)
    chosen=1  # Three-way concurrency measured slower than the sequential fits.
    if parallel['seconds_per_fit_throughput']<mean:
        raise RuntimeError('Recorded decision does not match measured throughput; review before freezing')
    packages={n:importlib.metadata.version(n) for n in ('numpy','scipy','torch','mne','moabb','pandas','scikit-learn')}
    freeze=subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True)
    lock=ROOT/'ops'/'requirements-lock.txt'
    if lock.exists(): raise FileExistsError(lock)
    lock.write_text(freeze,encoding='utf-8')
    environment=dict(observed_at=stamp,timezone='Europe/Istanbul',host=platform.node(),python=sys.version,
        python_executable=sys.executable,platform=platform.platform(),logical_processors=psutil.cpu_count(),
        ram_bytes=psutil.virtual_memory().total,
        cpu=registry(r'HARDWARE\DESCRIPTION\System\CentralProcessor\0',['ProcessorNameString']),
        computer=registry(r'HARDWARE\DESCRIPTION\System\BIOS',['SystemManufacturer','SystemProductName']),
        os=registry(r'SOFTWARE\Microsoft\Windows NT\CurrentVersion',['ProductName','DisplayVersion','CurrentBuild','UBR','EditionID']),
        cuda_available=torch.cuda.is_available(),cuda_runtime=torch.version.cuda,
        gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True).strip(),
        packages=packages,requirements_lock_sha256=sha(lock),
        setup_note='First isolated environment under the long project path failed at the Windows path limit. A separate short-path environment was created; existing environments and released code were preserved.',
        actor=dict(platform='OpenAI Codex desktop',system_identity='GPT-6-based Codex',
                   prior_user_session_label='ChatGPT Astra 6.1 Ultra',exact_service_model_and_effort='not independently exposed',
                   remote_inference_hardware='not exposed'))
    save(ROOT/'logs'/'ENVIRONMENT-V1.0.json',environment)
    pilot=dict(recorded_at=stamp,source_subject=1,source_day=1,held_out_day2_opened=False,
        epochs_per_fit=300,conditions=[dict(condition=r['identity']['condition'],train_seconds=r['train_seconds'],wall_seconds=r['wall_seconds'],
            peak_cuda_allocated_bytes=r['cuda_peak_allocated_bytes'],peak_cuda_reserved_bytes=r['cuda_peak_reserved_bytes']) for r in records],
        mean_wall_seconds=mean,estimated_sequential_training_hours_1350=mean*1350/3600,
        three_parallel_fits_throughput_seconds_each=parallel['seconds_per_fit_throughput'],
        parallel_measurement_sha256=sha(ROOT/'pilot'/'03_parallel_3'/'throughput.json'),chosen_gpu_workers=chosen,
        estimate_scope='Measured subject-1 Day-1 training only; excludes download/preparation, final-test inference, CSP-LDA, varying system load. Not an exact finish-time promise.',
        first_source_download_bytes=609007751,first_source_download_seconds=35.717,
        first_source_sha256='da1e4ce677f95bf2feed9ba0bc5edaef9daa4fb5ef2102d90fdcece69cc48b5c')
    save(ROOT/'PILOT_OLCUMU-V1.0.json',pilot)
    code={p.relative_to(ROOT).as_posix():sha(p) for folder in ('code','prepare','ops') for p in sorted((ROOT/folder).rglob('*.py'))}
    protocol=dict(version='1.0',status='frozen_before_day2_performance',frozen_at=stamp,timezone='Europe/Istanbul',
        user_authorization='Download Lee2019_MI, measure a small pilot, then run the experiments; prepare IEEE Access in parallel.',
        prior_use=dict(user_confirmed_no_prior_team_method_or_hyperparameter_development_use=True,
                       received_date='2026-10-18',source='Direct user answer in this chat'),
        dataset=dict(name='Lee2019_MI',doi='10.5524/100542',article_doi='10.1093/gigascience/giz002',license='CC0-1.0',
                     subjects=list(range(1,55)),training='day 1 offline EEG_MI_train',test='day 2 offline EEG_MI_train',
                     excluded_source_variables=['EEG_MI_test online run','resting data','EMG channels'],
                     n_train_per_subject=100,n_test_per_subject=100,n_classes=2,class_counts_each_day={'left_hand':50,'right_hand':50},
                     class_mapping={'left_hand':0,'right_hand':1},source_events={'left_hand':2,'right_hand':1},
                     eeg_channels=62,source_sampling_hz=1000,processed_shape=[100,62,512]),
        preprocessing=dict(filter_hz=[4,38],filter_method='MNE IIR default fourth-order Butterworth forward-backward on continuous EEG',
                           epoch_seconds=[0,4],epoch_endpoint='inclusive at source sampling; 4001 samples',resample_hz=128,
                           resample_method='MNE default FFT after epoching; 512 output samples',input_units='uV float32',
                           channel_order='original published 62 EEG names, identical between days',
                           trial_rejection='none; stop on unexpected missing, nonfinite or dropped trials',
                           normalization='per-channel mean/std fit on all Day-1 trial/time values only; float64 std+1e-6; apply to both days'),
        model=dict(architecture='EEGNet-8,2',conditions={'S0':'softmax hard targets','W0':'fixed Walsh targets','W1':'cumulative negotiated Walsh targets',
                   'W2':'anchored correctness-gated negotiated Walsh targets','W3':'classwise Walsh target smoothing'},
                   walsh_bits=16,code_rows='first two binary Walsh rows, unchanged from v2.1.0 release',
                   seeds=[1,2,3,4,5],optimizer='Adam',learning_rate=.001,batch_size=16,dropout=.5,
                   phases=10,epochs_per_phase=30,epochs_total=300,target_rate=.03,
                   zero_based_updates='After phase p, rate .03*p; used by phase p+1. Final p9 update not used for fitting.',
                   model_selection='none; final fixed-budget model only',mixed_precision=False,deterministic_algorithms=True),
        execution=dict(planned_fits=1350,planned_classical_reference_fits=54,parallel_gpu_workers=chosen,download_workers=2,threads_per_training_process=2,
                       timing_pilot_reused_as_confirmatory_result=False,checkpoint='every 30-epoch phase, including optimizer and all RNG states',
                       final_day2_evaluations_per_fit=1,per_phase_test_evaluations=0),
        classical_reference=json.loads((ROOT/'prepare'/'CLASSICAL_REFERENCE_SPEC.json').read_text(encoding='utf-8')),
        analysis=dict(independent_unit='participant after averaging the five seeds within condition',n=54,
                      primary_contrast='W2-W0',family=['W2-W0','W1-W0','W2-W1','W2-W3','W0-S0'],
                      test='two-sided paired t-test',multiplicity='Holm across exactly these five new contrasts',alpha=.05,
                      confidence_intervals='pointwise unadjusted 95%',secondary_metrics=['NLL','ECE with 15 equal-width bins'],
                      secondary_scope='descriptive; no additional confirmatory test family',
                      no_interim_inferential_analysis=True,required_complete_fits=1350,
                      old_dataset_results='preserved separately; no pooling with previous 32 participants'),
        exception_policy=dict(expected_complete_subjects=54,automatic_exclusion=False,
                              behavior='Retry network transfers; stop and document corrupt/unexpected data or software failure. No exclusion for low accuracy or unfavorable direction.'),
        code_sha256=code,environment_sha256=sha(ROOT/'logs'/'ENVIRONMENT-V1.0.json'),
        source_md5_manifest_sha256=sha(ROOT/'prepare'/'100542.md5'),
        pilot_sha256=sha(ROOT/'PILOT_OLCUMU-V1.0.json'),
        original_release='https://github.com/salihcolakoglu/negotiated-targets-mi-eeg/tree/v2.1.0',
        software_doi='10.5281/zenodo.23290274')
    target=ROOT/'DENEY_PROTOKOLU-V1.0.json'
    save(target,protocol)
    (ROOT/'DENEY_PROTOKOLU-V1.0.sha256').write_text(sha(target)+'  '+target.name+'\n',encoding='utf-8')
    print(json.dumps(dict(status=protocol['status'],protocol_sha256=sha(target),pilot=pilot,packages=packages),ensure_ascii=False))

if __name__=='__main__': main()
