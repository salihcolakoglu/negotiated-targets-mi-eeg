"""Exercise interrupted-download recovery and campaign integrity gates offline."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import download_lee
import run_campaign

class Checks(unittest.TestCase):
    def test_complete_part_recovers_without_network(self):
        with tempfile.TemporaryDirectory(prefix='lee_ops_') as tmp:
            root = Path(tmp)
            raw, logs = root/'raw', root/'logs'
            logs.mkdir()
            name = 'sess01_subj01_EEG_MI.mat'
            part = raw/'session1'/'s1'/(name+'.part')
            part.parent.mkdir(parents=True)
            payload = b'Known complete bytes, interrupted before atomic rename.'
            part.write_bytes(payload)
            expected = {name:hashlib.md5(payload).hexdigest()}
            with patch('download_lee.urllib.request.urlopen', side_effect=AssertionError('Network must not run')):
                record = download_lee.download_one(1,1,raw,logs,expected)
            self.assertEqual(record['status'], 'verified')
            self.assertEqual(Path(record['file']).read_bytes(), payload)
            self.assertFalse(part.exists())

    def test_prepared_identity_and_interruption(self):
        with tempfile.TemporaryDirectory(prefix='lee_ops_') as tmp:
            root = Path(tmp)
            out = root/'data'/'prepared'
            out.mkdir(parents=True)
            (root/'prepare').mkdir()
            md5 = '0123456789abcdef0123456789abcdef'
            (root/'prepare'/'100542.md5').write_text(md5+'  session1/s1/sess01_subj01_EEG_MI.mat\n')
            data = out/'subject_01_train.npz'
            data.write_bytes(b'Fixed synthetic artifact bytes for provenance checks')
            meta = out/'subject_01_meta.json'
            prep_sha = 'a'*64
            rec = dict(subject=1,schema='lee2019-separated-days-v1',data_units='uV',sampling_hz=128.0,
                label_mapping={'left_hand':0,'right_hand':1},channel_names=[f'C{i}' for i in range(62)],
                normalization='none',days={'train':dict(shape=[100,62,512],class_counts={'left_hand':50,'right_hand':50},
                    source_session=1,source_run='EEG_MI_train',source_event_codes_to_labels={'2':0,'1':1},
                    preparation_script_sha256=prep_sha,
                    source=dict(published_md5_verified=True,published_md5=md5,md5=md5,filename='sess01_subj01_EEG_MI.mat'),
                    processing=dict(filter=dict(l_freq=4.,h_freq=38.),resample_hz=128.,epoch_tmin_requested_s=0.,epoch_tmax_requested_s=4.),
                    prepared_npz={'sha256':run_campaign.sha(data)})})
            def save(value):
                meta.write_text(json.dumps(value),encoding='utf-8')
            with patch.object(run_campaign,'ROOT',root), patch.object(run_campaign,'FROZEN_SOURCES',{'prepare/prepare_lee2019.py':prep_sha}):
                save(rec)
                self.assertTrue(run_campaign.verify_prepared(1,1))
                for change in ('subject','filter','code','bytes'):
                    changed = copy.deepcopy(rec)
                    if change=='subject': changed['subject']=2
                    if change=='filter': changed['days']['train']['processing']['filter']['h_freq']=40.
                    if change=='code': changed['days']['train']['preparation_script_sha256']='b'*64
                    if change=='bytes': data.write_bytes(b'Altered artifact')
                    save(changed)
                    with self.assertRaises(RuntimeError):
                        run_campaign.verify_prepared(1,1)
                save(dict(rec,days={}))
                self.assertFalse(run_campaign.verify_prepared(1,1))

    def test_protocol_modification_blocks_next_child(self):
        with tempfile.TemporaryDirectory(prefix='lee_ops_') as tmp:
            path = Path(tmp)/'protocol.json'
            path.write_text('{"frozen":true}')
            initial = run_campaign.sha(path)
            with patch.object(run_campaign,'FROZEN_PROTOCOL',path), patch.object(run_campaign,'FROZEN_PROTOCOL_SHA',initial), patch.object(run_campaign,'FROZEN_SOURCES',{}):
                run_campaign.verify_frozen_sources()
                path.write_text('{"frozen":false}')
                with self.assertRaises(RuntimeError):
                    run_campaign.verify_frozen_sources()

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Checks)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),successful=result.wasSuccessful(),real_test_data_used=False)
    Path(__file__).with_name('ops_verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
