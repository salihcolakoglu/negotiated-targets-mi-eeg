"""Download original Lee2019 MI MAT files, verify published MD5, retain SHA256.

Downloads are resumable and never parse EEG or inspect outcomes. Source files
are retained under data/raw; logs contain metadata only.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import re
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE = 'https://s3.ap-northeast-1.wasabisys.com/gigadb-datasets/live/pub/10.5524/100001_101000/100542/'

def now():
    return datetime.now(timezone.utc).isoformat()

def atomic_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)

def hashes(path):
    md5 = hashlib.md5()
    sha = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            md5.update(block)
            sha.update(block)
    return md5.hexdigest(), sha.hexdigest()

def checksums(path):
    out = {}
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        match = re.match(r'^([0-9a-fA-F]{32})\s+\*?(.+?)\s*$', line)
        if match:
            out[Path(match.group(2).replace('\\', '/')).name] = match.group(1).lower()
    return out

def download_one(subject, session, raw, logs, expected):
    name = f'sess{session:02d}_subj{subject:02d}_EEG_MI.mat'
    relative = f'session{session}/s{subject}/{name}'
    url = BASE + relative
    dest = raw / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix('.mat.part')
    logpath = logs / (name + '.json')
    if name not in expected:
        raise RuntimeError(f'No published checksum for {name}')
    # A process may have stopped after the last byte but before validation and
    # rename. Recover a complete .part locally, without an invalid EOF Range.
    if not dest.exists() and part.exists():
        part_md5, _ = hashes(part)
        if part_md5 == expected[name]:
            part.replace(dest)
    if dest.exists():
        md5, sha = hashes(dest)
        if md5 != expected[name]:
            raise RuntimeError(f'Existing file fails published MD5: {dest}')
        record = dict(file=str(dest), url=url, bytes=dest.stat().st_size,
                      source_doi='10.5524/100542',
                      published_md5=expected[name], md5=md5, sha256=sha,
                      status='verified', verified_utc=now(), reused=True)
        atomic_json(logpath, record)
        print(json.dumps(dict(event='verified_existing', subject=subject, session=session, **record)), flush=True)
        return record
    began = time.perf_counter()
    started = now()
    for attempt in range(1, 7):
        offset = part.stat().st_size if part.exists() else 0
        req = urllib.request.Request(url, headers={'User-Agent': 'Lee2019-reproducibility-download/1.0'})
        if offset:
            req.add_header('Range', f'bytes={offset}-')
        try:
            with urllib.request.urlopen(req, timeout=90) as response:
                if offset and response.status != 206:
                    offset = 0
                mode = 'ab' if offset else 'wb'
                length = response.headers.get('Content-Length')
                total = offset + int(length) if length else None
                written = offset
                last = time.perf_counter()
                with part.open(mode) as f:
                    while True:
                        block = response.read(4 * 1024 * 1024)
                        if not block:
                            break
                        f.write(block)
                        written += len(block)
                        if time.perf_counter() - last >= 15:
                            elapsed = time.perf_counter() - began
                            print(json.dumps(dict(event='progress', subject=subject, session=session,
                                bytes=written, total_bytes=total, seconds=round(elapsed, 2))), flush=True)
                            last = time.perf_counter()
                if total is not None and written != total:
                    raise RuntimeError(f'Incomplete {name}: {written}/{total}')
            md5, sha = hashes(part)
            if md5 != expected[name]:
                raise RuntimeError(f'Published MD5 mismatch for {name}: {md5}; retained .part')
            part.replace(dest)
            record = dict(subject=subject, session=session, file=str(dest), url=url,
                source_doi='10.5524/100542', bytes=dest.stat().st_size,
                published_md5=expected[name], md5=md5, sha256=sha, status='verified',
                started_utc=started, completed_utc=now(), elapsed_seconds=round(time.perf_counter()-began, 3))
            atomic_json(logpath, record)
            print(json.dumps(dict(event='complete', **record)), flush=True)
            return record
        except Exception as exc:
            print(json.dumps(dict(event='retry', subject=subject, session=session, attempt=attempt,
                                  error=str(exc), utc=now())), flush=True)
            if attempt == 6 or 'MD5 mismatch' in str(exc):
                raise
            time.sleep(min(attempt * 3, 15))
    raise AssertionError('unreachable')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--subjects', type=int, nargs='+', required=True)
    p.add_argument('--sessions', type=int, nargs='+', default=[1, 2])
    p.add_argument('--workers', type=int, default=2)
    args = p.parse_args()
    if not all(1 <= n <= 54 for n in args.subjects) or not all(n in (1,2) for n in args.sessions):
        p.error('Subjects must be 1..54; sessions must be 1 or 2.')
    manifest = args.root / 'prepare' / '100542.md5'
    expected = checksums(manifest)
    raw = args.root / 'data' / 'raw'
    logs = args.root / 'logs' / 'downloads'
    logs.mkdir(parents=True, exist_ok=True)
    failures = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(download_one, s, d, raw, logs, expected):(s,d)
                   for s in args.subjects for d in args.sessions}
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as exc:
                failures.append(dict(subject=futures[future][0], session=futures[future][1], error=str(exc)))
    atomic_json(logs / 'last_download_batch.json', dict(utc=now(), subjects=args.subjects,
                sessions=args.sessions, workers=args.workers, failures=failures))
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
