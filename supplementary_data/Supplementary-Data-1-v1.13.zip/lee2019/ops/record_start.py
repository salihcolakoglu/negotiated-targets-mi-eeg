"""Append the verified experiment-start receipt without rewriting old journal bytes."""
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    # This receipt writer was added after protocol freeze; it is administrative
    # and is not imported by training, data preparation or final analysis.
    stamp=datetime.now(ZoneInfo('Europe/Istanbul')).isoformat(timespec='seconds')
    baseline=json.loads((PROJECT/'PAYLASIM_DENETIMI_2026-10-11-V1.0'/'BUTUNLUK_KONTROLU.json').read_text(encoding='utf-8-sig'))
    protected=[dict(path=f['path'],expected_sha256=f['sha256_before'],actual_sha256=sha(f['path'])) for f in baseline['files']]
    if any(f['expected_sha256']!=f['actual_sha256'] for f in protected):raise RuntimeError('Protected original changed')
    protocol=json.loads((ROOT/'DENEY_PROTOKOLU-V1.0.json').read_text(encoding='utf-8'))
    for rel,expected in protocol['code_sha256'].items():
        if sha(ROOT/rel)!=expected:raise RuntimeError(f'Frozen code changed: {rel}')
    status=json.loads((ROOT/'CAMPAIGN_STATUS.json').read_text(encoding='utf-8'))
    if status['status']!='running' or status['errors']:raise RuntimeError('Campaign is not running cleanly')
    journal=PROJECT/'CALISMA_GUNCESI.md'
    before=journal.read_bytes()
    ids=[int(x) for x in re.findall(r'^## G-(\d+)',before.decode('utf-8-sig'),flags=re.M)]
    number=max(ids)+1
    if number!=71:raise RuntimeError(f'Expected G-071, latest journal implies G-{number:03d}; reconcile before append')
    backup=ROOT/'logs'/'CALISMA_GUNCESI.before-G071.md'
    if backup.exists():raise FileExistsError(backup)
    backup.write_bytes(before)
    note=f'''

## G-071 — Lee2019 MI süre ölçümü ve sabit deneylerin başlatılması — {stamp}

**Yetki ve amaç:** Kullanıcı Lee2019_MI verisini indirmeyi, önce küçük süre denemesi yapmayı, ardından deneylere geçmeyi ve IEEE Access hazırlığını paralel sürdürmeyi istedi. Ekipte Lee verisinin daha önce yöntem geliştirme veya ayar seçimi için kullanılmadığını doğrudan teyit etti. Orta hedef editörün bağımsız doğrulama eleştirisini aynı yöntem ve sabit bütçeyle sınamak; uzun hedef tezle bağlantılı SCI-Expanded makale kabul/yayınıdır.

**Yapılan ve ölçülen:** Ayrı LEE2019_BAGIMSIZ_DOGRULAMA-V1.0 klasörü ve Python ortamı hazırlandı. İlk uzun ortam yolunda Windows dosya yolu sınırı kurulumu durdurdu; mevcut ortam değiştirilmeden kısa yolda C:\\Doktora makale iyileştirme çalışmaları\\Lee2019-V1.0-env oluşturuldu. PyTorch2.5.1+cu124, NumPy2.2.6, SciPy1.15.3, MNE1.12.1 ve MOABB1.5.0 kuruldu; pip check geçti. Yerel RTX4070 doğrulandı. İlk resmî MAT609.007.751 bayt,35,717sn; yayımlanmış MD5 ile eşleşti, SHA256 da1e4ce677f95bf2feed9ba0bc5edaef9daa4fb5ef2102d90fdcece69cc48b5c. İlk gün hazırlığı8,305sn;100×62×512,50sol/50sağ. Hazırlık ve klasik referans kontrolleri7+7, düzenleyici kontrolleri3 başarılı. CPU ve CUDA uyarlaması beş koşulda yayımlanmış kodla aynı cihaz üzerinde bit düzeyinde eşleşti; kesinti/devam ve istatistik denetimleri geçti.

**Pilot:** Yalnız ilk gün kullanıldı; ikinci gün veya test başarısı pilotta açılmadı.300tur W0 toplam12,89sn;W1 11,69sn;W2 12,40sn; ortalama12,33sn.1.350eğitim için yalnız eğitim tahmini4,62saattir; kesin bitiş taahhüdü değildir. Üç paralel işte dokuz eğitim124,45sn, eğitim başına13,83sn olduğundan tek GPU işi seçildi. En yüksek PyTorch tensör belleği285.451.264bayt; toplam GPU kullanımı değildir.

**Sabit protokol ve başlatma:** DENEY_PROTOKOLU-V1.0.json 09:09:39+03:00'da test performansı görülmeden sabitlendi; SHA256 493378c9982feff6182216eb7406f68799e1435284cd80d39d91b258130fcab8.54kişi×5koşul×5tohum=1.350EEGNet,300tur; gün1eğitim/gün2son model testi, ara test veya test turu seçimi yok. Önceki ayarlar korundu;4–38Hz,0–4sn,128Hz,62EEG ve yalnız eğitimden normalleştirme. Analiz54kişi ortalamasına dayanır; birincilW2−W0, yeni beşli Holm ailesi korunur. Eski32kişi ve eski istatistikler ayrı tutulur.54yeni klasik referansta iki uçtan altıCSP+varsayılanLDA kullanılacağı, eski tek uçlu üçözellikli referanstan farkı açıkça sabitlendi. Düşük başarıya göre kişi çıkarılmaz; bozuk/beklenmeyen girdide işlem durur.

**Yürütme durumu:** Başlatma09:10:29+03:00; gizli pencereyle arka plan süreci, başlatıcıPID17008/gerçek düzenleyiciPID{status['supervisor_pid']}. Bu kayıt anında {status['verified_source_files']}/108kaynak doğrulandı, {status['prepared_npz_files']}/108hazırlık ve {status['completed_fits']}/1.350eğitim kaydı mevcut; durum{status['status']}. Tamamlanmış gibi gösterilmedi. İki paralel indirme eğitimle örtüşür; aşama başına model/Adam/rastgelelik kaydı vardır. Klasik referanslar ve son istatistikler bütün1.350doğrulanmış modelden sonra otomatik çalışacak. Canlı durum CAMPAIGN_STATUS.json, ayrıntılar logs/campaign altındadır. Kaynak protokol/kod özetleri her alt işlem öncesi yeniden denetlenir.

**IEEE somut çıktı:** IEEE_ACCESS_HAZIRLIK-V1.0 içinde11sayfalık Manuscipt_IEEE_Access-V1.0.pdf, düzenlenebilir main.tex ve IEEE_Access_Source-V1.0.zip hazırlandı;6tablo,4şekil,3biyografi,204sözcük özet.81bilimsel blok ve sayılar korundu, bütün sayfalar görsel denetlendi. PDF SHA256 ffb453e73b97cb1c31dec60e142bae60e72fe3e51a82ad55a544747be8be0bb5. Resmî şablon ve doğrulanmış Tectonic0.17.0 kullanıldı; sınıf dosyası değiştirilmedi. Lee sonuçları henüz taslağa eklenmedi. Son yazar kontrolü, ORCID/başvuru alanları ve eklerin yeni metinle eşlenmesi son sürümde tamamlanacak. Gönderim, ödeme, transfer, e-posta ve GitHub/Zenodo değişikliği yapılmadı.

**Bütünlük ve geri dönüş:**29korunan eski dosya hash üzerinden aynı kaldı. Kaynak çalışma, gönderilmiş V4.4, yayımlanmış paket ve salt okunur tez arşivi değiştirilmedi. Günce eski baytları logs/CALISMA_GUNCESI.before-G071.md ile yedeklenip yalnız sona eklendi. Yeni deney için somut kaynaklar, hedefler, sürümler, süreler ve ortam ayrı dosyalardadır; geri dönüş eski sürümleri kullanmak veya yeni deney sürecini kontrollü durdurmaktır. Sonraki kayıtG-072.

**İmza:** OpenAI Codex desktop; sistem tanımıGPT-6tabanlıCodex. Önceki kullanıcı oturum etiketiChatGPT Astra6.1Ultra; kesin hizmet modeli/ayar ve uzak çıkarım donanımı bağımsız görünmüyor. YerelTHE_BEAST/SEMRUK S7 V9.2; i9-13950HX,32mantıksal işlemci,64GiB RAM; RTX4070Laptop8188MiB,sürücü595.79; Windows25H2build26200.9711. Yeni gözlem2026-10-18T09:09:39+03:00; Python3.12.14,CUDA12.4. Genel iş başlangıcı ayrıca ölçülmedi; ilk başarılı indirme başlangıcı08:55:03,640+03:00. Kayıt bitişi{stamp};Europe/Istanbul,UTC+03:00.
'''
    # Re-check the prefix immediately before the append to avoid overwriting
    # another actor's concurrent journal update.
    if journal.read_bytes()!=before:raise RuntimeError('Journal changed before append')
    with journal.open('ab') as f:f.write(note.encode('utf-8'))
    after=journal.read_bytes()
    if not after.startswith(before):raise RuntimeError('Journal prefix was not preserved')
    receipt=dict(record='G-071',recorded_at=stamp,journal_before_sha256=hashlib.sha256(before).hexdigest(),
                 journal_after_sha256=hashlib.sha256(after).hexdigest(),journal_previous_bytes_preserved=True,
                 protected_files_checked=len(protected),all_protected_files_unchanged=True,files=protected,
                 campaign_snapshot=status,protocol_sha256=sha(ROOT/'DENEY_PROTOKOLU-V1.0.json'))
    (ROOT/'logs'/'GUNCEL_BUTUNLUK_G071-V1.0.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('files','campaign_snapshot')},ensure_ascii=False))

if __name__=='__main__':main()
