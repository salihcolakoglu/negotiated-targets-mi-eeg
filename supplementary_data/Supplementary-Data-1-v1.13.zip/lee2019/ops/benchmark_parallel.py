"""Compare train-only throughput without reading held-out data or outcomes."""
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--python', required=True)
    p.add_argument('--workers', type=int, default=3)
    args = p.parse_args()
    out = ROOT/'pilot'/f'03_parallel_{args.workers}'
    out.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
               CUBLAS_WORKSPACE_CONFIG=':4096:8')
    def work(i):
        dest = out/f'worker_{i:02d}'
        cmd = [args.python, str(ROOT/'code'/'lee_train.py'), 'pilot',
               '--train-npz', str(ROOT/'data'/'prepared'/'subject_01_train.npz'),
               '--out', str(dest), '--device', 'cuda']
        with (out/f'worker_{i:02d}.log').open('x', encoding='utf-8') as log:
            subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True, env=env, cwd=ROOT)
    started = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(work, range(1,args.workers+1)))
    seconds = time.perf_counter()-started
    records = [json.loads(p.read_text(encoding='utf-8')) for p in out.glob('worker_*/records/*.json')]
    if len(records) != args.workers*3 or any(r['final_test_evaluations'] != 0 for r in records):
        raise RuntimeError('Incomplete or non-training-only pilot')
    result = dict(workers=args.workers, fits=len(records), wall_seconds=seconds,
                  seconds_per_fit_throughput=seconds/len(records),
                  per_fit_wall_seconds=[r['wall_seconds'] for r in records],
                  per_fit_train_seconds=[r['train_seconds'] for r in records],
                  per_process_peak_cuda_allocated_bytes=max(r['cuda_peak_allocated_bytes'] for r in records),
                  final_test_evaluations=0,
                  estimate_seconds_1350_fits=seconds/len(records)*1350,
                  estimate_excludes='source downloads, preparation, varying load, final test and classical reference')
    (out/'throughput.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
