# Deviations from the protocols of 15 November 2026 (A, B, C)

1. Operational, all analyses: the server driver first failed because the data folder for the BNCI files did not exist
   (download library error). The folder was created and the driver was restarted from that step (15 November 2026,
   16:51 UTC). No scientific step had run; the repetition of Experiment 3 (B), started earlier, was not affected.
2. Place of computation (A and C): the protocols did not fix a machine. A and C were planned in the authors' cloud
   workspace, but the raw files could not be transferred there; they ran on the rented server of B, which downloaded the
   official BNCI files itself. All 64 files equalled, by SHA-256, the files used for the published results.
3. A, item 4 of the analysis (agreement with the preliminary measurement of 24 September 2026): computed after the run
   from the result file, not by the driver option; the two-ended and one-ended accuracies equal the preliminary values
   for all 32 participants (largest absolute difference 0).
4. C: fits and the fidelity check ran on the graphics processor (CUDA), with one CPU thread per process, as the protocol
   allows; the device is recorded in every fit record.
No participant, fit or seed was excluded, and no analysis was repeated.
