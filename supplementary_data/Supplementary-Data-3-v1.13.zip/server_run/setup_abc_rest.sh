#!/bin/bash
# Operational driver on the rented server (not part of the scientific package; every scientific step is in new_computations/).
set -uo pipefail
W=/workspace/ABC; cd $W; mkdir -p logs
log(){ echo "[$(date -u +%FT%TZ)] $*" | tee -a logs/STEPS.log; }
fail(){ log "FAILED: $*"; exit 1; }
log "start"; nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader | tee -a logs/STEPS.log
P=new_computations/c_published_regime; PR=$P/PROTOCOL-C.json
# ---- official BNCI files
envA/bin/python fetch_bnci.py DATA > logs/fetch.log 2>&1 || fail "fetch BNCI"
log "BNCI files fetched: $(find DATA -name '*.mat' | wc -l)"
# ---- A
envA/bin/python new_computations/a_two_ended/run_a.py --repo release --data DATA --out results_A > logs/A.log 2>&1 || fail "A"
log "A complete"
# ---- C
envA/bin/python new_computations/common/link_bnci_layout.py --data DATA --sets 001-2014 004-2014 >> logs/STEPS.log 2>&1 || fail "link"
P=new_computations/c_published_regime; PR=$P/PROTOCOL-C.json
envC/bin/python $P/pr_run.py prepare --protocol $PR --benchmark bench --mne-data DATA --out results_C > logs/C_prepare.log 2>&1 || fail "C prepare"
log "C prepared"
PIDS=""
for k in 0 1 2 3 4 5; do envC/bin/python $P/pr_run.py fit --protocol $PR --benchmark bench --release release --out results_C --device cuda --threads 1 --shard $k/6 > logs/C_fit_$k.log 2>&1 & PIDS="$PIDS $!"; done
for k in 0 1; do envC/bin/python $P/pr_fidelity.py --protocol $PR --benchmark bench --mne-data DATA --out fidelity_C --threads 1 --shard $k/2 > logs/C_fid_$k.log 2>&1 & PIDS="$PIDS $!"; done
log "C fits started:$PIDS"
for p in $PIDS; do wait $p || log "a C process ended with an error (pid $p)"; done
envC/bin/python $P/pr_run.py fit --protocol $PR --benchmark bench --release release --out results_C --device cuda --threads 1 --shard 0/1 > logs/C_fit_check.log 2>&1 || fail "C fit check"
envC/bin/python $P/pr_run.py finalize --protocol $PR --out results_C >> logs/STEPS.log 2>&1 || fail "C finalize"
envC/bin/python $P/pr_fidelity.py --protocol $PR --benchmark bench --out fidelity_C --finalize >> logs/STEPS.log 2>&1 || fail "C fidelity finalize"
envC/bin/python $P/pr_analyze.py --protocol $PR --out results_C --analysis analysis_C --fidelity fidelity_C/FIDELITY.json > logs/C_analyze.log 2>&1 || fail "C analyze"
log "C complete"
