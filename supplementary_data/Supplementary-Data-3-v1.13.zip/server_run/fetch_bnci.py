"""Fetch the official BNCI files 001-2014, 002-2014, 004-2014 with MOABB 1.5.0 (its own download routine) into DATA.
Usage: fetch_bnci.py DATA"""
import os, sys
os.environ["MNE_DATA"] = os.environ["MNE_DATASETS_BNCI_PATH"] = os.path.abspath(sys.argv[1])
from moabb.datasets import BNCI2014_001, BNCI2014_002, BNCI2014_004
for cls, n in ((BNCI2014_001, 9), (BNCI2014_002, 14), (BNCI2014_004, 9)):
    ds = cls()
    for s in range(1, n + 1):
        print(cls.__name__, s, ds.data_path(s, update_path=False), flush=True)
