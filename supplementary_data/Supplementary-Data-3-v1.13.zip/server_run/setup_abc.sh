#!/bin/bash
# Operational driver on the rented server (not part of the scientific package; every scientific step is in new_computations/).
set -uo pipefail
W=/workspace/ABC; cd $W; mkdir -p logs
log(){ echo "[$(date -u +%FT%TZ)] $*" | tee -a logs/STEPS.log; }
fail(){ log "FAILED: $*"; exit 1; }
log "start"; nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader | tee -a logs/STEPS.log
(cd new_computations && sha256sum -c --quiet SHA256SUMS.txt) || fail "package hashes"
log "package V1.0 verified: $(sha256sum new_computations/SHA256SUMS.txt | cut -c1-64)"
command -v uv >/dev/null || pip install -q uv || fail "uv"
UV=$(command -v uv)
# ---- B in background (its own folder; unmodified public release v2.2.0)
mkdir -p /workspace/lee_repetition
cat > /workspace/lee_repetition/OPERATOR.md <<OP
# Operator of this run
Run operated by Claude (Anthropic; configured model id claude-fable-5-2, serving model may differ) on behalf of the first author
(Salih Colakoglu), on a RunPod server rented on the first author's account (pod "eeg-yeni-hesaplar-ABC", 1x RTX 4090).
Started $(date -u +%FT%TZ). This is a repetition by the authors' side on different hardware, not an independent replication.
OP
nohup python3 new_computations/b_repetition/run_b.py --root /workspace/lee_repetition all --workers-download 4 --workers-prepare 4 > logs/B.log 2>&1 &
log "B started (pid $!)"
# ---- checkouts
git clone -q --branch v2.2.0 --depth 1 https://github.com/salihcolakoglu/negotiated-targets-mi-eeg release || fail "clone release"
test "$(git -C release rev-parse HEAD)" = bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62 || fail "release commit"
git clone -q https://github.com/martinwimpff/channel-attention bench && git -C bench checkout -q f1ee0d4b665d8ea7c2cc5efc3e1ca9c56412b0c5 || fail "benchmark checkout"
log "checkouts ok"
# ---- environments
$UV venv -q --python 3.11 envA && $UV pip install -q --python envA/bin/python numpy==2.2.6 scipy==1.15.3 scikit-learn==1.7.2 pandas==2.3.3 h5py==3.15.1 mne==1.12.1 moabb==1.5.0 pooch==1.9.0 pyriemann==0.9 pymatreader==1.3.1 > logs/envA.log 2>&1 || fail "envA"
$UV venv -q --python 3.10 envC && $UV pip install --python envC/bin/python -c benchmark_lock_constraints.txt ./bench > logs/envC.log 2>&1 || fail "envC"
test -z "$(git -C bench status --porcelain --untracked-files=all | grep -v __pycache__)" || fail "benchmark checkout dirty after install"
envC/bin/python -c "import torch;print('envC torch',torch.__version__,torch.cuda.is_available())" | tee -a logs/STEPS.log
log "environments ok"
# ---- official BNCI files
envA/bin/python fetch_bnci.py DATA > logs/fetch.log 2>&1 || fail "fetch BNCI"
log "BNCI files fetched: $(find DATA -name '*.mat' | wc -l)"
# ---- A
envA/bin/python new_computations/a_two_ended/run_a.py --repo release --data DATA --out results_A > logs/A.log 2>&1 || fail "A"
log "A complete"
# ---- C
envA/bin/python new_computations/common/link_bnci_layout.py --data DATA --sets 001-2014 004-2014 >> logs/STEPS.log 2>&1 || fail "link"
P=new_computations/c_published_regime; PR=$P/PROTOCOL-C.json
envC/bin/python $P/pr_run.py prepare --protocol $PR --benchmark bench --mne-data DATA --out results_C > logs/C_prepare.log 2>&1 || fail "C prepare"
log "C prepared"
PIDS=""
for k in 0 1 2 3 4 5; do envC/bin/python $P/pr_run.py fit --protocol $PR --benchmark bench --release release --out results_C --device cuda --threads 1 --shard $k/6 > logs/C_fit_$k.log 2>&1 & PIDS="$PIDS $!"; done
for k in 0 1; do envC/bin/python $P/pr_fidelity.py --protocol $PR --benchmark bench --mne-data DATA --out fidelity_C --threads 1 --shard $k/2 > logs/C_fid_$k.log 2>&1 & PIDS="$PIDS $!"; done
log "C fits started:$PIDS"
for p in $PIDS; do wait $p || log "a C process ended with an error (pid $p)"; done
envC/bin/python $P/pr_run.py fit --protocol $PR --benchmark bench --release release --out results_C --device cuda --threads 1 --shard 0/1 > logs/C_fit_check.log 2>&1 || fail "C fit check"
envC/bin/python $P/pr_run.py finalize --protocol $PR --out results_C >> logs/STEPS.log 2>&1 || fail "C finalize"
envC/bin/python $P/pr_fidelity.py --protocol $PR --benchmark bench --out fidelity_C --finalize >> logs/STEPS.log 2>&1 || fail "C fidelity finalize"
envC/bin/python $P/pr_analyze.py --protocol $PR --out results_C --analysis analysis_C --fidelity fidelity_C/FIDELITY.json > logs/C_analyze.log 2>&1 || fail "C analyze"
log "C complete"
