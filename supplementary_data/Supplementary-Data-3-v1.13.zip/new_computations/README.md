# New computations for the manuscript revision (protocols and code)

Study: "Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding: A Controlled Evaluation of Accuracy and
Confidence" (Çolakoğlu, Onat, Korhan). Public release of the study: tag `v2.2.0`
(commit `bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62`) of this repository.

This folder holds three computations that were added in answer to an internal review of the manuscript. Each has a
written protocol. **The protocols and the code in this folder were written before the computations were run**
(written 15 November 2026, 17:15 (UTC+3)); the results are added later in a separate folder and do not change these files.

| | Question | Status | Size |
|---|---|---|---|
| A | CSP–LDA reference of Experiments 1 and 2 with the conventional two-ended filter selection | post hoc, descriptive; outcome known from a preliminary measurement (disclosed in the protocol) | no network training |
| B | Repetition of the Lee2019 evaluation (Experiment 3) on different hardware from the public code and data | repetition; agreement criteria fixed in advance | 1,350 networks |
| C | The study's target rules inside the published benchmark configuration of EEGNet (IV-2a, IV-2b) | exploratory; contrasts and reading rules fixed in advance | 360 networks + 18 fidelity fits |

- `PROTOCOL-A.md`, `PROTOCOL-B.md`, `PROTOCOL-C.md`: the written rules.
- `a_two_ended/`, `b_repetition/`, `c_published_regime/`, `common/`: the programs named in the protocols.
- `SHA256SUMS.txt`: SHA-256 of every file in this folder.

Materials that are used but not redistributed here: the study's release (this repository at `v2.2.0`); the
benchmark code of Wimpff et al. (`https://github.com/martinwimpff/channel-attention`, commit
`f1ee0d4b665d8ea7c2cc5efc3e1ca9c56412b0c5`, MIT licence); the BNCI Horizon 2020 recordings (001-2014, 002-2014,
004-2014); the Lee2019 recordings (GigaDB, doi 10.5524/100542, CC0). `b_repetition/100542.md5` is the publisher's
checksum list of the Lee2019 dataset; `b_repetition/download_lee.py` is the downloader of the original run.

The programs of this folder follow the MIT licence of the repository. They were written with the assistance of an
AI system (Claude, Anthropic) under the direction of the first author; the authors are responsible for them.
