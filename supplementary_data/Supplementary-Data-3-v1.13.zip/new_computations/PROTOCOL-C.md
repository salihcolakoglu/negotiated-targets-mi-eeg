# Protocol C — The study's target rules inside the published benchmark configuration of EEGNet

Study: "Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding" (Çolakoğlu, Onat, Korhan).
Protocol version 1.0, written 15 November 2026, 17:15 (UTC+3) before any network of this computation was trained on EEG data.
Machine-readable companion: `c_published_regime/PROTOCOL-C.json` (SHA-256 `c1b4aa3fd1900627506aa1fbc14e976a0bf632cb23f579f31616a65d9bc4ae31`).

## 1. Question and status

In Experiment 2 the EEGNet baseline reached 67–68 % on BCI Competition IV-2a and about 72 % on IV-2b, below the
values of a published benchmark (71.06 % and 83.54 %; Wimpff et al., J. Neural Eng. 2024). The differences between
target rules were therefore measured with a weaker baseline. The question is whether the two contrasts of the
study keep their size when the same rules are trained in the benchmark's own configuration.

Status: **exploratory**. The protocol is fixed before the run, but the test sessions of both datasets were already
used in Experiments 1 and 2 (in another preprocessing and training configuration; there W2 − W0 was −0.10 and
W1 − W0 was +0.08 percentage points over these 18 participants). The result is reported as a sensitivity analysis.

## 2. Benchmark configuration (taken without change)

Public code `https://github.com/martinwimpff/channel-attention`, commit
`f1ee0d4b665d8ea7c2cc5efc3e1ca9c56412b0c5` (MIT licence), configuration files `configs/bcic2a_eegnet.yaml` and
`configs/bcic2b_eegnet.yaml`. From the benchmark, unchanged: its data module (loading with braindecode/MOABB,
resampling to 128 Hz, 40 Hz low-pass, window 0.5–2.5 s after the cue = 256 samples, standardization fitted on the
training trials, partition), its EEGNet model class (8 temporal filters, depth 2, 16 separable filters, temporal
kernel 32, dropout 0.5; 1,716 parameters for IV-2a with class outputs), its seeding function, and the values of its
configuration: Adam, learning rate 0.001, no weight decay, no scheduler, batch 64, **500 epochs**, final model
(no early stopping, no selection).

Note on the number of epochs. The benchmark article states a general schedule of 1,000 epochs; the public
configuration files of EEGNet set 500 epochs and no learning-rate scheduler. This computation follows the public
configuration files. Section 7 compares the resulting baseline with the published values.

Partitions (the benchmark's): IV-2a — training session T, test session E (9 participants, four classes);
IV-2b — training sessions 1–3, test sessions 4–5 (9 participants, two classes).

## 3. Conditions (the study's, release v2.2.0, `src/eegnet/core.py`)

| | Output and loss | Training targets |
|---|---|---|
| S0 | K class outputs, cross-entropy | hard labels (this is the benchmark's own setting) |
| W0 | 16 Walsh-coded outputs, binary cross-entropy | fixed codeword of the class |
| W1 | as W0 | cumulative negotiation: T ← T − 0.03·p·(T − P) |
| W2 | as W0 | anchored, correctness-gated: T ← y + 0.03·p·(P − y) for training trials that the network decodes correctly, otherwise y |

Training runs in ten phases of 50 epochs (10 × 50 = 500; in the study 10 × 30 = 300). After phase p (p = 0…9) the
network predicts the training trials in evaluation mode (P); the rule gives the targets of the next phase; the
update after the last phase is not used. The codebook is the first K rows of the 16-bit Walsh matrix of the release;
Walsh outputs are decoded by the nearest codeword. The test trials are predicted once, by the final model.

Seeds 0–4 (the benchmark's configuration uses seed 0 and reports five runs). 2 datasets × 9 participants ×
4 conditions × 5 seeds = **360 fits**. Conditions are paired by participant and seed: the initial weights of all
shared layers and the order of the mini-batches are the same.

Random numbers. The training loop draws from the random-number generator at the same points as the benchmark's
trainer, so that S0 with a given seed is the benchmark's own training run. In a test on synthetic data the final
weights were identical, tensor by tensor, to those of the benchmark's unmodified training code (100 epochs).

## 4. Fidelity check on the EEG data (18 fits, not part of the contrasts)

For seed 0 the benchmark's own function `train_and_test` is called unmodified for every participant
(`pr_fidelity.py`), on the same machine. Its accuracies are compared with S0, participant by participant. The
number of identical participants and the largest difference are reported as observed.

## 5. Analysis (`pr_analyze.py`)

Unit: the participant; value: the mean test accuracy of the five seeds in a condition; 18 participants (both
datasets together, as the 32 participants of Experiments 1 and 2 were analysed together).

**Family of two contrasts**, two-sided paired t tests, Holm across the two, α = 0.05:

1. W2 − W0 (primary contrast of the study),
2. W1 − W0 (secondary contrast of the study).

For the same two contrasts: two one-sided tests against −1 and +1 percentage point (the one-point criterion of the
study), Holm across the two, with the 90 % interval.

**Descriptive**, without a claim of confirmation: the same contrasts within each dataset (n = 9); W0 − S0 and
W2 − W1; training accuracy of the final model (W1 − W0, W2 − W0); negative log-likelihood and expected calibration
error of each condition.

## 6. Reading rules (fixed in advance)

For each of the two contrasts two statements are evaluated: D (Holm-adjusted p < 0.05) and E (Holm-adjusted
equivalence p < 0.05).

- D without E → reported as a difference in this configuration, with its sign;
- D and E → reported as a difference smaller than one percentage point;
- E without D → reported as equivalent within one percentage point;
- neither → reported as inconclusive.

The result is reported whatever it is, including a change of sign or size relative to Experiments 1–3. It does not
replace the pre-specified evaluation of Experiment 3.

Sensitivity: with 18 participants a paired t test at the first Holm step (α = 0.025) has 80 % power for a
standardized difference d_z = 0.79. With the spread that these 18 participants showed in Experiment 2 (standard
deviation of the paired difference 0.86 points for W2 − W0 and 1.56 points for W1 − W0) this corresponds to about
0.7 and 1.2 percentage points. Smaller differences cannot be established by this computation.

## 7. Baseline criterion (fixed in advance)

S0 is formed as in the benchmark: the mean, and the standard deviation over the five runs, of the dataset accuracy.
If the S0 mean lies within 2.0 percentage points of the published mean (71.06 % for IV-2a, 83.54 % for IV-2b), the
manuscript states that the published baseline was reproduced; otherwise it states the obtained value and that the
published baseline was not reproduced. The contrasts are reported in either case.

## 8. Completeness and exceptions

All 360 fits and the 18 fidelity fits must complete; no participant, seed or fit is excluded. A fit that is
interrupted is trained again from its beginning with the same seed. Test accuracy is not printed or inspected
before all 360 fits are complete and the completion file is written.

## 9. Environment

The package versions of the benchmark's lock file: Python 3.10, torch 2.0.1, pytorch-lightning 2.0.7,
braindecode 0.7, moabb 0.5.0, mne 1.5.1, numpy 1.26.0, scipy 1.11.2, scikit-learn 1.3.1; the study's code for
decoding and metrics at release v2.2.0 (commit `bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62`). Device and exact
versions are written into every fit record. The raw recordings are the official BNCI files identified by SHA-256
(`common/BNCI_RAW_SHA256.txt`).

## 10. Reporting

A short paragraph in the Discussion (context from published benchmarks), one table in the Supplementary
Information, records and test outputs in Supplementary Data 2.

## 11. Files of this computation

| File | SHA-256 |
|---|---|
| `c_published_regime/pr_core.py` | `7d36121bf076703a1245016e83fbe6fdbbe04ae32a28d64207a457fdc9408aeb` |
| `c_published_regime/pr_run.py` | `128e00735c43e7d0f9aa22aa6ab7d4c746250f447426569e25c740c956fd3b11` |
| `c_published_regime/pr_fidelity.py` | `2c0cd61adc54e029ca787dfd93a0dc64cc4e08d1f3b5c58e9ea9dda298c4eef3` |
| `c_published_regime/pr_analyze.py` | `653c2bb51f91359e3fa7af76991372bb7f8111b22b1df3cb580ef7c59fcf9bf2` |
| `c_published_regime/PROTOCOL-C.json` | `c1b4aa3fd1900627506aa1fbc14e976a0bf632cb23f579f31616a65d9bc4ae31` |
| `common/BNCI_RAW_SHA256.txt` | `6e3212a58b9fe6e6336792ecf90094ceed2d4c3200001da7a99843bc59e4b32c` |
| `common/link_bnci_layout.py` | `605b1bc7cf0a10ba2e3366c1d904a4e75c274eba87aabdcf1ac519741c62ce6c` |

Commands: `pr_run.py prepare`, `pr_run.py fit` (parts can run in parallel), `pr_run.py finalize`,
`pr_fidelity.py`, `pr_analyze.py` (see the first lines of each file).

## 12. Deviations

Any deviation from this protocol is written, with its reason and time, into `DEVIATIONS.md` next to the results and
is reported with them.
