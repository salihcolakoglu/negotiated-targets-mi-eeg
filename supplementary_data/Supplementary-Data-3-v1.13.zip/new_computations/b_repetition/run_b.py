#!/usr/bin/env python3
"""Computation B, driver: repeat the Lee2019 evaluation (Experiment 3) on another machine from public code and data.

Every scientific step is the unmodified public release v2.2.0 of the study's repository:
  preparation   extensions/studies/lee54/source/prepare_lee2019.py   (one recording day per call)
  training      extensions/train.py  init, validate, fit, freeze, test, analyze  --study lee54
This driver only fetches the public files, calls those programs in the documented order, keeps logs and packs the
results. It uses the Python standard library; the scientific programs run in a separate environment created by the
`env` step with the package versions pinned by the release (extensions/requirements-training.txt).

Steps (each can be repeated; finished work is kept):
  env        clone the release at tag v2.2.0, create the Python environment, write the environment report
  download   108 MATLAB files of the labelled offline recordings (two days x 54 participants, about 61 GB) from
             GigaDB (doi 10.5524/100542); each file is checked against the publisher's MD5 list
  prepare    108 calls of the release's preparation program
  train      init, validate, fit (1,350 networks and 54 classical references), freeze, test, analyze
  compare    compare_with_published.py (new run against the published records)
  pack       one zip file with records, test outputs, tables and logs (no EEG signals, no network weights)
  status     counts of finished files
  all        env, download, prepare, train, compare, pack

Usage: python3 run_b.py --root /workspace/lee_repetition STEP [--workers-download 4] [--workers-prepare 3]
                        [--device cuda] [--clear-stale-lock] [--dry-run]
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
RELEASE_URL = "https://github.com/salihcolakoglu/negotiated-targets-mi-eeg"
RELEASE_TAG = "v2.2.0"
RELEASE_COMMIT = "bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62"
MD5_LIST_SHA256 = "20b1ef60db5877a8508bfb9fb04a206cf9173d884bf48850ce2627d55c957cb4"      # publisher's list 100542.md5 (as in the release protocol)
DOWNLOADER_SHA256 = "7b3dcf1bb92220c7f029b0df46d0b99dbf8051696778533abea9055175d05290"    # downloader of the original run, unchanged
PYTHON_VERSION = "3.12"
SUBJECTS = list(range(1, 55))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class Driver:
    def __init__(self, args):
        self.a = args
        self.root = Path(args.root).resolve()
        self.release = self.root / "release"
        self.env = self.root / "env"
        self.py = self.env / "bin" / "python"
        self.lee = self.root / "lee"                    # layout of the original downloader: prepare/, data/raw/, logs/downloads/
        self.prepared = self.lee / "prepared"
        self.run = self.root / "run"                    # new work folder of extensions/train.py
        self.logs = self.root / "logs"
        self.state = self.root / "RUN_PROTOCOL.json"

    # ---------------------------------------------------------------- helpers
    def call(self, command, log=None, cwd=None, env=None, check=True):
        text = " ".join(str(c) for c in command)
        print("[%s] %s" % (now(), text), flush=True)
        if self.a.dry_run:
            return 0, ""
        self.logs.mkdir(parents=True, exist_ok=True)
        if log is None:
            done = subprocess.run([str(c) for c in command], cwd=cwd, env=env, capture_output=True, text=True)
            output = done.stdout + done.stderr
        else:
            with open(self.logs / log, "a", encoding="utf-8") as handle:
                handle.write("\n===== %s %s\n" % (now(), text))
                handle.flush()
                done = subprocess.run([str(c) for c in command], cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT, text=True)
            output = (self.logs / log).read_text("utf-8", errors="replace")
        if check and done.returncode != 0:
            print(output[-3000:], flush=True)
            raise SystemExit("step failed (exit %d): %s" % (done.returncode, text))
        return done.returncode, output

    def release_ok(self):
        head = subprocess.run(["git", "-C", str(self.release), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
        dirty = subprocess.run(["git", "-C", str(self.release), "status", "--porcelain", "--untracked-files=all"], capture_output=True, text=True).stdout
        dirty = [line for line in dirty.splitlines() if "__pycache__" not in line and not line.endswith(".pyc")]
        if head != RELEASE_COMMIT or dirty:
            raise SystemExit("the release checkout is not the unmodified tag %s" % RELEASE_TAG)

    # ---------------------------------------------------------------- steps
    def step_env(self):
        if not self.a.dry_run:
            self.root.mkdir(parents=True, exist_ok=True)
        if not self.release.exists():
            self.call(["git", "clone", "--branch", RELEASE_TAG, "--depth", "1", RELEASE_URL, self.release], log="env.log")
        if not self.a.dry_run:
            self.release_ok()
        if not self.py.exists():
            if shutil.which("uv") is None:               # uv creates the environment with the Python version of the release
                code, _ = self.call([sys.executable, "-m", "pip", "install", "--quiet", "uv"], log="env.log", check=False)
                if code != 0:                            # system Python marked as externally managed
                    self.call([sys.executable, "-m", "pip", "install", "--quiet", "--break-system-packages", "uv"], log="env.log")
            uv = shutil.which("uv") or str(Path.home() / ".local" / "bin" / "uv")
            self.call([uv, "venv", "--python", PYTHON_VERSION, self.env], log="env.log")
            self.call([uv, "pip", "install", "--python", self.py, "-r", self.release / "extensions" / "requirements-training.txt"], log="env.log")
        report = self.root / "ENVIRONMENT.json"
        code = ("import json,platform,torch,numpy,scipy,sklearn,mne,joblib;"
                "print(json.dumps(dict(python=platform.python_version(),platform=platform.platform(),numpy=numpy.__version__,scipy=scipy.__version__,"
                "torch=str(torch.__version__),cuda_runtime=torch.version.cuda,cuda_available=torch.cuda.is_available(),"
                "gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,scikit_learn=sklearn.__version__,mne=mne.__version__,joblib=joblib.__version__)))")
        _, out = self.call([self.py, "-c", code])
        if self.a.dry_run:
            return
        info = json.loads(out.strip().splitlines()[-1])
        if self.a.device == "cuda" and not info["cuda_available"]:
            raise SystemExit("no CUDA device is visible to PyTorch")
        smi = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
        cpu = ""
        if Path("/proc/cpuinfo").exists():
            names = [line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")]
            cpu = names[0] if names else ""
        mem = ""
        if Path("/proc/meminfo").exists():
            mem = Path("/proc/meminfo").read_text().splitlines()[0]
        info.update(observed_utc=now(), nvidia_smi=smi, cpu=cpu, logical_processors=os.cpu_count(), memory=mem, machine=platform.machine(),
                    release_commit=RELEASE_COMMIT, driver_sha256=sha256(__file__))
        report.write_text(json.dumps(info, indent=1) + "\n", encoding="utf-8")
        print(json.dumps(info, indent=1), flush=True)

    def step_download(self):
        (self.lee / "prepare").mkdir(parents=True, exist_ok=True)
        md5 = self.lee / "prepare" / "100542.md5"
        if not self.a.dry_run:
            if sha256(HERE / "100542.md5") != MD5_LIST_SHA256 or sha256(HERE / "download_lee.py") != DOWNLOADER_SHA256:
                raise SystemExit("the MD5 list or the downloader differs from the protocol")
            if not md5.exists():
                shutil.copyfile(HERE / "100542.md5", md5)
        self.call([sys.executable, HERE / "download_lee.py", "--root", self.lee, "--subjects", *SUBJECTS, "--sessions", 1, 2,
                   "--workers", self.a.workers_download], log="download.log")
        if self.a.dry_run:
            return
        records = sorted((self.lee / "logs" / "downloads").glob("sess*_EEG_MI.mat.json"))
        good = [json.loads(p.read_text("utf-8")) for p in records]
        if len(good) != 108 or any(r["status"] != "verified" or r["md5"] != r["published_md5"] for r in good):
            raise SystemExit("download incomplete: %d verified records" % len(good))
        print("download complete: 108 files, %.1f GB, every file equal to the publisher's MD5" % (sum(r["bytes"] for r in good) / 1e9), flush=True)

    def prepare_subject(self, subject):
        meta = self.prepared / ("subject_%02d_meta.json" % subject)
        for day, part in ((1, "train"), (2, "test")):
            target = self.prepared / ("subject_%02d_%s.npz" % (subject, part))
            listed = meta.exists() and part in json.loads(meta.read_text("utf-8")).get("days", {})
            if target.exists() and listed:
                continue
            mat = self.lee / "data" / "raw" / ("session%d" % day) / ("s%d" % subject) / ("sess%02d_subj%02d_EEG_MI.mat" % (day, subject))
            command = [self.py, self.release / "extensions" / "studies" / "lee54" / "source" / "prepare_lee2019.py", "--mat", mat,
                       "--subject", subject, "--day", day, "--out-dir", self.prepared, "--checksum-manifest", self.lee / "prepare" / "100542.md5"]
            if target.exists():                       # the array was written but its metadata entry was not: repeat this day
                command.append("--overwrite")
            self.call(command, log="prepare_subject_%02d.log" % subject)
        return subject

    def step_prepare(self):
        self.prepared.mkdir(parents=True, exist_ok=True)
        if not self.a.dry_run:
            self.release_ok()
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.a.workers_prepare) as pool:
            for subject in pool.map(self.prepare_subject, SUBJECTS):
                print("prepared subject %02d" % subject, flush=True)
        if self.a.dry_run:
            return
        names = [f"subject_{s:02d}_{tail}" for s in SUBJECTS for tail in ("train.npz", "test.npz", "meta.json")]
        missing = [n for n in names if not (self.prepared / n).exists()]
        if missing:
            raise SystemExit("preparation incomplete: %d files missing" % len(missing))
        print("preparation complete: 162 files", flush=True)

    def step_train(self):
        if not self.a.dry_run:
            self.release_ok()
        train = self.release / "extensions" / "train.py"
        if not self.state.exists():
            if self.run.exists() and not self.a.dry_run:
                raise SystemExit("a work folder exists without its protocol record: " + str(self.run))
            _, out = self.call([self.py, train, "init", "--study", "lee54", "--data-root", self.prepared, "--work", self.run, "--device", self.a.device],
                               cwd=self.release)
            if self.a.dry_run:
                state = dict(protocol=str(self.run / "PUBLIC_PROTOCOL.json"), sha256="<printed by init>")
            else:
                state = json.loads([line for line in out.splitlines() if line.startswith("{")][-1])
                if state["input_files"] != 162 or state["sha256"] != sha256(state["protocol"]):
                    raise SystemExit("unexpected answer of init")
                state["initialised_utc"] = now()
                self.state.write_text(json.dumps(state, indent=1) + "\n", encoding="utf-8")
        else:
            state = json.loads(self.state.read_text("utf-8"))
        lock = self.run / "PUBLIC_RUNNING.lock"
        if lock.exists():
            if not self.a.clear_stale_lock:
                raise SystemExit("PUBLIC_RUNNING.lock exists: another run is active, or an earlier one was interrupted. "
                                 "If no training process is running, repeat with --clear-stale-lock.")
            lock.unlink()
        done = {"fit": self.run / "MODEL_FREEZE.json", "freeze": self.run / "MODEL_FREEZE.json", "test": self.run / "TEST_COMPLETION.json",
                "analyze": self.run / "final_analysis" / "final_analysis.json"}
        for command in ("validate", "fit", "freeze", "test", "analyze"):
            if command in done and done[command].exists():
                print("%s: already complete" % command, flush=True)
                continue
            self.call([self.py, train, command, "--protocol", state["protocol"], "--protocol-sha256", state["sha256"]],
                      log="train_%s.log" % command, cwd=self.release)
        print("training, test and analysis complete", flush=True)

    def step_compare(self):
        out = self.root / "comparison"
        if out.exists():
            print("comparison: already written", flush=True)
            return
        _, text = self.call([self.py, HERE / "compare_with_published.py", "--release", self.release, "--run", self.run,
                             "--prepared", self.prepared, "--out", out])
        print(text, flush=True)

    def step_pack(self):
        target = self.root / "LEE_REPETITION_RESULTS.zip"
        if self.a.dry_run:
            print("would write", target)
            return
        if not (self.root / "OPERATOR.md").exists():
            raise SystemExit("write OPERATOR.md (who operated this run, on whose account, when) into %s before packing" % self.root)
        members = []
        for pattern in ("PUBLIC_PROTOCOL.json", "MODEL_FREEZE.json", "TEST_COMPLETION.json", "classical_summary.csv", "final_analysis/*",
                        "records/*.json", "training_records/*.json", "predictions/*.npz", "classical_results/*.json",
                        "classical_fit_records/*.json", "classical_predictions/*.npz"):
            members += [(p, "run/" + p.relative_to(self.run).as_posix()) for p in sorted(self.run.glob(pattern))]
        members += [(p, "prepared_metadata/" + p.name) for p in sorted(self.prepared.glob("subject_*_meta.json"))]
        members += [(p, "download_records/" + p.name) for p in sorted((self.lee / "logs" / "downloads").glob("*.json"))]
        members += [(p, "comparison/" + p.name) for p in sorted((self.root / "comparison").glob("*"))]
        members += [(p, "logs/" + p.name) for p in sorted(self.logs.glob("*.log"))]
        members += [(p, p.name) for p in (self.root / "ENVIRONMENT.json", self.state, self.root / "OPERATOR.md", self.root / "DEVIATIONS.md") if p.exists()]
        members += [(p, "package/" + p.name) for p in sorted(HERE.glob("*")) if p.is_file()]
        forbidden = (".pt", ".mat", ".joblib")
        if any(name.endswith(forbidden) for _, name in members):
            raise SystemExit("refusing to pack network weights, classical heads or EEG files")
        listing = {name: sha256(path) for path, name in members}
        tmp = target.with_suffix(".tmp")
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            for path, name in members:
                z.write(path, name)
            z.writestr("SHA256SUMS.json", json.dumps(listing, indent=1) + "\n")
        os.replace(tmp, target)
        print("packed %d files: %s (%.1f MB), SHA-256 %s" % (len(members), target, target.stat().st_size / 1e6, sha256(target)), flush=True)

    def step_status(self):
        def count(folder, pattern):
            return len(list(folder.glob(pattern))) if folder.exists() else 0
        status = dict(time_utc=now(),
                      downloaded_files=count(self.lee / "logs" / "downloads", "sess*_EEG_MI.mat.json"), of_downloads=108,
                      prepared_arrays=count(self.prepared, "subject_*_t*.npz"), of_prepared=108,
                      fits=count(self.run / "training_records", "*.json"), of_fits=1350,
                      classical_fits=count(self.run / "classical_fit_records", "*.json"), of_classical=54,
                      tests=count(self.run / "records", "*.json"), of_tests=1350,
                      frozen=(self.run / "MODEL_FREEZE.json").exists(), tests_complete=(self.run / "TEST_COMPLETION.json").exists(),
                      analysis=(self.run / "final_analysis" / "final_analysis.json").exists(), comparison=(self.root / "comparison").exists(),
                      packed=(self.root / "LEE_REPETITION_RESULTS.zip").exists(), lock=(self.run / "PUBLIC_RUNNING.lock").exists())
        if shutil.which("df"):
            status["disk"] = subprocess.run(["df", "-h", str(self.root if self.root.exists() else self.root.parent)], capture_output=True, text=True).stdout.splitlines()[-1]
        print(json.dumps(status, indent=1), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("step", choices=["env", "download", "prepare", "train", "compare", "pack", "status", "all"])
    parser.add_argument("--root", required=True)
    parser.add_argument("--workers-download", type=int, default=4)
    parser.add_argument("--workers-prepare", type=int, default=3)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--clear-stale-lock", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    driver = Driver(args)
    steps = ["env", "download", "prepare", "train", "compare", "pack"] if args.step == "all" else [args.step]
    for step in steps:
        print("===== step: %s (%s)" % (step, now()), flush=True)
        getattr(driver, "step_" + step)()
    print("===== finished: %s (%s)" % (", ".join(steps), now()), flush=True)


if __name__ == "__main__":
    main()
