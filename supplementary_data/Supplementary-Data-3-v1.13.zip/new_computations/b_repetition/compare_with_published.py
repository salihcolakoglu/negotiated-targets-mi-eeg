#!/usr/bin/env python3
"""Computation B, comparison: a new complete run of the Lee2019 evaluation against the published records.

Nothing is trained or decoded by a model here. The script reads
  the published records of release v2.2.0   reference/new_studies_results.zip (tables, test predictions),
  the new run                               RUN/final_analysis/*.csv, RUN/predictions/*.npz, RUN/classical_predictions/*.npz
and writes the agreement measures fixed in PROTOCOL-B.md:

  1. the five paired contrasts of the published protocol, new run next to the published run;
  2. the five condition means;
  3. participant level, per condition: correlation, mean absolute difference and paired difference (new - published);
  4. fit level: share of the 1,350 fits with the same test accuracy, and share of the 135,000 test decisions that agree;
  5. the 54 classical reference fits (deterministic pipeline);
  6. the prepared input arrays: number of files byte-identical to the originally prepared files.

Decisions are decoded from the stored outputs with the expressions of the release's own verification script
(extensions/verify_retained.py): arg max for S0, nearest codeword for the Walsh conditions.

Usage: compare_with_published.py --release RELEASE_REPO --run RUN_FOLDER --prepared PREPARED_FOLDER --out NEW_FOLDER
"""
import argparse
import csv
import hashlib
import io
import json
import math
import sys
import zipfile
from pathlib import Path

import numpy as np

RELEASE_COMMIT = "bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62"
CONDITIONS = ["S0", "W0", "W1", "W2", "W3"]
SEEDS = [1, 2, 3, 4, 5]
SUBJECTS = list(range(1, 55))
CONTRASTS = ["W2-W0", "W1-W0", "W2-W1", "W2-W3", "W0-S0"]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def decisions(P, condition):
    """Class decisions from stored network outputs; same expressions as extensions/verify_retained.py."""
    if condition == "S0":
        return P.astype(np.float64).argmax(1)
    C = np.stack([np.ones(16, np.float32), np.tile(np.array([1, 0], np.float32), 8)])
    p = P.astype(np.float64)
    return ((p[:, None, :] - C[None, :, :]) ** 2).sum(-1).argmin(1)


def t_interval(d):
    """Mean, SD and 95% t interval of paired differences (percentage points); t quantile from scipy if available."""
    d = np.asarray(d, dtype=np.float64)
    n, mean, sd = int(d.size), float(d.mean()), float(d.std(ddof=1))
    out = dict(n=n, mean_pp=mean, sd_pp=sd)
    if sd > 0:
        from scipy import stats
        se = sd / math.sqrt(n)
        crit = float(stats.t.ppf(0.975, n - 1))
        out.update(ci95_pp=[mean - crit * se, mean + crit * se], p_two_sided=float(2 * stats.t.sf(abs(mean / se), n - 1)))
    return out


def read_csv(text):
    return list(csv.DictReader(io.StringIO(text)))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    release, run = args.release.resolve(), args.run.resolve()

    manifest = json.loads((release / "extensions" / "RESULTS_MANIFEST.json").read_text("utf-8"))
    archive = release / manifest["archive"]
    if sha256(archive) != manifest["archive_sha256"]:
        raise SystemExit("published archive differs from the release manifest")
    completion = json.loads((run / "TEST_COMPLETION.json").read_text("utf-8"))
    protocol = json.loads((run / "PUBLIC_PROTOCOL.json").read_text("utf-8"))
    if completion["count"] != 1350 or completion["classical"] != 54 or completion["protocol_sha256"] != sha256(run / "PUBLIC_PROTOCOL.json"):
        raise SystemExit("the new run is not a complete run of its own protocol")
    for name, digest in completion["files"].items():
        if sha256(run / name) != digest:
            raise SystemExit("file changed after test completion: " + name)

    with zipfile.ZipFile(archive) as z:
        pub_contrasts = {r["contrast"]: r for r in read_csv(z.read("lee54/tables/five_paired_contrasts_holm.csv").decode("utf-8"))}
        pub_conditions = {r["condition"]: r for r in read_csv(z.read("lee54/tables/condition_summary.csv").decode("utf-8"))}
        pub_participants = {(int(r["subject"]), r["condition"]): float(r["accuracy"])
                            for r in read_csv(z.read("lee54/tables/participant_seed_averages.csv").decode("utf-8"))}
        new_contrasts = {r["contrast"]: r for r in read_csv((run / "final_analysis" / "five_paired_contrasts_holm.csv").read_text("utf-8"))}
        new_conditions = {r["condition"]: r for r in read_csv((run / "final_analysis" / "condition_summary.csv").read_text("utf-8"))}
        new_participants = {(int(r["subject"]), r["condition"]): float(r["accuracy"])
                            for r in read_csv((run / "final_analysis" / "participant_seed_averages.csv").read_text("utf-8"))}
        if set(pub_contrasts) != set(CONTRASTS) or set(new_contrasts) != set(CONTRASTS):
            raise SystemExit("unexpected contrast table")
        if set(pub_participants) != {(s, c) for s in SUBJECTS for c in CONDITIONS} or set(new_participants) != set(pub_participants):
            raise SystemExit("unexpected participant table")

        # 1. contrasts
        contrasts = []
        for name in CONTRASTS:
            p, q = pub_contrasts[name], new_contrasts[name]
            row = dict(contrast=name, primary=p["primary"] == "True")
            for label, r in (("published", p), ("new", q)):
                row[label] = dict(mean_difference_pp=float(r["mean_difference_percentage_points"]),
                                  ci95_pp=[float(r["ci95_low_percentage_points"]), float(r["ci95_high_percentage_points"])],
                                  p_two_sided=float(r["p_two_sided"]), p_holm_five=float(r["p_holm_five"]),
                                  significant_after_holm=r["significant_after_holm_0_05"] == "True")
            row["same_holm_decision"] = row["published"]["significant_after_holm"] == row["new"]["significant_after_holm"]
            row["new_estimate_inside_published_ci"] = bool(row["published"]["ci95_pp"][0] <= row["new"]["mean_difference_pp"] <= row["published"]["ci95_pp"][1])
            row["published_estimate_inside_new_ci"] = bool(row["new"]["ci95_pp"][0] <= row["published"]["mean_difference_pp"] <= row["new"]["ci95_pp"][1])
            row["difference_of_estimates_pp"] = row["new"]["mean_difference_pp"] - row["published"]["mean_difference_pp"]
            contrasts.append(row)

        # 2. and 3. conditions and participants
        conditions = []
        for c in CONDITIONS:
            a = np.array([new_participants[(s, c)] for s in SUBJECTS])
            b = np.array([pub_participants[(s, c)] for s in SUBJECTS])
            diff = 100 * (a - b)
            conditions.append(dict(condition=c, published_mean_pct=float(pub_conditions[c]["accuracy_mean_percent"]),
                                   new_mean_pct=float(new_conditions[c]["accuracy_mean_percent"]),
                                   pearson_r_between_runs=float(np.corrcoef(a, b)[0, 1]),
                                   mean_absolute_difference_pp=float(np.abs(diff).mean()),
                                   largest_absolute_difference_pp=float(np.abs(diff).max()),
                                   new_minus_published=t_interval(diff)))

        # 4. fit level
        same_accuracy = agree = total = 0
        fit_abs = []
        by_condition = {c: [0, 0] for c in CONDITIONS}
        for s in SUBJECTS:
            for c in CONDITIONS:
                for k in SEEDS:
                    key = "subject_%02d_train__%s__seed%d" % (s, c, k)
                    with np.load(io.BytesIO(z.read("lee54/predictions/%s.npz" % key)), allow_pickle=False) as a:
                        y_pub, d_pub = a["y_test"], decisions(a["P_test"], c)
                    with np.load(run / "predictions" / (key + ".npz"), allow_pickle=False) as a:
                        y_new, d_new = a["y_test"], decisions(a["P_test"], c)
                    if not np.array_equal(y_pub, y_new):
                        raise SystemExit("test labels differ between the runs: " + key)
                    acc_pub, acc_new = float((d_pub == y_pub).mean()), float((d_new == y_new).mean())
                    same_accuracy += int(abs(acc_pub - acc_new) < 1e-12)
                    fit_abs.append(abs(acc_new - acc_pub) * 100)
                    agree += int((d_pub == d_new).sum())
                    total += int(d_pub.size)
                    by_condition[c][0] += int((d_pub == d_new).sum())
                    by_condition[c][1] += int(d_pub.size)
        fits = dict(fits=1350, fits_with_same_test_accuracy=same_accuracy, mean_absolute_accuracy_difference_pp=float(np.mean(fit_abs)),
                    largest_absolute_accuracy_difference_pp=float(np.max(fit_abs)), test_decisions=total, test_decisions_that_agree=agree,
                    share_of_decisions_that_agree=agree / total,
                    share_by_condition={c: v[0] / v[1] for c, v in by_condition.items()})

        # 5. classical reference
        identical = 0
        classical_pub, classical_new = [], []
        for s in SUBJECTS:
            with np.load(io.BytesIO(z.read("lee54/classical/subject_%02d_classical_predictions.npz" % s)), allow_pickle=False) as a:
                y_pub, d_pub = a["y_test"], a["P_test"].argmax(1)
            with np.load(run / "classical_predictions" / ("subject_%02d.npz" % s), allow_pickle=False) as a:
                y_new, d_new = a["y_test"], a["P_test"].argmax(1)
            if not np.array_equal(y_pub, y_new):
                raise SystemExit("classical test labels differ: subject %d" % s)
            identical += int(np.array_equal(d_pub, d_new))
            classical_pub.append(float((d_pub == y_pub).mean()))
            classical_new.append(float((d_new == y_new).mean()))
        classical = dict(participants=54, participants_with_identical_decisions=identical,
                         largest_absolute_accuracy_difference_pp=100 * float(np.max(np.abs(np.array(classical_new) - np.array(classical_pub)))),
                         published_mean_pct=100 * float(np.mean(classical_pub)), new_mean_pct=100 * float(np.mean(classical_new)))

    # 6. prepared inputs against the hashes of the originally prepared files (public calibration protocol of the release)
    original = json.loads((release / "extensions" / "studies" / "lee_calibration80_20" / "scientific_protocol.public.json").read_text("utf-8"))["protocol"]["data"]["prepared_sha256"]
    same_bytes = {"train": 0, "test": 0}
    same_arrays_note = "byte identity of the compressed files; arrays that differ in the last bits give different bytes"
    for s in SUBJECTS:
        for part in ("train", "test"):
            name = "subject_%02d_%s.npz" % (s, part)
            same_bytes[part] += int(sha256(args.prepared / name) == original[name])
    prepared = dict(files_per_part=54, byte_identical_training_files=same_bytes["train"], byte_identical_test_files=same_bytes["test"], note=same_arrays_note)

    summary = dict(
        all_five_holm_decisions_the_same=all(r["same_holm_decision"] for r in contrasts),
        all_five_new_estimates_inside_published_ci=all(r["new_estimate_inside_published_ci"] for r in contrasts),
        largest_absolute_change_of_a_contrast_pp=float(max(abs(r["difference_of_estimates_pp"]) for r in contrasts)),
        largest_absolute_change_of_a_condition_mean_pp=float(max(abs(r["new_mean_pct"] - r["published_mean_pct"]) for r in conditions)))
    result = dict(computation="B: repetition of the Lee2019 evaluation on different hardware, from the public code and the public data",
                  release_commit=RELEASE_COMMIT, published_archive_sha256=manifest["archive_sha256"],
                  new_run=dict(protocol_sha256=sha256(run / "PUBLIC_PROTOCOL.json"), device=protocol["device"], runtime_versions=protocol["runtime_versions"],
                               created_utc=protocol["created_utc"]),
                  summary=summary, contrasts=contrasts, conditions=conditions, fit_level=fits, classical_reference=classical, prepared_inputs=prepared,
                  script_sha256=sha256(__file__), versions=dict(python=sys.version.split()[0], numpy=np.__version__))
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "repetition_comparison.json").write_text(json.dumps(result, indent=1, allow_nan=False) + "\n", encoding="utf-8")
    lines = ["# Computation B: repetition of the Lee2019 evaluation against the published records", "",
             "Accuracy in percent; differences in percentage points; 54 participants, five-seed means.", "",
             "## Five paired contrasts", "", "| Contrast | Published (95% CI), Holm p | New run (95% CI), Holm p | Same Holm decision | New estimate inside published CI |",
             "|---|---|---|---|---|"]
    for r in contrasts:
        lines.append("| %s | %+.2f [%+.2f, %+.2f], %.3f | %+.2f [%+.2f, %+.2f], %.3f | %s | %s |" % (
            r["contrast"], r["published"]["mean_difference_pp"], *r["published"]["ci95_pp"], r["published"]["p_holm_five"],
            r["new"]["mean_difference_pp"], *r["new"]["ci95_pp"], r["new"]["p_holm_five"],
            "yes" if r["same_holm_decision"] else "no", "yes" if r["new_estimate_inside_published_ci"] else "no"))
    lines += ["", "## Condition means and participant-level agreement", "",
              "| Condition | Published | New run | r between runs | Mean absolute difference | New - published (95% CI) |", "|---|---:|---:|---:|---:|---|"]
    for r in conditions:
        d = r["new_minus_published"]
        ci = "[%+.2f, %+.2f]" % tuple(d["ci95_pp"]) if "ci95_pp" in d else "no spread"
        lines.append("| %s | %.2f | %.2f | %.3f | %.2f | %+.2f %s |" % (r["condition"], r["published_mean_pct"], r["new_mean_pct"],
                     r["pearson_r_between_runs"], r["mean_absolute_difference_pp"], d["mean_pp"], ci))
    lines += ["", "## Fit level, classical reference and prepared inputs", "",
              "- Fits with the same test accuracy: %d of 1,350; test decisions that agree: %.2f%% of %d." % (
                  fits["fits_with_same_test_accuracy"], 100 * fits["share_of_decisions_that_agree"], fits["test_decisions"]),
              "- Classical reference: identical decisions for %d of 54 participants; means %.2f (published) and %.2f (new run)." % (
                  classical["participants_with_identical_decisions"], classical["published_mean_pct"], classical["new_mean_pct"]),
              "- Prepared inputs byte-identical to the originally prepared files: %d of 54 training files, %d of 54 test files." % (
                  prepared["byte_identical_training_files"], prepared["byte_identical_test_files"])]
    (args.out / "repetition_tables.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
