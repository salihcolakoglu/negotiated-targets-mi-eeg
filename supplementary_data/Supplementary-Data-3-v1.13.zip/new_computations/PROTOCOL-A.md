# Protocol A — CSP–LDA reference with two-ended filter selection (Experiments 1 and 2)

Study: "Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding" (Çolakoğlu, Onat, Korhan).
Protocol version 1.0, written 15 November 2026, 17:15 (UTC+3) before the computation was run. Status of the computation: **post hoc,
descriptive**.

## 1. Question

The classical reference of Experiments 1 and 2 (Table 5 of the manuscript) is a CSP–LDA pipeline whose spatial
filters are taken from one end of the eigenvalue spectrum only (the `n_half` filters with the largest eigenvalues).
The conventional choice takes filters from both ends. The question is how the reference accuracy, and the
comparison of EEGNet with it, change when the conventional two-ended selection is used and nothing else changes.

## 2. What is already known (disclosure)

- The test trials of D1, D3 and D4 were used throughout Experiments 1 and 2. Nothing here is confirmatory.
- A preliminary measurement of 24 September 2026 (project file `on_olcum_v1.0_sonuclar.json`, SHA-256
  `73302288d021033a8e9e84010e4e30da17fa19827b99e0bb9af74c7f9bc404d1`) had already computed two-ended CSP–LDA
  accuracies on the same partitions: 63.27, 73.30 and 71.46 % for D1, D3 and D4, against 63.73, 76.79 and 71.46 %
  for the one-ended reference. Those values were not used in any manuscript version. The expected outcome of this
  computation is therefore known. The rule in Section 4 is not a choice made in view of it: it is the conventional
  selection with the same `n_half` as the release, and it has no free parameter.

## 3. Data

The 32 participants and the chronological partitions of Experiments 1 and 2 (D1: 9, D3: 14, D4: 9), prepared from
the 64 official BNCI files with the unmodified preparation of the public release v2.2.0
(commit `bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62`, command `python reproduce.py prepare-csp`, MOABB 1.5.0).
The raw files are identified by SHA-256 (`common/BNCI_RAW_SHA256.txt`).

## 4. Method

Everything except the set of kept filters is the arithmetic of the release (`src/csp/features.py`,
`src/csp/classical.py`): 8–30 Hz band-pass, class covariance matrices, whitening, eigen-decomposition, logarithm of
the variance of the filtered trials, scikit-learn's default linear discriminant analysis. No parameter is tuned and
no test trial enters a fit.

| | one-ended (release, manuscript) | two-ended (this computation) |
|---|---|---|
| kept filters | the `n_half` largest eigenvalues | the `n_half` largest and the `n_half` smallest eigenvalues |
| D3 (two classes, 15 channels), `n_half` = 3 | 3 features | 6 features |
| D4 (two classes, 3 channels), `n_half` = 3 | 3 features | the same 3 filters (2 × 3 is not smaller than 3): identical by construction |
| D1 (four classes, one-versus-rest), `n_half` = 2 per problem | 8 features | 16 features |

## 5. Checks that must pass before any two-ended number is computed

1. The release checkout is the unmodified tag; the raw files equal the SHA-256 list.
2. The one-ended features recomputed by `two_ended_reference.py` equal the features written by the release code
   bit for bit, for every participant.
3. The one-ended accuracies reproduce the values of the manuscript (Table 5 and the Experiment 1 comparison;
   tolerance 1e-9; file `expected_one_ended_reference.json`).

If a check fails, the run stops and the failure is reported; no two-ended comparison is produced from that run.

## 6. Analysis

Participants are the unit; EEGNet and CSP–CNN participant means are read from the stored public results
(`reference/stored_results.zip`); the paired statistics are computed with the release's own functions.

1. As in Table 5: for each dataset, S0 − LDA and W2 − LDA with 95 % t intervals; Holm across the six comparisons.
2. Two-ended minus one-ended reference, per dataset and over the 32 participants (paired, 95 % t interval).
3. The five CSP–CNN conditions of Experiment 1 against the two-ended reference, per dataset (descriptive).
4. Agreement of the two-ended accuracies with the preliminary measurement of 24 September, participant by
   participant (information only).

## 7. Reporting rule (fixed in advance)

Both references are reported side by side, whatever the values. The one-ended pipeline remains the reference that
was specified for the experiments; the two-ended pipeline is added as a sensitivity analysis and is labelled post
hoc. The manuscript states the two-ended accuracies, the changed differences and whether the sentence "these data
do not separate EEGNet from the reference" still holds (it holds if all six Holm-adjusted p values remain above
0.05).

## 8. Environment

Python 3.11; numpy 2.2.6, scipy 1.15.3, scikit-learn 1.7.2, mne 1.12.1, moabb 1.5.0, pandas 2.3.3, h5py 3.15.1,
pooch 1.9.0, pyriemann 0.9, pymatreader 1.3.1 (the release's `requirements/csp.txt` without TensorFlow and Keras,
which the steps used here do not import). CPU only. Exact versions are written into the result files.

## 9. Files of this computation

| File | SHA-256 |
|---|---|
| `a_two_ended/run_a.py` | `d9343bd6733c7b6e7c91fc8a82dc330947901ebfc08b9064b0c2b0c3a24565f0` |
| `a_two_ended/two_ended_reference.py` | `d7e311ef4fc959e2bdadf04e88b20807453b15235756274a1eaf12e674bd8187` |
| `a_two_ended/analyze_two_ended.py` | `78cc37a224fb60386b984ee8b6aadaad42ed68f996cd59425c5876a716825b54` |
| `a_two_ended/expected_one_ended_reference.json` | `36e1679990db2987fb9cdac5bd1b867dd5c6d3fd6e1fe32cf61f18287b1c5677` |
| `common/BNCI_RAW_SHA256.txt` | `6e3212a58b9fe6e6336792ecf90094ceed2d4c3200001da7a99843bc59e4b32c` |

Command: `python a_two_ended/run_a.py --repo RELEASE --data DATA --out NEW_FOLDER [--preliminary FILE]`

## 10. Deviations

Any deviation from this protocol is written, with its reason and time, into `DEVIATIONS.md` next to the results and
is reported with them.
