#!/usr/bin/env python3
"""CSP-LDA reference with two-ended CSP filter selection for D1, D3 and D4 (computation A; post hoc, descriptive).

Inputs: the raw-array files written by the unmodified public preparation of release v2.2.0
(`python reproduce.py prepare-csp`): WORK/Pickle_All_Datasets/Raw_Datasets/*.pkl, each holding
(x_train, y_train, x_test, y_test), and the one-ended feature files of the same command
(WORK/Pickle_All_Datasets/CSP_Datasets/*.pickle), which serve as a check.

Everything except the choice of spatial filters follows src/csp/features.py and src/csp/classical.py of the
release: the same 8-30 Hz filter, class covariances, whitening, eigen-decomposition, log-variance features and
scikit-learn's default LinearDiscriminantAnalysis. No parameter is tuned and no test trial enters a fit.

Filter choice (n_half = 3 for the two-class datasets; 2 for each one-versus-rest problem of the four-class D1):
  one-ended (release)      the n_half filters with the largest eigenvalues           -> 8 / 3 / 3 features (D1/D3/D4)
  two-ended (this script)  the n_half largest and the n_half smallest eigenvalues    -> 16 / 6 / 3 features
If 2 * n_half is not smaller than the number of channels (D4 has three channels), every filter is used once. For D4
the two choices are therefore the same three filters, and its result cannot differ from the one-ended reference.

The script recomputes the one-ended features with its own copy of the arithmetic and stops unless they equal the
features written by the release code bit for bit; the two-ended features then differ from them in the index set only.

Usage: two_ended_reference.py --repo PUBLIC_REPO --work WORK --out NEW_OUTPUT_FOLDER
"""
import argparse
import hashlib
import json
import pickle
import sys
from pathlib import Path

import numpy as np


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def select(n_filters, n_half, two_ended):
    """Indices into the filters sorted by descending eigenvalue."""
    if not two_ended:
        return list(range(n_half))
    if 2 * n_half >= n_filters:                       # e.g. three channels: the complete filter set, once
        return list(range(n_filters))
    return list(range(n_half)) + list(range(n_filters - n_half, n_filters))


def csp_binary(x_train, y_train, x_test, n_components, two_ended):
    """Arithmetic of features.compute_csp of the release; only the index set of the kept filters can differ."""
    classes = np.unique(y_train)
    assert len(classes) == 2
    c1, c2 = classes
    x1 = x_train[y_train == c1]
    x2 = x_train[y_train == c2]
    cov1 = np.mean([np.cov(trial) for trial in x1], axis=0)
    cov2 = np.mean([np.cov(trial) for trial in x2], axis=0)
    cov_composite = cov1 + cov2
    eigvals, eigvecs = np.linalg.eigh(cov_composite)
    idx = np.argsort(eigvals)[::-1]
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]
    eigvals = np.maximum(eigvals, 1e-10)
    P = np.dot(np.diag(1.0 / np.sqrt(eigvals)), eigvecs.T)
    S1 = np.dot(np.dot(P, cov1), P.T)
    eig_vals_s1, B = np.linalg.eigh(S1)
    idx = np.argsort(eig_vals_s1)[::-1]
    B = B[:, idx]
    n_half = n_components // 2
    kept = select(B.shape[1], n_half, two_ended)
    W = np.dot(B[:, kept].T, P)
    x_train_csp = np.array([np.log(np.var(np.dot(W, trial), axis=1)) for trial in x_train])
    x_test_csp = np.array([np.log(np.var(np.dot(W, trial), axis=1)) for trial in x_test])
    return x_train_csp, x_test_csp, kept


def csp(x_train, y_train, x_test, n_components, two_ended):
    """Two classes: one problem. More classes: one-versus-rest as in features.compute_csp_multiclass."""
    classes = np.unique(y_train)
    if len(classes) == 2:
        a, b, kept = csp_binary(x_train, y_train, x_test, n_components, two_ended)
        return a, b, [kept]
    n_per_class = max(2, n_components // len(classes))
    train_parts, test_parts, kept_all = [], [], []
    for cls in classes:
        y_cls = (y_train == cls).astype(int) + 1           # 1 = rest, 2 = this class (release convention)
        a, b, kept = csp_binary(x_train.copy(), y_cls, x_test, n_per_class, two_ended)
        train_parts.append(a)
        test_parts.append(b)
        kept_all.append(kept)
    return np.hstack(train_parts), np.hstack(test_parts), kept_all


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--repo", type=Path, required=True, help="public repository at release v2.2.0")
    parser.add_argument("--work", type=Path, required=True, help="work folder of `reproduce.py prepare-csp`")
    parser.add_argument("--out", type=Path, required=True, help="new output folder")
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / "src" / "csp"))
    from config import DATASETS, data_path, selected_subjects      # release code, unchanged
    from features import bandpass_filter                           # release code, unchanged
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    import sklearn
    import scipy

    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "predictions").mkdir()
    records, inputs = [], {}
    for dk, di in DATASETS.items():
        for subject in selected_subjects(dk):
            raw_path = data_path(args.work, dk, subject, raw=True)
            one_path = data_path(args.work, dk, subject)
            with raw_path.open("rb") as fh:                         # file written by the release code in this run
                x_train, y_train, x_test, y_test = pickle.load(fh)
            with one_path.open("rb") as fh:
                rel_train, rel_ytrain, rel_test, rel_ytest = pickle.load(fh)
            assert np.array_equal(y_train, rel_ytrain) and np.array_equal(y_test, rel_ytest)
            inputs[raw_path.name] = sha256(raw_path)
            inputs[one_path.name] = sha256(one_path)
            x_train_f = bandpass_filter(x_train, low=8.0, high=30.0, fs=float(di["fs"]))
            x_test_f = bandpass_filter(x_test, low=8.0, high=30.0, fs=float(di["fs"]))
            n_comp = 6 if di["n_classes"] == 2 else 4 * di["n_classes"]          # as in prepare.py of the release
            row = dict(dataset=dk, subject=subject, n_train=int(len(y_train)), n_test=int(len(y_test)),
                       n_channels=int(x_train.shape[1]))
            predictions = dict(y_test=np.asarray(y_test))
            for name, two_ended in (("one_ended", False), ("two_ended", True)):
                f_train, f_test, kept = csp(x_train_f, y_train, x_test_f, n_comp, two_ended)
                if not two_ended:                                   # must reproduce the release features exactly
                    if not (np.array_equal(f_train, rel_train) and np.array_equal(f_test, rel_test)):
                        raise SystemExit("one-ended recomputation differs from the release features: %s S%02d" % (dk, subject))
                assert np.isfinite(f_train).all() and np.isfinite(f_test).all()
                lda = LinearDiscriminantAnalysis().fit(f_train, y_train)
                pred = lda.predict(f_test)
                row[name] = dict(n_features=int(f_train.shape[1]), kept_filter_indices=kept,
                                 lda_train=float((lda.predict(f_train) == y_train).mean()),
                                 lda_test=float((pred == y_test).mean()))
                predictions["pred_" + name] = np.asarray(pred)
            row["same_filters_in_both_selections"] = row["one_ended"]["kept_filter_indices"] == row["two_ended"]["kept_filter_indices"]
            if row["same_filters_in_both_selections"]:
                assert row["one_ended"]["lda_test"] == row["two_ended"]["lda_test"]
            np.savez_compressed(args.out / "predictions" / ("%s_S%02d.npz" % (dk, subject)), **predictions)
            records.append(row)
            print("%s S%02d: one-ended %.4f (%d features), two-ended %.4f (%d features)"
                  % (dk, subject, row["one_ended"]["lda_test"], row["one_ended"]["n_features"],
                     row["two_ended"]["lda_test"], row["two_ended"]["n_features"]), flush=True)
    means = {name: {dk: float(np.mean([r[name]["lda_test"] for r in records if r["dataset"] == dk])) for dk in DATASETS}
             for name in ("one_ended", "two_ended")}
    result = dict(
        computation="A: two-ended CSP-LDA reference (post hoc, descriptive)",
        one_ended_features_equal_release_features_bit_for_bit=True,
        per_subject=records, dataset_means=means,
        # same layout as classical_results.json of the release, for the two-ended reference
        release_layout_two_ended=dict(per_subject=[dict(dataset=r["dataset"], subject=r["subject"], lda_train=r["two_ended"]["lda_train"],
                                                         lda_test=r["two_ended"]["lda_test"], n_train=r["n_train"], n_test=r["n_test"],
                                                         n_features=r["two_ended"]["n_features"]) for r in records],
                                      dataset_means=means["two_ended"]),
        versions=dict(python=sys.version.split()[0], numpy=np.__version__, scipy=scipy.__version__, scikit_learn=sklearn.__version__),
        script_sha256=sha256(__file__), input_sha256=inputs)
    (args.out / "two_ended_results.json").write_text(json.dumps(result, indent=1, allow_nan=False) + "\n", encoding="utf-8")
    print("dataset means (one-ended):", {k: round(100 * v, 2) for k, v in means["one_ended"].items()})
    print("dataset means (two-ended):", {k: round(100 * v, 2) for k, v in means["two_ended"].items()})


if __name__ == "__main__":
    main()
