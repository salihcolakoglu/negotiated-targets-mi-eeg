#!/usr/bin/env python3
"""Computation A, analysis: EEGNet and CSP-CNN participant means against the CSP-LDA reference (post hoc, descriptive).

The participant means of Experiments 1 and 2 are read from the stored public results (reference/stored_results.zip of
release v2.2.0); nothing is trained. The paired statistics use the release's own functions (src/verify_results.py:
paired, holm), so that the two-ended reference is analysed exactly as the one-ended reference of Table 5 was:
for each dataset, S0 minus LDA and W2 minus LDA (six comparisons, Holm across the six), with 95% t intervals.

Order of work, fixed in advance:
  1. the recomputed one-ended reference must reproduce the stored values of the manuscript (tolerance 1e-9);
     otherwise the script stops before any two-ended comparison is computed;
  2. the same comparisons are computed with the two-ended reference;
  3. the paired difference two-ended minus one-ended is reported per dataset and over the 32 participants;
  4. the five CSP-CNN conditions of Experiment 1 are compared with the two-ended reference per dataset.

Usage: analyze_two_ended.py --repo PUBLIC_REPO --results two_ended_results.json --expected expected_one_ended_reference.json --out NEW_FOLDER
"""
import argparse
import csv
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np

STORED_SHA256 = "611731ede56c195037f33bfd517ee48b856f06a361733cc4e9977c0e08eec3a6"      # reference/stored_results.zip, release v2.2.0


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--expected", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / "src"))
    from verify_results import NS, PARTICIPANTS, holm, paired            # release code, unchanged

    stored = args.repo / "reference" / "stored_results.zip"
    if sha256(stored) != STORED_SHA256:
        raise SystemExit("reference/stored_results.zip is not the file of release v2.2.0")
    with zipfile.ZipFile(stored) as z:
        rows = list(csv.DictReader(io.StringIO(z.read("e1_e2_subject_seed_means_verified_v4.csv").decode("utf-8"))))
    means = {(r["experiment"], r["dataset"], int(r["subject"]), r["condition"], r["code"]): float(r["mean_test_accuracy"]) for r in rows}
    result = json.loads(args.results.read_text("utf-8"))
    if not result.get("one_ended_features_equal_release_features_bit_for_bit"):
        raise SystemExit("the one-ended features were not confirmed against the release features")
    lda = {name: {(r["dataset"], int(r["subject"])): float(r[name]["lda_test"]) for r in result["per_subject"]}
           for name in ("one_ended", "two_ended")}
    for name in lda:
        if set(lda[name]) != set(PARTICIPANTS):
            raise SystemExit("expected one LDA result for each of the 32 participants")

    def eegnet_family(name):
        out = []
        for cond in ("S0", "W2"):
            code = "softmax" if cond == "S0" else "K1"
            for d, n in NS.items():
                ref = [lda[name][(d, s)] for s in range(1, n + 1)]
                value = paired([means[("E2", d, s, cond, code)] for s in range(1, n + 1)], ref)
                value.update(dataset=d, condition=cond, mean_lda_pct=100 * float(np.mean(ref)),
                             mean_condition_pct=100 * float(np.mean([means[("E2", d, s, cond, code)] for s in range(1, n + 1)])))
                out.append(value)
        for value, p in zip(out, holm([v["p_t"] for v in out])):
            value["p_holm"] = p
        return out

    def csp_cnn_family(name):
        out = []
        for cond in ("C0", "C1", "C2", "C3", "C4"):
            for d, n in NS.items():
                ref = [lda[name][(d, s)] for s in range(1, n + 1)]
                value = paired([means[("E1", d, s, cond, "K1")] for s in range(1, n + 1)], ref)
                value.update(dataset=d, condition=cond, mean_lda_pct=100 * float(np.mean(ref)))
                out.append(value)
        return out

    # 1. the one-ended reference of the manuscript must be reproduced
    expected = json.loads(args.expected.read_text("utf-8"))
    one = eegnet_family("one_ended")
    worst = 0.0
    for want in expected["E2_LDA_family"]:
        got = next(v for v in one if v["dataset"] == want["dataset"] and v["condition"] == want["condition"])
        for key in ("mean_lda_pct", "mean_diff_pp", "sd_diff_pp", "p_t", "p_holm"):
            worst = max(worst, abs(got[key] - want[key]))
        worst = max(worst, abs(got["ci95_pp"][0] - want["ci95_pp"][0]), abs(got["ci95_pp"][1] - want["ci95_pp"][1]))
        if (got["higher"], got["ties"], got["lower"], got["n"]) != (want["higher"], want["ties"], want["lower"], want["n"]):
            raise SystemExit("one-ended reference: participant counts differ from the manuscript values")
    one_cnn = csp_cnn_family("one_ended")
    for want in expected["E1_LDA_family"]:
        got = next(v for v in one_cnn if v["dataset"] == want["dataset"] and v["condition"] == want["condition"])
        worst = max(worst, abs(got["mean_diff_pp"] - want["mean_diff_pp"]), abs(got["mean_lda_pct"] - 100 * want["mean_csp_lda"]))
    if worst > 1e-9:
        raise SystemExit("the recomputed one-ended reference does not reproduce the manuscript values (largest difference %.3g)" % worst)
    print("one-ended reference reproduces the manuscript values; largest absolute difference %.3g" % worst)

    # 2. to 4. the two-ended reference
    two = eegnet_family("two_ended")
    two_cnn = csp_cnn_family("two_ended")
    change = []
    for d, n in list(NS.items()) + [("all", None)]:
        keys = PARTICIPANTS if d == "all" else [(d, s) for s in range(1, n + 1)]
        a = [lda["two_ended"][k] for k in keys]
        b = [lda["one_ended"][k] for k in keys]
        diff = (np.array(a) - np.array(b)) * 100
        entry = dict(dataset=d, n=len(keys), two_ended_mean_pct=100 * float(np.mean(a)), one_ended_mean_pct=100 * float(np.mean(b)),
                     mean_diff_pp=float(diff.mean()))
        if float(diff.std(ddof=1)) > 0:
            entry.update({k: v for k, v in paired(a, b).items() if k in ("ci95_pp", "p_t", "t", "d_z", "sd_diff_pp", "higher", "ties", "lower")})
        else:
            entry["note"] = "identical for every participant (the two selections keep the same filters)"
        change.append(entry)
    features = {d: sorted({(r["one_ended"]["n_features"], r["two_ended"]["n_features"]) for r in result["per_subject"] if r["dataset"] == d})
                for d in NS}
    output = dict(
        computation="A: two-ended CSP-LDA reference (post hoc, descriptive; the test trials had been seen in earlier analyses)",
        one_ended_reproduces_manuscript=dict(largest_absolute_difference=worst, tolerance=1e-9),
        features_one_ended_then_two_ended=features,
        eegnet_minus_lda=dict(one_ended=one, two_ended=two, holm="across the six comparisons of each reference, as in Table 5"),
        csp_cnn_minus_lda=dict(one_ended=one_cnn, two_ended=two_cnn, note="unadjusted; descriptive"),
        two_ended_minus_one_ended=change,
        inputs=dict(results_sha256=sha256(args.results), expected_sha256=sha256(args.expected), stored_results_sha256=STORED_SHA256),
        script_sha256=sha256(__file__), versions=dict(python=sys.version.split()[0], numpy=np.__version__))
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "two_ended_analysis.json").write_text(json.dumps(output, indent=1, allow_nan=False) + "\n", encoding="utf-8")
    lines = ["# Computation A: CSP-LDA reference with two-ended filter selection", "",
             "Accuracy in percent; differences in percentage points; participants are the unit; 95% t intervals; Holm across six.", "",
             "| Dataset | Features (one-ended -> two-ended) | LDA one-ended | LDA two-ended | two-ended minus one-ended (95% CI) |", "|---|---|---:|---:|---|"]
    for c in change:
        ci = "[%+.2f, %+.2f]" % tuple(c["ci95_pp"]) if "ci95_pp" in c else "identical"
        f = "" if c["dataset"] == "all" else " -> ".join(str(x) for x in features[c["dataset"]][0])
        lines.append("| %s | %s | %.2f | %.2f | %+.2f %s |" % (c["dataset"], f, c["one_ended_mean_pct"], c["two_ended_mean_pct"], c["mean_diff_pp"], ci))
    for name, fam in (("one-ended (manuscript)", one), ("two-ended", two)):
        lines += ["", "## EEGNet minus CSP-LDA, %s reference" % name, "", "| Dataset | Condition | LDA | Difference | 95% CI | p | Holm p |", "|---|---|---:|---:|---|---:|---:|"]
        for v in fam:
            lines.append("| %s | %s | %.2f | %+.2f | [%+.2f, %+.2f] | %.3f | %.3f |" % (v["dataset"], v["condition"], v["mean_lda_pct"], v["mean_diff_pp"],
                                                                                 v["ci95_pp"][0], v["ci95_pp"][1], v["p_t"], v["p_holm"]))
    lines += ["", "## CSP-CNN (Experiment 1) minus CSP-LDA, two-ended reference", "", "| Dataset | Condition | Difference | 95% CI |", "|---|---|---:|---|"]
    for v in two_cnn:
        lines.append("| %s | %s | %+.2f | [%+.2f, %+.2f] |" % (v["dataset"], v["condition"], v["mean_diff_pp"], v["ci95_pp"][0], v["ci95_pp"][1]))
    (args.out / "two_ended_tables.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[:12]))


if __name__ == "__main__":
    main()
