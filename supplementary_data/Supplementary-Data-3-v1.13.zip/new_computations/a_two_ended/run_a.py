#!/usr/bin/env python3
"""Computation A, driver: CSP-LDA reference of Experiments 1 and 2 with two-ended filter selection.

Order of work (each step stops the run if its check fails):
  1. the release checkout is the unmodified tag v2.2.0; the 64 official BNCI files are identified by SHA-256
     and compared with the list of the files used for the published results (common/BNCI_RAW_SHA256.txt);
  2. the release's own preparation is run unchanged:   python reproduce.py prepare-csp
     (MOABB 1.5.0 reads the local files; raw arrays and the release's one-ended CSP features are written);
  3. the release's own classical reference is run unchanged:   python reproduce.py classical
  4. two_ended_reference.py  recomputes the one-ended features (must equal the release features bit for bit) and
     computes the two-ended features and their LDA accuracies;
  5. analyze_two_ended.py    reproduces the manuscript's one-ended comparisons (tolerance 1e-9) and then computes
     the same comparisons with the two-ended reference;
  6. the two-ended accuracies are compared, participant by participant, with the preliminary measurement of
     24 September 2026 when that file is supplied (information only).

No network is trained. Usage:
  run_a.py --repo RELEASE_REPO --data DATA_DIR --out NEW_FOLDER [--preliminary on_olcum_v1.0_sonuclar.json]
DATA_DIR is the MNE data folder that holds MNE-bnci-data/~bci/database/{001-2014,002-2014,004-2014}/*.mat
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
RELEASE_COMMIT = "bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def run(command, log, cwd=None, env=None):
    text = " ".join(str(c) for c in command)
    print("[%s] %s" % (time.strftime("%H:%M:%S"), text), flush=True)
    with open(log, "a", encoding="utf-8") as handle:
        handle.write("\n===== " + text + "\n")
        handle.flush()
        done = subprocess.run([str(c) for c in command], cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT, text=True)
    if done.returncode != 0:
        print(Path(log).read_text("utf-8", errors="replace")[-3000:])
        raise SystemExit("step failed: " + text)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--preliminary", type=Path)
    args = parser.parse_args()
    repo, data, out = args.repo.resolve(), args.data.resolve(), args.out.resolve()

    # 1. identities
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    dirty = subprocess.run(["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=all"], capture_output=True, text=True, check=True).stdout
    dirty = [line for line in dirty.splitlines() if "__pycache__" not in line and not line.endswith(".pyc")]
    if head != RELEASE_COMMIT or dirty:
        raise SystemExit("the release checkout is not the unmodified tag v2.2.0")
    reference = {}
    for line in (HERE.parent / "common" / "BNCI_RAW_SHA256.txt").read_text("utf-8").splitlines():
        if line.strip() and not line.startswith("#"):
            digest, size, name = line.split()
            reference[name] = (digest, int(size))
    if len(reference) != 64:
        raise SystemExit("the reference list must hold 64 files")
    base = data / "MNE-bnci-data" / "~bci" / "database"
    raw_files = {}
    for name, (digest, size) in sorted(reference.items()):
        path = base / name
        if not path.is_file():
            raise SystemExit("raw file missing: " + str(path))
        got = sha256(path)
        if got != digest or path.stat().st_size != size:
            raise SystemExit("raw file differs from the reference list: " + name)
        raw_files[name] = got
    extra = sorted(p.relative_to(base).as_posix() for p in base.rglob("*.mat") if p.relative_to(base).as_posix() not in reference)
    if extra:
        raise SystemExit("unexpected raw files: " + ", ".join(extra[:5]))
    out.mkdir(parents=True, exist_ok=False)
    log = out / "run_a.log"
    work = out / "work"
    env = dict(os.environ, PYTHONHASHSEED="1", PYTHONDONTWRITEBYTECODE="1")
    print("64 raw files equal the reference list", flush=True)

    # 2. and 3. release code, unchanged
    run([sys.executable, repo / "reproduce.py", "prepare-csp", "--work-dir", work, "--data-dir", data], log, cwd=repo, env=env)
    run([sys.executable, repo / "reproduce.py", "classical", "--work-dir", work, "--out", out / "classical_release"], log, cwd=repo, env=env)
    # 4. and 5.
    run([sys.executable, HERE / "two_ended_reference.py", "--repo", repo, "--work", work, "--out", out / "two_ended"], log, env=env)
    run([sys.executable, HERE / "analyze_two_ended.py", "--repo", repo, "--results", out / "two_ended" / "two_ended_results.json",
         "--expected", HERE / "expected_one_ended_reference.json", "--out", out / "analysis"], log, env=env)

    result = json.loads((out / "two_ended" / "two_ended_results.json").read_text("utf-8"))
    released = json.loads((out / "classical_release" / "classical_results.json").read_text("utf-8"))
    one = {(r["dataset"], r["subject"]): r["one_ended"]["lda_test"] for r in result["per_subject"]}
    rel = {(r["dataset"], r["subject"]): r["lda_test"] for r in released["per_subject"]}
    if one != rel:
        raise SystemExit("one-ended accuracies of this script differ from the release's classical step")
    summary = dict(computation="A", release_commit=head, raw_files_sha256=raw_files, one_ended_equals_release_classical_step=True,
                   dataset_means_pct={k: {d: 100 * v for d, v in m.items()} for k, m in result["dataset_means"].items()},
                   code_sha256={p.name: sha256(p) for p in sorted(HERE.glob("*.py"))},
                   expected_reference_sha256=sha256(HERE / "expected_one_ended_reference.json"),
                   completed_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))

    # 6. information only: the preliminary measurement of 24 September 2026
    if args.preliminary:
        pre = json.loads(args.preliminary.read_text("utf-8"))
        two = {(r["dataset"], r["subject"]): r["two_ended"]["lda_test"] for r in result["per_subject"]}
        d_two = max(abs(two[(d, s["subject"])] - s["lda_two_ended_csp"]) for d in pre for s in pre[d]["subjects"])
        d_one = max(abs(one[(d, s["subject"])] - s["lda_one_ended_csp"]) for d in pre for s in pre[d]["subjects"])
        summary["preliminary_measurement_2026_09_24"] = dict(file_sha256=sha256(args.preliminary),
                                                             largest_absolute_difference_two_ended=d_two,
                                                             largest_absolute_difference_one_ended=d_one,
                                                             same_participant_accuracies=bool(d_two < 1e-12 and d_one < 1e-12))
    (out / "RUN_A_SUMMARY.json").write_text(json.dumps(summary, indent=1, allow_nan=False) + "\n", encoding="utf-8")
    print((out / "analysis" / "two_ended_tables.md").read_text("utf-8"))
    print(json.dumps({k: v for k, v in summary.items() if k not in ("raw_files_sha256", "code_sha256")}, indent=1))


if __name__ == "__main__":
    main()
