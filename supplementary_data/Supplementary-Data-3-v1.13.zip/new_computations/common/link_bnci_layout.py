#!/usr/bin/env python3
"""Make the BNCI files visible under the folder names of both MOABB generations (hard links; no copy, no download).

MOABB 1.5.0 (release of the study) looks for   DATA/MNE-bnci-data/~bci/database/<set>/<file>.mat
MOABB 0.5.0 (environment of the benchmark)     DATA/MNE-bnci-data/database/data-sets/<set>/<file>.mat
The files are the same official files; only the folder names differ between the two library versions. Every file
is checked against common/BNCI_RAW_SHA256.txt before it is linked.

Usage: link_bnci_layout.py --data DATA [--sets 001-2014 004-2014]
"""
import argparse
import hashlib
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--sets", nargs="+", default=["001-2014", "002-2014", "004-2014"])
    args = parser.parse_args()
    new = args.data.resolve() / "MNE-bnci-data" / "~bci" / "database"
    old = args.data.resolve() / "MNE-bnci-data" / "database" / "data-sets"
    done = 0
    for line in (HERE / "BNCI_RAW_SHA256.txt").read_text("utf-8").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        digest, size, name = line.split()
        if name.split("/")[0] not in args.sets:
            continue
        source = new / name
        if sha256(source) != digest or source.stat().st_size != int(size):
            raise SystemExit("file differs from the reference list: " + name)
        target = old / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not os.path.samefile(source, target):
                raise SystemExit("a different file already exists: " + str(target))
        else:
            os.link(source, target)
        done += 1
    print("%d files verified and linked under %s" % (done, old))


if __name__ == "__main__":
    main()
