# Protocol B — Repetition of the Lee2019 evaluation (Experiment 3) on different hardware

Study: "Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding" (Çolakoğlu, Onat, Korhan).
Protocol version 1.0, written 15 November 2026, 17:15 (UTC+3) before the repetition was run.

## 1. Question and status

Experiment 3 (54 participants of Lee2019, first-day training, second-day testing, five conditions, five seeds;
1,350 networks) was run once, on one machine. The question is whether the published results are obtained again
when the complete public pipeline is run from the public data on a different machine and operating system.

This is a **repetition from public materials on different hardware**. Who operates the run is recorded in
`OPERATOR.md` next to the results. If it is operated by the authors' side, it is not an independent replication by
another group, and the manuscript will not call it one.

The published results are known. The agreement measures and criteria of Sections 5 and 6 are fixed before the run.

## 2. What is repeated

The complete chain, with the unmodified public release v2.2.0 of the study's repository
(`https://github.com/salihcolakoglu/negotiated-targets-mi-eeg`, commit `bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62`):

1. Download of the 108 labelled offline recordings (two days × 54 participants, about 61 GB) from GigaDB
   (doi 10.5524/100542); every file must equal the publisher's MD5 list (`100542.md5`, SHA-256
   `20b1ef60db5877a8508bfb9fb04a206cf9173d884bf48850ce2627d55c957cb4`, the value pinned in the release protocol).
   The downloader is the one of the original run, unchanged.
2. Preparation: `extensions/studies/lee54/source/prepare_lee2019.py`, one recording day per call.
3. `extensions/train.py init | validate | fit | freeze | test | analyze --study lee54`: 1,350 networks and 54
   classical references are fitted on first-day data; all fitted models are frozen before any second-day array is
   opened; the release's own analysis writes the five paired contrasts with Holm correction.

The release controller fixes every scientific setting (network, rules, seeds 1–5, 300 epochs, batch 16, learning
rate 0.001) and refuses changed code or inputs. The driver of this protocol (`run_b.py`) only calls these programs
in the documented order, keeps logs and packs results; it sets no scientific value.

## 3. Machines

| | Published run (18 October 2026) | Repetition |
|---|---|---|
| Operating system | Windows 11 | Linux (rented server) |
| Graphics processor | NVIDIA GeForce RTX 4070 Laptop GPU | recorded in `ENVIRONMENT.json` (a different model) |
| Python | 3.12.14 | 3.12.x, recorded |
| Packages | numpy 2.2.6, scipy 1.15.3, torch 2.5.1+cu124, scikit-learn 1.7.2, mne 1.12.1 | the same pinned versions (`extensions/requirements-training.txt`), recorded |

Results that are identical bit for bit are not expected across graphics processors and operating systems.

## 4. Completeness

All 108 files, 1,350 networks, 54 classical references and 1,350 + 54 tests must complete. There is no exclusion
of participants or fits. An interrupted step is resumed (the release controller keeps finished fits and continues
from the last completed training phase); every interruption is logged. There is one run: it is not repeated in
order to obtain better agreement.

## 5. Agreement measures (computed by `compare_with_published.py`)

1. The five paired contrasts of the published protocol (W2 − W0 primary; W1 − W0, W2 − W1, W2 − W3, W0 − S0):
   estimate, 95 % interval and Holm-adjusted p of the new run next to the published values.
2. The five condition means.
3. Participant level, per condition: correlation between the runs, mean absolute difference, paired difference
   (new − published) with its 95 % interval.
4. Fit level: number of the 1,350 fits with the same test accuracy; share of the 135,000 test decisions that agree.
5. The 54 classical references (a deterministic pipeline): number of participants with identical decisions.
6. Prepared inputs: number of prepared files that are byte-identical to the originally prepared files (hashes in
   the release's public calibration protocol).

## 6. Criteria (fixed in advance)

- **R1**: all five Holm decisions at 0.05 are the same as published, and each new estimate lies inside the
  published 95 % interval.
- **R2**: each of the five condition means lies within 1.0 percentage point of the published mean.

If R1 and R2 hold, the manuscript states that the repetition agreed with the published results and gives the
numbers. If one of them fails, the manuscript states which one, gives the numbers, and the affected statements of
the Results are revised accordingly. All measures of Section 5 are reported in either case.

## 7. Scope

The repetition covers Experiment 3 as released. The later Lee2019 controls (W4, S1, W5), the held-out calibration
study and the classical-pipeline benchmark are not repeated here.

## 8. Reporting

One sentence in the manuscript (reproducibility section), one table in the Supplementary Information, and the
records, test outputs and tables of the new run in Supplementary Data 2. No EEG signals and no network weights are
distributed.

## 9. Files of this computation

| File | SHA-256 |
|---|---|
| `b_repetition/run_b.py` | `997f4b1fca4b9cb7d64c185b1cf6048a08c2692f3764c4d427c0b7e23afde884` |
| `b_repetition/compare_with_published.py` | `bf2a9850bff1d47f1ae9b83c189c51ea57b007c4644ea28e29e5507521df9caa` |
| `b_repetition/download_lee.py` | `7b3dcf1bb92220c7f029b0df46d0b99dbf8051696778533abea9055175d05290` |
| `b_repetition/100542.md5` | `20b1ef60db5877a8508bfb9fb04a206cf9173d884bf48850ce2627d55c957cb4` |

Command on the server: `python3 b_repetition/run_b.py --root /workspace/lee_repetition all`
(`status` shows progress; every step can be repeated and keeps finished work).

## 10. Deviations

Any deviation from this protocol is written, with its reason and time, into `DEVIATIONS.md` next to the results and
is reported with them.
