#!/usr/bin/env python3
"""Computation C, analysis of the 360 completed fits (see PROTOCOL-C.md, section "Analysis").

Unit of analysis: the participant. A participant's value in a condition is the mean test accuracy of its five fits
(seeds 0-4). The 18 participants are the nine of BCI Competition IV-2a and the nine of IV-2b.

Fixed in the protocol before the run:
  family of two contrasts over the 18 participants, two-sided paired t tests, Holm across the two:
      W2 - W0   (primary:   anchored, correctness-gated rule against fixed Walsh targets)
      W1 - W0   (secondary: cumulative negotiation against fixed Walsh targets)
  for the same two contrasts: two one-sided tests against -1 and +1 percentage point (TOST), Holm across the two.
Descriptive, without a claim of confirmation: the same contrasts within each dataset (n = 9), W0 - S0, W2 - W1,
training accuracy, negative log-likelihood and expected calibration error of each condition, and the S0 accuracy
next to the values published for this configuration.

The paired statistics are computed exactly as in the manuscript's equivalence analysis (v1.9): t distribution with
n - 1 degrees of freedom, 95% and 90% t intervals.

Usage: pr_analyze.py --protocol PROTOCOL-C.json --out RUN_FOLDER --analysis NEW_FOLDER [--fidelity FIDELITY.json]
"""
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent
BOUND = 1.0                 # percentage points; the one-point criterion of the study's earlier plans
ALPHA = 0.05
FAMILY = [("W2", "W0", "primary"), ("W1", "W0", "secondary")]
DESCRIPTIVE = [("W0", "S0"), ("W2", "W1")]
PUBLISHED_S0 = {"bcic2a": dict(mean=71.06, sd_over_five_runs=1.00), "bcic2b": dict(mean=83.54, sd_over_five_runs=0.46)}
BASELINE_MARGIN = 2.0       # percentage points: S0 within this distance of the published mean = baseline reproduced


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def holm(pvalues):
    """Holm step-down adjusted p values, in the order given."""
    m = len(pvalues)
    order = sorted(range(m), key=lambda i: pvalues[i])
    adjusted, running = [0.0] * m, 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * pvalues[i])
        adjusted[i] = min(1.0, running)
    return adjusted


def paired(differences_pp):
    """Paired statistics of participant differences given in percentage points."""
    d = np.asarray(differences_pp, dtype=np.float64)
    n = int(d.size)
    mean, sd = float(d.mean()), float(d.std(ddof=1))
    out = dict(n=n, df=n - 1, mean_difference_pp=mean, sd_difference_pp=sd,
               higher=int(np.sum(d > 1e-12)), ties=int(np.sum(np.abs(d) <= 1e-12)), lower=int(np.sum(d < -1e-12)))
    if not sd > 0:
        out["note"] = "all participant differences are equal; no t statistics"
        return out
    se = sd / math.sqrt(n)
    df = n - 1
    t = mean / se
    t95, t90 = float(stats.t.ppf(0.975, df)), float(stats.t.ppf(0.95, df))
    p_lower = float(stats.t.sf((mean + BOUND) / se, df))        # H0: difference <= -BOUND
    p_upper = float(stats.t.cdf((mean - BOUND) / se, df))       # H0: difference >= +BOUND
    out.update(se_pp=se, d_z=mean / sd, t=t, p_two_sided=float(2.0 * stats.t.sf(abs(t), df)),
               ci95_pp=[mean - t95 * se, mean + t95 * se], ci90_pp=[mean - t90 * se, mean + t90 * se],
               tost_p_lower_bound=p_lower, tost_p_upper_bound=p_upper, tost_p=max(p_lower, p_upper),
               ci90_within_bounds=bool(mean - t90 * se > -BOUND and mean + t90 * se < BOUND))
    return out


def participant_table(records, datasets, subjects, conditions, seeds, key):
    """{(dataset, subject, condition): mean of `key` over the seeds}; every cell must be complete."""
    cells = {}
    for r in records:
        i = r["identity"]
        cells.setdefault((i["dataset"], i["subject"], i["condition"]), {})[i["seed"]] = float(r[key])
    table = {}
    for d in datasets:
        for s in subjects[d]:
            for c in conditions:
                got = cells.get((d, s, c), {})
                if sorted(got) != sorted(seeds):
                    raise SystemExit("incomplete cell: %s S%02d %s has seeds %s" % (d, s, c, sorted(got)))
                table[(d, s, c)] = float(np.mean([got[k] for k in seeds]))
    return table


def analyse(records, datasets, subjects, conditions, seeds):
    """All tables of the analysis from the list of fit records (dictionaries as written by pr_run.py)."""
    acc = participant_table(records, datasets, subjects, conditions, seeds, "acc_test")
    acc_train = participant_table(records, datasets, subjects, conditions, seeds, "acc_train")
    nll = participant_table(records, datasets, subjects, conditions, seeds, "nll_test")
    ece = participant_table(records, datasets, subjects, conditions, seeds, "ece_test")
    everyone = [(d, s) for d in datasets for s in subjects[d]]

    def diff(table, a, b, who):
        return [100.0 * (table[(d, s, a)] - table[(d, s, b)]) for d, s in who]

    family = []
    for a, b, role in FAMILY:
        row = paired(diff(acc, a, b, everyone))
        row.update(contrast="%s-%s" % (a, b), role=role, scope="18 participants, both datasets")
        family.append(row)
    for row, p_adj, tost_adj in zip(family, holm([r["p_two_sided"] for r in family]), holm([r["tost_p"] for r in family])):
        row["p_holm_two_contrasts"] = p_adj
        row["tost_p_holm_two_contrasts"] = tost_adj
        row["significant_after_holm"] = bool(p_adj < ALPHA)
        row["equivalent_within_one_point_after_holm"] = bool(tost_adj < ALPHA)
        row["reading"] = {(True, True): "difference smaller than one point", (True, False): "difference",
                          (False, True): "equivalent within one point", (False, False): "inconclusive"}[
                              (row["significant_after_holm"], row["equivalent_within_one_point_after_holm"])]

    descriptive = []
    for a, b in [(a, b) for a, b, _ in FAMILY] + DESCRIPTIVE:
        for d in datasets:
            row = paired(diff(acc, a, b, [(d, s) for s in subjects[d]]))
            row.update(contrast="%s-%s" % (a, b), scope=d, measure="test accuracy", status="descriptive; p unadjusted")
            descriptive.append(row)
    for a, b in DESCRIPTIVE:
        row = paired(diff(acc, a, b, everyone))
        row.update(contrast="%s-%s" % (a, b), scope="18 participants, both datasets", measure="test accuracy",
                   status="descriptive; p unadjusted")
        descriptive.append(row)
    for a, b, _ in FAMILY:
        for scope, who in [("18 participants, both datasets", everyone)] + [(d, [(d, s) for s in subjects[d]]) for d in datasets]:
            row = paired(diff(acc_train, a, b, who))
            row.update(contrast="%s-%s" % (a, b), scope=scope, measure="training accuracy of the final model",
                       status="descriptive; p unadjusted")
            descriptive.append(row)

    conditions_table = []
    for d in datasets:
        for c in conditions:
            values = np.array([acc[(d, s, c)] for s in subjects[d]])
            conditions_table.append(dict(
                dataset=d, condition=c, n_participants=len(subjects[d]),
                accuracy_mean_pct=100 * float(values.mean()), accuracy_sd_between_participants_pp=100 * float(values.std(ddof=1)),
                training_accuracy_mean_pct=100 * float(np.mean([acc_train[(d, s, c)] for s in subjects[d]])),
                nll_mean=float(np.mean([nll[(d, s, c)] for s in subjects[d]])),
                ece_mean=float(np.mean([ece[(d, s, c)] for s in subjects[d]]))))

    # S0 next to the published values: the benchmark reports the mean and the SD of five runs, each run being the
    # mean over the nine participants; the same two numbers are formed here from seeds 0-4.
    baseline = []
    by_seed = {}
    for r in records:
        i = r["identity"]
        if i["condition"] == "S0":
            by_seed.setdefault((i["dataset"], i["seed"]), []).append(float(r["acc_test"]))
    for d in datasets:
        runs = np.array([100 * float(np.mean(by_seed[(d, k)])) for k in seeds])
        published = PUBLISHED_S0[d]
        mean = float(runs.mean())
        baseline.append(dict(dataset=d, s0_mean_pct=mean, s0_sd_over_five_runs_pp=float(runs.std(ddof=1)), s0_run_means_pct=runs.tolist(),
                             published_mean_pct=published["mean"], published_sd_over_five_runs_pp=published["sd_over_five_runs"],
                             difference_from_published_pp=mean - published["mean"], margin_pp=BASELINE_MARGIN,
                             baseline_reproduced=bool(abs(mean - published["mean"]) <= BASELINE_MARGIN)))

    participants = [dict(dataset=d, subject=s, **{c: acc[(d, s, c)] for c in conditions},
                         **{"train_" + c: acc_train[(d, s, c)] for c in conditions}) for d, s in everyone]
    return dict(family_of_two_contrasts=family, descriptive_contrasts=descriptive, condition_summary=conditions_table,
                s0_against_published=baseline, participant_means=participants)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True, help="run folder of pr_run.py (records, predictions, COMPLETE.json)")
    parser.add_argument("--analysis", type=Path, required=True, help="new folder for the tables")
    parser.add_argument("--fidelity", type=Path, help="FIDELITY.json written by pr_fidelity.py")
    args = parser.parse_args()
    sys.path.insert(0, str(HERE))
    import pr_run
    protocol, protocol_sha = pr_run.load_protocol(args.protocol)
    plan = protocol["analysis"]                 # the written analysis plan and the constants of this script must agree
    assert plan["family"] == ["%s-%s" % (a, b) for a, b, _ in FAMILY] and plan["primary"] == "%s-%s" % FAMILY[0][:2]
    assert plan["alpha"] == ALPHA and plan["equivalence_bound_pp"] == BOUND and plan["baseline_margin_pp"] == BASELINE_MARGIN
    assert plan["published_s0_pct"] == {d: [v["mean"], v["sd_over_five_runs"]] for d, v in PUBLISHED_S0.items()}
    out = args.out.resolve()
    if (out / "SMOKE_NOT_A_RESULT.txt").exists():
        raise SystemExit("smoke output is not a result")
    complete = json.loads((out / "COMPLETE.json").read_text("utf-8"))
    if complete["status"] != "ALL_360_FITS_COMPLETE" or complete["protocol_sha256"] != protocol_sha:
        raise SystemExit("the run folder is not a complete run of this protocol")
    records = []
    for name, digest in sorted(complete["files"].items()):
        if sha256(out / name) != digest:
            raise SystemExit("file changed after completion: " + name)
        if name.startswith("records/"):
            records.append(json.loads((out / name).read_text("utf-8")))
    if len(records) != 360:
        raise SystemExit("expected 360 records, found %d" % len(records))
    datasets = ["bcic" + d for d in pr_run.DATASETS]
    subjects = {"bcic" + d: pr_run.DATASETS[d]["subjects"] for d in pr_run.DATASETS}
    result = analyse(records, datasets, subjects, pr_run.CONDITIONS, pr_run.SEEDS)
    result = dict(computation="C: the study's target rules inside the published benchmark configuration of EEGNet",
                  status="post hoc; protocol written before the run; test data of both datasets had been used in the study's Experiments 1 and 2",
                  protocol_sha256=protocol_sha, fits=len(records), devices=complete["devices"],
                  equivalence_bound_pp=BOUND, alpha=ALPHA, **result,
                  inputs=dict(complete_sha256=sha256(out / "COMPLETE.json")),
                  script_sha256=sha256(__file__), versions=dict(python=sys.version.split()[0], numpy=np.__version__))
    if args.fidelity:
        fidelity = json.loads(args.fidelity.read_text("utf-8"))
        if fidelity.get("smoke") or fidelity.get("status") != "COMPLETE":
            raise SystemExit("the fidelity file is not a complete, full run")
        s0 = {(r["identity"]["dataset"], r["identity"]["subject"]): (float(r["acc_test"]), int(r["n_test"])) for r in records
              if r["identity"]["condition"] == "S0" and r["identity"]["seed"] == fidelity["seed"]}
        rows = []
        for row in fidelity["participants"]:
            ours, n_test = s0[(row["dataset"], row["subject"])]
            # the benchmark prints a single-precision accuracy; both values are turned into numbers of correct test trials
            k_ours, k_bench = int(round(ours * n_test)), int(round(row["test_acc"] * n_test))
            assert abs(ours * n_test - k_ours) < 1e-6 and abs(row["test_acc"] * n_test - k_bench) < 1e-3
            rows.append(dict(dataset=row["dataset"], subject=row["subject"], n_test=n_test, correct_benchmark_procedure=k_bench,
                             correct_study_loop_s0=k_ours, benchmark_procedure=k_bench / n_test, study_loop_s0=k_ours / n_test,
                             difference_pp=100.0 * (k_ours - k_bench) / n_test))
        d = np.array([r["difference_pp"] for r in rows])
        result["fidelity_seed0"] = dict(
            what="benchmark's own training procedure (unmodified) against the S0 loop of this computation, same seed, same machine",
            seed=fidelity["seed"], participants=rows, identical_participants=int(np.sum(d == 0)), n=len(rows),
            mean_difference_pp=float(d.mean()), largest_absolute_difference_pp=float(np.abs(d).max()),
            benchmark_procedure_mean_pct={ds: 100 * float(np.mean([r["benchmark_procedure"] for r in rows if r["dataset"] == ds])) for ds in datasets},
            fidelity_sha256=sha256(args.fidelity))
    args.analysis.mkdir(parents=True, exist_ok=False)
    (args.analysis / "published_regime_analysis.json").write_text(json.dumps(result, indent=1, allow_nan=False) + "\n", encoding="utf-8")

    lines = ["# Computation C: target rules inside the published EEGNet configuration", "",
             "Accuracy in percent, differences in percentage points; participants are the unit (five-seed means).", "",
             "## Conditions", "", "| Dataset | Condition | Test accuracy | SD between participants | Training accuracy | NLL | ECE |",
             "|---|---|---:|---:|---:|---:|---:|"]
    for r in result["condition_summary"]:
        lines.append("| %s | %s | %.2f | %.2f | %.2f | %.3f | %.3f |" % (r["dataset"], r["condition"], r["accuracy_mean_pct"],
                     r["accuracy_sd_between_participants_pp"], r["training_accuracy_mean_pct"], r["nll_mean"], r["ece_mean"]))
    lines += ["", "## S0 next to the published values", "", "| Dataset | S0 here (mean, SD of five runs) | Published | Difference | Within %.0f points |" % BASELINE_MARGIN,
              "|---|---|---|---:|---|"]
    for r in result["s0_against_published"]:
        lines.append("| %s | %.2f, %.2f | %.2f, %.2f | %+.2f | %s |" % (r["dataset"], r["s0_mean_pct"], r["s0_sd_over_five_runs_pp"],
                     r["published_mean_pct"], r["published_sd_over_five_runs_pp"], r["difference_from_published_pp"],
                     "yes" if r["baseline_reproduced"] else "no"))
    lines += ["", "## Family of two contrasts (18 participants)", "",
              "| Contrast | Role | Difference | 95% CI | p | Holm p | 90% CI | TOST p | TOST Holm p | Reading |", "|---|---|---:|---|---:|---:|---|---:|---:|---|"]
    for r in result["family_of_two_contrasts"]:
        lines.append("| %s | %s | %+.2f | [%+.2f, %+.2f] | %.4f | %.4f | [%+.2f, %+.2f] | %.4f | %.4f | %s |" % (
            r["contrast"], r["role"], r["mean_difference_pp"], r["ci95_pp"][0], r["ci95_pp"][1], r["p_two_sided"], r["p_holm_two_contrasts"],
            r["ci90_pp"][0], r["ci90_pp"][1], r["tost_p"], r["tost_p_holm_two_contrasts"], r["reading"]))
    lines += ["", "## Descriptive contrasts", "", "| Measure | Contrast | Scope | n | Difference | 95% CI | p (unadjusted) |", "|---|---|---|---:|---:|---|---:|"]
    for r in result["descriptive_contrasts"]:
        ci = "[%+.2f, %+.2f]" % tuple(r["ci95_pp"]) if "ci95_pp" in r else "no spread"
        p = "%.4f" % r["p_two_sided"] if "p_two_sided" in r else ""
        lines.append("| %s | %s | %s | %d | %+.2f | %s | %s |" % (r["measure"], r["contrast"], r["scope"], r["n"], r["mean_difference_pp"], ci, p))
    if "fidelity_seed0" in result:
        f = result["fidelity_seed0"]
        lines += ["", "## Fidelity check (seed %d)" % f["seed"], "",
                  "Benchmark's own procedure against the S0 loop: %d of %d participants identical; mean difference %+.3f, largest absolute difference %.3f points."
                  % (f["identical_participants"], f["n"], f["mean_difference_pp"], f["largest_absolute_difference_pp"])]
    (args.analysis / "published_regime_tables.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
