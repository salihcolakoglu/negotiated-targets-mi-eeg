#!/usr/bin/env python3
"""Computation C, runner: 2 datasets x 9 participants x 4 conditions x 5 seeds = 360 fits (see pr_core.py).

Every value of the training configuration is read from the benchmark's own configuration file and checked against
the values written in the protocol; nothing can be changed from the command line except which jobs run (sharding)
and on which device. Completed fits are kept; a repeated command continues with the missing ones.

Usage:
  pr_run.py prepare  --protocol PROTOCOL-C.json --benchmark BENCHMARK_REPO --mne-data DIR --out OUT
  pr_run.py fit      --protocol PROTOCOL-C.json --benchmark BENCHMARK_REPO --release RELEASE_REPO --out OUT
                     [--device cpu|cuda] [--threads N] [--shard K/N] [--smoke]
  pr_run.py finalize --protocol PROTOCOL-C.json --out OUT

`prepare` runs the benchmark's own data module once per participant and stores the arrays; `fit` only reads them, so
that every fit and every parallel shard sees the same bytes.

`--smoke` trains one epoch per phase to exercise the pipeline. It does not use the test trials: the last quarter of
the training trials stands in for them. Smoke output goes to its own folder, is marked as such and is refused by
the analysis.
"""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
BENCHMARK_COMMIT = "f1ee0d4b665d8ea7c2cc5efc3e1ca9c56412b0c5"
RELEASE_COMMIT = "bd063a8c4ce2e1b4b0766bbebc7a894acdaabc62"            # tag v2.2.0 of the study's repository
DATASETS = {
    "2a": dict(config="bcic2a_eegnet.yaml", module="BCICIV2a", n_classes=4, in_channels=22, subjects=list(range(1, 10))),
    "2b": dict(config="bcic2b_eegnet.yaml", module="BCICIV2b", n_classes=2, in_channels=3, subjects=list(range(1, 10))),
}
CONDITIONS = ["S0", "W0", "W1", "W2"]
SEEDS = [0, 1, 2, 3, 4]
PHASES = 10
# values that the benchmark's configuration files must hold (they define the regime; the run stops if they differ)
EXPECTED = dict(max_epochs=500, preprocessing=dict(sfreq=128, low_cut=0, high_cut=40, start=0.5, z_scale=True, batch_size=64),
                model="EEGNet", model_kwargs=dict(input_window_samples=256, F1=8, D=2, F2=16, drop_prob=0.5, kernel_length=32,
                                                  pool_time_length=4, pool_time_stride=4, kernel_length_dw_sep=16, lr=0.001,
                                                  weight_decay=0.0, optimizer="adam", scheduler=False))
STOP = {"2a": -1.5, "2b": -2.0}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    tmp.write_text(json.dumps(payload, indent=1, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def git_head(repo):
    return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()


def git_clean(repo):
    """True if the checkout has no modified, deleted or untracked source file."""
    status = subprocess.run(["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=all"], capture_output=True, text=True, check=True).stdout
    return not [line for line in status.splitlines() if "__pycache__" not in line and not line.endswith(".pyc")]


def use_benchmark(benchmark):
    """Import the benchmark package from the pinned, unmodified checkout (not from another installed copy).

    The benchmark is started with `python run.py` from its package folder; its BCI Competition III module therefore
    imports `utils.load_bcic3` relative to that folder. Both the repository root and the package folder are put on
    the import path, which is the same situation as in the documented call.
    """
    root = Path(benchmark).resolve()
    assert git_head(root) == BENCHMARK_COMMIT, "benchmark repository is not at the protocol's commit"
    assert git_clean(root), "benchmark checkout has local changes"
    for entry in (str(root / "channel_attention"), str(root)):
        if entry in sys.path:
            sys.path.remove(entry)
        sys.path.insert(0, entry)
    import channel_attention
    assert Path(channel_attention.__file__).resolve().parent == root / "channel_attention", "benchmark imported from another location"
    return root


def use_release(release):
    """The study's own code (decoding, metrics, codebook) from the pinned, unmodified checkout of release v2.2.0."""
    root = Path(release).resolve()
    assert git_head(root) == RELEASE_COMMIT, "study repository is not at release v2.2.0"
    assert git_clean(root), "study checkout has local changes"
    entry = str(root / "src" / "eegnet")
    if entry in sys.path:
        sys.path.remove(entry)
    sys.path.insert(0, entry)
    import core
    assert Path(core.__file__).resolve().parent == root / "src" / "eegnet", "study code imported from another location"
    return root


def load_protocol(path):
    protocol = json.loads(Path(path).read_text("utf-8"))
    for name, digest in protocol["code_sha256"].items():
        if sha256(HERE / name) != digest:
            raise SystemExit("code file differs from the protocol: " + name)
    assert protocol["benchmark_commit"] == BENCHMARK_COMMIT and protocol["release_commit"] == RELEASE_COMMIT
    assert protocol["conditions"] == CONDITIONS and protocol["seeds"] == SEEDS and protocol["phases"] == PHASES
    assert protocol["epochs_total"] == EXPECTED["max_epochs"] and protocol["epochs_per_phase"] * PHASES == EXPECTED["max_epochs"]
    return protocol, sha256(path)


def jobs():
    return [(d, s, c, k) for k in SEEDS for d in DATASETS for s in DATASETS[d]["subjects"] for c in CONDITIONS]


def job_id(d, s, c, k):
    return "bcic%s_S%02d__%s__seed%d" % (d, s, c, k)


def read_config(benchmark, d):
    import yaml
    path = Path(benchmark) / "configs" / DATASETS[d]["config"]
    config = yaml.safe_load(path.read_text("utf-8"))
    assert config["max_epochs"] == EXPECTED["max_epochs"] and config["model"] == EXPECTED["model"], config
    for key, value in EXPECTED["preprocessing"].items():
        assert config["preprocessing"][key] == value, (key, config["preprocessing"][key])
    assert config["preprocessing"]["stop"] == STOP[d]
    for key, value in EXPECTED["model_kwargs"].items():
        assert config["model_kwargs"][key] == value, (key, config["model_kwargs"][key])
    assert config["model_kwargs"]["n_classes"] == DATASETS[d]["n_classes"] and config["model_kwargs"]["in_channels"] == DATASETS[d]["in_channels"]
    return config, sha256(path)


def prepare_command(args):
    """Arrays of every participant from the benchmark's own data module (no training, no model)."""
    import numpy as np
    load_protocol(args.protocol)
    out = Path(args.out).resolve()
    os.environ["MNE_DATA"] = os.environ["MNE_DATASETS_BNCI_PATH"] = str(Path(args.mne_data).resolve())
    use_benchmark(args.benchmark)
    import channel_attention.datamodules as datamodules
    summary = []
    for d in DATASETS:
        config, config_sha = read_config(args.benchmark, d)
        for s in DATASETS[d]["subjects"]:
            path = out / "prepared" / ("bcic%s_S%02d.npz" % (d, s))
            if not path.exists():
                dm = getattr(datamodules, DATASETS[d]["module"])(config["preprocessing"], subject_id=s)
                dm.prepare_data()
                dm.setup()
                X_train, y_train = dm.train_dataset.tensors
                X_test, y_test = dm.test_dataset.tensors
                path.parent.mkdir(parents=True, exist_ok=True)
                tmp = path.with_name(path.stem + ".tmp-" + uuid.uuid4().hex + ".npz")
                np.savez_compressed(tmp, X_train=X_train.numpy(), y_train=y_train.numpy(), X_test=X_test.numpy(), y_test=y_test.numpy())
                os.replace(tmp, path)
            arrays, digest = prepared(out, d, s)
            row = dict(dataset="bcic" + d, subject=s, train_shape=list(arrays["X_train"].shape), test_shape=list(arrays["X_test"].shape),
                       train_class_counts=np.bincount(arrays["y_train"]).tolist(), test_class_counts=np.bincount(arrays["y_test"]).tolist(),
                       sha256=digest, benchmark_config_sha256=config_sha)
            summary.append(row)
            print(json.dumps(row), flush=True)
    atomic_json(out / "prepared" / "PREPARED_SUMMARY.json", summary)


def prepared(out, d, s):
    """Stored arrays of one participant (written by `prepare`)."""
    import numpy as np
    path = Path(out) / "prepared" / ("bcic%s_S%02d.npz" % (d, s))
    if not path.exists():
        raise SystemExit("run `pr_run.py prepare` first: " + str(path))
    with np.load(path, allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files}
    K, ch = DATASETS[d]["n_classes"], DATASETS[d]["in_channels"]
    assert arrays["X_train"].dtype == np.float32 and arrays["X_train"].shape[1:] == (ch, 256) and arrays["X_test"].shape[1:] == (ch, 256)
    assert sorted(np.unique(arrays["y_train"]).tolist()) == list(range(K)) and sorted(np.unique(arrays["y_test"]).tolist()) == list(range(K))
    assert np.isfinite(arrays["X_train"]).all() and np.isfinite(arrays["X_test"]).all()
    return arrays, sha256(path)


def fit_command(args):
    protocol, protocol_sha = load_protocol(args.protocol)
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    marker = out / ("SMOKE_NOT_A_RESULT.txt" if args.smoke else "FULL_RUN.txt")
    other = out / ("FULL_RUN.txt" if args.smoke else "SMOKE_NOT_A_RESULT.txt")
    if other.exists():
        raise SystemExit("this output folder belongs to the other kind of run (smoke/full)")
    marker.touch()
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    import numpy as np
    import torch
    torch.set_num_threads(args.threads)
    use_release(args.release)
    import core as release                       # study code, release v2.2.0 (decoding and metrics)
    from data import code_rows, R_RATE as REL_RATE, PHASES as REL_PHASES
    sys.path.insert(0, str(HERE))
    import pr_core
    assert (REL_RATE, REL_PHASES) == (pr_core.R_RATE, pr_core.PHASES) == (0.03, PHASES)
    use_benchmark(args.benchmark)
    from channel_attention.models.eegnet import EEGNetModule
    from channel_attention.utils.seed import seed_everything
    if args.device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("cuda requested but not available; no silent fallback")
    device = torch.device(args.device)
    versions = dict(python=platform.python_version(), torch=str(torch.__version__), numpy=np.__version__, cuda=torch.version.cuda if args.device == "cuda" else None)
    code = {name: sha256(HERE / name) for name in ("pr_core.py", "pr_run.py")}
    epochs_per_phase = 1 if args.smoke else protocol["epochs_per_phase"]
    shard_k, shard_n = (int(x) for x in args.shard.split("/"))
    todo = [j for i, j in enumerate(jobs()) if i % shard_n == shard_k]
    configs = {d: read_config(args.benchmark, d) for d in DATASETS}
    done = 0
    for d, s, c, k in todo:
        jid = job_id(d, s, c, k)
        record_path, pred_path = out / "records" / (jid + ".json"), out / "predictions" / (jid + ".npz")
        config, config_sha = configs[d]
        arrays, prepared_sha = prepared(out, d, s)
        identity = dict(dataset="bcic" + d, subject=s, condition=c, seed=k, smoke=bool(args.smoke), epochs_per_phase=epochs_per_phase,
                        phases=PHASES, batch=config["preprocessing"]["batch_size"], lr=config["model_kwargs"]["lr"], n_bits=16,
                        benchmark_commit=BENCHMARK_COMMIT, benchmark_config_sha256=config_sha, release_commit=RELEASE_COMMIT,
                        prepared_sha256=prepared_sha, code_sha256=code, protocol_sha256=protocol_sha, device=args.device, versions=versions)
        if record_path.exists():
            old = json.loads(record_path.read_text("utf-8"))
            if old["identity"] != identity or sha256(pred_path) != old["prediction_sha256"]:
                raise SystemExit("a completed fit has a different identity or changed files: " + jid)
            continue
        K = DATASETS[d]["n_classes"]
        walsh = c != "S0"
        C = code_rows(K)
        if args.smoke:                                                 # no test trial is used in a smoke run
            cut = len(arrays["y_train"]) - len(arrays["y_train"]) // 4
            arrays = dict(X_train=arrays["X_train"][:cut], y_train=arrays["y_train"][:cut],
                          X_test=arrays["X_train"][cut:], y_test=arrays["y_train"][cut:])
        X_train, y_train = torch.from_numpy(arrays["X_train"]), torch.from_numpy(arrays["y_train"]).long()
        X_test, y_test = torch.from_numpy(arrays["X_test"]), torch.from_numpy(arrays["y_test"]).long()
        seed_everything(k)                                             # the benchmark's own seeding function
        kw = config["model_kwargs"]
        model = EEGNetModule(in_channels=kw["in_channels"], n_classes=16 if walsh else K, input_window_samples=kw["input_window_samples"],
                             F1=kw["F1"], D=kw["D"], F2=kw["F2"], kernel_length=kw["kernel_length"], drop_prob=kw["drop_prob"],
                             pool_time_length=kw["pool_time_length"], pool_time_stride=kw["pool_time_stride"],
                             kernel_length_dw_sep=kw["kernel_length_dw_sep"]).to(device)
        start = time.time()
        fit_record, fit_arrays = pr_core.fit(model, X_train, y_train, condition=c, C=C, epochs_per_phase=epochs_per_phase,
                                             batch=config["preprocessing"]["batch_size"], lr=kw["lr"], device=device, release=release)
        final_record, final_arrays = pr_core.evaluate(model, X_train, y_train, X_test, y_test, condition=c, C=C, device=device, release=release)
        tmp = pred_path.with_name(pred_path.stem + ".tmp-" + uuid.uuid4().hex + ".npz")
        pred_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(tmp, **fit_arrays, **final_arrays)
        os.replace(tmp, pred_path)
        record = dict(job=jid, identity=identity, n_train=int(len(y_train)), n_test=int(len(y_test)), **fit_record, **final_record,
                      wall_seconds=round(time.time() - start, 2), threads=int(torch.get_num_threads()), prediction_file="predictions/" + pred_path.name,
                      prediction_sha256=sha256(pred_path), completed_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        for key, value in record.items():
            if isinstance(value, float) and not np.isfinite(value):
                raise SystemExit("non-finite value in " + jid + ": " + key)
        atomic_json(record_path, record)
        done += 1
        print(json.dumps({"fit_complete": jid, "seconds": record["wall_seconds"], "shard": args.shard}), flush=True)   # no accuracy is printed
    print(json.dumps({"shard": args.shard, "new_fits": done, "jobs_in_shard": len(todo)}), flush=True)


def finalize_command(args):
    protocol, protocol_sha = load_protocol(args.protocol)
    out = Path(args.out).resolve()
    if (out / "SMOKE_NOT_A_RESULT.txt").exists():
        raise SystemExit("smoke output is not a result")
    files = {}
    for d, s, c, k in jobs():
        jid = job_id(d, s, c, k)
        record_path = out / "records" / (jid + ".json")
        record = json.loads(record_path.read_text("utf-8"))
        ident = record["identity"]
        assert (ident["dataset"], ident["subject"], ident["condition"], ident["seed"]) == ("bcic" + d, s, c, k)
        assert ident["protocol_sha256"] == protocol_sha and not ident["smoke"] and record["epochs_completed"] == protocol["epochs_total"]
        assert sha256(out / record["prediction_file"]) == record["prediction_sha256"]
        files["records/" + record_path.name] = sha256(record_path)
        files[record["prediction_file"]] = record["prediction_sha256"]
    extra = {p.stem for p in (out / "records").glob("*.json")} - {job_id(*j) for j in jobs()}
    assert not extra, extra
    for p in sorted((out / "prepared").glob("*.npz")):
        files["prepared/" + p.name] = sha256(p)
    devices = sorted({json.loads((out / "records" / (job_id(*j) + ".json")).read_text("utf-8"))["identity"]["device"] for j in jobs()})
    atomic_json(out / "COMPLETE.json", dict(status="ALL_360_FITS_COMPLETE", protocol_sha256=protocol_sha, fits=len(jobs()), devices=devices, files=files))
    print("complete: %d fits, %d files listed" % (len(jobs()), len(files)))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    q = sub.add_parser("prepare")
    q.add_argument("--protocol", required=True)
    q.add_argument("--benchmark", required=True)
    q.add_argument("--mne-data", required=True)
    q.add_argument("--out", required=True)
    f = sub.add_parser("fit")
    f.add_argument("--protocol", required=True)
    f.add_argument("--benchmark", required=True)
    f.add_argument("--release", required=True)
    f.add_argument("--out", required=True)
    f.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    f.add_argument("--threads", type=int, default=1)
    f.add_argument("--shard", default="0/1")
    f.add_argument("--smoke", action="store_true")
    g = sub.add_parser("finalize")
    g.add_argument("--protocol", required=True)
    g.add_argument("--out", required=True)
    args = parser.parse_args()
    {"prepare": prepare_command, "fit": fit_command, "finalize": finalize_command}[args.command](args)


if __name__ == "__main__":
    main()
