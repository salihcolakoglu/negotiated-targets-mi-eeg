"""Computation C: the study's target rules inside the published benchmark configuration of EEGNet.

Benchmark: Wimpff et al., "EEG motor imagery decoding: a framework for comparative analysis with channel attention
mechanisms" (J. Neural Eng., 2024); public code github.com/martinwimpff/channel-attention (MIT licence).
Taken from the benchmark without change: the data module (loading, 128 Hz, 40 Hz low-pass, 0.5-2.5 s window,
standardization fitted on the training trials, train/test partition), the EEGNet model class, the seeding function and
the values of its configuration file (Adam, learning rate 0.001, batch 64, 500 epochs, dropout 0.5, no scheduler).
Added here: the output coding and the target rules of the study (release v2.2.0, src/eegnet/core.py):

  S0  class outputs, cross-entropy, hard labels (the benchmark's own setting)
  W0  16 Walsh-coded outputs, binary cross-entropy, fixed targets
  W1  as W0, cumulative negotiation:              T <- T - (T - P) * 0.03 * p
  W2  as W0, anchored, correctness-gated rule:    T <- y + 0.03 * p * (P - y) for correctly decoded training trials, else y

Training runs in ten phases of equal length. After phase p (p = 0..9) the network predicts the training trials in
evaluation mode (P) and the rule gives the targets of the next phase; the update after the last phase is not used.
The test trials are predicted once, by the final model. Nothing is selected on test data.

The mini-batch loop mirrors what the benchmark's Lightning trainer does for this model: shuffled batches from a
torch DataLoader, zero_grad, backward, Adam step; float32; no gradient clipping; no mixed precision.

Random numbers. The benchmark seeds once per participant and then lets the trainer run. Its trainer draws from the
global generator at fixed points: one number whenever an iterator of a DataLoader is created (training loader and
evaluation loader once before the first epoch; training loader at the start and evaluation loader at the end of
every epoch) and one number for the shuffling order of each epoch; dropout draws in between. The loop below
creates iterators at the same points (the second loader, `shadow`, holds only trial indices and is never read), so
that with the same seed the S0 condition is the benchmark's own training run. pr_fidelity.py checks this against
the benchmark's unmodified code. The Walsh conditions use the same loop and therefore the same random stream.
"""
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

R_RATE, PHASES = 0.03, 10                       # the study's negotiation rate and number of phases
RULES = {"S0": "hard", "W0": "hard", "W1": "neg_paper", "W2": "neg_anchor_gate"}


@torch.no_grad()
def predict(model, X, walsh, device, batch=256):
    """Outputs for all trials of X in evaluation mode: sigmoid outputs (Walsh) or class probabilities (softmax)."""
    model.eval()
    out = [model(X[i:i + batch].to(device)) for i in range(0, X.shape[0], batch)]
    z = torch.cat(out).float()
    return (torch.sigmoid(z) if walsh else torch.softmax(z, 1)).cpu().numpy()


def fit(model, X_train, y_train, *, condition, C, epochs_per_phase, batch, lr, device, release, phases=PHASES):
    """Train `model` in `phases` phases; return a record and arrays.

    X_train: float32 tensor (n, channels, samples); y_train: int64 tensor (n,) with classes 0..K-1.
    C: Walsh codebook (K, 16) float32. `release` is the study's module src/eegnet/core.py (nearest-codeword decoding).
    """
    walsh = condition != "S0"
    rule = RULES[condition]
    n = X_train.shape[0]
    y0 = y_train.numpy().astype(np.int64)
    opt = torch.optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), weight_decay=0.0)
    loader = DataLoader(TensorDataset(X_train, torch.arange(n)), batch_size=batch, shuffle=True)
    shadow = DataLoader(TensorDataset(torch.arange(n)), batch_size=batch)      # stands for the trainer's evaluation loader; never read
    if walsh:
        Y = C[y0].astype(np.float32)
        Yneg = Y.copy()
    else:
        Y = Yneg = None
    Y_used = Yneg
    gate = None
    used_dist, used_gate, phase_train_acc = [], [], []
    y_dev = y_train.to(device)
    t0 = time.time()
    iter(loader)                                    # as the trainer before the first epoch: one iterator of each loader
    iter(shadow)
    for p in range(phases):
        Y_used = Yneg
        if walsh:
            used_dist.append(float(np.linalg.norm(Y_used - Y, axis=1).mean()))
            used_gate.append(None if gate is None else float(gate.mean()))
            T = torch.from_numpy(Yneg).to(device)
        model.train()
        for _ in range(epochs_per_phase):
            for xb, ib in loader:
                xb, ib = xb.to(device), ib.to(device)
                logits = model(xb)
                if walsh:
                    loss = F.binary_cross_entropy_with_logits(logits, T[ib])
                else:
                    loss = F.cross_entropy(logits, y_dev[ib])
                opt.zero_grad()
                loss.backward()
                opt.step()
            iter(shadow)                            # as the trainer after every epoch: an iterator of its evaluation loader
        P = predict(model, X_train, walsh, device)
        phase_train_acc.append(float((release.nearest(P, C) == y0).mean()) if walsh else float((P.argmax(1) == y0).mean()))
        a = R_RATE * p
        if walsh and rule == "neg_paper":
            Yneg = (Yneg - (Yneg - P) * R_RATE * p).astype(np.float32)          # same expression as the release
        elif walsh and rule == "neg_anchor_gate":
            gate = release.nearest(P, C) == y0
            Yneg = Y.copy()
            Yneg[gate] = ((1 - a) * Y[gate] + a * P[gate]).astype(np.float32)
        elif rule != "hard":
            raise ValueError(rule)
    record = dict(train_seconds=round(time.time() - t0, 2), epochs_completed=phases * epochs_per_phase,
                  phase_train_acc=phase_train_acc)
    arrays = {}
    if walsh:
        record["last_target_wrong_frac"] = float((release.nearest(Y_used, C) != y0).mean())
        record["last_target_dist"] = float(np.linalg.norm(Y_used - Y, axis=1).mean())
        record["used_target_dist_by_phase"] = used_dist
        record["used_gate_open_by_phase"] = used_gate
        arrays["Y_used_last"] = Y_used.astype(np.float32)
    return record, arrays


def evaluate(model, X_train, y_train, X_test, y_test, *, condition, C, device, release):
    """Final model: predictions and the study's metrics on the training and the test trials."""
    walsh = condition != "S0"
    ytr, yte = y_train.numpy().astype(np.int64), y_test.numpy().astype(np.int64)
    P_test = predict(model, X_test, walsh, device)
    P_train = predict(model, X_train, walsh, device)
    m_test = release.walsh_metrics(P_test, yte, C) if walsh else release.softmax_metrics(P_test, yte)
    m_train = release.walsh_metrics(P_train, ytr, C) if walsh else release.softmax_metrics(P_train, ytr)
    record = dict(acc_test=m_test["acc"], acc_train=m_train["acc"], acc_test_post=m_test["acc_post"], bce_test=m_test["bce"],
                  nll_test=m_test["nll"], ece_test=m_test["ece"], nll_train=m_train["nll"])
    arrays = dict(P_test=P_test.astype(np.float32), P_train=P_train.astype(np.float32), y_test=yte, y_train=ytr)
    return record, arrays
