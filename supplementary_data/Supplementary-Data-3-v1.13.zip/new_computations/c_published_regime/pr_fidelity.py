#!/usr/bin/env python3
"""Computation C, fidelity check: the benchmark's own training procedure, unmodified, for seed 0.

For each dataset and participant the benchmark's own function `channel_attention.train_test.train_and_test` is
called with the benchmark's own configuration file; the only value set here is `subject_ids` (one participant per
call, which the configuration file allows: "either 'all' or integer"), so that the accuracy of each participant is
kept. The function seeds, builds the trainer, the data module and the model, trains and tests exactly as in the
benchmark; it prints "test_acc: <value>", which is read from its output. 2 datasets x 9 participants = 18 fits.

Purpose: the S0 condition of this computation uses a hand-written training loop (pr_core.py) so that the Walsh
conditions can share it. This check shows, participant by participant, how closely that loop follows the
benchmark's procedure on the same machine with the same seed. It is not part of the two-contrast family.

Usage: pr_fidelity.py --protocol PROTOCOL-C.json --benchmark BENCHMARK_REPO --mne-data DIR --out FIDELITY_FOLDER
                      [--threads N] [--shard K/N] [--smoke]
(`--smoke`: one epoch; the benchmark's function evaluates its test loader, so this switch is for synthetic data only.)
Use the same number of threads as for the S0 fits, so that the two runs can be compared number by number.
       pr_fidelity.py --protocol PROTOCOL-C.json --benchmark BENCHMARK_REPO --out FIDELITY_FOLDER --finalize
"""
import argparse
import contextlib
import io
import json
import os
import platform
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED = 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--benchmark", required=True)
    parser.add_argument("--mne-data")
    parser.add_argument("--out", required=True)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--shard", default="0/1")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--finalize", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(HERE))
    import pr_run
    protocol, protocol_sha = pr_run.load_protocol(args.protocol)
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    marker = out / ("SMOKE_NOT_A_RESULT.txt" if args.smoke else "FULL_RUN.txt")
    other = out / ("FULL_RUN.txt" if args.smoke else "SMOKE_NOT_A_RESULT.txt")
    if other.exists():
        raise SystemExit("this output folder belongs to the other kind of run (smoke/full)")
    todo = [(d, s) for d in pr_run.DATASETS for s in pr_run.DATASETS[d]["subjects"]]

    if args.finalize:
        if args.smoke or not marker.exists():
            raise SystemExit("finalize needs a full (non-smoke) fidelity folder")
        rows = []
        for d, s in todo:
            row = json.loads((out / "participants" / ("bcic%s_S%02d.json" % (d, s))).read_text("utf-8"))
            assert (row["dataset"], row["subject"], row["seed"], row["smoke"]) == ("bcic" + d, s, SEED, False)
            assert row["protocol_sha256"] == protocol_sha and row["max_epochs"] == protocol["epochs_total"]
            rows.append(row)
        pr_run.atomic_json(out / "FIDELITY.json", dict(status="COMPLETE", smoke=False, seed=SEED, protocol_sha256=protocol_sha,
                                                       participants=rows, fits=len(rows)))
        print("fidelity complete: %d participants" % len(rows))
        return

    marker.touch()
    os.environ["MNE_DATA"] = os.environ["MNE_DATASETS_BNCI_PATH"] = str(Path(args.mne_data).resolve())
    pr_run.use_benchmark(args.benchmark)
    import numpy as np
    import torch
    import yaml
    torch.set_num_threads(args.threads)
    import channel_attention.train_test as benchmark             # the benchmark's own module, unchanged
    shard_k, shard_n = (int(x) for x in args.shard.split("/"))
    done = 0
    for index, (d, s) in enumerate(todo):
        if index % shard_n != shard_k:
            continue
        path = out / "participants" / ("bcic%s_S%02d.json" % (d, s))
        if path.exists():
            continue
        _, config_sha = pr_run.read_config(args.benchmark, d)     # checks the regime values of the configuration file
        config = yaml.safe_load((Path(args.benchmark) / "configs" / pr_run.DATASETS[d]["config"]).read_text("utf-8"))
        assert config["seed"] == SEED and config["subject_ids"] == "all"
        config["subject_ids"] = s                                 # one participant per call (allowed by the configuration)
        if args.smoke:
            config["max_epochs"] = 1
        captured = io.StringIO()
        start = time.time()
        with contextlib.redirect_stdout(captured):
            benchmark.train_and_test(config)
        found = re.findall(r"^test_acc: ([0-9.eE+-]+)\s*$", captured.getvalue(), flags=re.M)
        if len(found) != 1:
            raise SystemExit("could not read the benchmark's printed accuracy for bcic%s S%02d" % (d, s))
        row = dict(dataset="bcic" + d, subject=s, seed=SEED, smoke=bool(args.smoke), max_epochs=config["max_epochs"],
                   test_acc=float(found[0]), benchmark_commit=pr_run.BENCHMARK_COMMIT, benchmark_config_sha256=config_sha,
                   protocol_sha256=protocol_sha, threads=args.threads, wall_seconds=round(time.time() - start, 2),
                   device="cuda" if torch.cuda.is_available() else "cpu",
                   versions=dict(python=platform.python_version(), torch=str(torch.__version__), numpy=np.__version__),
                   completed_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        pr_run.atomic_json(path, row)
        done += 1
        print(json.dumps({"fidelity_fit_complete": "bcic%s_S%02d" % (d, s), "seconds": row["wall_seconds"]}), flush=True)   # no accuracy printed
    print(json.dumps({"shard": args.shard, "new_fits": done}), flush=True)


if __name__ == "__main__":
    main()
