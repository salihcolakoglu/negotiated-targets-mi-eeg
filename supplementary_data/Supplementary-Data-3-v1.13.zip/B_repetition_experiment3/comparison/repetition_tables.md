# Computation B: repetition of the Lee2019 evaluation against the published records

Accuracy in percent; differences in percentage points; 54 participants, five-seed means.

## Five paired contrasts

| Contrast | Published (95% CI), Holm p | New run (95% CI), Holm p | Same Holm decision | New estimate inside published CI |
|---|---|---|---|---|
| W2-W0 | +0.05 [-0.13, +0.22], 1.000 | +0.02 [-0.19, +0.23], 1.000 | yes | yes |
| W1-W0 | +0.53 [+0.08, +0.98], 0.091 | +0.49 [+0.04, +0.93], 0.129 | yes | yes |
| W2-W1 | -0.48 [-0.88, -0.08], 0.091 | -0.47 [-0.84, -0.09], 0.077 | yes | yes |
| W2-W3 | +0.32 [-0.14, +0.77], 0.495 | +0.28 [-0.16, +0.72], 0.606 | yes | yes |
| W0-S0 | -0.30 [-1.42, +0.82], 1.000 | -0.36 [-1.49, +0.76], 1.000 | yes | yes |

## Condition means and participant-level agreement

| Condition | Published | New run | r between runs | Mean absolute difference | New - published (95% CI) |
|---|---:|---:|---:|---:|---|
| S0 | 63.56 | 63.64 | 1.000 | 0.22 | +0.09 [-0.00, +0.17] |
| W0 | 63.26 | 63.28 | 1.000 | 0.16 | +0.02 [-0.05, +0.09] |
| W1 | 63.79 | 63.76 | 1.000 | 0.15 | -0.02 [-0.09, +0.04] |
| W2 | 63.30 | 63.30 | 1.000 | 0.20 | -0.01 [-0.09, +0.07] |
| W3 | 62.99 | 63.01 | 1.000 | 0.13 | +0.03 [-0.02, +0.08] |

## Fit level, classical reference and prepared inputs

- Fits with the same test accuracy: 1074 of 1,350; test decisions that agree: 99.62% of 135000.
- Classical reference: identical decisions for 54 of 54 participants; means 61.59 (published) and 61.59 (new run).
- Prepared inputs byte-identical to the originally prepared files: 0 of 54 training files, 0 of 54 test files.
