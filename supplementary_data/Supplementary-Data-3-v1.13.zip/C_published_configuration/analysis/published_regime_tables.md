# Computation C: target rules inside the published EEGNet configuration

Accuracy in percent, differences in percentage points; participants are the unit (five-seed means).

## Conditions

| Dataset | Condition | Test accuracy | SD between participants | Training accuracy | NLL | ECE |
|---|---|---:|---:|---:|---:|---:|
| bcic2a | S0 | 71.03 | 10.81 | 99.39 | 1.021 | 0.160 |
| bcic2a | W0 | 72.18 | 10.43 | 98.49 | 3.151 | 0.251 |
| bcic2a | W1 | 72.20 | 10.49 | 94.97 | 2.078 | 0.231 |
| bcic2a | W2 | 72.28 | 10.43 | 98.22 | 2.841 | 0.246 |
| bcic2b | S0 | 83.05 | 11.10 | 92.58 | 0.390 | 0.068 |
| bcic2b | W0 | 83.68 | 10.44 | 91.60 | 1.633 | 0.150 |
| bcic2b | W1 | 84.21 | 11.04 | 87.88 | 1.234 | 0.140 |
| bcic2b | W2 | 83.77 | 10.54 | 91.42 | 1.427 | 0.145 |

## S0 next to the published values

| Dataset | S0 here (mean, SD of five runs) | Published | Difference | Within 2 points |
|---|---|---|---:|---|
| bcic2a | 71.03, 1.16 | 71.06, 1.00 | -0.03 | yes |
| bcic2b | 83.05, 0.57 | 83.54, 0.46 | -0.49 | yes |

## Family of two contrasts (18 participants)

| Contrast | Role | Difference | 95% CI | p | Holm p | 90% CI | TOST p | TOST Holm p | Reading |
|---|---|---:|---|---:|---:|---|---:|---:|---|
| W2-W0 | primary | +0.09 | [-0.03, +0.22] | 0.1437 | 0.2874 | [-0.01, +0.19] | 0.0000 | 0.0000 | equivalent within one point |
| W1-W0 | secondary | +0.27 | [-0.30, +0.84] | 0.3283 | 0.3283 | [-0.20, +0.74] | 0.0074 | 0.0074 | equivalent within one point |

## Descriptive contrasts

| Measure | Contrast | Scope | n | Difference | 95% CI | p (unadjusted) |
|---|---|---|---:|---:|---|---:|
| test accuracy | W2-W0 | bcic2a | 9 | +0.09 | [-0.08, +0.26] | 0.2415 |
| test accuracy | W2-W0 | bcic2b | 9 | +0.09 | [-0.14, +0.32] | 0.3888 |
| test accuracy | W1-W0 | bcic2a | 9 | +0.02 | [-0.84, +0.87] | 0.9678 |
| test accuracy | W1-W0 | bcic2b | 9 | +0.53 | [-0.38, +1.43] | 0.2173 |
| test accuracy | W0-S0 | bcic2a | 9 | +1.15 | [+0.11, +2.19] | 0.0347 |
| test accuracy | W0-S0 | bcic2b | 9 | +0.64 | [-0.19, +1.46] | 0.1119 |
| test accuracy | W2-W1 | bcic2a | 9 | +0.08 | [-0.78, +0.94] | 0.8410 |
| test accuracy | W2-W1 | bcic2b | 9 | -0.44 | [-1.33, +0.46] | 0.2950 |
| test accuracy | W0-S0 | 18 participants, both datasets | 18 | +0.89 | [+0.29, +1.50] | 0.0062 |
| test accuracy | W2-W1 | 18 participants, both datasets | 18 | -0.18 | [-0.75, +0.39] | 0.5127 |
| training accuracy of the final model | W2-W0 | 18 participants, both datasets | 18 | -0.22 | [-0.34, -0.10] | 0.0011 |
| training accuracy of the final model | W2-W0 | bcic2a | 9 | -0.27 | [-0.40, -0.14] | 0.0015 |
| training accuracy of the final model | W2-W0 | bcic2b | 9 | -0.18 | [-0.40, +0.05] | 0.1147 |
| training accuracy of the final model | W1-W0 | 18 participants, both datasets | 18 | -3.62 | [-4.42, -2.81] | 0.0000 |
| training accuracy of the final model | W1-W0 | bcic2a | 9 | -3.52 | [-4.93, -2.11] | 0.0004 |
| training accuracy of the final model | W1-W0 | bcic2b | 9 | -3.72 | [-4.85, -2.59] | 0.0001 |

## Fidelity check (seed 0)

Benchmark's own procedure against the S0 loop: 18 of 18 participants identical; mean difference +0.000, largest absolute difference 0.000 points.
