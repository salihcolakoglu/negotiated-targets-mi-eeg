Supplementary Data 3, version 1.13 (file Supplementary-Data-3-v1.13.zip): additional sensitivity analyses
(Supplementary Section S19)

Study: "Walsh-Coded and Negotiated Targets for Motor Imagery EEG Decoding: A Controlled Evaluation of Accuracy and Confidence"
(S. Colakoglu, M. Onat, N. Korhan).

Contents
  new_computations/            Written protocols (PROTOCOL-A.md, PROTOCOL-B.md, PROTOCOL-C.md) and the programs they name,
                               exactly as fixed on 15 November 2026, 17:15 (UTC+3), before any of the three analyses was run;
                               SHA256SUMS.txt lists every file (SHA-256 of that list: 05c36a368f8009d3d0d3378212a20cd792ab2bc5c40260790b5d104e6dc65847).
  A_two_ended_csp/             CSP-LDA reference of Experiments 1 and 2 with two-ended filter selection: per-participant results,
                               the release's own classical step, the analysis tables, the run summary (SHA-256 of the 64 raw files).
  B_repetition_experiment3/    Repetition of Experiment 3 from public code and data on different hardware: run protocol, environment,
                               operator note, download records, metadata of the prepared inputs (no signals), training and test records,
                               test predictions, classical references, the released analysis (final_analysis/) and the comparison with
                               the published records (comparison/).
  C_published_configuration/   Target rules in the public EEGNet configuration of Wimpff et al. (2024): 360 fit records and test outputs,
                               completion list, fidelity check (benchmark's own training code, seed 0), analysis tables.
  server_run/                  Operational driver and logs of the rented server (Linux, AMD Ryzen 9 7950X, NVIDIA GeForce RTX 4090).
  DEVIATIONS.md                Deviations from the protocols.
  MANIFEST-SHA256.txt          SHA-256 of every member of this archive.

Wording of the files that were fixed before the analyses were run. The folder new_computations/ is kept exactly as it was
fixed on 15 November 2026, 17:15 (UTC+3); an edit would change the SHA-256 list named above. Where its files speak of a
"revision" of the manuscript or of an "internal review", they mean the authors' own revision before submission, after a
reading by a co-author. Where they name Supplementary-Data-1-v1.9.zip, they mean the first data file of this submission,
which is now named Supplementary-Data-1-v1.13.zip (only its README and manifest differ).

What changed in versions 1.10 to 1.13 (16 to 18 November 2026): only this README and MANIFEST-SHA256.txt. Every other
file is byte-identical to Supplementary-Data-3-v1.9.zip (SHA-256 23f2f1789981153aa3548429619723bc494e7805fd8892c94b214f72d4baa382),
to Supplementary-Data-3-v1.10.zip (SHA-256 2912ecb6be26d3a093be796e88f2e886c16d84d3e23c0ab972aefd3408bffb1a)
to Supplementary-Data-3-v1.11.zip (SHA-256 0fa6852bbe4b7c20ee7801571b8f24a5a1dc05ade36e1354b75c09760f494540)
and to Supplementary-Data-3-v1.12.zip (SHA-256 300a99ed40e030fbbd625ab08beebbdc77557513d27362430226399d9aed8800).
From version 1.13 the three data files are published in folder supplementary_data/ of software release v2.3.0
of the repository https://github.com/salihcolakoglu/negotiated-targets-mi-eeg.
Companion files of the same submission: Supplementary-Data-1-v1.13.zip (Experiments 1 to 3) and
Supplementary-Data-2-v1.13.zip (S1/W5 control, record-based summaries, classical pipelines, equivalence analysis).

Not included: raw EEG, prepared signal arrays, network weights or optimizer states. The raw data are available from their
providers (BNCI Horizon 2020: 001-2014, 002-2014, 004-2014; Lee2019/OpenBMI: GigaDB doi 10.5524/100542).
Licenses: programs MIT; result records CC BY 4.0. The benchmark code of Wimpff et al. (MIT) is not redistributed.
The analyses were prepared and operated with the assistance of an AI system (Claude, Anthropic) for the authors.
